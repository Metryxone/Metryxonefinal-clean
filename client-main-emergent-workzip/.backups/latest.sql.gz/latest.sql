--
-- PostgreSQL database cluster dump
--

\restrict UcuHbWh45cOEtXQciuWuMrWZzTQODrhthtYQ1mWXr3rjbbZrCtsxUMDOVgC4abn

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:XfxiUJCuuRX95uV4XOHOmg==$egp6xjwbd18uuXoTva76JXMnN3z3btv+y/eaoGodtRE=:o2SgI8b4Hpek1C+qajwP44uFDFRoDutQLGgSFy3oFSQ=';

--
-- User Configurations
--








\unrestrict UcuHbWh45cOEtXQciuWuMrWZzTQODrhthtYQ1mWXr3rjbbZrCtsxUMDOVgC4abn

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict wfX9jn5nmilaedgcUxoBrKnSdyvxCN4VfVIC9s7SukVd8ryFdaGgqKGjbRphiPB

-- Dumped from database version 15.16 (Debian 15.16-0+deb12u1)
-- Dumped by pg_dump version 15.16 (Debian 15.16-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict wfX9jn5nmilaedgcUxoBrKnSdyvxCN4VfVIC9s7SukVd8ryFdaGgqKGjbRphiPB

--
-- Database "metryxone" dump
--

--
-- PostgreSQL database dump
--

\restrict V3zAWHac42baQ699YhIPBcygTI71XKwm00kbVJ7IYUFLFrdyZ7caujZyLa4Bz87

-- Dumped from database version 15.16 (Debian 15.16-0+deb12u1)
-- Dumped by pg_dump version 15.16 (Debian 15.16-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: metryxone; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE metryxone WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE metryxone OWNER TO postgres;

\unrestrict V3zAWHac42baQ699YhIPBcygTI71XKwm00kbVJ7IYUFLFrdyZ7caujZyLa4Bz87
\connect metryxone
\restrict V3zAWHac42baQ699YhIPBcygTI71XKwm00kbVJ7IYUFLFrdyZ7caujZyLa4Bz87

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: difficulty_level; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.difficulty_level AS ENUM (
    'EASY',
    'MEDIUM',
    'HARD'
);


ALTER TYPE public.difficulty_level OWNER TO postgres;

--
-- Name: question_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.question_status AS ENUM (
    'DRAFT',
    'APPROVED',
    'PUBLISHED',
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public.question_status OWNER TO postgres;

--
-- Name: question_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.question_type AS ENUM (
    'MCQ',
    'SUBJECTIVE',
    'LIKERT'
);


ALTER TYPE public.question_type OWNER TO postgres;

--
-- Name: test_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.test_status AS ENUM (
    'DRAFT',
    'ACTIVE',
    'COMPLETED'
);


ALTER TYPE public.test_status OWNER TO postgres;

--
-- Name: upload_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.upload_status AS ENUM (
    'RECEIVED',
    'VALIDATED',
    'COMMITTED',
    'FAILED'
);


ALTER TYPE public.upload_status OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'SUPERADMIN',
    'INSTITUTE',
    'PARENT',
    'STUDENT'
);


ALTER TYPE public.user_role OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attempts (
    test_id uuid NOT NULL,
    student_id uuid NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    submitted_at timestamp with time zone,
    score numeric,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    extra jsonb NOT NULL
);


ALTER TABLE public.attempts OWNER TO postgres;

--
-- Name: bulk_upload_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bulk_upload_jobs (
    upload_type character varying(50) NOT NULL,
    filename character varying(255) NOT NULL,
    status public.upload_status NOT NULL,
    error_count integer NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    extra jsonb NOT NULL
);


ALTER TABLE public.bulk_upload_jobs OWNER TO postgres;

--
-- Name: bulk_upload_rows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bulk_upload_rows (
    job_id uuid NOT NULL,
    row_num integer NOT NULL,
    status character varying(20) NOT NULL,
    error text,
    raw jsonb NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bulk_upload_rows OWNER TO postgres;

--
-- Name: question_bank; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.question_bank (
    module_code character varying(50) NOT NULL,
    question_code character varying(100) NOT NULL,
    question_type public.question_type NOT NULL,
    question_text text NOT NULL,
    difficulty public.difficulty_level,
    bloom_level character varying(50),
    status public.question_status NOT NULL,
    is_active boolean NOT NULL,
    created_by uuid,
    version integer NOT NULL,
    board character varying(100),
    grade character varying(50),
    subject character varying(120),
    chapter character varying(120),
    topic character varying(120),
    language character varying(30),
    tags text,
    source character varying(120),
    review_state character varying(40),
    llm_improvable boolean,
    llm_notes text,
    domain_code character varying(50),
    domain_name character varying(255),
    subdomain_code character varying(50),
    subdomain_name character varying(255),
    age_band_code character varying(20),
    keying character varying(20),
    anchor character varying(10),
    passage_text text,
    explanation text,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    extra jsonb NOT NULL
);


ALTER TABLE public.question_bank OWNER TO postgres;

--
-- Name: question_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.question_options (
    question_id uuid NOT NULL,
    option_code character varying(10) NOT NULL,
    option_text text NOT NULL,
    option_score numeric,
    is_correct boolean NOT NULL,
    sort_order integer NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    extra jsonb NOT NULL
);


ALTER TABLE public.question_options OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    user_id uuid NOT NULL,
    full_name character varying(255) NOT NULL,
    grade character varying(50),
    board character varying(100),
    is_active boolean NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: task_variants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_variants (
    variant_id character varying(100) NOT NULL,
    instruction_text text NOT NULL,
    primary_target character varying(255),
    distractors character varying(255),
    age_band character varying(20),
    selectivity character varying(50),
    target character varying(255),
    module_code character varying(50) NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    extra jsonb NOT NULL
);


ALTER TABLE public.task_variants OWNER TO postgres;

--
-- Name: test_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_questions (
    test_id uuid NOT NULL,
    question_id uuid NOT NULL,
    sequence integer NOT NULL
);


ALTER TABLE public.test_questions OWNER TO postgres;

--
-- Name: tests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tests (
    test_name character varying(255) NOT NULL,
    module_code character varying(50) NOT NULL,
    duration_minutes integer NOT NULL,
    status public.test_status NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    extra jsonb NOT NULL
);


ALTER TABLE public.tests OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    email character varying(320),
    password_hash text NOT NULL,
    role public.user_role NOT NULL,
    is_active boolean NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attempts (test_id, student_id, started_at, submitted_at, score, id, created_at, updated_at, extra) FROM stdin;
\.


--
-- Data for Name: bulk_upload_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bulk_upload_jobs (upload_type, filename, status, error_count, id, created_at, updated_at, extra) FROM stdin;
\.


--
-- Data for Name: bulk_upload_rows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bulk_upload_rows (job_id, row_num, status, error, raw, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: question_bank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.question_bank (module_code, question_code, question_type, question_text, difficulty, bloom_level, status, is_active, created_by, version, board, grade, subject, chapter, topic, language, tags, source, review_state, llm_improvable, llm_notes, domain_code, domain_name, subdomain_code, subdomain_name, age_band_code, keying, anchor, passage_text, explanation, id, created_at, updated_at, extra) FROM stdin;
\.


--
-- Data for Name: question_options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.question_options (question_id, option_code, option_text, option_score, is_correct, sort_order, id, created_at, updated_at, extra) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (user_id, full_name, grade, board, is_active, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_variants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_variants (variant_id, instruction_text, primary_target, distractors, age_band, selectivity, target, module_code, id, created_at, updated_at, extra) FROM stdin;
\.


--
-- Data for Name: test_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_questions (test_id, question_id, sequence) FROM stdin;
\.


--
-- Data for Name: tests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tests (test_name, module_code, duration_minutes, status, id, created_at, updated_at, extra) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (email, password_hash, role, is_active, id, created_at, updated_at) FROM stdin;
\.


--
-- Name: attempts attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attempts
    ADD CONSTRAINT attempts_pkey PRIMARY KEY (id);


--
-- Name: bulk_upload_jobs bulk_upload_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_upload_jobs
    ADD CONSTRAINT bulk_upload_jobs_pkey PRIMARY KEY (id);


--
-- Name: bulk_upload_rows bulk_upload_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_upload_rows
    ADD CONSTRAINT bulk_upload_rows_pkey PRIMARY KEY (id);


--
-- Name: question_bank question_bank_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_bank
    ADD CONSTRAINT question_bank_pkey PRIMARY KEY (id);


--
-- Name: question_options question_options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_options
    ADD CONSTRAINT question_options_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: task_variants task_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_variants
    ADD CONSTRAINT task_variants_pkey PRIMARY KEY (id);


--
-- Name: test_questions test_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_questions
    ADD CONSTRAINT test_questions_pkey PRIMARY KEY (test_id, question_id);


--
-- Name: tests tests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (id);


--
-- Name: bulk_upload_rows uq_bulk_upload_rows_job_row; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_upload_rows
    ADD CONSTRAINT uq_bulk_upload_rows_job_row UNIQUE (job_id, row_num);


--
-- Name: question_options uq_question_options_questionid_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_options
    ADD CONSTRAINT uq_question_options_questionid_code UNIQUE (question_id, option_code);


--
-- Name: test_questions uq_test_questions_testid_sequence; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_questions
    ADD CONSTRAINT uq_test_questions_testid_sequence UNIQUE (test_id, sequence);


--
-- Name: users uq_users_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_email UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_attempts_student_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attempts_student_id ON public.attempts USING btree (student_id);


--
-- Name: ix_attempts_test_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attempts_test_id ON public.attempts USING btree (test_id);


--
-- Name: ix_bulk_upload_jobs_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_bulk_upload_jobs_type ON public.bulk_upload_jobs USING btree (upload_type);


--
-- Name: ix_bulk_upload_rows_job_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_bulk_upload_rows_job_id ON public.bulk_upload_rows USING btree (job_id);


--
-- Name: ix_qb_domain_subdomain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_qb_domain_subdomain ON public.question_bank USING btree (domain_code, subdomain_code);


--
-- Name: ix_qb_grade_subject; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_qb_grade_subject ON public.question_bank USING btree (grade, subject);


--
-- Name: ix_qb_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_qb_status ON public.question_bank USING btree (status);


--
-- Name: ix_question_bank_module_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_question_bank_module_code ON public.question_bank USING btree (module_code);


--
-- Name: ix_question_bank_question_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_question_bank_question_code ON public.question_bank USING btree (question_code);


--
-- Name: ix_question_options_question_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_question_options_question_id ON public.question_options USING btree (question_id);


--
-- Name: ix_students_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_students_user_id ON public.students USING btree (user_id);


--
-- Name: ix_task_variants_module_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_variants_module_code ON public.task_variants USING btree (module_code);


--
-- Name: ix_task_variants_variant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_task_variants_variant_id ON public.task_variants USING btree (variant_id);


--
-- Name: ix_test_questions_test_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_test_questions_test_id ON public.test_questions USING btree (test_id);


--
-- Name: ix_tests_module_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tests_module_code ON public.tests USING btree (module_code);


--
-- Name: ix_tests_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tests_status ON public.tests USING btree (status);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: attempts attempts_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attempts
    ADD CONSTRAINT attempts_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: attempts attempts_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attempts
    ADD CONSTRAINT attempts_test_id_fkey FOREIGN KEY (test_id) REFERENCES public.tests(id) ON DELETE CASCADE;


--
-- Name: bulk_upload_rows bulk_upload_rows_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bulk_upload_rows
    ADD CONSTRAINT bulk_upload_rows_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.bulk_upload_jobs(id) ON DELETE CASCADE;


--
-- Name: question_bank question_bank_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_bank
    ADD CONSTRAINT question_bank_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: question_options question_options_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_options
    ADD CONSTRAINT question_options_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.question_bank(id) ON DELETE CASCADE;


--
-- Name: students students_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: test_questions test_questions_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_questions
    ADD CONSTRAINT test_questions_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.question_bank(id) ON DELETE CASCADE;


--
-- Name: test_questions test_questions_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_questions
    ADD CONSTRAINT test_questions_test_id_fkey FOREIGN KEY (test_id) REFERENCES public.tests(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict V3zAWHac42baQ699YhIPBcygTI71XKwm00kbVJ7IYUFLFrdyZ7caujZyLa4Bz87

--
-- Database "metryxone_node" dump
--

--
-- PostgreSQL database dump
--

\restrict 0DFc4WoRxM7Bg2GErawB9MSBaTnMmSzRORbPEPTUjqeqeGWw6391ePcgbh2MJzh

-- Dumped from database version 15.16 (Debian 15.16-0+deb12u1)
-- Dumped by pg_dump version 15.16 (Debian 15.16-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: metryxone_node; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE metryxone_node WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE metryxone_node OWNER TO postgres;

\unrestrict 0DFc4WoRxM7Bg2GErawB9MSBaTnMmSzRORbPEPTUjqeqeGWw6391ePcgbh2MJzh
\connect metryxone_node
\restrict 0DFc4WoRxM7Bg2GErawB9MSBaTnMmSzRORbPEPTUjqeqeGWw6391ePcgbh2MJzh

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: academic_chapters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.academic_chapters (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    subject_id character varying NOT NULL,
    chapter_number integer NOT NULL,
    chapter_name text NOT NULL,
    description text,
    estimated_hours real,
    display_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.academic_chapters OWNER TO postgres;

--
-- Name: academic_classes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.academic_classes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    board_id character varying NOT NULL,
    class_number integer NOT NULL,
    class_name text NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.academic_classes OWNER TO postgres;

--
-- Name: academic_subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.academic_subjects (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    board_id character varying NOT NULL,
    class_id character varying NOT NULL,
    subject_code text NOT NULL,
    subject_name text NOT NULL,
    subject_type text DEFAULT 'Core'::text NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.academic_subjects OWNER TO postgres;

--
-- Name: academic_topics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.academic_topics (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    chapter_id character varying NOT NULL,
    topic_number integer NOT NULL,
    topic_name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.academic_topics OWNER TO postgres;

--
-- Name: access_control_policies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_control_policies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    policy_name text NOT NULL,
    policy_type text NOT NULL,
    resource text NOT NULL,
    actions text[] NOT NULL,
    conditions text,
    allowed_roles text[],
    denied_roles text[],
    priority integer DEFAULT 100 NOT NULL,
    effect text DEFAULT 'allow'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.access_control_policies OWNER TO postgres;

--
-- Name: acknowledgements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acknowledgements (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    notification_id character varying,
    acknowledgement_type text NOT NULL,
    reference_id text,
    reference_type text,
    notes text,
    acknowledged_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.acknowledgements OWNER TO postgres;

--
-- Name: admin_audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id character varying,
    action_type text NOT NULL,
    target_type text NOT NULL,
    target_id character varying NOT NULL,
    previous_state text,
    new_state text,
    ip_address text,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_audit_logs OWNER TO postgres;

--
-- Name: assessment_blueprints; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assessment_blueprints (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    blueprint_code text NOT NULL,
    blueprint_name text NOT NULL,
    board_id character varying,
    class_id character varying,
    subject_id character varying,
    assessment_type text DEFAULT 'Practice'::text NOT NULL,
    total_marks integer DEFAULT 100 NOT NULL,
    duration_minutes integer DEFAULT 60 NOT NULL,
    instructions text,
    passing_marks integer DEFAULT 35,
    is_active boolean DEFAULT true NOT NULL,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.assessment_blueprints OWNER TO postgres;

--
-- Name: assessment_template_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assessment_template_questions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    template_id character varying NOT NULL,
    question_text text NOT NULL,
    option_a text NOT NULL,
    option_b text NOT NULL,
    option_c text,
    option_d text,
    correct_option text NOT NULL,
    marks integer DEFAULT 1 NOT NULL,
    order_index integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.assessment_template_questions OWNER TO postgres;

--
-- Name: assessment_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assessment_templates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    subject text NOT NULL,
    grade text NOT NULL,
    description text,
    duration integer DEFAULT 60 NOT NULL,
    total_marks integer DEFAULT 100 NOT NULL,
    difficulty text DEFAULT 'Medium'::text NOT NULL,
    category text DEFAULT 'Academic'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.assessment_templates OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    entity_type text NOT NULL,
    entity_id character varying,
    action text NOT NULL,
    details text,
    ip_address text,
    user_agent text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: batches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.batches (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    institute_id character varying NOT NULL,
    batch_code text NOT NULL,
    batch_name text NOT NULL,
    academic_year text NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.batches OWNER TO postgres;

--
-- Name: behavioural_insights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.behavioural_insights (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    student_id character varying NOT NULL,
    category text NOT NULL,
    metric text NOT NULL,
    value integer,
    description text,
    recorded_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.behavioural_insights OWNER TO postgres;

--
-- Name: blueprint_sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blueprint_sections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    blueprint_id character varying NOT NULL,
    section_name text NOT NULL,
    section_order integer DEFAULT 1 NOT NULL,
    question_type text DEFAULT 'MCQ'::text NOT NULL,
    difficulty_mix text DEFAULT '40:40:20'::text,
    questions_count integer DEFAULT 10 NOT NULL,
    marks_per_question real DEFAULT 1 NOT NULL,
    negative_marks real DEFAULT 0,
    chapter_scope text DEFAULT 'Full Syllabus'::text,
    chapter_ids text[],
    optional_questions integer DEFAULT 0,
    instructions text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.blueprint_sections OWNER TO postgres;

--
-- Name: child_academic_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.child_academic_profiles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    child_id character varying NOT NULL,
    board_id character varying,
    class_id character varying,
    academic_year text NOT NULL,
    section text,
    roll_number text,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.child_academic_profiles OWNER TO postgres;

--
-- Name: child_exam_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.child_exam_questions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    child_exam_id character varying NOT NULL,
    question_text text NOT NULL,
    option_a text NOT NULL,
    option_b text NOT NULL,
    option_c text,
    option_d text,
    correct_option text NOT NULL,
    marks integer DEFAULT 1 NOT NULL,
    order_index integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.child_exam_questions OWNER TO postgres;

--
-- Name: child_exams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.child_exams (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    child_id character varying NOT NULL,
    title text NOT NULL,
    subject text NOT NULL,
    grade text,
    exam_type text DEFAULT 'academic'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    score integer,
    total_marks integer DEFAULT 100 NOT NULL,
    due_date timestamp without time zone,
    completed_at timestamp without time zone,
    improved_topics text[],
    focus_areas text[],
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.child_exams OWNER TO postgres;

--
-- Name: child_subject_enrollments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.child_subject_enrollments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    profile_id character varying NOT NULL,
    subject_id character varying NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.child_subject_enrollments OWNER TO postgres;

--
-- Name: children; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.children (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    parent_id character varying NOT NULL,
    student_user_id character varying,
    name text NOT NULL,
    age integer NOT NULL,
    grade text NOT NULL,
    class_section text,
    school_name text,
    roll_number text,
    gender text,
    date_of_birth date,
    blood_group text,
    primary_language text,
    education_board text,
    city text,
    state text,
    special_needs text,
    study_hours text,
    favorite_subjects text[],
    weak_subjects text[],
    learning_style text,
    career_interest text,
    relationship text,
    school_type text,
    medium_of_instruction text,
    extracurricular text,
    emergency_contact text,
    medical_conditions text,
    lbi_consent boolean DEFAULT false NOT NULL,
    data_collection_consent boolean DEFAULT false NOT NULL,
    dpdp_consent boolean DEFAULT false NOT NULL,
    development_acknowledgment boolean DEFAULT false NOT NULL,
    progress_sharing_consent boolean DEFAULT false NOT NULL,
    consent_date timestamp without time zone,
    consent_revoked_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.children OWNER TO postgres;

--
-- Name: cohorts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cohorts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    role_code text,
    role_name text,
    experience_min integer DEFAULT 0 NOT NULL,
    experience_max integer DEFAULT 99 NOT NULL,
    location text,
    industry text,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cohorts OWNER TO postgres;

--
-- Name: competencies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competencies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    domain_id character varying NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    competency_type text DEFAULT 'behavioral'::text NOT NULL,
    proficiency_levels jsonb DEFAULT '{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}'::jsonb NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    tag text DEFAULT 'behavioral'::text NOT NULL
);


ALTER TABLE public.competencies OWNER TO postgres;

--
-- Name: competency_assessment_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competency_assessment_items (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    competency_id character varying NOT NULL,
    code text NOT NULL,
    item_type text DEFAULT 'mcq'::text NOT NULL,
    difficulty integer DEFAULT 3 NOT NULL,
    level integer DEFAULT 3 NOT NULL,
    question text NOT NULL,
    expected_time integer DEFAULT 60 NOT NULL,
    scoring_type text DEFAULT 'auto'::text NOT NULL,
    industry text,
    role_tag text,
    language_code text DEFAULT 'en'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.competency_assessment_items OWNER TO postgres;

--
-- Name: competency_assessment_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competency_assessment_options (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    item_id character varying NOT NULL,
    text text NOT NULL,
    score_value real DEFAULT 0 NOT NULL,
    display_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.competency_assessment_options OWNER TO postgres;

--
-- Name: competency_cluster_map; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competency_cluster_map (
    cluster_id character varying NOT NULL,
    competency_id character varying NOT NULL
);


ALTER TABLE public.competency_cluster_map OWNER TO postgres;

--
-- Name: competency_clusters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competency_clusters (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.competency_clusters OWNER TO postgres;

--
-- Name: competency_domains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competency_domains (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    color text,
    weight real DEFAULT 1 NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.competency_domains OWNER TO postgres;

--
-- Name: competency_library; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competency_library (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    competency_number integer NOT NULL,
    competency_name text NOT NULL,
    domain text,
    sub_domain text,
    description text,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.competency_library OWNER TO postgres;

--
-- Name: competency_user_responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competency_user_responses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    item_id character varying NOT NULL,
    option_id character varying,
    score_obtained real,
    time_taken integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.competency_user_responses OWNER TO postgres;

--
-- Name: competency_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competency_versions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    version integer NOT NULL,
    label text,
    notes text,
    changed_by character varying,
    change_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    snapshot jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.competency_versions OWNER TO postgres;

--
-- Name: compliance_audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compliance_audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    log_id text NOT NULL,
    log_type text NOT NULL,
    category text NOT NULL,
    action text NOT NULL,
    resource_type text NOT NULL,
    resource_id character varying,
    resource_name text,
    actor_id character varying,
    actor_type text,
    actor_name text,
    actor_role text,
    ip_address text,
    user_agent text,
    session_id character varying,
    request_id character varying,
    previous_value text,
    new_value text,
    change_reason text,
    status text NOT NULL,
    error_code text,
    error_message text,
    compliance_frameworks text[],
    data_classification text,
    retention_period text DEFAULT '7_years'::text,
    log_hash text,
    previous_log_hash text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_audit_logs OWNER TO postgres;

--
-- Name: compliance_violations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compliance_violations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mentor_id character varying NOT NULL,
    violation_type text NOT NULL,
    severity text NOT NULL,
    description text NOT NULL,
    evidence_url text,
    reported_by character varying,
    status text DEFAULT 'reported'::text NOT NULL,
    resolution text,
    resolved_by character varying,
    resolved_at timestamp without time zone,
    action_taken text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_violations OWNER TO postgres;

--
-- Name: concern_areas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.concern_areas (
    id integer NOT NULL,
    category text NOT NULL,
    concern_area text NOT NULL,
    parent_worry text NOT NULL,
    impact_on_child text NOT NULL,
    assessment_type text,
    search_keywords text,
    services jsonb DEFAULT '[]'::jsonb NOT NULL,
    roles jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.concern_areas OWNER TO postgres;

--
-- Name: concern_areas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.concern_areas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.concern_areas_id_seq OWNER TO postgres;

--
-- Name: concern_areas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.concern_areas_id_seq OWNED BY public.concern_areas.id;


--
-- Name: consent_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.consent_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    parent_student_link_id character varying NOT NULL,
    parent_id character varying NOT NULL,
    action text NOT NULL,
    reason text,
    ip_address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.consent_logs OWNER TO postgres;

--
-- Name: consent_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.consent_records (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying NOT NULL,
    entity_name text,
    consent_type text NOT NULL,
    consent_version text DEFAULT '1.0'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    granted_at timestamp without time zone,
    revoked_at timestamp without time zone,
    expires_at timestamp without time zone,
    ip_address text,
    user_agent text,
    consent_text text,
    data_categories text[],
    processing_purposes text[],
    lawful_basis text,
    retention_period text,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.consent_records OWNER TO postgres;

--
-- Name: consent_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.consent_types (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    consent_code text NOT NULL,
    consent_name text NOT NULL,
    description text,
    consent_text_template text NOT NULL,
    version text DEFAULT '1.0'::text NOT NULL,
    is_mandatory boolean DEFAULT true NOT NULL,
    requires_witness boolean DEFAULT false NOT NULL,
    requires_guardian boolean DEFAULT false NOT NULL,
    lawful_basis text,
    data_categories text[],
    processing_purposes text[],
    retention_period text,
    display_order integer DEFAULT 0,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.consent_types OWNER TO postgres;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    title text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.conversations_id_seq OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: data_retention_policies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_retention_policies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    policy_name text NOT NULL,
    data_category text NOT NULL,
    retention_period_days integer NOT NULL,
    archival_period_days integer,
    deletion_method text DEFAULT 'secure_delete'::text NOT NULL,
    compliance_framework text[],
    legal_basis text,
    exceptions text,
    last_executed timestamp without time zone,
    next_scheduled timestamp without time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.data_retention_policies OWNER TO postgres;

--
-- Name: document_access_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document_access_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    document_id character varying NOT NULL,
    user_id character varying NOT NULL,
    access_type text NOT NULL,
    ip_address text,
    user_agent text,
    device_type text,
    location text,
    access_status text DEFAULT 'success'::text NOT NULL,
    failure_reason text,
    session_id character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.document_access_logs OWNER TO postgres;

--
-- Name: document_folders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document_folders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying NOT NULL,
    entity_name text,
    folder_path text NOT NULL,
    folder_name text NOT NULL,
    parent_folder_id character varying,
    access_level text DEFAULT 'private'::text NOT NULL,
    retention_policy text DEFAULT '7_years'::text,
    encryption_status text DEFAULT 'encrypted'::text NOT NULL,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.document_folders OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    folder_id character varying,
    entity_type text NOT NULL,
    entity_id character varying NOT NULL,
    document_type text NOT NULL,
    document_category text NOT NULL,
    document_name text NOT NULL,
    file_name text NOT NULL,
    file_size integer,
    mime_type text,
    storage_path text NOT NULL,
    checksum text,
    version integer DEFAULT 1 NOT NULL,
    is_latest boolean DEFAULT true NOT NULL,
    previous_version_id character varying,
    status text DEFAULT 'pending'::text NOT NULL,
    maker_verified_by character varying,
    maker_verified_at timestamp without time zone,
    maker_notes text,
    checker_approved_by character varying,
    checker_approved_at timestamp without time zone,
    checker_notes text,
    rejected_by character varying,
    rejected_at timestamp without time zone,
    rejection_reason text,
    expiry_date date,
    is_expired boolean DEFAULT false NOT NULL,
    sensitivity_level text DEFAULT 'confidential'::text NOT NULL,
    encryption_algorithm text DEFAULT 'AES-256'::text,
    access_count integer DEFAULT 0 NOT NULL,
    last_accessed_at timestamp without time zone,
    last_accessed_by character varying,
    uploaded_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: education_boards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.education_boards (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    board_code text NOT NULL,
    board_name text NOT NULL,
    description text,
    country text DEFAULT 'India'::text NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.education_boards OWNER TO postgres;

--
-- Name: email_consents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_consents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    consent_type text NOT NULL,
    is_consented boolean DEFAULT true NOT NULL,
    consented_at timestamp without time zone,
    revoked_at timestamp without time zone,
    ip_address text,
    user_agent text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_consents OWNER TO postgres;

--
-- Name: enrollment_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.enrollment_requests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    institute_id character varying NOT NULL,
    student_id character varying NOT NULL,
    batch_id character varying NOT NULL,
    status text DEFAULT 'Submitted'::text NOT NULL,
    requested_on timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.enrollment_requests OWNER TO postgres;

--
-- Name: entity_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entity_codes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying NOT NULL,
    code text NOT NULL,
    code_type text DEFAULT 'standard'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    generated_by character varying,
    valid_from timestamp without time zone DEFAULT now() NOT NULL,
    valid_until timestamp without time zone,
    revoked_at timestamp without time zone,
    revoked_reason text,
    usage_count integer DEFAULT 0 NOT NULL,
    max_usage integer,
    metadata text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.entity_codes OWNER TO postgres;

--
-- Name: exam_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_attempts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    exam_id character varying NOT NULL,
    student_id character varying NOT NULL,
    status text DEFAULT 'In Progress'::text NOT NULL,
    score_obtained real,
    total_marks real,
    started_at timestamp without time zone DEFAULT now(),
    submitted_at timestamp without time zone
);


ALTER TABLE public.exam_attempts OWNER TO postgres;

--
-- Name: exam_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_questions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    exam_id character varying NOT NULL,
    question_text text NOT NULL,
    option_a text NOT NULL,
    option_b text NOT NULL,
    option_c text,
    option_d text,
    correct_option text NOT NULL,
    marks integer DEFAULT 1 NOT NULL,
    order_index integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exam_questions OWNER TO postgres;

--
-- Name: exam_responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_responses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    attempt_id character varying NOT NULL,
    question_id character varying NOT NULL,
    selected_option text,
    is_correct boolean,
    marks_obtained real DEFAULT 0,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exam_responses OWNER TO postgres;

--
-- Name: exams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exams (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    institute_id character varying NOT NULL,
    exam_code text NOT NULL,
    exam_name text NOT NULL,
    batch_id character varying NOT NULL,
    status text DEFAULT 'Draft'::text NOT NULL,
    start_at timestamp without time zone NOT NULL,
    end_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exams OWNER TO postgres;

--
-- Name: express_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.express_sessions (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.express_sessions OWNER TO postgres;

--
-- Name: forum_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forum_attachments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    post_id character varying,
    reply_id character varying,
    file_name text NOT NULL,
    file_type text NOT NULL,
    file_url text NOT NULL,
    file_size integer,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.forum_attachments OWNER TO postgres;

--
-- Name: forum_moderation_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forum_moderation_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    post_id character varying,
    reply_id character varying,
    reported_by character varying,
    moderated_by character varying,
    report_reason text,
    moderation_action text,
    moderation_notes text,
    status text DEFAULT 'Pending'::text NOT NULL,
    reported_at timestamp without time zone DEFAULT now() NOT NULL,
    moderated_at timestamp without time zone
);


ALTER TABLE public.forum_moderation_logs OWNER TO postgres;

--
-- Name: forum_posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forum_posts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    author_id character varying NOT NULL,
    author_type text DEFAULT 'student'::text NOT NULL,
    child_id character varying,
    test_id character varying,
    question_id character varying,
    title text NOT NULL,
    content text NOT NULL,
    post_type text DEFAULT 'doubt'::text NOT NULL,
    subject_id character varying,
    chapter_id character varying,
    is_anonymous boolean DEFAULT false NOT NULL,
    visibility text DEFAULT 'public'::text NOT NULL,
    target_audience text DEFAULT 'all'::text NOT NULL,
    assigned_mentor_id character varying,
    assigned_teacher_id character varying,
    status text DEFAULT 'Open'::text NOT NULL,
    upvotes integer DEFAULT 0 NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    is_resolved boolean DEFAULT false NOT NULL,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.forum_posts OWNER TO postgres;

--
-- Name: forum_replies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forum_replies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    post_id character varying NOT NULL,
    author_id character varying NOT NULL,
    author_type text DEFAULT 'student'::text NOT NULL,
    parent_reply_id character varying,
    content text NOT NULL,
    is_anonymous boolean DEFAULT false NOT NULL,
    is_accepted_answer boolean DEFAULT false NOT NULL,
    upvotes integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.forum_replies OWNER TO postgres;

--
-- Name: forum_votes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forum_votes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    post_id character varying,
    reply_id character varying,
    vote_type text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.forum_votes OWNER TO postgres;

--
-- Name: hr_audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hr_audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    actor_user_id character varying,
    action_type text NOT NULL,
    target_type text NOT NULL,
    target_id character varying NOT NULL,
    previous_state text,
    new_state text,
    ip_address text,
    user_agent text,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hr_audit_logs OWNER TO postgres;

--
-- Name: hr_consent_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hr_consent_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    mentor_id character varying,
    consent_type text NOT NULL,
    consent_text text NOT NULL,
    consent_given boolean DEFAULT false NOT NULL,
    ip_address text,
    user_agent text,
    consented_at timestamp without time zone,
    revoked_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hr_consent_logs OWNER TO postgres;

--
-- Name: institute_staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.institute_staff (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    institute_id character varying NOT NULL,
    user_id character varying NOT NULL,
    role_id character varying NOT NULL,
    staff_code text,
    full_name text NOT NULL,
    email text,
    phone text,
    department text,
    status text DEFAULT 'Active'::text NOT NULL,
    joined_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.institute_staff OWNER TO postgres;

--
-- Name: institutes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.institutes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id character varying,
    institute_code text NOT NULL,
    legal_name text NOT NULL,
    display_name text NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.institutes OWNER TO postgres;

--
-- Name: institutional_slas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.institutional_slas (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    institute_id character varying NOT NULL,
    tier text DEFAULT 'silver'::text NOT NULL,
    response_time_hours integer DEFAULT 24 NOT NULL,
    completion_target_percent real DEFAULT 90 NOT NULL,
    satisfaction_target_percent real DEFAULT 85 NOT NULL,
    reporting_frequency text DEFAULT 'weekly'::text NOT NULL,
    dedicated_support boolean DEFAULT false NOT NULL,
    priority_escalation boolean DEFAULT false NOT NULL,
    custom_branding boolean DEFAULT false NOT NULL,
    effective_from date NOT NULL,
    effective_until date,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.institutional_slas OWNER TO postgres;

--
-- Name: job_applications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_applications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    job_id character varying NOT NULL,
    applicant_user_id character varying NOT NULL,
    full_name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    resume_url text,
    cover_letter text,
    source_channel text,
    status text DEFAULT 'applied'::text NOT NULL,
    membership_fee real,
    membership_paid_at timestamp without time zone,
    consent_captured boolean DEFAULT false NOT NULL,
    consent_captured_at timestamp without time zone,
    rejection_reason text,
    processed_by character varying,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.job_applications OWNER TO postgres;

--
-- Name: job_approval_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_approval_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    job_id character varying NOT NULL,
    from_status text NOT NULL,
    to_status text NOT NULL,
    action text NOT NULL,
    comments text,
    actor_id character varying,
    actor_role text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.job_approval_logs OWNER TO postgres;

--
-- Name: job_distributions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_distributions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    job_id character varying NOT NULL,
    channel text NOT NULL,
    external_post_id text,
    posted_at timestamp without time zone,
    unpublished_at timestamp without time zone,
    reach_metrics integer DEFAULT 0,
    applications_from_channel integer DEFAULT 0,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.job_distributions OWNER TO postgres;

--
-- Name: job_postings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_postings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    role_category text NOT NULL,
    employment_type text NOT NULL,
    work_mode text NOT NULL,
    eligibility text NOT NULL,
    qualifications text NOT NULL,
    responsibilities text NOT NULL,
    kpis text NOT NULL,
    compensation_model text NOT NULL,
    legal_clauses text,
    status text DEFAULT 'draft'::text NOT NULL,
    hr_review_by character varying,
    hr_review_at timestamp without time zone,
    hr_review_notes text,
    legal_review_by character varying,
    legal_review_at timestamp without time zone,
    legal_review_notes text,
    leadership_approval_by character varying,
    leadership_approval_at timestamp without time zone,
    leadership_approval_notes text,
    published_at timestamp without time zone,
    closed_at timestamp without time zone,
    hiring_quota integer DEFAULT 0,
    hired_count integer DEFAULT 0 NOT NULL,
    created_by character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.job_postings OWNER TO postgres;

--
-- Name: kyc_document_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kyc_document_types (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    document_type text NOT NULL,
    document_name text NOT NULL,
    description text,
    is_mandatory boolean DEFAULT true NOT NULL,
    validity_period integer,
    accepted_formats text[] DEFAULT ARRAY['pdf'::text, 'jpg'::text, 'png'::text],
    max_file_size_mb integer DEFAULT 5,
    sample_doc_url text,
    verification_instructions text,
    display_order integer DEFAULT 0,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.kyc_document_types OWNER TO postgres;

--
-- Name: kyc_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kyc_documents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying NOT NULL,
    entity_name text NOT NULL,
    document_type text NOT NULL,
    document_number text,
    document_url text,
    file_name text,
    file_size integer,
    mime_type text,
    status text DEFAULT 'pending'::text NOT NULL,
    maker_id character varying,
    maker_verified_at timestamp without time zone,
    maker_notes text,
    checker_id character varying,
    checker_verified_at timestamp without time zone,
    checker_notes text,
    rejection_reason text,
    expiry_date timestamp without time zone,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.kyc_documents OWNER TO postgres;

--
-- Name: lbi_age_band_weights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_age_band_weights (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    age_band_code text NOT NULL,
    subdomain_code text NOT NULL,
    weight real DEFAULT 1 NOT NULL,
    weight_type text DEFAULT 'core'::text NOT NULL
);


ALTER TABLE public.lbi_age_band_weights OWNER TO postgres;

--
-- Name: lbi_age_bands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_age_bands (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    band_code text NOT NULL,
    band_name text NOT NULL,
    min_age integer NOT NULL,
    max_age integer NOT NULL,
    grade_range text,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_age_bands OWNER TO postgres;

--
-- Name: lbi_age_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_age_groups (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    group_code text NOT NULL,
    group_name text NOT NULL,
    min_age integer NOT NULL,
    max_age integer NOT NULL,
    difficulty_level integer NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_age_groups OWNER TO postgres;

--
-- Name: lbi_assessment_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_assessment_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    child_id character varying,
    student_id character varying,
    age_band_id character varying,
    assessment_type text DEFAULT 'full'::text NOT NULL,
    target_domains text[],
    status text DEFAULT 'not_started'::text NOT NULL,
    total_questions integer DEFAULT 0 NOT NULL,
    questions_answered integer DEFAULT 0 NOT NULL,
    current_question_index integer DEFAULT 0 NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    time_spent_seconds integer DEFAULT 0,
    device_info text,
    ip_address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_assessment_sessions OWNER TO postgres;

--
-- Name: lbi_assessments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_assessments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    assessment_code text NOT NULL,
    assessment_name text NOT NULL,
    lbi_type_id character varying NOT NULL,
    total_questions integer NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_assessments OWNER TO postgres;

--
-- Name: lbi_cluster_map; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_cluster_map (
    cluster_id character varying NOT NULL,
    subdomain_code text NOT NULL
);


ALTER TABLE public.lbi_cluster_map OWNER TO postgres;

--
-- Name: lbi_clusters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_clusters (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_clusters OWNER TO postgres;

--
-- Name: lbi_domain_scores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_domain_scores (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying NOT NULL,
    domain_id character varying NOT NULL,
    raw_score real NOT NULL,
    percentile_score real,
    stanine_score integer,
    classification text,
    questions_answered integer NOT NULL,
    total_questions integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_domain_scores OWNER TO postgres;

--
-- Name: lbi_domains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_domains (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    domain_code text NOT NULL,
    domain_name text NOT NULL,
    description text,
    color text,
    icon text,
    weightage real DEFAULT 1 NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_domains OWNER TO postgres;

--
-- Name: lbi_learning_mappings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_learning_mappings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    subdomain_code text NOT NULL,
    level integer DEFAULT 3 NOT NULL,
    action_type text,
    title text,
    resource_link text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_learning_mappings OWNER TO postgres;

--
-- Name: lbi_modules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_modules (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    module_code text NOT NULL,
    module_name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_modules OWNER TO postgres;

--
-- Name: lbi_overall_index; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_overall_index (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying NOT NULL,
    child_id character varying,
    student_id character varying,
    lbi_score real NOT NULL,
    percentile_rank real,
    stanine_score integer,
    classification text,
    strength_domains text[],
    development_areas text[],
    recommendations text,
    report_generated_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_overall_index OWNER TO postgres;

--
-- Name: lbi_performance_correlation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_performance_correlation (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    child_id character varying NOT NULL,
    lbi_category text NOT NULL,
    lbi_metric text NOT NULL,
    lbi_score integer,
    subject_id character varying,
    academic_score real,
    correlation_strength real,
    correlation_type text,
    insight text,
    recommended_actions text[],
    analysis_date timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_performance_correlation OWNER TO postgres;

--
-- Name: lbi_question_bank; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_question_bank (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    sub_module_id character varying NOT NULL,
    question_code text NOT NULL,
    set_number integer,
    difficulty_level integer DEFAULT 1 NOT NULL,
    question_type text DEFAULT 'likert'::text NOT NULL,
    question_text text NOT NULL,
    passage_text text,
    keying text DEFAULT 'Positive'::text NOT NULL,
    option_a text,
    option_a_score integer,
    option_b text,
    option_b_score integer,
    option_c text,
    option_c_score integer,
    option_d text,
    option_d_score integer,
    option_e text,
    option_e_score integer,
    correct_answer text,
    explanation text,
    subject text,
    age_group_id character varying,
    language text DEFAULT 'EN'::text,
    anchor boolean DEFAULT false NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_question_bank OWNER TO postgres;

--
-- Name: lbi_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_questions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    question_code text NOT NULL,
    domain_id character varying NOT NULL,
    subdomain_id character varying NOT NULL,
    age_band_id character varying NOT NULL,
    response_scale_id character varying,
    question_text text NOT NULL,
    question_text_hi text,
    question_text_mr text,
    question_text_ta text,
    question_text_te text,
    question_type text DEFAULT 'likert'::text NOT NULL,
    response_options text,
    scoring text,
    reverse_scored boolean DEFAULT false NOT NULL,
    difficulty text DEFAULT 'MEDIUM'::text NOT NULL,
    language text DEFAULT 'EN'::text NOT NULL,
    set_number integer DEFAULT 1,
    display_order integer DEFAULT 0 NOT NULL,
    tags text[],
    version integer DEFAULT 1 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.lbi_questions OWNER TO postgres;

--
-- Name: lbi_questions_legacy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_questions_legacy (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    question_code text NOT NULL,
    lbi_type_id character varying NOT NULL,
    difficulty_level integer NOT NULL,
    question_text text NOT NULL,
    status text DEFAULT 'Draft'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_questions_legacy OWNER TO postgres;

--
-- Name: lbi_response_scales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_response_scales (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    scale_code text NOT NULL,
    scale_name text NOT NULL,
    scale_type text DEFAULT 'likert'::text NOT NULL,
    options text NOT NULL,
    scoring text NOT NULL,
    reverse_scoring_map text,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_response_scales OWNER TO postgres;

--
-- Name: lbi_scoring_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_scoring_rules (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    rule_code text NOT NULL,
    rule_name text NOT NULL,
    domain_id character varying,
    subdomain_id character varying,
    age_band_id character varying,
    calculation_type text DEFAULT 'mean'::text NOT NULL,
    norm_type text DEFAULT 'percentile'::text NOT NULL,
    norm_data text,
    min_score real,
    max_score real,
    cutoffs text,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_scoring_rules OWNER TO postgres;

--
-- Name: lbi_session_responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_session_responses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying NOT NULL,
    question_id character varying NOT NULL,
    response_value integer,
    response_text text,
    raw_score real,
    adjusted_score real,
    response_time_ms integer,
    question_order integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_session_responses OWNER TO postgres;

--
-- Name: lbi_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    assessment_id character varying NOT NULL,
    student_id character varying NOT NULL,
    status text DEFAULT 'Not Started'::text NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.lbi_sessions OWNER TO postgres;

--
-- Name: lbi_sub_modules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_sub_modules (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    module_id character varying NOT NULL,
    sub_module_code text NOT NULL,
    sub_module_name text NOT NULL,
    question_type text DEFAULT 'likert'::text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_sub_modules OWNER TO postgres;

--
-- Name: lbi_subdomain_norms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_subdomain_norms (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    age_band_code text NOT NULL,
    subdomain_code text NOT NULL,
    min_score real DEFAULT 0 NOT NULL,
    median_score real DEFAULT 50 NOT NULL,
    top10_score real DEFAULT 100 NOT NULL
);


ALTER TABLE public.lbi_subdomain_norms OWNER TO postgres;

--
-- Name: lbi_subdomain_scores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_subdomain_scores (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying NOT NULL,
    subdomain_id character varying NOT NULL,
    raw_score real NOT NULL,
    percentile_score real,
    stanine_score integer,
    classification text,
    questions_answered integer NOT NULL,
    total_questions integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_subdomain_scores OWNER TO postgres;

--
-- Name: lbi_subdomains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_subdomains (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    domain_id character varying NOT NULL,
    subdomain_code text NOT NULL,
    subdomain_name text NOT NULL,
    description text,
    weightage real DEFAULT 1 NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_subdomains OWNER TO postgres;

--
-- Name: lbi_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_types (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    type_name text NOT NULL,
    description text,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_types OWNER TO postgres;

--
-- Name: lbi_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lbi_versions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    version integer NOT NULL,
    label text,
    notes text,
    changed_by character varying,
    change_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lbi_versions OWNER TO postgres;

--
-- Name: learning_mappings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.learning_mappings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    competency_id character varying NOT NULL,
    level integer DEFAULT 3 NOT NULL,
    action_type text,
    title text,
    resource_link text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.learning_mappings OWNER TO postgres;

--
-- Name: learning_plan_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.learning_plan_templates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    template_name text NOT NULL,
    description text,
    target_grade text,
    target_board text,
    subject_focus text[],
    duration_weeks integer DEFAULT 12 NOT NULL,
    difficulty text DEFAULT 'moderate'::text NOT NULL,
    weekly_hours integer DEFAULT 10 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    milestones text,
    created_by character varying,
    approved_by character varying,
    approved_at timestamp without time zone,
    published_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.learning_plan_templates OWNER TO postgres;

--
-- Name: lei_registrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lei_registrations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    lei_code text NOT NULL,
    entity_name text NOT NULL,
    entity_type text NOT NULL,
    registration_authority text,
    registration_number text,
    jurisdiction text,
    legal_address text,
    headquarters_address text,
    contact_name text,
    contact_email text,
    contact_phone text,
    status text DEFAULT 'pending'::text NOT NULL,
    valid_from date,
    valid_until date,
    last_verified timestamp without time zone,
    verified_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lei_registrations OWNER TO postgres;

--
-- Name: mentor_kpis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mentor_kpis (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mentor_id character varying NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    student_satisfaction real DEFAULT 0,
    session_completion_rate real DEFAULT 0,
    outcome_improvement real DEFAULT 0,
    compliance_adherence real DEFAULT 0,
    revenue_contribution real DEFAULT 0,
    sessions_completed integer DEFAULT 0,
    students_assigned integer DEFAULT 0,
    alert_level text DEFAULT 'none'::text,
    alert_issued_at timestamp without time zone,
    alert_notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mentor_kpis OWNER TO postgres;

--
-- Name: mentor_payouts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mentor_payouts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mentor_id character varying NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    gross_revenue real DEFAULT 0 NOT NULL,
    commission_rate real DEFAULT 0 NOT NULL,
    commission_amount real DEFAULT 0 NOT NULL,
    deductions real DEFAULT 0,
    net_payout real DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    blocked_reason text,
    approved_by character varying,
    approved_at timestamp without time zone,
    paid_at timestamp without time zone,
    transaction_ref text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mentor_payouts OWNER TO postgres;

--
-- Name: mentor_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mentor_profiles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mentor_id character varying,
    user_id character varying,
    application_id character varying,
    mentor_code text NOT NULL,
    full_name text NOT NULL,
    email text NOT NULL,
    phone text,
    profile_photo text,
    bio text,
    specializations text[],
    qualifications text[],
    languages text[],
    availability text,
    preferred_age_groups text[],
    status text DEFAULT 'pending_activation'::text NOT NULL,
    activated_at timestamp without time zone,
    activated_by character varying,
    suspended_at timestamp without time zone,
    suspended_reason text,
    deactivated_at timestamp without time zone,
    deactivation_reason text,
    rating real,
    total_sessions integer DEFAULT 0 NOT NULL,
    completed_sessions integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mentor_profiles OWNER TO postgres;

--
-- Name: mentor_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mentor_tasks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mentor_id character varying NOT NULL,
    task_type text NOT NULL,
    title text NOT NULL,
    description text,
    target_audience text,
    scheduled_date timestamp without time zone,
    duration integer,
    location text,
    is_online boolean DEFAULT true NOT NULL,
    meeting_link text,
    status text DEFAULT 'assigned'::text NOT NULL,
    completed_at timestamp without time zone,
    feedback text,
    rating integer,
    notes text,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mentor_tasks OWNER TO postgres;

--
-- Name: mentors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mentors (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_id character varying,
    mentor_code text NOT NULL,
    full_name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    specialization text,
    qualifications text,
    status text DEFAULT 'pending_training'::text NOT NULL,
    activated_at timestamp without time zone,
    warning_issued_at timestamp without time zone,
    warning_reason text,
    suspended_at timestamp without time zone,
    suspension_reason text,
    deactivated_at timestamp without time zone,
    deactivation_reason text,
    performance_health_index real DEFAULT 100,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mentors OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: mfa_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mfa_codes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    code character varying(6) NOT NULL,
    email character varying NOT NULL,
    attempt_token character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mfa_codes OWNER TO postgres;

--
-- Name: ngo_registrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ngo_registrations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    ngo_code text NOT NULL,
    legal_name text NOT NULL,
    display_name text NOT NULL,
    registration_number text,
    tax_exemption_number text,
    contact_name text NOT NULL,
    contact_email text NOT NULL,
    contact_phone text,
    address text,
    city text,
    state text,
    pincode text,
    focus_areas text[],
    beneficiary_count integer DEFAULT 0,
    status text DEFAULT 'pending'::text NOT NULL,
    documents_verified boolean DEFAULT false,
    kyc_verified boolean DEFAULT false,
    verified_by character varying,
    verified_at timestamp without time zone,
    onboarded_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ngo_registrations OWNER TO postgres;

--
-- Name: notification_broadcasts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_broadcasts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    sender_id character varying NOT NULL,
    type text DEFAULT 'fyi'::text NOT NULL,
    category text DEFAULT 'system'::text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    target_roles text[],
    target_user_ids text[],
    priority text DEFAULT 'normal'::text NOT NULL,
    action_url text,
    action_label text,
    send_email boolean DEFAULT false NOT NULL,
    total_recipients integer DEFAULT 0 NOT NULL,
    total_delivered integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    scheduled_at timestamp without time zone,
    sent_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_broadcasts OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    recipient_id character varying NOT NULL,
    sender_id character varying,
    type text DEFAULT 'fyi'::text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    action_url text,
    action_label text,
    priority text DEFAULT 'normal'::text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    is_acknowledged boolean DEFAULT false NOT NULL,
    acknowledged_at timestamp without time zone,
    is_email_sent boolean DEFAULT false NOT NULL,
    email_sent_at timestamp without time zone,
    metadata text,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: onboarding_approvals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.onboarding_approvals (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying NOT NULL,
    entity_name text NOT NULL,
    entity_email text,
    entity_phone text,
    status text DEFAULT 'pending'::text NOT NULL,
    submitted_at timestamp without time zone DEFAULT now() NOT NULL,
    reviewed_by character varying,
    reviewed_at timestamp without time zone,
    review_notes text,
    rejection_reason text,
    documents_verified boolean DEFAULT false,
    kyc_verified boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_approvals OWNER TO postgres;

--
-- Name: parent_student_links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parent_student_links (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    parent_id character varying NOT NULL,
    student_id character varying NOT NULL,
    relationship text DEFAULT 'Parent'::text,
    lbi_consent boolean DEFAULT false NOT NULL,
    consent_date timestamp without time zone,
    consent_revoked_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.parent_student_links OWNER TO postgres;

--
-- Name: parent_test_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parent_test_assignments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    test_id character varying NOT NULL,
    child_id character varying NOT NULL,
    assigned_by character varying NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    due_date timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.parent_test_assignments OWNER TO postgres;

--
-- Name: parent_test_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parent_test_results (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    assignment_id character varying NOT NULL,
    student_id character varying NOT NULL,
    answers text NOT NULL,
    marks_obtained integer NOT NULL,
    total_marks integer NOT NULL,
    score integer NOT NULL,
    correct_answers integer NOT NULL,
    incorrect_answers integer NOT NULL,
    question_results text NOT NULL,
    completed_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.parent_test_results OWNER TO postgres;

--
-- Name: parent_tests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parent_tests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    created_by character varying NOT NULL,
    title text NOT NULL,
    subject text NOT NULL,
    description text,
    duration integer DEFAULT 30 NOT NULL,
    total_marks integer NOT NULL,
    questions text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.parent_tests OWNER TO postgres;

--
-- Name: parents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    full_name text NOT NULL,
    mobile text,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.parents OWNER TO postgres;

--
-- Name: payment_reconciliations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_reconciliations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    reconciliation_period text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    total_payments_received real DEFAULT 0 NOT NULL,
    total_payments_done real DEFAULT 0 NOT NULL,
    net_balance real DEFAULT 0 NOT NULL,
    transaction_count integer DEFAULT 0 NOT NULL,
    payout_count integer DEFAULT 0 NOT NULL,
    discrepancy_amount real,
    discrepancy_notes text,
    reconciled_by character varying,
    reconciled_at timestamp without time zone,
    approved_by character varying,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payment_reconciliations OWNER TO postgres;

--
-- Name: performance_analytics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.performance_analytics (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    child_id character varying NOT NULL,
    subject_id character varying,
    chapter_id character varying,
    test_type text,
    total_tests integer DEFAULT 0 NOT NULL,
    completed_tests integer DEFAULT 0 NOT NULL,
    average_score real,
    highest_score real,
    lowest_score real,
    average_time_seconds integer,
    improvement_trend real,
    last_updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.performance_analytics OWNER TO postgres;

--
-- Name: permission_definitions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permission_definitions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    permission_key text NOT NULL,
    display_name text NOT NULL,
    description text,
    category text DEFAULT 'general'::text NOT NULL,
    resource text NOT NULL,
    action text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.permission_definitions OWNER TO postgres;

--
-- Name: platform_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    setting_key text NOT NULL,
    setting_value text NOT NULL,
    setting_type text DEFAULT 'string'::text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    description text,
    updated_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.platform_settings OWNER TO postgres;

--
-- Name: platform_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    transaction_type text NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying NOT NULL,
    entity_name text,
    amount real NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    payment_method text,
    payment_gateway text,
    gateway_transaction_id text,
    gateway_order_id text,
    description text,
    invoice_number text,
    invoice_url text,
    processed_by character varying,
    processed_at timestamp without time zone,
    failure_reason text,
    refunded_amount real,
    refunded_at timestamp without time zone,
    metadata text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.platform_transactions OWNER TO postgres;

--
-- Name: pre_onboarding_checklists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pre_onboarding_checklists (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying NOT NULL,
    entity_name text,
    temporary_onboarding_status text DEFAULT 'pending'::text NOT NULL,
    temporary_approved_by character varying,
    temporary_approved_at timestamp without time zone,
    total_kyc_documents integer DEFAULT 0 NOT NULL,
    uploaded_kyc_documents integer DEFAULT 0 NOT NULL,
    verified_kyc_documents integer DEFAULT 0 NOT NULL,
    kyc_completion_percent real DEFAULT 0 NOT NULL,
    total_consents integer DEFAULT 0 NOT NULL,
    granted_consents integer DEFAULT 0 NOT NULL,
    consent_completion_percent real DEFAULT 0 NOT NULL,
    total_amount real DEFAULT 0 NOT NULL,
    paid_amount real DEFAULT 0 NOT NULL,
    payment_status text DEFAULT 'pending'::text NOT NULL,
    overall_status text DEFAULT 'incomplete'::text NOT NULL,
    spoc_name text,
    spoc_email text,
    spoc_phone text,
    spoc_designation text,
    approved_by character varying,
    approved_at timestamp without time zone,
    rejected_by character varying,
    rejected_at timestamp without time zone,
    rejection_reason text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pre_onboarding_checklists OWNER TO postgres;

--
-- Name: psychometric_age_bands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psychometric_age_bands (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    band_code text NOT NULL,
    band_name text NOT NULL,
    age_range_start integer NOT NULL,
    age_range_end integer,
    context text NOT NULL,
    display_order integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.psychometric_age_bands OWNER TO postgres;

--
-- Name: psychometric_assessment_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psychometric_assessment_results (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    student_id character varying NOT NULL,
    age_band_id character varying NOT NULL,
    domain_id character varying NOT NULL,
    subdomain_id character varying,
    raw_score real,
    percentile_score real,
    scaled_score real,
    interpretation text,
    recommendations text,
    assessed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.psychometric_assessment_results OWNER TO postgres;

--
-- Name: psychometric_domain_age_band_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psychometric_domain_age_band_config (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    domain_id character varying NOT NULL,
    age_band_id character varying NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    questions_count integer DEFAULT 10,
    weightage real DEFAULT 1,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.psychometric_domain_age_band_config OWNER TO postgres;

--
-- Name: psychometric_domains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psychometric_domains (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    domain_code text NOT NULL,
    domain_name text NOT NULL,
    description text,
    category text DEFAULT 'Core'::text,
    display_order integer DEFAULT 1 NOT NULL,
    icon_name text,
    color_code text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.psychometric_domains OWNER TO postgres;

--
-- Name: psychometric_question_bank; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psychometric_question_bank (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    question_code text NOT NULL,
    domain_id character varying NOT NULL,
    subdomain_id character varying,
    age_band_id character varying NOT NULL,
    question_text text NOT NULL,
    question_type text DEFAULT 'Likert'::text NOT NULL,
    response_options text,
    scoring_logic text,
    reverse_scored boolean DEFAULT false NOT NULL,
    difficulty text DEFAULT 'Medium'::text,
    language text DEFAULT 'EN'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.psychometric_question_bank OWNER TO postgres;

--
-- Name: psychometric_subdomains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psychometric_subdomains (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    domain_id character varying NOT NULL,
    subdomain_code text NOT NULL,
    subdomain_name text NOT NULL,
    description text,
    measurement_scale text DEFAULT '1-10'::text,
    display_order integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.psychometric_subdomains OWNER TO postgres;

--
-- Name: psychopsis_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psychopsis_categories (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    title text NOT NULL,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.psychopsis_categories OWNER TO postgres;

--
-- Name: role_competency_weights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_competency_weights (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    role_code text NOT NULL,
    role_name text NOT NULL,
    competency_id character varying NOT NULL,
    weight real DEFAULT 1 NOT NULL,
    weight_type text DEFAULT 'core'::text NOT NULL
);


ALTER TABLE public.role_competency_weights OWNER TO postgres;

--
-- Name: role_definitions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_definitions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    role_name text NOT NULL,
    display_name text NOT NULL,
    description text,
    level integer DEFAULT 0 NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.role_definitions OWNER TO postgres;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    role_id character varying NOT NULL,
    permission_id character varying NOT NULL,
    granted_by character varying,
    granted_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: scoring_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scoring_configs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    value real NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scoring_configs OWNER TO postgres;

--
-- Name: sdi_cluster_map; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_cluster_map (
    cluster_id character varying NOT NULL,
    subdomain_code text NOT NULL
);


ALTER TABLE public.sdi_cluster_map OWNER TO postgres;

--
-- Name: sdi_clusters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_clusters (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sdi_clusters OWNER TO postgres;

--
-- Name: sdi_domains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_domains (
    id integer NOT NULL,
    domain_code text NOT NULL,
    domain_name text NOT NULL,
    description text,
    icon_key text DEFAULT 'Layers'::text NOT NULL,
    color text DEFAULT '#344E86'::text NOT NULL,
    category text,
    weightage real DEFAULT 1 NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sdi_domains OWNER TO postgres;

--
-- Name: sdi_domains_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sdi_domains_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sdi_domains_id_seq OWNER TO postgres;

--
-- Name: sdi_domains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sdi_domains_id_seq OWNED BY public.sdi_domains.id;


--
-- Name: sdi_item_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_item_options (
    id integer NOT NULL,
    item_id integer NOT NULL,
    option_text text NOT NULL,
    score_value real DEFAULT 0 NOT NULL,
    display_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.sdi_item_options OWNER TO postgres;

--
-- Name: sdi_item_options_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sdi_item_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sdi_item_options_id_seq OWNER TO postgres;

--
-- Name: sdi_item_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sdi_item_options_id_seq OWNED BY public.sdi_item_options.id;


--
-- Name: sdi_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_items (
    id integer NOT NULL,
    subdomain_code text NOT NULL,
    item_code text NOT NULL,
    item_type text DEFAULT 'likert5'::text NOT NULL,
    difficulty integer DEFAULT 3 NOT NULL,
    question text NOT NULL,
    expected_time integer DEFAULT 30 NOT NULL,
    scoring_type text DEFAULT 'auto'::text NOT NULL,
    language_code text DEFAULT 'en'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sdi_items OWNER TO postgres;

--
-- Name: sdi_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sdi_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sdi_items_id_seq OWNER TO postgres;

--
-- Name: sdi_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sdi_items_id_seq OWNED BY public.sdi_items.id;


--
-- Name: sdi_learning_mappings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_learning_mappings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    subdomain_code text NOT NULL,
    level integer DEFAULT 3 NOT NULL,
    action_type text,
    title text,
    resource_link text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sdi_learning_mappings OWNER TO postgres;

--
-- Name: sdi_stage_weights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_stage_weights (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    stage_code text NOT NULL,
    subdomain_code text NOT NULL,
    weight real DEFAULT 1 NOT NULL,
    weight_type text DEFAULT 'core'::text NOT NULL
);


ALTER TABLE public.sdi_stage_weights OWNER TO postgres;

--
-- Name: sdi_stages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_stages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    stage_code text NOT NULL,
    stage_name text NOT NULL,
    min_grade integer,
    max_grade integer,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.sdi_stages OWNER TO postgres;

--
-- Name: sdi_subdomain_norms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_subdomain_norms (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    stage_code text NOT NULL,
    subdomain_code text NOT NULL,
    min_score real DEFAULT 0 NOT NULL,
    median_score real DEFAULT 50 NOT NULL,
    top10_score real DEFAULT 100 NOT NULL
);


ALTER TABLE public.sdi_subdomain_norms OWNER TO postgres;

--
-- Name: sdi_subdomains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_subdomains (
    id integer NOT NULL,
    domain_code text NOT NULL,
    subdomain_code text NOT NULL,
    subdomain_name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sdi_subdomains OWNER TO postgres;

--
-- Name: sdi_subdomains_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sdi_subdomains_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sdi_subdomains_id_seq OWNER TO postgres;

--
-- Name: sdi_subdomains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sdi_subdomains_id_seq OWNED BY public.sdi_subdomains.id;


--
-- Name: sdi_user_responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_user_responses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    item_id integer NOT NULL,
    option_id integer,
    score_obtained real,
    time_taken integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sdi_user_responses OWNER TO postgres;

--
-- Name: sdi_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdi_versions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    version integer NOT NULL,
    label text,
    notes text,
    changed_by character varying,
    change_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sdi_versions OWNER TO postgres;

--
-- Name: security_configurations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.security_configurations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    config_key text NOT NULL,
    config_value text NOT NULL,
    config_type text NOT NULL,
    description text,
    is_encrypted boolean DEFAULT false NOT NULL,
    compliance_framework text[],
    last_modified_by character varying,
    last_modified_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.security_configurations OWNER TO postgres;

--
-- Name: security_incidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.security_incidents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    incident_code text NOT NULL,
    incident_type text NOT NULL,
    severity text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    title text NOT NULL,
    description text,
    affected_systems text[],
    affected_users text[],
    detected_at timestamp without time zone DEFAULT now() NOT NULL,
    detected_by character varying,
    contained_at timestamp without time zone,
    resolved_at timestamp without time zone,
    root_cause text,
    remediation_steps text,
    preventive_measures text,
    assigned_to character varying,
    escalated_to character varying,
    notifications_sent boolean DEFAULT false NOT NULL,
    compliance_impact text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.security_incidents OWNER TO postgres;

--
-- Name: staff_batch_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff_batch_assignments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    staff_id character varying NOT NULL,
    batch_id character varying NOT NULL,
    subject_id character varying,
    is_primary boolean DEFAULT false NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.staff_batch_assignments OWNER TO postgres;

--
-- Name: staff_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff_roles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    role_name text NOT NULL,
    role_code text NOT NULL,
    permissions text[],
    description text,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.staff_roles OWNER TO postgres;

--
-- Name: stage_competency_norms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stage_competency_norms (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    stage_code text NOT NULL,
    competency_id character varying NOT NULL,
    min_score real DEFAULT 0 NOT NULL,
    median_score real DEFAULT 50 NOT NULL,
    top10_score real DEFAULT 100 NOT NULL
);


ALTER TABLE public.stage_competency_norms OWNER TO postgres;

--
-- Name: student_assessment_responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_assessment_responses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying NOT NULL,
    question_id character varying NOT NULL,
    selected_option text,
    text_response text,
    score integer,
    response_time_ms integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.student_assessment_responses OWNER TO postgres;

--
-- Name: student_assessment_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_assessment_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    student_id character varying NOT NULL,
    module_id character varying NOT NULL,
    age_group_id character varying,
    status text DEFAULT 'Not Started'::text NOT NULL,
    total_questions integer DEFAULT 0 NOT NULL,
    questions_answered integer DEFAULT 0 NOT NULL,
    raw_score real,
    percentile_score real,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.student_assessment_sessions OWNER TO postgres;

--
-- Name: student_bulk_imports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_bulk_imports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    institute_id character varying NOT NULL,
    batch_id character varying,
    file_name text NOT NULL,
    file_size integer,
    storage_path text,
    status text DEFAULT 'pending'::text NOT NULL,
    total_rows integer DEFAULT 0 NOT NULL,
    processed_rows integer DEFAULT 0 NOT NULL,
    successful_rows integer DEFAULT 0 NOT NULL,
    failed_rows integer DEFAULT 0 NOT NULL,
    duplicate_rows integer DEFAULT 0 NOT NULL,
    error_log text,
    validation_errors text[],
    requires_approval boolean DEFAULT true NOT NULL,
    approval_status text DEFAULT 'pending'::text NOT NULL,
    approved_by character varying,
    approved_at timestamp without time zone,
    rejection_reason text,
    uploaded_by character varying,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.student_bulk_imports OWNER TO postgres;

--
-- Name: student_competency_scores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_competency_scores (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    student_id character varying NOT NULL,
    competency_id character varying NOT NULL,
    session_id character varying,
    raw_score real,
    percentile_score real,
    proficiency_level text,
    assessed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.student_competency_scores OWNER TO postgres;

--
-- Name: student_enrollments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_enrollments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    institute_id character varying NOT NULL,
    institute_name text NOT NULL,
    student_id character varying NOT NULL,
    student_name text NOT NULL,
    parent_id character varying,
    parent_name text,
    class_name text,
    section text,
    roll_number text,
    admission_date timestamp without time zone,
    status text DEFAULT 'pending'::text NOT NULL,
    payment_status text DEFAULT 'pending'::text,
    fee_amount real,
    paid_amount real DEFAULT 0,
    due_date timestamp without time zone,
    approved_by character varying,
    approved_at timestamp without time zone,
    approval_notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.student_enrollments OWNER TO postgres;

--
-- Name: student_import_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_import_records (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    import_id character varying NOT NULL,
    row_number integer NOT NULL,
    student_name text NOT NULL,
    dob date,
    gender text,
    parent_name text,
    parent_email text,
    parent_phone text,
    class_grade text,
    section text,
    roll_number text,
    admission_number text,
    status text DEFAULT 'pending'::text NOT NULL,
    validation_errors text[],
    student_id character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.student_import_records OWNER TO postgres;

--
-- Name: student_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_subscriptions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    child_id character varying,
    student_id character varying,
    package_id character varying NOT NULL,
    purchase_date timestamp without time zone DEFAULT now() NOT NULL,
    expiry_date timestamp without time zone,
    status text DEFAULT 'active'::text NOT NULL,
    assessment_completed_at timestamp without time zone,
    report_generated_at timestamp without time zone,
    payment_transaction_id character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.student_subscriptions OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    institute_id character varying,
    student_code text NOT NULL,
    full_name text NOT NULL,
    dob date,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: study_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.study_tasks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    child_id character varying NOT NULL,
    created_by_parent_id character varying NOT NULL,
    title text NOT NULL,
    description text,
    task_type text DEFAULT 'study'::text NOT NULL,
    subject_id character varying,
    chapter_id character varying,
    topic_id character varying,
    priority text DEFAULT 'Medium'::text NOT NULL,
    due_date timestamp without time zone,
    estimated_minutes integer,
    status text DEFAULT 'Pending'::text NOT NULL,
    completed_at timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.study_tasks OWNER TO postgres;

--
-- Name: subscription_packages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_packages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    category text NOT NULL,
    student_segment text NOT NULL,
    product_name text NOT NULL,
    is_recommended boolean DEFAULT false NOT NULL,
    domains_covered text[] NOT NULL,
    price real,
    validity_days integer,
    question_count integer,
    report_type text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_packages OWNER TO postgres;

--
-- Name: supervised_test_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supervised_test_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    exam_id character varying NOT NULL,
    parent_id character varying NOT NULL,
    child_id character varying NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone
);


ALTER TABLE public.supervised_test_sessions OWNER TO postgres;

--
-- Name: test_approvals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_approvals (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    test_id character varying NOT NULL,
    approver_user_id character varying NOT NULL,
    approval_status text DEFAULT 'Pending'::text NOT NULL,
    comments text,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.test_approvals OWNER TO postgres;

--
-- Name: test_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_assignments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    test_id character varying NOT NULL,
    assignment_type text NOT NULL,
    child_id character varying,
    batch_id character varying,
    institute_id character varying,
    section text,
    assigned_by character varying NOT NULL,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.test_assignments OWNER TO postgres;

--
-- Name: test_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_attempts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    test_id character varying NOT NULL,
    assignment_id character varying,
    child_id character varying NOT NULL,
    status text DEFAULT 'Not Started'::text NOT NULL,
    score_obtained real,
    total_marks real,
    percentage_score real,
    time_taken_seconds integer,
    started_at timestamp without time zone,
    submitted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.test_attempts OWNER TO postgres;

--
-- Name: test_blueprints; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_blueprints (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    blueprint_code text NOT NULL,
    blueprint_name text NOT NULL,
    test_type text NOT NULL,
    description text,
    board_id character varying,
    class_id character varying,
    subject_id character varying,
    chapter_id character varying,
    duration integer DEFAULT 60 NOT NULL,
    total_marks integer DEFAULT 100 NOT NULL,
    passing_marks integer DEFAULT 35 NOT NULL,
    total_questions integer DEFAULT 20 NOT NULL,
    question_distribution text,
    instructions text,
    created_by character varying,
    institute_id character varying,
    is_public boolean DEFAULT false NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.test_blueprints OWNER TO postgres;

--
-- Name: test_question_bank; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_question_bank (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    question_code text NOT NULL,
    question_type text DEFAULT 'MCQ'::text NOT NULL,
    difficulty_level text DEFAULT 'Medium'::text NOT NULL,
    question_text text NOT NULL,
    option_a text,
    option_b text,
    option_c text,
    option_d text,
    option_e text,
    correct_option text,
    answer_text text,
    explanation text,
    marks integer DEFAULT 1 NOT NULL,
    negative_marks real DEFAULT 0,
    board_id character varying,
    class_id character varying,
    subject_id character varying,
    chapter_id character varying,
    topic_id character varying,
    assessment_type text DEFAULT 'Practice'::text,
    assessment_code text,
    passage_id character varying,
    case_study_id character varying,
    diagram_url text,
    tags text[],
    language text DEFAULT 'EN'::text NOT NULL,
    psychopsis_sub_module_id character varying,
    created_by character varying,
    institute_id character varying,
    is_verified boolean DEFAULT false NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.test_question_bank OWNER TO postgres;

--
-- Name: test_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_questions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    test_id character varying NOT NULL,
    question_bank_id character varying,
    question_text text NOT NULL,
    option_a text,
    option_b text,
    option_c text,
    option_d text,
    correct_option text NOT NULL,
    explanation text,
    marks integer DEFAULT 1 NOT NULL,
    negative_marks real DEFAULT 0,
    order_index integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.test_questions OWNER TO postgres;

--
-- Name: test_responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_responses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    attempt_id character varying NOT NULL,
    question_id character varying NOT NULL,
    selected_option text,
    is_correct boolean,
    marks_obtained real DEFAULT 0,
    time_taken_seconds integer,
    is_flagged boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.test_responses OWNER TO postgres;

--
-- Name: test_workflow_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_workflow_history (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    test_id character varying NOT NULL,
    from_status text NOT NULL,
    to_status text NOT NULL,
    action_by character varying NOT NULL,
    action_type text NOT NULL,
    comments text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.test_workflow_history OWNER TO postgres;

--
-- Name: tests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    test_code text NOT NULL,
    test_name text NOT NULL,
    test_type text NOT NULL,
    blueprint_id character varying,
    board_id character varying,
    class_id character varying,
    subject_id character varying,
    chapter_id character varying,
    duration integer DEFAULT 60 NOT NULL,
    total_marks integer DEFAULT 100 NOT NULL,
    passing_marks integer DEFAULT 35 NOT NULL,
    instructions text,
    created_by character varying NOT NULL,
    institute_id character varying,
    creator_type text DEFAULT 'parent'::text NOT NULL,
    workflow_status text DEFAULT 'Draft'::text NOT NULL,
    is_auto_generated boolean DEFAULT false NOT NULL,
    scheduled_at timestamp without time zone,
    expires_at timestamp without time zone,
    status text DEFAULT 'Active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tests OWNER TO postgres;

--
-- Name: training_enrollments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_enrollments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mentor_id character varying NOT NULL,
    program_id character varying NOT NULL,
    status text DEFAULT 'enrolled'::text NOT NULL,
    attendance_percent real DEFAULT 0,
    assessment_score real,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    failure_reason text,
    retraining_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.training_enrollments OWNER TO postgres;

--
-- Name: training_programs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_programs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    program_name text NOT NULL,
    description text,
    role_category text NOT NULL,
    duration_days integer DEFAULT 7 NOT NULL,
    passing_score integer DEFAULT 70 NOT NULL,
    modules text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.training_programs OWNER TO postgres;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    session_token text NOT NULL,
    ip_address text,
    user_agent text,
    device_type text,
    browser text,
    os text,
    location text,
    is_active boolean DEFAULT true NOT NULL,
    last_activity timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone,
    terminated_at timestamp without time zone,
    termination_reason text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    full_name text,
    role text DEFAULT 'parent'::text NOT NULL,
    roles text[] DEFAULT ARRAY['parent'::text] NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: white_label_partners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.white_label_partners (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    partner_code text NOT NULL,
    company_name text NOT NULL,
    contact_name text NOT NULL,
    contact_email text NOT NULL,
    contact_phone text,
    brand_logo_url text,
    brand_primary_color text,
    brand_accent_color text,
    custom_domain text,
    revenue_share_percent real DEFAULT 20 NOT NULL,
    mentor_pool_size integer DEFAULT 0,
    status text DEFAULT 'pilot'::text NOT NULL,
    pilot_start_date date,
    rollout_date date,
    terminated_at timestamp without time zone,
    termination_reason text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.white_label_partners OWNER TO postgres;

--
-- Name: concern_areas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.concern_areas ALTER COLUMN id SET DEFAULT nextval('public.concern_areas_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: sdi_domains id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_domains ALTER COLUMN id SET DEFAULT nextval('public.sdi_domains_id_seq'::regclass);


--
-- Name: sdi_item_options id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_item_options ALTER COLUMN id SET DEFAULT nextval('public.sdi_item_options_id_seq'::regclass);


--
-- Name: sdi_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_items ALTER COLUMN id SET DEFAULT nextval('public.sdi_items_id_seq'::regclass);


--
-- Name: sdi_subdomains id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_subdomains ALTER COLUMN id SET DEFAULT nextval('public.sdi_subdomains_id_seq'::regclass);


--
-- Data for Name: academic_chapters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.academic_chapters (id, subject_id, chapter_number, chapter_name, description, estimated_hours, display_order, status, created_at) FROM stdin;
8374da60-ee3b-4888-b61b-a780679b00ff	0bdffdb6-f3c6-45b5-b806-3d3537acc662	1	Real Numbers	\N	\N	1	Active	2026-05-01 04:27:53.783381
62f2ac9e-57ab-4720-a991-6bc2efb5f6fe	0bdffdb6-f3c6-45b5-b806-3d3537acc662	2	Polynomials	\N	\N	2	Active	2026-05-01 04:27:53.783381
0c898833-e777-4f9d-9a7b-514c61a30723	0bdffdb6-f3c6-45b5-b806-3d3537acc662	3	Pair of Linear Equations	\N	\N	3	Active	2026-05-01 04:27:53.783381
53d6f7b9-c420-42ae-9ab8-0a69bba0f93b	0bdffdb6-f3c6-45b5-b806-3d3537acc662	4	Quadratic Equations	\N	\N	4	Active	2026-05-01 04:27:53.783381
df36e336-0acf-49fd-85ec-81eb1e7a7677	0bdffdb6-f3c6-45b5-b806-3d3537acc662	5	Arithmetic Progressions	\N	\N	5	Active	2026-05-01 04:27:53.783381
8b3d00b5-40ce-4fd9-bfdf-ab624803f00f	0bdffdb6-f3c6-45b5-b806-3d3537acc662	6	Triangles	\N	\N	6	Active	2026-05-01 04:27:53.783381
ed1a0da5-49f2-42c8-9b4e-4f1d08558be1	0bdffdb6-f3c6-45b5-b806-3d3537acc662	7	Coordinate Geometry	\N	\N	7	Active	2026-05-01 04:27:53.783381
55c9466a-7610-4460-b703-ff1ce72f9454	0bdffdb6-f3c6-45b5-b806-3d3537acc662	8	Introduction to Trigonometry	\N	\N	8	Active	2026-05-01 04:27:53.783381
8b5e0d4b-42ac-48ef-a074-de501c2face3	a1934710-3f8d-42c5-ba3e-153f991d9b0a	1	Chemical Reactions and Equations	\N	\N	1	Active	2026-05-01 04:27:53.785137
80cf1a89-0c80-4aeb-9fee-1c11562df435	a1934710-3f8d-42c5-ba3e-153f991d9b0a	2	Acids, Bases and Salts	\N	\N	2	Active	2026-05-01 04:27:53.785137
81596a76-4ca0-4bff-8a4f-4b803af01480	a1934710-3f8d-42c5-ba3e-153f991d9b0a	3	Metals and Non-metals	\N	\N	3	Active	2026-05-01 04:27:53.785137
d3cbee0c-d03b-40e7-a293-7b3afcd339f7	a1934710-3f8d-42c5-ba3e-153f991d9b0a	4	Carbon and its Compounds	\N	\N	4	Active	2026-05-01 04:27:53.785137
3862fdfa-38dd-427b-b1c3-9760f3aa6685	a1934710-3f8d-42c5-ba3e-153f991d9b0a	5	Life Processes	\N	\N	5	Active	2026-05-01 04:27:53.785137
45f01e3a-abee-4235-97c7-b7c7337ea366	a1934710-3f8d-42c5-ba3e-153f991d9b0a	6	Control and Coordination	\N	\N	6	Active	2026-05-01 04:27:53.785137
a3e1f6e7-5990-4fe0-8c30-f9dcee96e02c	a1934710-3f8d-42c5-ba3e-153f991d9b0a	7	Heredity and Evolution	\N	\N	7	Active	2026-05-01 04:27:53.785137
42c9c221-2dd7-423f-9e5e-b95611937447	a1934710-3f8d-42c5-ba3e-153f991d9b0a	8	Light - Reflection and Refraction	\N	\N	8	Active	2026-05-01 04:27:53.785137
\.


--
-- Data for Name: academic_classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.academic_classes (id, board_id, class_number, class_name, display_order, status, created_at) FROM stdin;
194873d1-8625-47fc-b6e7-51631ce596b7	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6	Class 6	6	Active	2026-05-01 04:27:53.779068
26d871ec-dc0d-4ad1-834d-f744fc86b01e	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	7	Class 7	7	Active	2026-05-01 04:27:53.779068
17458c31-2994-491e-8b14-f6f4ffaa1a38	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	8	Class 8	8	Active	2026-05-01 04:27:53.779068
2a834320-56b8-4c1a-9d58-f9202a1af557	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	9	Class 9	9	Active	2026-05-01 04:27:53.779068
6a884ad1-6b96-4ac0-b032-a47a4e969a13	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	10	Class 10	10	Active	2026-05-01 04:27:53.779068
ff115ac7-9aab-4a8a-a2ab-e0e57d0a6199	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	11	Class 11	11	Active	2026-05-01 04:27:53.779068
1b008da4-9f5e-4f12-a079-9e5da8d35afc	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	12	Class 12	12	Active	2026-05-01 04:27:53.779068
\.


--
-- Data for Name: academic_subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.academic_subjects (id, board_id, class_id, subject_code, subject_name, subject_type, display_order, status, created_at) FROM stdin;
0bdffdb6-f3c6-45b5-b806-3d3537acc662	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6a884ad1-6b96-4ac0-b032-a47a4e969a13	MATH_10	Mathematics	Core	1	Active	2026-05-01 04:27:53.780831
a1934710-3f8d-42c5-ba3e-153f991d9b0a	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6a884ad1-6b96-4ac0-b032-a47a4e969a13	SCIENCE_10	Science	Core	2	Active	2026-05-01 04:27:53.780831
5f70dccc-6ab6-4793-b6be-66bc367e0445	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6a884ad1-6b96-4ac0-b032-a47a4e969a13	ENGLISH_10	English	Core	3	Active	2026-05-01 04:27:53.780831
605a92b0-fbe0-4490-8f74-66cc24647f6f	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6a884ad1-6b96-4ac0-b032-a47a4e969a13	HINDI_10	Hindi	Core	4	Active	2026-05-01 04:27:53.780831
52aabe06-1b6a-40de-8062-179269e8d9a3	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6a884ad1-6b96-4ac0-b032-a47a4e969a13	SST_10	Social Science	Core	5	Active	2026-05-01 04:27:53.780831
\.


--
-- Data for Name: academic_topics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.academic_topics (id, chapter_id, topic_number, topic_name, description, display_order, status, created_at) FROM stdin;
8c7fa6f6-bcb1-49a6-af5c-92e311430f9b	8374da60-ee3b-4888-b61b-a780679b00ff	1	Euclid's Division Lemma	\N	1	Active	2026-05-01 04:27:53.7868
d181aa3b-007b-4695-a227-ed1055bea3bc	8374da60-ee3b-4888-b61b-a780679b00ff	2	Fundamental Theorem of Arithmetic	\N	2	Active	2026-05-01 04:27:53.7868
7303c475-4911-43e5-99b9-7a9b75ed345e	8374da60-ee3b-4888-b61b-a780679b00ff	3	Irrational Numbers	\N	3	Active	2026-05-01 04:27:53.7868
c1faa4c1-e281-4d9d-90fa-fe8c5f7a2a5d	8374da60-ee3b-4888-b61b-a780679b00ff	4	Decimal Expansions of Rational Numbers	\N	4	Active	2026-05-01 04:27:53.7868
\.


--
-- Data for Name: access_control_policies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_control_policies (id, policy_name, policy_type, resource, actions, conditions, allowed_roles, denied_roles, priority, effect, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: acknowledgements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acknowledgements (id, user_id, notification_id, acknowledgement_type, reference_id, reference_type, notes, acknowledged_at) FROM stdin;
\.


--
-- Data for Name: admin_audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_audit_logs (id, admin_user_id, action_type, target_type, target_id, previous_state, new_state, ip_address, notes, created_at) FROM stdin;
\.


--
-- Data for Name: assessment_blueprints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assessment_blueprints (id, blueprint_code, blueprint_name, board_id, class_id, subject_id, assessment_type, total_marks, duration_minutes, instructions, passing_marks, is_active, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: assessment_template_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assessment_template_questions (id, template_id, question_text, option_a, option_b, option_c, option_d, correct_option, marks, order_index) FROM stdin;
b6f4ba15-e8d6-4c60-90aa-4e38ac228da2	8e414246-f1da-4bf5-8fe6-717d49cbac40	What is 15 + 27?	42	43	41	44	A	5	1
1462fee4-8278-4243-bdfa-e152567fae33	8e414246-f1da-4bf5-8fe6-717d49cbac40	What is 8 × 7?	54	56	58	52	B	5	2
25c2f1c1-61f2-459e-899c-a4fb197d4ecd	8e414246-f1da-4bf5-8fe6-717d49cbac40	What is the square root of 81?	7	8	9	10	C	5	3
baf9a0a6-cfb1-4d33-bd3d-8b6fd27c2cd6	8e414246-f1da-4bf5-8fe6-717d49cbac40	Which is a prime number?	15	21	23	25	C	5	4
90be632a-06d4-468e-835f-847d90bb15ec	8e414246-f1da-4bf5-8fe6-717d49cbac40	What is 144 ÷ 12?	10	11	12	13	C	5	5
efd9986f-066b-4bf0-b106-3f44f1c25768	8e414246-f1da-4bf5-8fe6-717d49cbac40	What is 3² + 4²?	25	24	23	22	A	5	6
d1454bf0-f95e-425a-a129-170f13f26a9c	8e414246-f1da-4bf5-8fe6-717d49cbac40	What is the value of π (pi) approximately?	3.12	3.14	3.16	3.18	B	5	7
d1d311fc-8693-4f31-9869-a596112140ff	8e414246-f1da-4bf5-8fe6-717d49cbac40	What is 20% of 150?	25	30	35	40	B	5	8
f1611b27-361c-41a7-9985-091fca0c3473	8e414246-f1da-4bf5-8fe6-717d49cbac40	Which fraction is equivalent to 0.5?	1/3	1/4	1/2	2/3	C	5	9
dbd40937-8eef-4136-9c56-e80a458f6e77	8e414246-f1da-4bf5-8fe6-717d49cbac40	What is the next number in the sequence: 2, 4, 8, 16, ...?	24	28	30	32	D	5	10
07d64548-b6ee-4bd2-8342-bdb96e7e303c	d90df307-e2e5-454b-b8e5-1441488eb041	What is the chemical symbol for water?	H2O	CO2	O2	NaCl	A	4	1
df14c7eb-ddb2-4ff0-bbff-bc15d0451b3f	d90df307-e2e5-454b-b8e5-1441488eb041	What is the unit of force?	Joule	Watt	Newton	Pascal	C	4	2
12fb4c6e-4c83-43cf-b997-4699b6fe47b5	d90df307-e2e5-454b-b8e5-1441488eb041	Which planet is known as the Red Planet?	Venus	Mars	Jupiter	Saturn	B	4	3
8e950382-8cfb-4fb1-8da4-ec142890b0fc	d90df307-e2e5-454b-b8e5-1441488eb041	What is the powerhouse of the cell?	Nucleus	Ribosome	Mitochondria	Golgi body	C	4	4
3c278fab-67cb-470c-95e8-7fc381dbfda5	d90df307-e2e5-454b-b8e5-1441488eb041	What is the speed of light approximately?	3×10⁶ m/s	3×10⁷ m/s	3×10⁸ m/s	3×10⁹ m/s	C	4	5
0e15f145-053d-453d-a3f6-29e8890f429e	d90df307-e2e5-454b-b8e5-1441488eb041	Which gas do plants absorb from the atmosphere?	Oxygen	Nitrogen	Carbon dioxide	Hydrogen	C	4	6
ce947a04-0d20-4a0e-8b1d-726375466a67	d90df307-e2e5-454b-b8e5-1441488eb041	What is the atomic number of Carbon?	4	6	8	12	B	4	7
bc31253a-547f-43f5-9dab-45a989ed250f	d90df307-e2e5-454b-b8e5-1441488eb041	Which force keeps planets in orbit around the Sun?	Friction	Magnetic	Gravity	Nuclear	C	4	8
a0578613-f92a-4df4-be2d-c0ba43dc48cc	d90df307-e2e5-454b-b8e5-1441488eb041	What is the pH of pure water?	5	6	7	8	C	4	9
f1a4fa6b-8b05-4e45-ad21-77ed6dc99501	d90df307-e2e5-454b-b8e5-1441488eb041	Which state of matter has a definite shape and volume?	Solid	Liquid	Gas	Plasma	A	4	10
12415a0d-578f-400a-9a28-11ae4aed3b6e	e50fbcfc-4d65-4c32-8095-c2169f8bc059	Which word is a noun?	Run	Beautiful	Happiness	Quickly	C	5	1
a817f15e-73f7-47c8-890b-1509c6568465	e50fbcfc-4d65-4c32-8095-c2169f8bc059	What is the past tense of 'go'?	Goes	Going	Went	Gone	C	5	2
1b338409-c061-41fc-8e25-1eba419aad74	e50fbcfc-4d65-4c32-8095-c2169f8bc059	Which is a synonym for 'happy'?	Sad	Angry	Joyful	Tired	C	5	3
f8cf7a9b-96b3-419a-8536-60f9cf8641f6	e50fbcfc-4d65-4c32-8095-c2169f8bc059	Which sentence is grammatically correct?	She don't like it	She doesn't likes it	She doesn't like it	She not like it	C	5	4
b927768c-7bfb-4fb7-8f7e-39f7a929e8b3	e50fbcfc-4d65-4c32-8095-c2169f8bc059	What is an antonym of 'ancient'?	Old	Modern	Historic	Vintage	B	5	5
6a84ff9c-2182-49fb-9806-939bd03fa4de	e50fbcfc-4d65-4c32-8095-c2169f8bc059	Which word is an adjective?	Quickly	Running	Beautiful	Jump	C	5	6
3a6fc3e8-5f7f-4d34-a455-54241b4a8064	e50fbcfc-4d65-4c32-8095-c2169f8bc059	What type of word is 'however'?	Noun	Verb	Conjunction	Preposition	C	5	7
dead5f45-c53b-4e9b-93d2-c008c29cd97d	e50fbcfc-4d65-4c32-8095-c2169f8bc059	Which is the correct plural of 'child'?	Childs	Childes	Children	Childern	C	5	8
34f89b24-9690-4d62-9504-19ecb3f05358	e50fbcfc-4d65-4c32-8095-c2169f8bc059	What is a simile?	A type of poem	A comparison using 'like' or 'as'	A repeated sound	A question in writing	B	5	9
e0ef055f-fa00-4027-a54c-333e784e299c	e50fbcfc-4d65-4c32-8095-c2169f8bc059	Which punctuation ends a question?	Period	Comma	Exclamation mark	Question mark	D	5	10
fc6ce138-8166-447e-b1de-2c41a38f95a6	1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	What is 15 + 27?	42	43	41	44	A	6	1
21404a6b-bcf9-4d59-8494-fd45df5888cf	1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	What is 8 × 7?	54	56	58	52	B	6	2
6e501aa3-12f8-4c22-a10e-d0502184a1e7	1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	What is the square root of 81?	7	8	9	10	C	6	3
604f0e10-c76e-4a44-8d49-4a4ff87d5420	1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	Which is a prime number?	15	21	23	25	C	6	4
d6de7363-4702-4483-ac0c-decfa93f6d69	1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	What is 144 ÷ 12?	10	11	12	13	C	6	5
6b6a1351-e6db-4aca-be6c-35952152e609	1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	What is 3² + 4²?	25	24	23	22	A	6	6
b4a3dbbb-5773-4e5b-b6f7-8c96149c6693	1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	What is the value of π (pi) approximately?	3.12	3.14	3.16	3.18	B	6	7
213d2106-4800-4353-aea1-ad6a4775e6fe	1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	What is 20% of 150?	25	30	35	40	B	6	8
be85bce4-c2cc-4c53-92fb-aba625beb2bf	1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	Which fraction is equivalent to 0.5?	1/3	1/4	1/2	2/3	C	6	9
7078134f-d260-4c74-9eb3-3479a5003668	1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	What is the next number in the sequence: 2, 4, 8, 16, ...?	24	28	30	32	D	6	10
c52256f1-19fc-4612-8a0c-12ba9426d069	3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	What is the chemical symbol for water?	H2O	CO2	O2	NaCl	A	5	1
78a917c5-fec1-48af-9bfd-5464350498fa	3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	What is the unit of force?	Joule	Watt	Newton	Pascal	C	5	2
87012e6b-5ee4-4a4e-9bca-fcc3d3feac54	3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	Which planet is known as the Red Planet?	Venus	Mars	Jupiter	Saturn	B	5	3
957f8f5d-afe1-4573-947f-712cf7b2dd5e	3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	What is the powerhouse of the cell?	Nucleus	Ribosome	Mitochondria	Golgi body	C	5	4
781659c7-d5cb-4e94-a6d4-fb7419e3a4f7	3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	What is the speed of light approximately?	3×10⁶ m/s	3×10⁷ m/s	3×10⁸ m/s	3×10⁹ m/s	C	5	5
3bd0b35d-6655-4ac9-b150-c878d4d5bb53	3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	Which gas do plants absorb from the atmosphere?	Oxygen	Nitrogen	Carbon dioxide	Hydrogen	C	5	6
b5b8966f-d4cc-4b23-8f58-6c555979a09c	3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	What is the atomic number of Carbon?	4	6	8	12	B	5	7
d6c4a460-c8a0-4f32-b19f-5f4998b5a40d	3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	Which force keeps planets in orbit around the Sun?	Friction	Magnetic	Gravity	Nuclear	C	5	8
6a2fba88-75d9-4364-9094-3b447542b4aa	3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	What is the pH of pure water?	5	6	7	8	C	5	9
b08c9800-348d-4a74-b596-861d1470dad3	3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	Which state of matter has a definite shape and volume?	Solid	Liquid	Gas	Plasma	A	5	10
da70d052-d69f-4ae8-a3f1-7991f63681ac	7705e386-ed13-4970-8a55-6813cc9cdcae	Which word is a noun?	Run	Beautiful	Happiness	Quickly	C	5	1
6819b0b2-8f02-4547-89e8-61aab2bf4165	7705e386-ed13-4970-8a55-6813cc9cdcae	What is the past tense of 'go'?	Goes	Going	Went	Gone	C	5	2
30eebd21-2c59-4890-9bbc-822d05b6112b	7705e386-ed13-4970-8a55-6813cc9cdcae	Which is a synonym for 'happy'?	Sad	Angry	Joyful	Tired	C	5	3
c181ef88-d97d-4cec-9e87-8aa535011b04	7705e386-ed13-4970-8a55-6813cc9cdcae	Which sentence is grammatically correct?	She don't like it	She doesn't likes it	She doesn't like it	She not like it	C	5	4
0722c396-51f2-4892-b1bc-5ec5ad845828	7705e386-ed13-4970-8a55-6813cc9cdcae	What is an antonym of 'ancient'?	Old	Modern	Historic	Vintage	B	5	5
4347098d-e9c6-4474-88cd-87d3a64d2486	7705e386-ed13-4970-8a55-6813cc9cdcae	Which word is an adjective?	Quickly	Running	Beautiful	Jump	C	5	6
c8331cf7-034e-4c38-a688-78f04b104dfb	7705e386-ed13-4970-8a55-6813cc9cdcae	What type of word is 'however'?	Noun	Verb	Conjunction	Preposition	C	5	7
9ea24219-5d3a-4e5b-95b2-ec1e269f1b9c	7705e386-ed13-4970-8a55-6813cc9cdcae	Which is the correct plural of 'child'?	Childs	Childes	Children	Childern	C	5	8
2493f702-1475-4e6c-b307-4eecb7f657d9	7705e386-ed13-4970-8a55-6813cc9cdcae	What is a simile?	A type of poem	A comparison using 'like' or 'as'	A repeated sound	A question in writing	B	5	9
2ac8d20c-cd6a-4371-b3fb-f1c75435792c	7705e386-ed13-4970-8a55-6813cc9cdcae	Which punctuation ends a question?	Period	Comma	Exclamation mark	Question mark	D	5	10
7697039a-7c37-4c1f-a423-da7cee2df1a6	6a929d66-b76a-4e76-8c82-f29991b926d7	What is 15 + 27?	42	43	41	44	A	8	1
71048e4a-c638-4894-9377-2efa90525dec	6a929d66-b76a-4e76-8c82-f29991b926d7	What is 8 × 7?	54	56	58	52	B	8	2
b7247643-a7da-4574-922f-e555a0e35a56	6a929d66-b76a-4e76-8c82-f29991b926d7	What is the square root of 81?	7	8	9	10	C	8	3
0610fdd3-2809-44ca-86cd-af4ccb9b75d7	6a929d66-b76a-4e76-8c82-f29991b926d7	Which is a prime number?	15	21	23	25	C	8	4
d9b46491-036e-42a7-8779-d11f920abe6d	6a929d66-b76a-4e76-8c82-f29991b926d7	What is 144 ÷ 12?	10	11	12	13	C	8	5
f5752891-f476-4084-8b1d-27c058816dab	6a929d66-b76a-4e76-8c82-f29991b926d7	What is 3² + 4²?	25	24	23	22	A	8	6
09757dd8-1a27-4b75-a429-02e50b228cf4	6a929d66-b76a-4e76-8c82-f29991b926d7	What is the value of π (pi) approximately?	3.12	3.14	3.16	3.18	B	8	7
27b1f12d-59d0-4823-bb38-df3e6fb22efd	6a929d66-b76a-4e76-8c82-f29991b926d7	What is 20% of 150?	25	30	35	40	B	8	8
1281b94e-d791-4a9d-a85c-17bbaf2b6642	6a929d66-b76a-4e76-8c82-f29991b926d7	Which fraction is equivalent to 0.5?	1/3	1/4	1/2	2/3	C	8	9
51f9f6ee-3e09-4ab4-a9b8-ca83dfb9e3cd	6a929d66-b76a-4e76-8c82-f29991b926d7	What is the next number in the sequence: 2, 4, 8, 16, ...?	24	28	30	32	D	8	10
1010ea0c-36d0-4465-91ba-7cd744097080	f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	What is the chemical symbol for water?	H2O	CO2	O2	NaCl	A	6	1
d70824db-c965-42d9-b87e-315a78cc12c8	f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	What is the unit of force?	Joule	Watt	Newton	Pascal	C	6	2
7d136df3-ccb3-472e-8c83-8035970a7c1d	f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	Which planet is known as the Red Planet?	Venus	Mars	Jupiter	Saturn	B	6	3
784b9b94-2c73-4cd4-b0ed-3868e5771f5f	f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	What is the powerhouse of the cell?	Nucleus	Ribosome	Mitochondria	Golgi body	C	6	4
193ee91f-169d-4cb8-be96-a53d0a4dd89c	f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	What is the speed of light approximately?	3×10⁶ m/s	3×10⁷ m/s	3×10⁸ m/s	3×10⁹ m/s	C	6	5
d6e37406-9ec2-4e11-bbce-37eebfa4d8ad	f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	Which gas do plants absorb from the atmosphere?	Oxygen	Nitrogen	Carbon dioxide	Hydrogen	C	6	6
bf9d44a3-bb1b-4b9c-b57b-63e35c681c46	f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	What is the atomic number of Carbon?	4	6	8	12	B	6	7
ced4ecd8-a6c4-4b5d-a966-a51894490782	f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	Which force keeps planets in orbit around the Sun?	Friction	Magnetic	Gravity	Nuclear	C	6	8
7c6c99e5-f76f-41b4-9e2c-9b6b53e31d5b	f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	What is the pH of pure water?	5	6	7	8	C	6	9
d3cfc45b-ab26-471b-9607-7bbb8bf82522	f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	Which state of matter has a definite shape and volume?	Solid	Liquid	Gas	Plasma	A	6	10
b6970f84-9b83-49d1-a758-2edab914a552	cc2d0482-cc56-4e46-9c74-41352e2ae150	Which word is a noun?	Run	Beautiful	Happiness	Quickly	C	5	1
4026e9b2-bdc7-4596-8ffb-5257a50f4710	cc2d0482-cc56-4e46-9c74-41352e2ae150	What is the past tense of 'go'?	Goes	Going	Went	Gone	C	5	2
8a10edcc-6500-4fe2-83b4-dfce5440af60	cc2d0482-cc56-4e46-9c74-41352e2ae150	Which is a synonym for 'happy'?	Sad	Angry	Joyful	Tired	C	5	3
5c04964c-caf8-4d5c-a577-90c0744f36c9	cc2d0482-cc56-4e46-9c74-41352e2ae150	Which sentence is grammatically correct?	She don't like it	She doesn't likes it	She doesn't like it	She not like it	C	5	4
4c3820f9-06ae-414b-9bf8-adc625aaf3df	cc2d0482-cc56-4e46-9c74-41352e2ae150	What is an antonym of 'ancient'?	Old	Modern	Historic	Vintage	B	5	5
fed6fbda-a25f-48a2-98fa-ac6fc240925a	cc2d0482-cc56-4e46-9c74-41352e2ae150	Which word is an adjective?	Quickly	Running	Beautiful	Jump	C	5	6
d93cc322-a9ef-4d27-affa-7c6224094242	cc2d0482-cc56-4e46-9c74-41352e2ae150	What type of word is 'however'?	Noun	Verb	Conjunction	Preposition	C	5	7
e25e270a-67f3-463f-802c-39f563656bf7	cc2d0482-cc56-4e46-9c74-41352e2ae150	Which is the correct plural of 'child'?	Childs	Childes	Children	Childern	C	5	8
75aeaab6-cf04-4c47-b3e1-00a0c9f8e967	cc2d0482-cc56-4e46-9c74-41352e2ae150	What is a simile?	A type of poem	A comparison using 'like' or 'as'	A repeated sound	A question in writing	B	5	9
31ccd15a-70ff-46f6-ba02-8ffc8a06e334	cc2d0482-cc56-4e46-9c74-41352e2ae150	Which punctuation ends a question?	Period	Comma	Exclamation mark	Question mark	D	5	10
8af94ed5-11a3-4599-9536-3710786ae003	8bd7c29b-eb6c-4065-aad4-eb1289227e5f	What is 15 + 27?	42	43	41	44	A	8	1
9f97bee3-74df-4af5-907b-0013161149ff	8bd7c29b-eb6c-4065-aad4-eb1289227e5f	What is 8 × 7?	54	56	58	52	B	8	2
3ea070ba-87f1-4f9f-86d0-919e64c83f22	8bd7c29b-eb6c-4065-aad4-eb1289227e5f	What is the square root of 81?	7	8	9	10	C	8	3
df1df21b-3ffe-4dfb-90b3-107d1fb88d45	8bd7c29b-eb6c-4065-aad4-eb1289227e5f	Which is a prime number?	15	21	23	25	C	8	4
f30459f3-7ceb-487d-963b-3552b102098f	8bd7c29b-eb6c-4065-aad4-eb1289227e5f	What is 144 ÷ 12?	10	11	12	13	C	8	5
9be5a3d0-6ae3-41d9-a11b-22f78a97992f	8bd7c29b-eb6c-4065-aad4-eb1289227e5f	What is 3² + 4²?	25	24	23	22	A	8	6
e4885d1a-3adc-45a4-951a-abd6282153ef	8bd7c29b-eb6c-4065-aad4-eb1289227e5f	What is the value of π (pi) approximately?	3.12	3.14	3.16	3.18	B	8	7
d1c3147f-96e3-4ab3-93aa-0ffaa2ef21da	8bd7c29b-eb6c-4065-aad4-eb1289227e5f	What is 20% of 150?	25	30	35	40	B	8	8
086bc547-550f-47e9-94af-eeb158b45ac6	8bd7c29b-eb6c-4065-aad4-eb1289227e5f	Which fraction is equivalent to 0.5?	1/3	1/4	1/2	2/3	C	8	9
be3b356d-3de6-49e7-83a8-5c05e577c917	8bd7c29b-eb6c-4065-aad4-eb1289227e5f	What is the next number in the sequence: 2, 4, 8, 16, ...?	24	28	30	32	D	8	10
d724ae4c-91df-41bd-84b0-087e31336925	a705b19b-dbf2-4ec7-8eed-89e309f748fd	What is the chemical symbol for water?	H2O	CO2	O2	NaCl	A	7	1
564b6bf2-10e0-4b9a-9e0f-7fdc5a0281bd	a705b19b-dbf2-4ec7-8eed-89e309f748fd	What is the unit of force?	Joule	Watt	Newton	Pascal	C	7	2
e2388985-d7f5-4825-8779-7345bdad79c5	a705b19b-dbf2-4ec7-8eed-89e309f748fd	Which planet is known as the Red Planet?	Venus	Mars	Jupiter	Saturn	B	7	3
17fb92d2-78e3-447b-9636-db3e6a9051b4	a705b19b-dbf2-4ec7-8eed-89e309f748fd	What is the powerhouse of the cell?	Nucleus	Ribosome	Mitochondria	Golgi body	C	7	4
bed0b708-a474-4e6e-bdb8-fe95337decda	a705b19b-dbf2-4ec7-8eed-89e309f748fd	What is the speed of light approximately?	3×10⁶ m/s	3×10⁷ m/s	3×10⁸ m/s	3×10⁹ m/s	C	7	5
0e255c2b-6f3b-4e42-9b43-f2e007d23c56	a705b19b-dbf2-4ec7-8eed-89e309f748fd	Which gas do plants absorb from the atmosphere?	Oxygen	Nitrogen	Carbon dioxide	Hydrogen	C	7	6
5a001149-9b4d-4bed-b66a-ff3f91a20458	a705b19b-dbf2-4ec7-8eed-89e309f748fd	What is the atomic number of Carbon?	4	6	8	12	B	7	7
607b6f16-af41-42b2-a0b4-c0596e9ef204	a705b19b-dbf2-4ec7-8eed-89e309f748fd	Which force keeps planets in orbit around the Sun?	Friction	Magnetic	Gravity	Nuclear	C	7	8
96232330-2953-4fed-be9d-cf2775605a90	a705b19b-dbf2-4ec7-8eed-89e309f748fd	What is the pH of pure water?	5	6	7	8	C	7	9
d571b3d3-9f1f-4eb0-90e3-73cfe6e3ec61	a705b19b-dbf2-4ec7-8eed-89e309f748fd	Which state of matter has a definite shape and volume?	Solid	Liquid	Gas	Plasma	A	7	10
973aceb2-2ec9-4fd6-8c13-c8482dfe1efd	e608b1dd-6a4a-45df-b973-18ad0602583c	What is the chemical symbol for water?	H2O	CO2	O2	NaCl	A	7	1
21bf2ff5-8380-45d0-a72e-5ff2e95a3b38	e608b1dd-6a4a-45df-b973-18ad0602583c	What is the unit of force?	Joule	Watt	Newton	Pascal	C	7	2
b1fc1d4f-2135-428b-84e4-9d1c44b79697	e608b1dd-6a4a-45df-b973-18ad0602583c	Which planet is known as the Red Planet?	Venus	Mars	Jupiter	Saturn	B	7	3
d62ac31d-1fc6-415c-8ec0-eba39280dd01	e608b1dd-6a4a-45df-b973-18ad0602583c	What is the powerhouse of the cell?	Nucleus	Ribosome	Mitochondria	Golgi body	C	7	4
5e5df96e-9600-4b8a-ba56-5c8486f863a5	e608b1dd-6a4a-45df-b973-18ad0602583c	What is the speed of light approximately?	3×10⁶ m/s	3×10⁷ m/s	3×10⁸ m/s	3×10⁹ m/s	C	7	5
11cfac61-1c39-4672-a09b-3f17b4aa846b	e608b1dd-6a4a-45df-b973-18ad0602583c	Which gas do plants absorb from the atmosphere?	Oxygen	Nitrogen	Carbon dioxide	Hydrogen	C	7	6
1d1a205c-3974-4fce-a547-5491e89c4665	e608b1dd-6a4a-45df-b973-18ad0602583c	What is the atomic number of Carbon?	4	6	8	12	B	7	7
a75f85a1-463c-45f1-9ab0-c1c326cf70b4	e608b1dd-6a4a-45df-b973-18ad0602583c	Which force keeps planets in orbit around the Sun?	Friction	Magnetic	Gravity	Nuclear	C	7	8
48da225c-8d7e-44fc-82b6-85c1bc4669b7	e608b1dd-6a4a-45df-b973-18ad0602583c	What is the pH of pure water?	5	6	7	8	C	7	9
a23d1372-204f-4325-b9da-1504d5e30eb0	e608b1dd-6a4a-45df-b973-18ad0602583c	Which state of matter has a definite shape and volume?	Solid	Liquid	Gas	Plasma	A	7	10
0c150d5c-2072-423a-a4a8-77d21473d0ab	884bb46b-475c-479b-91ba-a8ef5c58c318	What is 15 + 27?	42	43	41	44	A	10	1
1ec005d6-7765-433b-9ef2-efa231fc8a85	884bb46b-475c-479b-91ba-a8ef5c58c318	What is 8 × 7?	54	56	58	52	B	10	2
e6765e8f-f093-4953-8eb0-4f36ef8cdc85	884bb46b-475c-479b-91ba-a8ef5c58c318	What is the square root of 81?	7	8	9	10	C	10	3
b652aa3a-f6e9-4407-a0dc-843f6fb092b8	884bb46b-475c-479b-91ba-a8ef5c58c318	Which is a prime number?	15	21	23	25	C	10	4
70f12ed8-27ff-4ccc-94ad-34060691c198	884bb46b-475c-479b-91ba-a8ef5c58c318	What is 144 ÷ 12?	10	11	12	13	C	10	5
3e890b5a-e7d1-4f20-8ec1-1130cee4c69a	884bb46b-475c-479b-91ba-a8ef5c58c318	What is 3² + 4²?	25	24	23	22	A	10	6
fa9956dd-c98e-4d9a-aab5-ea8e9a52a66f	884bb46b-475c-479b-91ba-a8ef5c58c318	What is the value of π (pi) approximately?	3.12	3.14	3.16	3.18	B	10	7
53196768-d875-4dd9-924c-7b86ac3ec07d	884bb46b-475c-479b-91ba-a8ef5c58c318	What is 20% of 150?	25	30	35	40	B	10	8
63ab135e-ab8d-4575-91f0-b7cbd973a87d	884bb46b-475c-479b-91ba-a8ef5c58c318	Which fraction is equivalent to 0.5?	1/3	1/4	1/2	2/3	C	10	9
f511bf77-d8aa-4d77-b0f9-e6a06b5857cc	884bb46b-475c-479b-91ba-a8ef5c58c318	What is the next number in the sequence: 2, 4, 8, 16, ...?	24	28	30	32	D	10	10
bf4d5266-c1d1-491a-ac96-8eeebebd3d24	d1d08c9b-50c1-4020-9031-880d44d05b94	What is the chemical symbol for water?	H2O	CO2	O2	NaCl	A	8	1
b4e96a1f-a841-419a-8c24-fc5db7072859	d1d08c9b-50c1-4020-9031-880d44d05b94	What is the unit of force?	Joule	Watt	Newton	Pascal	C	8	2
655eb92e-e4d7-4a43-9d14-49257d698003	d1d08c9b-50c1-4020-9031-880d44d05b94	Which planet is known as the Red Planet?	Venus	Mars	Jupiter	Saturn	B	8	3
20613117-68a1-4543-9f04-bc1bb9b3da18	d1d08c9b-50c1-4020-9031-880d44d05b94	What is the powerhouse of the cell?	Nucleus	Ribosome	Mitochondria	Golgi body	C	8	4
c480a125-6cb2-4c1e-ac97-830744732d60	d1d08c9b-50c1-4020-9031-880d44d05b94	What is the speed of light approximately?	3×10⁶ m/s	3×10⁷ m/s	3×10⁸ m/s	3×10⁹ m/s	C	8	5
2843ec6e-833a-4479-bff9-133de1978749	d1d08c9b-50c1-4020-9031-880d44d05b94	Which gas do plants absorb from the atmosphere?	Oxygen	Nitrogen	Carbon dioxide	Hydrogen	C	8	6
72245bc2-d902-4268-9e9d-3dd6d125ca5b	d1d08c9b-50c1-4020-9031-880d44d05b94	What is the atomic number of Carbon?	4	6	8	12	B	8	7
7fdb7e80-aaac-4ec4-9cf7-bc593bd4e4a8	d1d08c9b-50c1-4020-9031-880d44d05b94	Which force keeps planets in orbit around the Sun?	Friction	Magnetic	Gravity	Nuclear	C	8	8
c4979d62-7df2-4f90-82da-27e4faba172b	d1d08c9b-50c1-4020-9031-880d44d05b94	What is the pH of pure water?	5	6	7	8	C	8	9
2be0efc3-04d5-4b0c-96d7-01b0a3f241cf	d1d08c9b-50c1-4020-9031-880d44d05b94	Which state of matter has a definite shape and volume?	Solid	Liquid	Gas	Plasma	A	8	10
ef8acc76-cd2b-4dac-afed-a826e41c7a39	6b01d835-0134-4da5-a0d0-45a9fec8fbbc	What is the chemical symbol for water?	H2O	CO2	O2	NaCl	A	8	1
fa054c3c-52be-4532-8b6a-adde606ec6c6	6b01d835-0134-4da5-a0d0-45a9fec8fbbc	What is the unit of force?	Joule	Watt	Newton	Pascal	C	8	2
a64d7b1c-a63c-4727-a6e6-db1903560f8a	6b01d835-0134-4da5-a0d0-45a9fec8fbbc	Which planet is known as the Red Planet?	Venus	Mars	Jupiter	Saturn	B	8	3
c9963c3e-c354-405b-a627-7c75dc6e4309	6b01d835-0134-4da5-a0d0-45a9fec8fbbc	What is the powerhouse of the cell?	Nucleus	Ribosome	Mitochondria	Golgi body	C	8	4
16a04756-0adf-4949-8b22-6bcc89823ef7	6b01d835-0134-4da5-a0d0-45a9fec8fbbc	What is the speed of light approximately?	3×10⁶ m/s	3×10⁷ m/s	3×10⁸ m/s	3×10⁹ m/s	C	8	5
0d8adf78-2556-4c52-9503-b50d0448b8dd	6b01d835-0134-4da5-a0d0-45a9fec8fbbc	Which gas do plants absorb from the atmosphere?	Oxygen	Nitrogen	Carbon dioxide	Hydrogen	C	8	6
b2dac9b5-ca22-403d-bcd1-bf1dfea2b870	6b01d835-0134-4da5-a0d0-45a9fec8fbbc	What is the atomic number of Carbon?	4	6	8	12	B	8	7
ba1d94a2-181e-49b6-bdf2-f2267f8a5783	6b01d835-0134-4da5-a0d0-45a9fec8fbbc	Which force keeps planets in orbit around the Sun?	Friction	Magnetic	Gravity	Nuclear	C	8	8
7555e180-857c-4247-81d1-b6b31fd3eb2c	6b01d835-0134-4da5-a0d0-45a9fec8fbbc	What is the pH of pure water?	5	6	7	8	C	8	9
7f0b9484-7e5b-496e-96ca-e7fe420c8595	6b01d835-0134-4da5-a0d0-45a9fec8fbbc	Which state of matter has a definite shape and volume?	Solid	Liquid	Gas	Plasma	A	8	10
\.


--
-- Data for Name: assessment_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assessment_templates (id, title, subject, grade, description, duration, total_marks, difficulty, category, is_active, created_at) FROM stdin;
8e414246-f1da-4bf5-8fe6-717d49cbac40	Mathematics Foundation Test	Mathematics	Grade 6	Basic arithmetic, fractions, and geometry concepts	45	50	Easy	Academic	t	2026-05-01 04:27:53.645875
d90df307-e2e5-454b-b8e5-1441488eb041	Science Basics Quiz	Science	Grade 6	Introduction to physics, chemistry and biology	40	40	Easy	Academic	t	2026-05-01 04:27:53.660769
e50fbcfc-4d65-4c32-8095-c2169f8bc059	English Grammar Assessment	English	Grade 6	Parts of speech, sentence structure, and vocabulary	45	50	Easy	Academic	t	2026-05-01 04:27:53.670033
1cc0721d-7eec-4dfa-92a3-9eb0af4ccf67	Algebra Fundamentals	Mathematics	Grade 7	Linear equations and basic algebra	50	60	Medium	Academic	t	2026-05-01 04:27:53.67826
3e1daa56-e3e5-4ac0-b7df-8b98e5db5674	Life Sciences Test	Science	Grade 7	Cell biology, ecosystems, and human body	45	50	Medium	Academic	t	2026-05-01 04:27:53.68625
7705e386-ed13-4970-8a55-6813cc9cdcae	Reading Comprehension	English	Grade 7	Passages and comprehension questions	50	50	Medium	Academic	t	2026-05-01 04:27:53.694162
6a929d66-b76a-4e76-8c82-f29991b926d7	Geometry & Mensuration	Mathematics	Grade 8	Areas, volumes, and geometric proofs	60	80	Medium	Academic	t	2026-05-01 04:27:53.701911
f07cd8e9-f7f0-4f3b-ab8e-43c6cdaa8518	Physical Sciences	Science	Grade 8	Force, motion, and energy concepts	50	60	Medium	Academic	t	2026-05-01 04:27:53.708915
cc2d0482-cc56-4e46-9c74-41352e2ae150	Creative Writing Skills	English	Grade 8	Essay writing and narrative skills	60	50	Medium	Academic	t	2026-05-01 04:27:53.716587
8bd7c29b-eb6c-4065-aad4-eb1289227e5f	Quadratic Equations	Mathematics	Grade 9	Solving quadratic equations and graphing	60	80	Hard	Academic	t	2026-05-01 04:27:53.724367
a705b19b-dbf2-4ec7-8eed-89e309f748fd	Chemistry Fundamentals	Chemistry	Grade 9	Atoms, molecules, and chemical reactions	55	70	Hard	Academic	t	2026-05-01 04:27:53.733105
e608b1dd-6a4a-45df-b973-18ad0602583c	Physics Mechanics	Physics	Grade 9	Newton's laws and kinematics	55	70	Hard	Academic	t	2026-05-01 04:27:53.7432
884bb46b-475c-479b-91ba-a8ef5c58c318	Trigonometry Test	Mathematics	Grade 10	Trigonometric ratios and identities	60	100	Hard	Academic	t	2026-05-01 04:27:53.751946
d1d08c9b-50c1-4020-9031-880d44d05b94	Organic Chemistry Basics	Chemistry	Grade 10	Hydrocarbons and functional groups	60	80	Hard	Academic	t	2026-05-01 04:27:53.760848
6b01d835-0134-4da5-a0d0-45a9fec8fbbc	Electricity & Magnetism	Physics	Grade 10	Current, circuits, and magnetic effects	60	80	Hard	Academic	t	2026-05-01 04:27:53.768517
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, user_id, entity_type, entity_id, action, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.batches (id, institute_id, batch_code, batch_name, academic_year, status, created_at) FROM stdin;
\.


--
-- Data for Name: behavioural_insights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.behavioural_insights (id, student_id, category, metric, value, description, recorded_at) FROM stdin;
\.


--
-- Data for Name: blueprint_sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blueprint_sections (id, blueprint_id, section_name, section_order, question_type, difficulty_mix, questions_count, marks_per_question, negative_marks, chapter_scope, chapter_ids, optional_questions, instructions, created_at) FROM stdin;
\.


--
-- Data for Name: child_academic_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.child_academic_profiles (id, child_id, board_id, class_id, academic_year, section, roll_number, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: child_exam_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.child_exam_questions (id, child_exam_id, question_text, option_a, option_b, option_c, option_d, correct_option, marks, order_index, created_at) FROM stdin;
\.


--
-- Data for Name: child_exams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.child_exams (id, child_id, title, subject, grade, exam_type, status, score, total_marks, due_date, completed_at, improved_topics, focus_areas, created_at) FROM stdin;
\.


--
-- Data for Name: child_subject_enrollments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.child_subject_enrollments (id, profile_id, subject_id, status, created_at) FROM stdin;
\.


--
-- Data for Name: children; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.children (id, parent_id, student_user_id, name, age, grade, class_section, school_name, roll_number, gender, date_of_birth, blood_group, primary_language, education_board, city, state, special_needs, study_hours, favorite_subjects, weak_subjects, learning_style, career_interest, relationship, school_type, medium_of_instruction, extracurricular, emergency_contact, medical_conditions, lbi_consent, data_collection_consent, dpdp_consent, development_acknowledgment, progress_sharing_consent, consent_date, consent_revoked_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cohorts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cohorts (id, name, role_code, role_name, experience_min, experience_max, location, industry, notes, is_active, created_at, updated_at) FROM stdin;
602d8cb9-5c09-43b7-8ac9-368874b3d221	Fresher Engineers — Global	SDE	Software Engineer	0	1	Global	Tech	Entry-level software engineers, all locations	t	2026-05-01 15:06:22.66691	2026-05-01 15:06:22.66691
907c1071-bf88-4cf5-a062-7008e831abf0	Junior Engineers — India	SDE	Software Engineer	1	3	India	Tech	1–3 yrs experience SDEs in India	t	2026-05-01 15:06:22.66691	2026-05-01 15:06:22.66691
33fea9ac-1389-4469-bf3a-908345be44ba	Mid-level Engineers — Global	SDE	Software Engineer	3	7	Global	Tech	3–7 yrs experience	t	2026-05-01 15:06:22.66691	2026-05-01 15:06:22.66691
30c65757-a7ce-4d97-a9e5-9ad465186b1f	Senior Engineers — Global	SDE	Software Engineer	7	15	Global	Tech	7–15 yrs experience	t	2026-05-01 15:06:22.66691	2026-05-01 15:06:22.66691
2cda3ee5-226b-4a77-b7f9-b5910d386375	Junior PMs — Global	PM	Product Manager	0	2	Global	Tech	APM and PM-1 cohort	t	2026-05-01 15:06:22.66691	2026-05-01 15:06:22.66691
9bf53b12-baba-4f9c-a73a-72e185ddfc0d	Senior PMs — Global	PM	Product Manager	5	15	Global	Tech	Senior + Group PM cohort	t	2026-05-01 15:06:22.66691	2026-05-01 15:06:22.66691
5db94154-ba90-44d0-bb0a-7f4e96a9a271	Data Analysts — India	DA	Data Analyst	0	3	India	Data	Junior data analysts in India	t	2026-05-01 15:06:22.66691	2026-05-01 15:06:22.66691
2329cc6c-ed21-4775-925e-e45cc14fa788	Sales BDR — APAC	SALES	Sales / BD	0	2	APAC	Sales	BDR/SDR cohort APAC	t	2026-05-01 15:06:22.66691	2026-05-01 15:06:22.66691
7dc26712-0bee-4390-8a30-874000b65a22	Senior Sales — Global	SALES	Sales / BD	5	20	Global	Sales	Senior AEs and sales leadership	t	2026-05-01 15:06:22.66691	2026-05-01 15:06:22.66691
\.


--
-- Data for Name: competencies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competencies (id, domain_id, code, name, description, competency_type, proficiency_levels, display_order, is_active, created_at, updated_at, tag) FROM stdin;
e2b719b0-522d-47f1-bd1e-c13a44465b49	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_01	Numerical Aptitude	Number sense, arithmetic accuracy, quantitative reasoning, estimation accuracy, proportional reasoning, financial numeracy	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
ae9dbf32-0f4a-4924-9b2e-905750982ede	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_02	Logical Reasoning	Deductive reasoning, inductive reasoning, abductive reasoning, syllogistic reasoning, analogy mapping, sequence logic	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
cc112339-7074-4598-9935-cbe47fa7a404	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_03	Critical Thinking	Assumption identification, argument evaluation, bias detection, logical consistency, evidence validation, fallacy detection	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
7271fa08-e44a-403a-b149-9d13e0f3688b	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_04	Analytical Thinking	Problem decomposition, root cause analysis, variable isolation, structured thinking, prioritization, causal analysis	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
f8c00def-9a89-48e8-b2ae-72259b14d366	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_05	Problem Solving	Problem identification, hypothesis generation, solution ideation, alternative evaluation, feasibility analysis, iterative refinement	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	5	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_06	Decision Making	Risk assessment, trade-off evaluation, cost-benefit analysis, probabilistic thinking, judgment accuracy, speed-quality balance	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	6	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
4d6c9473-f695-4211-ab51-d1356b090bf4	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_07	Systems Thinking	Interdependency mapping, feedback loop understanding, holistic reasoning, complexity handling, system dynamics	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	7	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
6ca14809-7aca-4b68-abf6-ea3e9370a580	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_08	Conceptual Thinking	Abstraction, generalization, theoretical modeling, principle application	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	8	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
e8fd5615-1881-4dcc-bd44-cd29674d3885	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_09	Research & Data Analysis	Data sourcing, hypothesis testing, statistical reasoning, data interpretation, synthesis, insight extraction	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	9	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
b780467e-639b-4507-991b-eb860e7b68bf	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_10	Creativity & Innovation	Idea fluency, originality, divergent thinking, lateral thinking, recombination ability, experimentation mindset	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	10	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
1fc73df2-2590-4284-8aa3-dca7dd802fcd	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_11	Spatial Intelligence	Visualization, mental rotation, spatial reasoning, diagrammatic interpretation	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	11	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
99390c52-0291-4018-88d4-81a4a4da81e6	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_12	Mechanical Reasoning	Cause-effect understanding, system functionality, physical reasoning, troubleshooting	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	12	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
a3a8013e-f8ae-4887-96c7-2895f8ab481f	9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN_13	Metacognition	Self-monitoring, strategy selection, cognitive flexibility, error awareness, learning regulation	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	13	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
8d5cd822-b4ae-489a-992c-9b5ac87a6105	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_01	Verbal Communication	Clarity, articulation, fluency, pronunciation, tone modulation, vocabulary depth	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
d7525db7-8927-4459-bfa1-ab274367f8df	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_02	Written Communication	Grammar accuracy, syntax control, clarity, conciseness, coherence, structured writing	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
de0175d7-42d0-4d86-88b5-8e6d618be96a	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_03	Business Communication	Email etiquette, formal writing, professional tone, structured documentation, clarity of intent	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
8d4de2da-6e42-40fc-aa60-0d002fd26948	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_04	Presentation Skills	Structuring content, audience engagement, storytelling, visual communication, delivery confidence	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
bf81449b-f2f4-4ee2-9281-e56273b096a7	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_05	Active Listening	Attention, interpretation, paraphrasing, questioning, response relevance	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	5	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
b3b99b67-4747-4943-8f79-e5ec1e0b6d20	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_06	Persuasion & Influence	Argument framing, influencing strategies, objection handling, negotiation framing	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	6	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
a0d4e97b-dfe8-487b-9d15-ad646febb8ff	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_07	Assertiveness	Boundary setting, confident communication, respectful disagreement	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	7	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
cf5a6ec2-d6c0-42af-b554-8787ae398127	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_08	Public Speaking	Stage presence, voice control, audience interaction, confidence under pressure	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	8	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
4fffa5ac-3619-4097-8895-be009f4aabd6	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_09	Storytelling	Narrative structuring, emotional appeal, audience connection	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	9	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
d2b166fa-8308-4de2-88e7-c56fb2bf42a1	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_10	Cross-functional Communication	Adaptability across audiences, clarity in diverse teams	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	10	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
214c70ad-0444-4973-92ba-1ee8991ebf23	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_11	Feedback Communication	Constructive feedback delivery, receptiveness, feedback framing	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	11	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
9e34db04-5933-47c9-bd3f-6b5b34d6bc69	496492ac-9c58-4e5f-91f8-56db774b6c7f	COM_12	Digital Communication	Email/chat clarity, asynchronous communication, brevity, tone appropriateness	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	12	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
5a44cbd3-272e-44ee-a983-c53f268e38a2	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_01	Self-Motivation	Initiative, drive, goal orientation, proactiveness	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
ba4d5a0b-de42-4777-9f17-b440d557a612	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_02	Discipline	Consistency, habit formation, focus maintenance, self-control	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
a34a79c2-cde4-4893-a47b-a76b77713445	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_03	Resilience	Stress tolerance, recovery ability, persistence, adversity handling	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
bc5c127d-fcc1-4d0e-9751-6f227917585b	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_04	Adaptability	Flexibility, openness to change, situational adjustment	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
0f7f4297-1de4-48fc-8497-2e0c797494fa	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_05	Integrity & Ethics	Honesty, ethical reasoning, transparency, fairness	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	5	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
2657d0bc-b2d9-4282-9789-0a633a41b160	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_06	Accountability	Ownership, responsibility, follow-through, reliability	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	6	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
5ca7c62a-f414-4798-91a3-c07be84e6a45	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_07	Self-Awareness	Strength/weakness identification, reflective thinking, emotional awareness	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	7	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
b97e2925-e046-4fb1-9634-db85e2aa19fe	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_08	Emotional Regulation	Emotional control, composure, impulse management	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	8	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
6fe50eb1-8338-4de7-bd6c-31c55dc48c66	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_09	Learning Agility	Curiosity, speed of learning, knowledge transfer, experimentation	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	9	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
11c5184b-9c1b-4e60-a370-b68a68091bdf	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_10	Growth Mindset	Openness to feedback, continuous improvement orientation	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	10	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
23b18e24-73b6-4a39-ac25-6a4ee1734fd7	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_11	Energy Management	Sustained performance, fatigue management, burnout prevention	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	11	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
15663cfd-4327-4d0f-9398-57344ccf0884	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_12	Time Management	Prioritization, scheduling, deadline adherence, time estimation	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	12	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER_13	Stress Management	Performance under pressure, coping strategies	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	13	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
0aed465c-8ea1-4422-b633-0aad6ca4324d	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_01	Interpersonal Skills	Rapport building, relationship management, empathy in interaction	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
02c9688e-2900-4b9d-af2b-f652e20b22f9	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_02	Emotional Intelligence	Empathy, emotional awareness, emotional regulation in social context	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_03	Teamwork & Collaboration	Cooperation, contribution, coordination, mutual support	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
229abe94-2a63-4b86-810d-d247f4b312bc	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_04	Conflict Resolution	Mediation, negotiation, de-escalation strategies	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_05	Cultural Intelligence	Diversity sensitivity, inclusion, cross-cultural adaptability	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	5	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
68a8270d-3c39-4147-8238-df60a0b0b876	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_06	Networking	Relationship building, maintaining professional networks	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	6	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
edea5550-5eaa-4655-b4f1-7233774a6a7c	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_07	Stakeholder Management	Expectation alignment, communication clarity, influence management	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	7	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_08	Customer Orientation	Service mindset, empathy, responsiveness	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	8	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
af883093-9f75-4ba7-82bd-d01ea45888b0	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_09	Trust Building	Credibility, consistency, transparency	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	9	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
bddab227-b2ba-421e-8f14-dad2aa12e5f6	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_10	Social Awareness	Group dynamics understanding, situational awareness	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	10	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
d98acd03-5b09-453e-bca8-960566f07c7b	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_11	Influence Without Authority	Persuasion, alignment building	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	11	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
a573e600-0003-4185-a22f-3c4610414309	0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC_12	Collaboration Across Teams	Cross-functional coordination, integration	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	12	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
26304df3-d564-4d70-96ce-07ca92325f44	9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA_01	Leadership Skills	Vision setting, direction, alignment	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA_02	People Management	Delegation, mentoring, coaching, performance management	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA_03	Strategic Thinking	Long-term planning, foresight, scenario analysis	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
caa13bfa-3c48-4800-b010-e7b5bb1bddbd	9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA_04	Decision Leadership	Decisiveness, accountability in decisions	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
ac3a9ffa-e911-4250-80ee-245231946a8d	9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA_05	Change Management	Leading change, adaptability, transition management	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	5	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
bde3a934-5e03-46af-ba36-9bb1a46954f7	9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA_06	Coaching & Mentoring	Developing others, feedback guidance	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	6	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
6386f4be-6929-4430-b13d-2b80ac8a0bdb	9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA_07	Execution Leadership	Driving results, ensuring outcomes	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	7	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
f7842945-608d-412c-b26a-fc8fa2d405e8	9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA_08	Team Building	Structuring teams, synergy creation	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	8	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
2426d7dd-df6b-4654-ae51-376b0d3247e3	9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA_09	Inspirational Leadership	Motivation, influence, engagement	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	9	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
103d92e2-1d5e-4283-8a91-718a59743655	9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA_10	Entrepreneurial Mindset	Opportunity recognition, calculated risk-taking	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	10	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
0bd37ca4-92b9-4931-86ff-859be789dd67	ae83757d-2afe-40b9-8957-faf586c01914	EXE_01	Task Execution	Ownership, closure, quality of execution	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
f1b8cdfb-21b3-471e-ba3e-7583368e7e05	ae83757d-2afe-40b9-8957-faf586c01914	EXE_02	Project Management	Planning, execution, monitoring, risk tracking	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
abfe5de5-353d-4565-ae4b-a36db9884441	ae83757d-2afe-40b9-8957-faf586c01914	EXE_03	Process Management	Workflow design, process optimization	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	ae83757d-2afe-40b9-8957-faf586c01914	EXE_04	Operational Efficiency	Resource optimization, output maximization	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
86516083-311e-4cc4-9c2d-8da1035c1226	ae83757d-2afe-40b9-8957-faf586c01914	EXE_05	Attention to Detail	Accuracy, precision, quality control	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	5	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
9e2595a9-eec4-44fe-9911-3605e2a6c27e	ae83757d-2afe-40b9-8957-faf586c01914	EXE_06	Multitasking	Managing multiple priorities effectively	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	6	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
c77e5916-e12c-4142-9386-1cd156481617	ae83757d-2afe-40b9-8957-faf586c01914	EXE_07	Resource Management	Efficient utilization of time, tools, people	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	7	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
dadc42b8-4473-46f7-a3c6-187dfc79dbc1	ae83757d-2afe-40b9-8957-faf586c01914	EXE_08	Goal Execution	Outcome delivery, milestone tracking	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	8	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
945a4bbe-c5b6-4f55-a770-7d07b88a987e	ae83757d-2afe-40b9-8957-faf586c01914	EXE_09	Performance Tracking	Monitoring metrics, feedback loops	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	9	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
1df38045-50e0-449b-926a-8d988ff372a5	c9496927-8178-4245-89a2-c91afbd37841	CAR_01	Career Awareness	Goal clarity, career mapping	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
4684e00c-aab3-4e8b-a0d5-818084769a96	c9496927-8178-4245-89a2-c91afbd37841	CAR_02	Professionalism	Workplace etiquette, behavior standards	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
250c4513-34cc-4e5a-b384-c6a7a94ee4a3	c9496927-8178-4245-89a2-c91afbd37841	CAR_03	Employability Skills	Readiness for job roles, workplace adaptability	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
72184930-fe7a-419a-8c8d-45b20a0715bb	c9496927-8178-4245-89a2-c91afbd37841	CAR_04	Interview Skills	Communication, confidence, structured responses	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
7a391dd0-2e40-4536-a7b3-5521a0d6e197	c9496927-8178-4245-89a2-c91afbd37841	CAR_05	Resume & Profile Building	Achievement articulation, structuring	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	5	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
e2682ae1-28b5-40de-a4c0-dfc0f788b086	c9496927-8178-4245-89a2-c91afbd37841	CAR_06	Personal Branding	Self-positioning, visibility	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	6	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
441de88e-ef98-42e8-b681-1a95b08721d6	c9496927-8178-4245-89a2-c91afbd37841	CAR_07	Organizational Awareness	Workplace structure, dynamics understanding	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	7	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	c9496927-8178-4245-89a2-c91afbd37841	CAR_08	Industry Awareness	Market trends, domain knowledge	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	8	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
5ec547f1-09bf-4844-bfbe-90f5a6c34490	cf0ce02f-a6d9-4177-ab94-e28e4404afce	DIG_01	Digital Literacy	Basic computing, internet usage	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
04f45cea-6096-4aad-99c2-fc4952b1f15a	cf0ce02f-a6d9-4177-ab94-e28e4404afce	DIG_02	Data Literacy	Data interpretation, visualization, basic analytics	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
f174dfe6-fa3e-45f2-bad6-f8a098259389	cf0ce02f-a6d9-4177-ab94-e28e4404afce	DIG_03	Technical Skills	Domain-specific technical knowledge	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
500f3c7a-6fc8-403b-bb3e-7c09477c8942	cf0ce02f-a6d9-4177-ab94-e28e4404afce	DIG_04	Digital Communication Tools	Email, collaboration tools, remote work tools	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
fbbbd2de-2901-44f3-95ac-3ae03815cf86	cf0ce02f-a6d9-4177-ab94-e28e4404afce	DIG_05	Technology Adaptability	Learning new tools, tech agility	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	5	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
e5339884-e709-492b-951c-3ebcc488888a	cf0ce02f-a6d9-4177-ab94-e28e4404afce	DIG_06	Automation Awareness	Understanding tools for efficiency	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	6	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
5cac77a8-91c9-46c4-a108-8c9d279cf8d6	cf0ce02f-a6d9-4177-ab94-e28e4404afce	DIG_07	Cyber Awareness	Data privacy, basic cybersecurity hygiene	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	7	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	3a23e24d-11f4-44e7-9eb5-7614d61ed5f7	INN_01	Innovation Skills	Idea validation, prototyping, experimentation	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
7914ba09-3101-4895-bdf9-366e5f881724	3a23e24d-11f4-44e7-9eb5-7614d61ed5f7	INN_02	Entrepreneurial Skills	Opportunity spotting, resourcefulness	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	3a23e24d-11f4-44e7-9eb5-7614d61ed5f7	INN_03	Business Acumen	Market understanding, value creation logic	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
118fd01a-0fb2-4ee7-a4fd-3902037b0f76	3a23e24d-11f4-44e7-9eb5-7614d61ed5f7	INN_04	Financial Literacy	Budgeting, cost understanding, ROI thinking	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
40fac2ff-5ea4-438f-b891-2f900665b80b	3a23e24d-11f4-44e7-9eb5-7614d61ed5f7	INN_05	Design Thinking	User empathy, ideation, prototyping	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	5	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
684ea464-ff78-4c77-8cf8-8894c81fec58	51295242-5447-4e3c-b8cc-cbcc1acb782a	ETH_01	Ethical Reasoning	Moral judgment, fairness, integrity	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
6a407735-42f8-4e8f-82a7-0a678f62d285	51295242-5447-4e3c-b8cc-cbcc1acb782a	ETH_02	Compliance Awareness	Rules, regulations understanding	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
1323078d-84da-4b61-8ca3-2f4fa9bac09b	51295242-5447-4e3c-b8cc-cbcc1acb782a	ETH_03	Social Responsibility	Sustainability awareness, ethical impact	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
573862b8-a47a-494b-b93f-4b1fd5912f24	51295242-5447-4e3c-b8cc-cbcc1acb782a	ETH_04	Accountability Systems	Transparency, reporting responsibility	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
d56fbb88-b402-4c02-b8a3-7715e20093c0	e6a91a38-3a5e-46a3-ae78-af89e09101b6	HEA_01	Physical Wellbeing	Energy levels, health maintenance awareness	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
f735e34e-2752-4ba7-bb9e-8b5c38b57218	e6a91a38-3a5e-46a3-ae78-af89e09101b6	HEA_02	Mental Wellbeing	Stress balance, emotional health awareness	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	e6a91a38-3a5e-46a3-ae78-af89e09101b6	HEA_03	Work-Life Balance	Balance management, sustainability	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
ff0f818b-173d-43ef-a528-ef553787ca5f	e6a91a38-3a5e-46a3-ae78-af89e09101b6	HEA_04	Occupational Health Awareness	Safe work practices	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
a8d775e5-2281-47fb-a984-9dfe240a1841	fd050e00-11aa-46f6-934b-c4c996526774	GLO_01	Global Awareness	Geopolitical awareness, global trends	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
8c949a6a-a93c-4923-99ef-967276e60d8d	fd050e00-11aa-46f6-934b-c4c996526774	GLO_02	Future Skills Orientation	AI awareness, adaptability to future roles	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
5fd97c47-e245-4016-a348-5dd80f708a89	fd050e00-11aa-46f6-934b-c4c996526774	GLO_03	Lifelong Learning Orientation	Continuous upskilling mindset	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
2b60f322-e228-4a5e-bdae-1d9853b1ca1d	fd050e00-11aa-46f6-934b-c4c996526774	GLO_04	Remote Work Readiness	Virtual collaboration, self-management	behavioral	{"1": "Basic awareness", "2": "Guided execution", "3": "Independent execution", "4": "Advanced application", "5": "Strategic mastery"}	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418	behavioral
\.


--
-- Data for Name: competency_assessment_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competency_assessment_items (id, competency_id, code, item_type, difficulty, level, question, expected_time, scoring_type, industry, role_tag, language_code, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: competency_assessment_options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competency_assessment_options (id, item_id, text, score_value, display_order) FROM stdin;
\.


--
-- Data for Name: competency_cluster_map; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competency_cluster_map (cluster_id, competency_id) FROM stdin;
\.


--
-- Data for Name: competency_clusters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competency_clusters (id, name, description, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: competency_domains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competency_domains (id, code, name, description, color, weight, display_order, is_active, created_at, updated_at) FROM stdin;
9eb0010c-0113-46ce-ae6b-6aa9d6bbe46d	CGN	Cognitive & Analytical Intelligence	\N	#2563EB	1	1	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
496492ac-9c58-4e5f-91f8-56db774b6c7f	COM	Communication & Expression	\N	#10B981	1	2	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
fec71b6a-3b0d-453d-99f4-f091619fc5a5	PER	Personal Effectiveness & Self-Management	\N	#EC4899	1	3	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
0428c1c6-67ba-48db-9fa2-17e6a0d1f048	SOC	Social & Interpersonal Intelligence	\N	#F59E0B	1	4	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
9ada369e-e4e5-42e6-bfb6-43e216032a82	LEA	Leadership & Influence	\N	#8B5CF6	1	5	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
ae83757d-2afe-40b9-8957-faf586c01914	EXE	Execution, Operations & Productivity	\N	#0EA5E9	1	6	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
c9496927-8178-4245-89a2-c91afbd37841	CAR	Career & Professional Readiness	\N	#14B8A6	1	7	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
cf0ce02f-a6d9-4177-ab94-e28e4404afce	DIG	Digital, Data & Technology Skills	\N	#6366F1	1	8	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
3a23e24d-11f4-44e7-9eb5-7614d61ed5f7	INN	Innovation, Entrepreneurship & Value Creation	\N	#F97316	1	9	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
51295242-5447-4e3c-b8cc-cbcc1acb782a	ETH	Ethics, Governance & Responsibility	\N	#EF4444	1	10	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
e6a91a38-3a5e-46a3-ae78-af89e09101b6	HEA	Health, Wellbeing & Sustainability	\N	#84CC16	1	11	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
fd050e00-11aa-46f6-934b-c4c996526774	GLO	Global & Future Readiness	\N	#06B6D4	1	12	t	2026-05-01 15:06:22.42418	2026-05-01 15:06:22.42418
\.


--
-- Data for Name: competency_library; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competency_library (id, competency_number, competency_name, domain, sub_domain, description, status, created_at) FROM stdin;
d85be0ca-3436-4e8f-b287-8c44c4eb14bc	30	Problem identification	Cognitive & Analytical Intelligence	Problem Solving	\N	Active	2026-05-01 04:52:02.744343
b8c55e3c-7298-4687-83c2-5034c5ae2af5	31	hypothesis generation	Cognitive & Analytical Intelligence	Problem Solving	\N	Active	2026-05-01 04:52:02.744343
abbdc8e7-eee1-4625-af4f-076b4983cd02	32	solution ideation	Cognitive & Analytical Intelligence	Problem Solving	\N	Active	2026-05-01 04:52:02.744343
81a4941d-6855-4204-9421-535834bea123	33	alternative evaluation	Cognitive & Analytical Intelligence	Problem Solving	\N	Active	2026-05-01 04:52:02.744343
e51000c7-172b-41c2-800b-56cf97b8075c	34	feasibility analysis	Cognitive & Analytical Intelligence	Problem Solving	\N	Active	2026-05-01 04:52:02.744343
9ddf420a-a342-4d55-9d7b-5b137baca09c	47	Abstraction	Cognitive & Analytical Intelligence	Conceptual Thinking	\N	Active	2026-05-01 04:52:02.744343
2b78f435-1220-4a15-bb95-693416252fd4	48	generalization	Cognitive & Analytical Intelligence	Conceptual Thinking	\N	Active	2026-05-01 04:52:02.744343
ec415d92-7b55-49a1-b31e-4aa00ae474e6	49	theoretical modeling	Cognitive & Analytical Intelligence	Conceptual Thinking	\N	Active	2026-05-01 04:52:02.744343
77a33043-0ce3-4d98-9f9e-245b1b9697b8	50	principle application	Cognitive & Analytical Intelligence	Conceptual Thinking	\N	Active	2026-05-01 04:52:02.744343
b9b8a38f-b124-481a-9d16-1828cf37cea3	51	Data sourcing	Cognitive & Analytical Intelligence	Research & Data Analysis	\N	Active	2026-05-01 04:52:02.744343
bada8db2-351a-4aaf-ad79-09f7ba1232e8	52	hypothesis testing	Cognitive & Analytical Intelligence	Research & Data Analysis	\N	Active	2026-05-01 04:52:02.744343
cd391ed0-d374-4e81-a3a2-23f1e3d95e84	53	statistical reasoning	Cognitive & Analytical Intelligence	Research & Data Analysis	\N	Active	2026-05-01 04:52:02.744343
da07a92a-5a40-4b63-9892-74447a98a8ab	54	data interpretation	Cognitive & Analytical Intelligence	Research & Data Analysis	\N	Active	2026-05-01 04:52:02.744343
29cf63c5-5723-4dbd-8b24-63c9df964d45	55	synthesis	Cognitive & Analytical Intelligence	Research & Data Analysis	\N	Active	2026-05-01 04:52:02.744343
a005d5a9-6906-4d9e-856f-be6d4e80b6b4	56	insight extraction	Cognitive & Analytical Intelligence	Research & Data Analysis	\N	Active	2026-05-01 04:52:02.744343
c72681d0-c4a6-4a20-87c8-0dd1fe4a8c46	57	Idea fluency	Cognitive & Analytical Intelligence	Creativity & Innovation	\N	Active	2026-05-01 04:52:02.744343
c3feaed7-da66-4dbf-9272-a5b865f26e60	58	originality	Cognitive & Analytical Intelligence	Creativity & Innovation	\N	Active	2026-05-01 04:52:02.744343
09e62d7f-11f0-4af9-ba31-953cc51d4f38	59	divergent thinking	Cognitive & Analytical Intelligence	Creativity & Innovation	\N	Active	2026-05-01 04:52:02.744343
0bd801ef-081c-4525-b768-c0eba07c6236	60	lateral thinking	Cognitive & Analytical Intelligence	Creativity & Innovation	\N	Active	2026-05-01 04:52:02.744343
bef4c2de-584a-41e6-8af2-b8d3cc1147fb	61	recombination ability	Cognitive & Analytical Intelligence	Creativity & Innovation	\N	Active	2026-05-01 04:52:02.744343
1458e29f-be7b-4e7e-8412-66c34747e56a	62	experimentation mindset	Cognitive & Analytical Intelligence	Creativity & Innovation	\N	Active	2026-05-01 04:52:02.744343
e012adcf-65b1-4ecb-bda4-df20d9fbc599	63	Visualization	Cognitive & Analytical Intelligence	Spatial Intelligence	\N	Active	2026-05-01 04:52:02.744343
0a284d4c-95a4-4987-b1b9-cc018385bb25	64	mental rotation	Cognitive & Analytical Intelligence	Spatial Intelligence	\N	Active	2026-05-01 04:52:02.744343
532b3015-6d79-44cb-8a29-e940d59bba18	65	spatial reasoning	Cognitive & Analytical Intelligence	Spatial Intelligence	\N	Active	2026-05-01 04:52:02.744343
230d7234-fcee-411f-9fc9-3317f544e9bc	66	diagrammatic interpretation	Cognitive & Analytical Intelligence	Spatial Intelligence	\N	Active	2026-05-01 04:52:02.744343
61633e02-98bb-4ef3-88c8-ee3eb6582853	67	Cause-effect understanding	Cognitive & Analytical Intelligence	Mechanical Reasoning	\N	Active	2026-05-01 04:52:02.744343
2646bed5-38e9-40ab-a8e1-2fe55383f1cd	68	system functionality	Cognitive & Analytical Intelligence	Mechanical Reasoning	\N	Active	2026-05-01 04:52:02.744343
bd87f7a0-bc16-4c9e-8bac-b1c119dd1177	69	physical reasoning	Cognitive & Analytical Intelligence	Mechanical Reasoning	\N	Active	2026-05-01 04:52:02.744343
03ae0d2a-b786-4644-b53b-c7a681fc686e	70	troubleshooting	Cognitive & Analytical Intelligence	Mechanical Reasoning	\N	Active	2026-05-01 04:52:02.744343
07ec24da-cd48-4883-b4bc-d887f91db7a1	71	Self-monitoring	Cognitive & Analytical Intelligence	Metacognition	\N	Active	2026-05-01 04:52:02.744343
70d57beb-d781-41aa-b5f1-d78e573f7e7b	72	strategy selection	Cognitive & Analytical Intelligence	Metacognition	\N	Active	2026-05-01 04:52:02.744343
4591bfdc-1394-440e-80df-6e3394cee4f3	73	cognitive flexibility	Cognitive & Analytical Intelligence	Metacognition	\N	Active	2026-05-01 04:52:02.744343
dab58474-8322-4b05-9f3e-0050934018e3	74	error awareness	Cognitive & Analytical Intelligence	Metacognition	\N	Active	2026-05-01 04:52:02.744343
00d9c6c6-6ac8-4f0d-9486-1ffe0613888b	75	learning regulation	Cognitive & Analytical Intelligence	Metacognition	\N	Active	2026-05-01 04:52:02.744343
7ba12342-2b95-468e-822c-4a383550f8f4	76	Clarity	Communication & Expression	Verbal Communication	\N	Active	2026-05-01 04:52:02.744343
2b410237-487c-4583-8411-188497b4473d	77	articulation	Communication & Expression	Verbal Communication	\N	Active	2026-05-01 04:52:02.744343
2c416f64-0514-462c-b3c5-9a1254edc562	78	fluency	Communication & Expression	Verbal Communication	\N	Active	2026-05-01 04:52:02.744343
31d96db7-40fd-42e5-906f-a51fb99be722	79	pronunciation	Communication & Expression	Verbal Communication	\N	Active	2026-05-01 04:52:02.744343
d78eb3f5-1b3f-49ed-92ae-e223b7522e46	80	tone modulation	Communication & Expression	Verbal Communication	\N	Active	2026-05-01 04:52:02.744343
8793ff57-4222-4302-b893-411e11e2f883	81	vocabulary depth	Communication & Expression	Verbal Communication	\N	Active	2026-05-01 04:52:02.744343
600b78a9-60e6-4022-a2bb-f5afb2b6b81e	82	Grammar accuracy	Communication & Expression	Written Communication	\N	Active	2026-05-01 04:52:02.744343
4862ba95-ea91-4302-b874-33b6fc7551a3	83	syntax control	Communication & Expression	Written Communication	\N	Active	2026-05-01 04:52:02.744343
f361d845-c7ca-4be3-a2da-73e95a30e81d	84	clarity	Communication & Expression	Written Communication	\N	Active	2026-05-01 04:52:02.744343
0f9f2a7d-9910-4f92-afc8-2096990421a5	85	conciseness	Communication & Expression	Written Communication	\N	Active	2026-05-01 04:52:02.744343
a02c1b09-81a2-482e-8f25-95277555ce72	86	coherence	Communication & Expression	Written Communication	\N	Active	2026-05-01 04:52:02.744343
b01141b1-4f41-41e0-b25d-8ecfe757fb83	87	structured writing	Communication & Expression	Written Communication	\N	Active	2026-05-01 04:52:02.744343
fddfef76-6c18-436e-b1c0-41e3e37b3ce5	88	Email etiquette	Communication & Expression	Business Communication	\N	Active	2026-05-01 04:52:02.744343
5ad9a32f-8716-4d67-b435-8cdb133cd8e5	89	formal writing	Communication & Expression	Business Communication	\N	Active	2026-05-01 04:52:02.744343
b4082c9c-4832-49a3-8060-8a48ea2918b6	90	professional tone	Communication & Expression	Business Communication	\N	Active	2026-05-01 04:52:02.744343
cfa5fc33-99b0-41bb-ab82-8dc827d5d1e8	91	structured documentation	Communication & Expression	Business Communication	\N	Active	2026-05-01 04:52:02.744343
f2d4459a-832a-4b26-b1b9-ff11b2ddcb0e	92	clarity of intent	Communication & Expression	Business Communication	\N	Active	2026-05-01 04:52:02.744343
d35114c1-4f5a-4f3b-99ac-379cb6363a74	93	Structuring content	Communication & Expression	Presentation Skills	\N	Active	2026-05-01 04:52:02.744343
2de60507-f474-420f-9698-dbb6c28d8221	94	audience engagement	Communication & Expression	Presentation Skills	\N	Active	2026-05-01 04:52:02.744343
1cf94199-783a-4278-9adb-74a820374e63	95	storytelling	Communication & Expression	Presentation Skills	\N	Active	2026-05-01 04:52:02.744343
0860bdc8-0baf-4875-b3a7-9ea6bfe48e86	96	visual communication	Communication & Expression	Presentation Skills	\N	Active	2026-05-01 04:52:02.744343
63d98d69-9483-437d-895d-b1793063d115	97	delivery confidence	Communication & Expression	Presentation Skills	\N	Active	2026-05-01 04:52:02.744343
9f5ca7ed-0813-4df5-b54c-39f76138dccd	98	Attention	Communication & Expression	Active Listening	\N	Active	2026-05-01 04:52:02.744343
a62e7878-7516-4eba-be2c-13399cdee4a5	99	interpretation	Communication & Expression	Active Listening	\N	Active	2026-05-01 04:52:02.744343
08f48203-3550-4376-9514-f27269dabd12	100	paraphrasing	Communication & Expression	Active Listening	\N	Active	2026-05-01 04:52:02.744343
12d7b65d-27c5-4059-84e9-700cb2bcf02f	101	questioning	Communication & Expression	Active Listening	\N	Active	2026-05-01 04:52:02.744343
5321f0d1-a990-4915-b14a-8942c855897a	102	response relevance	Communication & Expression	Active Listening	\N	Active	2026-05-01 04:52:02.744343
8b5c8c1c-1a15-4b65-8ebc-324b5da22cde	103	Argument framing	Communication & Expression	Persuasion & Influence	\N	Active	2026-05-01 04:52:02.744343
bbe4cb74-92b9-4e19-89c9-b5d02fb879f3	104	influencing strategies	Communication & Expression	Persuasion & Influence	\N	Active	2026-05-01 04:52:02.744343
4cb69732-d76d-4787-8b05-295e250a383c	105	objection handling	Communication & Expression	Persuasion & Influence	\N	Active	2026-05-01 04:52:02.744343
eed76c7f-c157-4584-ac95-24ec154a3989	106	negotiation framing	Communication & Expression	Persuasion & Influence	\N	Active	2026-05-01 04:52:02.744343
fa197e8a-0177-46b3-a1b7-4d608ff77714	107	Boundary setting	Communication & Expression	Assertiveness	\N	Active	2026-05-01 04:52:02.744343
7c20f92f-5194-403c-8e9b-59295a705301	108	confident communication	Communication & Expression	Assertiveness	\N	Active	2026-05-01 04:52:02.744343
8b65a248-9900-4268-8e4a-e1fd5fb4ca35	109	respectful disagreement	Communication & Expression	Assertiveness	\N	Active	2026-05-01 04:52:02.744343
ba966614-9c58-40b5-8881-4345df764db1	110	Stage presence	Communication & Expression	Public Speaking	\N	Active	2026-05-01 04:52:02.744343
215df2ab-02ac-4146-9cf3-508f15ed029a	111	voice control	Communication & Expression	Public Speaking	\N	Active	2026-05-01 04:52:02.744343
c00a13a9-e258-4a8a-967a-e30e3bccf43b	112	audience interaction	Communication & Expression	Public Speaking	\N	Active	2026-05-01 04:52:02.744343
cd2b4dbd-c971-44b7-844c-f60f91c128c3	113	confidence under pressure	Communication & Expression	Public Speaking	\N	Active	2026-05-01 04:52:02.744343
52301470-f2bf-4f46-a545-87591c7c2729	114	Narrative structuring	Communication & Expression	Storytelling	\N	Active	2026-05-01 04:52:02.744343
1db2f035-3f58-4523-8d79-a8100794f6bd	115	emotional appeal	Communication & Expression	Storytelling	\N	Active	2026-05-01 04:52:02.744343
065fea9b-dbe1-402e-82d9-2f5800709584	116	audience connection	Communication & Expression	Storytelling	\N	Active	2026-05-01 04:52:02.744343
a8d66238-3bb1-4a00-8fa6-6ac4fdee87c7	117	Adaptability across audiences	Communication & Expression	Cross-functional Communication	\N	Active	2026-05-01 04:52:02.744343
0d9e00b5-f9d6-46ac-bc45-f0cd4e448795	118	clarity in diverse teams	Communication & Expression	Cross-functional Communication	\N	Active	2026-05-01 04:52:02.744343
c2f2014a-959c-4197-8be2-51d9ba7ddf2a	119	Constructive feedback delivery	Communication & Expression	Feedback Communication	\N	Active	2026-05-01 04:52:02.744343
b6b45c00-dcd8-427c-a029-ae08562649e7	120	receptiveness	Communication & Expression	Feedback Communication	\N	Active	2026-05-01 04:52:02.744343
9553fb64-2409-4629-8a8d-2dab5f48cea2	121	feedback framing	Communication & Expression	Feedback Communication	\N	Active	2026-05-01 04:52:02.744343
f22988ff-538c-44f3-b056-e4d298f95733	122	Email/chat clarity	Communication & Expression	Digital Communication	\N	Active	2026-05-01 04:52:02.744343
3595cc07-f464-4c85-bc18-0a6c651313ba	123	asynchronous communication	Communication & Expression	Digital Communication	\N	Active	2026-05-01 04:52:02.744343
ff7b5aa9-1ffc-4d6c-be54-fd0290b0abd9	124	brevity	Communication & Expression	Digital Communication	\N	Active	2026-05-01 04:52:02.744343
6e0b0e31-6f1f-4045-ab69-b50714f3f99e	125	tone appropriateness	Communication & Expression	Digital Communication	\N	Active	2026-05-01 04:52:02.744343
ca0b48fd-538d-4cd5-9ce8-f2fd7b2bb08f	126	Initiative	Personal Effectiveness & Self-Management	Self-Motivation	\N	Active	2026-05-01 04:52:02.744343
f46a1f55-2daf-432c-95b9-f6fba7872992	127	drive	Personal Effectiveness & Self-Management	Self-Motivation	\N	Active	2026-05-01 04:52:02.744343
6e5886f8-a152-4762-aba2-d92310c7aa91	128	goal orientation	Personal Effectiveness & Self-Management	Self-Motivation	\N	Active	2026-05-01 04:52:02.744343
c66e4c42-b573-4c1d-b1fa-f92ee398f5f3	129	proactiveness	Personal Effectiveness & Self-Management	Self-Motivation	\N	Active	2026-05-01 04:52:02.744343
ab85771b-095a-4c27-9664-12e7cb96070c	130	Consistency	Personal Effectiveness & Self-Management	Discipline	\N	Active	2026-05-01 04:52:02.744343
326d0935-c710-4ae4-a11d-186f306c0987	131	habit formation	Personal Effectiveness & Self-Management	Discipline	\N	Active	2026-05-01 04:52:02.744343
a6760273-8ed8-4c26-8904-b8f83b237850	132	focus maintenance	Personal Effectiveness & Self-Management	Discipline	\N	Active	2026-05-01 04:52:02.744343
7a99c585-4b1c-409f-9970-07514537964a	133	self-control	Personal Effectiveness & Self-Management	Discipline	\N	Active	2026-05-01 04:52:02.744343
eecc9c9e-9fe8-46f3-962d-a239ec67d189	134	Stress tolerance	Personal Effectiveness & Self-Management	Resilience	\N	Active	2026-05-01 04:52:02.744343
c9ce9798-55ed-4169-b553-a88dcec16299	135	recovery ability	Personal Effectiveness & Self-Management	Resilience	\N	Active	2026-05-01 04:52:02.744343
6e6f63f4-3716-4ab8-96d2-f61b15e463db	136	persistence	Personal Effectiveness & Self-Management	Resilience	\N	Active	2026-05-01 04:52:02.744343
2c60bfd9-9edf-43fe-b6d6-f89183ff4bd8	137	adversity handling	Personal Effectiveness & Self-Management	Resilience	\N	Active	2026-05-01 04:52:02.744343
a859a18d-847c-49f6-ae28-91f29df2d84a	138	Flexibility	Personal Effectiveness & Self-Management	Adaptability	\N	Active	2026-05-01 04:52:02.744343
cfb8743f-87f7-4a63-a41b-36855c7bf352	139	openness to change	Personal Effectiveness & Self-Management	Adaptability	\N	Active	2026-05-01 04:52:02.744343
4fe9cd19-1665-45ae-8a32-ab570069fb01	140	situational adjustment	Personal Effectiveness & Self-Management	Adaptability	\N	Active	2026-05-01 04:52:02.744343
04fa4dde-055b-4e1c-9c40-0cc11e4804d5	141	Honesty	Personal Effectiveness & Self-Management	Integrity & Ethics	\N	Active	2026-05-01 04:52:02.744343
540f215e-17b9-4689-89fe-cd8a99d5097b	142	ethical reasoning	Personal Effectiveness & Self-Management	Integrity & Ethics	\N	Active	2026-05-01 04:52:02.744343
fbdba334-65b0-4d5d-bc88-660c66ea45d4	143	transparency	Personal Effectiveness & Self-Management	Integrity & Ethics	\N	Active	2026-05-01 04:52:02.744343
3e97659d-53b1-4d51-aae3-e3f6175aa714	144	fairness	Personal Effectiveness & Self-Management	Integrity & Ethics	\N	Active	2026-05-01 04:52:02.744343
adf48a91-9990-485d-9a68-5f88dc066519	145	Ownership	Personal Effectiveness & Self-Management	Accountability	\N	Active	2026-05-01 04:52:02.744343
d5698034-e42e-461c-925a-7f5069fb5e37	146	responsibility	Personal Effectiveness & Self-Management	Accountability	\N	Active	2026-05-01 04:52:02.744343
7b9c5427-758d-4203-be96-5e71067c73eb	147	follow-through	Personal Effectiveness & Self-Management	Accountability	\N	Active	2026-05-01 04:52:02.744343
44f341cc-d8c8-43ec-974e-9c025e8b3dca	148	reliability	Personal Effectiveness & Self-Management	Accountability	\N	Active	2026-05-01 04:52:02.744343
14766a8b-9184-4a8d-9394-238e88ffb66d	149	Strength/weakness identification	Personal Effectiveness & Self-Management	Self-Awareness	\N	Active	2026-05-01 04:52:02.744343
43d9bb60-a021-473c-b7d1-3e6199452378	150	reflective thinking	Personal Effectiveness & Self-Management	Self-Awareness	\N	Active	2026-05-01 04:52:02.744343
2b8e3882-15cd-4963-bffb-6d83b84caf10	151	emotional awareness	Personal Effectiveness & Self-Management	Self-Awareness	\N	Active	2026-05-01 04:52:02.744343
042a37b8-dcd7-44b8-beb0-fe2be314778e	152	Emotional control	Personal Effectiveness & Self-Management	Emotional Regulation	\N	Active	2026-05-01 04:52:02.744343
ee58b3f9-2b15-4bea-b4c5-81e1673d3e99	153	composure	Personal Effectiveness & Self-Management	Emotional Regulation	\N	Active	2026-05-01 04:52:02.744343
2fc230ee-e00a-4f20-bedb-df997381c05b	154	impulse management	Personal Effectiveness & Self-Management	Emotional Regulation	\N	Active	2026-05-01 04:52:02.744343
bde77785-daf2-484a-aa0f-681cb7ef29a0	155	Curiosity	Personal Effectiveness & Self-Management	Learning Agility	\N	Active	2026-05-01 04:52:02.744343
bbb7682a-e045-4501-8990-146aaff8c557	156	speed of learning	Personal Effectiveness & Self-Management	Learning Agility	\N	Active	2026-05-01 04:52:02.744343
8c2c5451-2cea-40ac-8122-99003eeac222	157	knowledge transfer	Personal Effectiveness & Self-Management	Learning Agility	\N	Active	2026-05-01 04:52:02.744343
62c8fc77-f52b-440c-af7f-8c420e321235	158	experimentation	Personal Effectiveness & Self-Management	Learning Agility	\N	Active	2026-05-01 04:52:02.744343
e4696193-244c-4070-bf72-b0f661da22fc	159	Openness to feedback	Personal Effectiveness & Self-Management	Growth Mindset	\N	Active	2026-05-01 04:52:02.744343
204683e1-dda9-4fa2-89b3-dd71ca86664a	160	continuous improvement orientation	Personal Effectiveness & Self-Management	Growth Mindset	\N	Active	2026-05-01 04:52:02.744343
2aa989f7-d310-4de2-b84d-f0dc80e3408c	161	Sustained performance	Personal Effectiveness & Self-Management	Energy Management	\N	Active	2026-05-01 04:52:02.744343
1e8b35e6-fc9a-4cda-bb97-e6dabcda5931	162	fatigue management	Personal Effectiveness & Self-Management	Energy Management	\N	Active	2026-05-01 04:52:02.744343
e278ab53-c9d2-4c0c-8850-21c9ac0bb150	163	burnout prevention	Personal Effectiveness & Self-Management	Energy Management	\N	Active	2026-05-01 04:52:02.744343
8da3c7f3-ff05-4e9b-a1cc-c7d97dc507c0	164	Prioritization	Personal Effectiveness & Self-Management	Time Management	\N	Active	2026-05-01 04:52:02.744343
f84a3283-ba74-425d-b725-6adc9a1c8f39	165	scheduling	Personal Effectiveness & Self-Management	Time Management	\N	Active	2026-05-01 04:52:02.744343
7941f95a-8d9d-484e-be52-aedf9398d701	166	deadline adherence	Personal Effectiveness & Self-Management	Time Management	\N	Active	2026-05-01 04:52:02.744343
9ee838ce-ac27-494f-97b5-6734d6bd9ee2	167	time estimation	Personal Effectiveness & Self-Management	Time Management	\N	Active	2026-05-01 04:52:02.744343
4d2ab885-b45f-4fbd-a0be-f50331fed510	168	Performance under pressure	Personal Effectiveness & Self-Management	Stress Management	\N	Active	2026-05-01 04:52:02.744343
26fffc77-3720-4e5f-9ecd-5a75cf8ba6b1	169	coping strategies	Personal Effectiveness & Self-Management	Stress Management	\N	Active	2026-05-01 04:52:02.744343
4b4cd126-e68f-4c47-b4fe-29cc6ed532d5	170	Rapport building	Social & Interpersonal Intelligence	Interpersonal Skills	\N	Active	2026-05-01 04:52:02.744343
e9ddc0f3-0fa3-48c3-b95b-8223bb2e55bf	171	relationship management	Social & Interpersonal Intelligence	Interpersonal Skills	\N	Active	2026-05-01 04:52:02.744343
d294053c-f1f8-4317-b071-88340adbf391	172	empathy in interaction	Social & Interpersonal Intelligence	Interpersonal Skills	\N	Active	2026-05-01 04:52:02.744343
e7ab3534-fd8b-4a7d-8c29-caccf8c134d7	173	Empathy	Social & Interpersonal Intelligence	Emotional Intelligence	\N	Active	2026-05-01 04:52:02.744343
7d67635e-3aa1-4795-9821-df7ac52d9187	174	emotional awareness	Social & Interpersonal Intelligence	Emotional Intelligence	\N	Active	2026-05-01 04:52:02.744343
53d64ca9-38fd-417b-b492-0537d776037c	175	emotional regulation in social context	Social & Interpersonal Intelligence	Emotional Intelligence	\N	Active	2026-05-01 04:52:02.744343
7dc10f9b-1a4b-401e-8ddc-efa1d6805425	176	Cooperation	Social & Interpersonal Intelligence	Teamwork & Collaboration	\N	Active	2026-05-01 04:52:02.744343
d417f2c8-8f43-4dda-afa7-fbcc2f2b37bd	177	contribution	Social & Interpersonal Intelligence	Teamwork & Collaboration	\N	Active	2026-05-01 04:52:02.744343
b32e7f86-3e59-421b-9b2b-4cccb74bf842	178	coordination	Social & Interpersonal Intelligence	Teamwork & Collaboration	\N	Active	2026-05-01 04:52:02.744343
a399c274-cceb-4cdb-8266-9a944df276ac	179	mutual support	Social & Interpersonal Intelligence	Teamwork & Collaboration	\N	Active	2026-05-01 04:52:02.744343
4d920126-5e55-4d50-ae3a-8e0a5aad47c2	180	Mediation	Social & Interpersonal Intelligence	Conflict Resolution	\N	Active	2026-05-01 04:52:02.744343
3e8cefaa-9a39-49b2-9d9c-130d9801a316	181	negotiation	Social & Interpersonal Intelligence	Conflict Resolution	\N	Active	2026-05-01 04:52:02.744343
cef6ca35-e55d-4845-bfe6-a96e3216708b	182	de-escalation strategies	Social & Interpersonal Intelligence	Conflict Resolution	\N	Active	2026-05-01 04:52:02.744343
b8aba321-c906-4fcb-8126-459d2f24cf28	183	Diversity sensitivity	Social & Interpersonal Intelligence	Cultural Intelligence	\N	Active	2026-05-01 04:52:02.744343
0529b00b-7083-460a-a88f-8257a55e22f7	184	inclusion	Social & Interpersonal Intelligence	Cultural Intelligence	\N	Active	2026-05-01 04:52:02.744343
ab89fc16-f0ca-47de-a0f6-03edf865e061	185	cross-cultural adaptability	Social & Interpersonal Intelligence	Cultural Intelligence	\N	Active	2026-05-01 04:52:02.744343
80c5feb1-685b-466c-bdad-b2f2b35670f3	186	Relationship building	Social & Interpersonal Intelligence	Networking	\N	Active	2026-05-01 04:52:02.744343
b659cd83-d1c4-4d78-aada-82e2bdc97d4f	187	maintaining professional networks	Social & Interpersonal Intelligence	Networking	\N	Active	2026-05-01 04:52:02.744343
94c5a676-7ad3-4c3e-8557-56b917eab6b8	188	Expectation alignment	Social & Interpersonal Intelligence	Stakeholder Management	\N	Active	2026-05-01 04:52:02.744343
66b94fdd-2158-4a08-a844-af3198f398c4	189	communication clarity	Social & Interpersonal Intelligence	Stakeholder Management	\N	Active	2026-05-01 04:52:02.744343
5d7c171e-f81e-40c4-b7fa-b6aa3d67ac67	190	influence management	Social & Interpersonal Intelligence	Stakeholder Management	\N	Active	2026-05-01 04:52:02.744343
70149e5c-791b-4914-8989-665e2b5b501b	191	Service mindset	Social & Interpersonal Intelligence	Customer Orientation	\N	Active	2026-05-01 04:52:02.744343
1111bd61-28c7-4a4e-adfc-3eed044d27ab	192	empathy	Social & Interpersonal Intelligence	Customer Orientation	\N	Active	2026-05-01 04:52:02.744343
b4b1558f-2999-40d8-b040-f62b35e71976	193	responsiveness	Social & Interpersonal Intelligence	Customer Orientation	\N	Active	2026-05-01 04:52:02.744343
27509dcd-962b-4d3a-ad2a-66fd6279e469	194	Credibility	Social & Interpersonal Intelligence	Trust Building	\N	Active	2026-05-01 04:52:02.744343
b662b14b-0ad7-4156-87ea-9965d9240e0f	195	consistency	Social & Interpersonal Intelligence	Trust Building	\N	Active	2026-05-01 04:52:02.744343
63ebfade-d56e-42b7-952e-acf8ee17c210	196	transparency	Social & Interpersonal Intelligence	Trust Building	\N	Active	2026-05-01 04:52:02.744343
3770449c-bdd8-4500-8c41-5a77c7e39dae	197	Group dynamics understanding	Social & Interpersonal Intelligence	Social Awareness	\N	Active	2026-05-01 04:52:02.744343
02170f2a-7599-4dc9-b155-bae66efa170d	198	situational awareness	Social & Interpersonal Intelligence	Social Awareness	\N	Active	2026-05-01 04:52:02.744343
8e126e04-582e-42ff-ba41-29866993ba88	199	Persuasion	Social & Interpersonal Intelligence	Influence Without Authority	\N	Active	2026-05-01 04:52:02.744343
ba823099-99fb-4d6e-97a0-1e234d640fef	200	alignment building	Social & Interpersonal Intelligence	Influence Without Authority	\N	Active	2026-05-01 04:52:02.744343
3537e4ab-8850-4810-8db5-bd6289bfca9b	201	Cross-functional coordination	Social & Interpersonal Intelligence	Collaboration Across Teams	\N	Active	2026-05-01 04:52:02.744343
8ec26146-e532-4667-bb32-59d721c25e30	202	integration	Social & Interpersonal Intelligence	Collaboration Across Teams	\N	Active	2026-05-01 04:52:02.744343
250cbac2-3e2e-449d-8db9-ecd42244c2ca	203	Vision setting	Leadership & Influence	Leadership Skills	\N	Active	2026-05-01 04:52:02.744343
7ea24234-d6c2-4e82-9d21-ecc724ffca84	204	direction	Leadership & Influence	Leadership Skills	\N	Active	2026-05-01 04:52:02.744343
bacc4b16-3fe1-4f4b-a4cc-23bec87f00c9	205	alignment	Leadership & Influence	Leadership Skills	\N	Active	2026-05-01 04:52:02.744343
cdeebe26-cbce-4a8a-b44a-346419cd86b8	206	Delegation	Leadership & Influence	People Management	\N	Active	2026-05-01 04:52:02.744343
e43f7552-e766-47c0-8d44-c2141d432764	207	mentoring	Leadership & Influence	People Management	\N	Active	2026-05-01 04:52:02.744343
cf1138cd-1714-40c0-8765-601041ebdf19	208	coaching	Leadership & Influence	People Management	\N	Active	2026-05-01 04:52:02.744343
f33b2361-4614-4c43-8035-b9b33ad0f515	209	performance management	Leadership & Influence	People Management	\N	Active	2026-05-01 04:52:02.744343
9d869e42-cb58-4bac-9b5f-bb81c0bb6098	210	Long-term planning	Leadership & Influence	Strategic Thinking	\N	Active	2026-05-01 04:52:02.744343
db3cf54f-f742-40b7-9e6c-fbe02344b754	211	foresight	Leadership & Influence	Strategic Thinking	\N	Active	2026-05-01 04:52:02.744343
61487159-f75e-4d92-99b9-291012e63ed6	212	scenario analysis	Leadership & Influence	Strategic Thinking	\N	Active	2026-05-01 04:52:02.744343
36916d8f-bb31-4773-a8b9-bba1412012a1	213	Decisiveness	Leadership & Influence	Decision Leadership	\N	Active	2026-05-01 04:52:02.744343
67ed50b9-d2e9-4e26-9416-2ba90ac5794a	214	accountability in decisions	Leadership & Influence	Decision Leadership	\N	Active	2026-05-01 04:52:02.744343
ff9571be-c412-4d5d-9a1f-5484119d62e0	215	Leading change	Leadership & Influence	Change Management	\N	Active	2026-05-01 04:52:02.744343
7530811d-59c8-4650-a365-f214b061c46b	216	adaptability	Leadership & Influence	Change Management	\N	Active	2026-05-01 04:52:02.744343
0d7bf860-271b-4998-bde7-9175a588d6c4	217	transition management	Leadership & Influence	Change Management	\N	Active	2026-05-01 04:52:02.744343
a3fd7500-80a8-4c14-ae00-180b9f34eb61	218	Developing others	Leadership & Influence	Coaching & Mentoring	\N	Active	2026-05-01 04:52:02.744343
a0dd5354-5081-4701-a1db-f13c6623b1b5	219	feedback guidance	Leadership & Influence	Coaching & Mentoring	\N	Active	2026-05-01 04:52:02.744343
dd3a9e0f-27d9-41e5-9893-e713e78492bf	220	Driving results	Leadership & Influence	Execution Leadership	\N	Active	2026-05-01 04:52:02.744343
ba36798f-9996-48b3-b0f2-fe3d75b5160c	221	ensuring outcomes	Leadership & Influence	Execution Leadership	\N	Active	2026-05-01 04:52:02.744343
570ad5f5-f90c-46dc-b95c-8be7b4520acf	222	Structuring teams	Leadership & Influence	Team Building	\N	Active	2026-05-01 04:52:02.744343
40f9af00-f375-4cb1-85fb-f20255f0a6ff	223	synergy creation	Leadership & Influence	Team Building	\N	Active	2026-05-01 04:52:02.744343
9dc19cac-0d1d-456a-96dd-b3522520cc1e	224	Motivation	Leadership & Influence	Inspirational Leadership	\N	Active	2026-05-01 04:52:02.744343
fd0df803-a09e-402c-846a-5e0b0fec5c30	225	influence	Leadership & Influence	Inspirational Leadership	\N	Active	2026-05-01 04:52:02.744343
c6eee42c-1f7e-44b8-903f-01e996fd9925	226	engagement	Leadership & Influence	Inspirational Leadership	\N	Active	2026-05-01 04:52:02.744343
c71d962d-2d71-4d12-b384-57c27b804bdd	227	Opportunity recognition	Leadership & Influence	Entrepreneurial Mindset	\N	Active	2026-05-01 04:52:02.744343
ff2094ad-f7c1-4dff-a616-bf2ea5bc394e	228	calculated risk-taking	Leadership & Influence	Entrepreneurial Mindset	\N	Active	2026-05-01 04:52:02.744343
82ad3883-de27-40b9-9186-6c5725013074	229	Ownership	Execution, Operations & Productivity	Task Execution	\N	Active	2026-05-01 04:52:02.744343
70ca0e43-5c67-4e14-bb40-c50721c6b8bf	230	closure	Execution, Operations & Productivity	Task Execution	\N	Active	2026-05-01 04:52:02.744343
a173083b-0f70-41bc-9d57-f093bcd77721	231	quality of execution	Execution, Operations & Productivity	Task Execution	\N	Active	2026-05-01 04:52:02.744343
2e2aff95-a77e-4107-a3de-12a3cf19b0de	232	Planning	Execution, Operations & Productivity	Project Management	\N	Active	2026-05-01 04:52:02.744343
10504722-06db-41e0-a87f-e3268b6deb48	233	execution	Execution, Operations & Productivity	Project Management	\N	Active	2026-05-01 04:52:02.744343
52bd304a-db11-4f52-92d3-233da05da03b	234	monitoring	Execution, Operations & Productivity	Project Management	\N	Active	2026-05-01 04:52:02.744343
a2764f6f-83c8-4a06-b7ad-1ef10e54de61	235	risk tracking	Execution, Operations & Productivity	Project Management	\N	Active	2026-05-01 04:52:02.744343
e58a1fc8-775b-484d-b027-967bfc1bf5a7	236	Workflow design	Execution, Operations & Productivity	Process Management	\N	Active	2026-05-01 04:52:02.744343
3215d351-c151-4319-b055-08aa74529fbb	237	process optimization	Execution, Operations & Productivity	Process Management	\N	Active	2026-05-01 04:52:02.744343
d3a59bcf-b0ad-452e-b283-2b6c1be1e5bd	238	Resource optimization	Execution, Operations & Productivity	Operational Efficiency	\N	Active	2026-05-01 04:52:02.744343
d3f9d9d8-c0cf-4730-83b3-a5649e32f324	239	output maximization	Execution, Operations & Productivity	Operational Efficiency	\N	Active	2026-05-01 04:52:02.744343
6ede9427-7941-4a24-9861-07ede81141c8	241	precision	Execution, Operations & Productivity	Attention to Detail	\N	Active	2026-05-01 04:52:02.744343
da096517-0ce7-4efd-8d51-383c631bce69	242	quality control	Execution, Operations & Productivity	Attention to Detail	\N	Active	2026-05-01 04:52:02.744343
2531748c-fdda-4e99-a3a4-50fb6a2e7a0e	243	Managing multiple priorities effectively	Execution, Operations & Productivity	Multitasking	\N	Active	2026-05-01 04:52:02.744343
649265dd-1a17-44f0-92fa-f72e1cd083a2	244	Efficient utilization of time	Execution, Operations & Productivity	Resource Management	\N	Active	2026-05-01 04:52:02.744343
a259b41c-a275-42c6-9e4c-4b11d1d615f2	245	tools	Execution, Operations & Productivity	Resource Management	\N	Active	2026-05-01 04:52:02.744343
eda7d0ec-60c6-4fcb-a5d1-00611c6cd075	246	people	Execution, Operations & Productivity	Resource Management	\N	Active	2026-05-01 04:52:02.744343
3465c1d3-770c-4ede-bfad-d9a968de1e99	247	Outcome delivery	Execution, Operations & Productivity	Goal Execution	\N	Active	2026-05-01 04:52:02.744343
b7337def-a03a-4ceb-b8e7-2a9d15b11d69	248	milestone tracking	Execution, Operations & Productivity	Goal Execution	\N	Active	2026-05-01 04:52:02.744343
ce75fab6-f8fe-44b0-965f-013c87e6fadc	249	Monitoring metrics	Execution, Operations & Productivity	Performance Tracking	\N	Active	2026-05-01 04:52:02.744343
0f7f695c-4ebe-4f24-8a4c-824caec955f9	250	feedback loops	Execution, Operations & Productivity	Performance Tracking	\N	Active	2026-05-01 04:52:02.744343
bf29608f-dbe5-4868-a794-72d06341c118	251	Goal clarity	Career & Professional Readiness	Career Awareness	\N	Active	2026-05-01 04:52:02.744343
d2edd990-909e-4434-9967-cb2f9a617faf	252	career mapping	Career & Professional Readiness	Career Awareness	\N	Active	2026-05-01 04:52:02.744343
a24c9b53-676b-4dbb-9184-f5f6035c39b3	253	Workplace etiquette	Career & Professional Readiness	Professionalism	\N	Active	2026-05-01 04:52:02.744343
890fca7d-ac81-4b3a-8f2b-cb03233f044b	254	behavior standards	Career & Professional Readiness	Professionalism	\N	Active	2026-05-01 04:52:02.744343
18112c98-3af1-46c3-8ea8-f269599092fa	255	Readiness for job roles	Career & Professional Readiness	Employability Skills	\N	Active	2026-05-01 04:52:02.744343
94a7d4dc-3520-4180-92d5-8b2f3eecef20	256	workplace adaptability	Career & Professional Readiness	Employability Skills	\N	Active	2026-05-01 04:52:02.744343
fb655b3f-cc18-4c79-9959-7760c6453a9e	257	Communication	Career & Professional Readiness	Interview Skills	\N	Active	2026-05-01 04:52:02.744343
4c390f1d-6b0e-498f-82f2-daf8c3826004	258	confidence	Career & Professional Readiness	Interview Skills	\N	Active	2026-05-01 04:52:02.744343
6db06c60-bcb0-4288-847d-87c507cd78fa	259	structured responses	Career & Professional Readiness	Interview Skills	\N	Active	2026-05-01 04:52:02.744343
cb3f30b4-2600-48b5-b396-d3162c15cf2e	260	Achievement articulation	Career & Professional Readiness	Resume & Profile Building	\N	Active	2026-05-01 04:52:02.744343
310b60dd-bac7-4fdb-86a4-c46ddd1e9a01	261	structuring	Career & Professional Readiness	Resume & Profile Building	\N	Active	2026-05-01 04:52:02.744343
3ea32ccb-d057-45df-87c3-4adde35871fe	262	Self-positioning	Career & Professional Readiness	Personal Branding	\N	Active	2026-05-01 04:52:02.744343
bdefeadd-3806-41da-95a9-df699eeac22b	263	visibility	Career & Professional Readiness	Personal Branding	\N	Active	2026-05-01 04:52:02.744343
e9d4ac35-7ad3-4175-822f-2dd9b2a5e2c0	264	Workplace structure	Career & Professional Readiness	Organizational Awareness	\N	Active	2026-05-01 04:52:02.744343
dddc2864-5851-418b-b03b-ac11c9f3b15f	265	dynamics understanding	Career & Professional Readiness	Organizational Awareness	\N	Active	2026-05-01 04:52:02.744343
5dd5c176-d8df-4902-9b3b-3b92cca6d513	266	Market trends	Career & Professional Readiness	Industry Awareness	\N	Active	2026-05-01 04:52:02.744343
e944a652-ece8-4a2f-8b2c-e05381519bd1	267	domain knowledge	Career & Professional Readiness	Industry Awareness	\N	Active	2026-05-01 04:52:02.744343
18fc8648-6a15-416f-8081-298b02b621ba	268	Basic computing	Digital, Data & Technology Skills	Digital Literacy	\N	Active	2026-05-01 04:52:02.744343
2daab26f-10be-4017-ba4f-ce6fb69b30fd	269	internet usage	Digital, Data & Technology Skills	Digital Literacy	\N	Active	2026-05-01 04:52:02.744343
830bfa84-c1ed-468d-b503-192e0199964c	270	Data interpretation	Digital, Data & Technology Skills	Data Literacy	\N	Active	2026-05-01 04:52:02.744343
e26dae42-69fa-4c2f-b851-14cd2392009e	271	visualization	Digital, Data & Technology Skills	Data Literacy	\N	Active	2026-05-01 04:52:02.744343
08fe0a0c-25fb-4bfb-9785-845e60cd0edd	272	basic analytics	Digital, Data & Technology Skills	Data Literacy	\N	Active	2026-05-01 04:52:02.744343
59726b58-d8fa-42b3-952a-dec985d9697e	273	Domain-specific technical knowledge	Digital, Data & Technology Skills	Technical Skills	\N	Active	2026-05-01 04:52:02.744343
0996307b-2aff-4ec7-b88e-d12c40f02e83	274	Email	Digital, Data & Technology Skills	Digital Communication Tools	\N	Active	2026-05-01 04:52:02.744343
e1c5ba68-089d-4948-90a0-7038516fc54b	275	collaboration tools	Digital, Data & Technology Skills	Digital Communication Tools	\N	Active	2026-05-01 04:52:02.744343
9cf212da-aa41-4b7a-9fc4-159a38c5ac2e	276	remote work tools	Digital, Data & Technology Skills	Digital Communication Tools	\N	Active	2026-05-01 04:52:02.744343
7f19b80e-9c6d-49b5-845c-dc8910ab4fce	277	Learning new tools	Digital, Data & Technology Skills	Technology Adaptability	\N	Active	2026-05-01 04:52:02.744343
b354b05f-40ea-41e9-850c-1974ba6da021	278	tech agility	Digital, Data & Technology Skills	Technology Adaptability	\N	Active	2026-05-01 04:52:02.744343
1fb0262a-abbf-42b2-b5aa-f84909e5f438	279	Understanding tools for efficiency	Digital, Data & Technology Skills	Automation Awareness	\N	Active	2026-05-01 04:52:02.744343
0f23a41f-0bb1-46e0-b83f-d4ab20ea3c75	280	Data privacy	Digital, Data & Technology Skills	Cyber Awareness	\N	Active	2026-05-01 04:52:02.744343
7b1e832d-37e1-4c87-a298-63c531e51077	281	basic cybersecurity hygiene	Digital, Data & Technology Skills	Cyber Awareness	\N	Active	2026-05-01 04:52:02.744343
e2170024-03d7-46e8-a35e-0da85b6bb5c9	282	Idea validation	Innovation, Entrepreneurship & Value Creation	Innovation Skills	\N	Active	2026-05-01 04:52:02.744343
e79ec220-c4a7-4a7a-82d1-7570f22f0074	283	prototyping	Innovation, Entrepreneurship & Value Creation	Innovation Skills	\N	Active	2026-05-01 04:52:02.744343
0810710c-b10f-4736-9825-6207b753ce2f	284	experimentation	Innovation, Entrepreneurship & Value Creation	Innovation Skills	\N	Active	2026-05-01 04:52:02.744343
e9971092-285d-421b-a1ee-21758b188af9	285	Opportunity spotting	Innovation, Entrepreneurship & Value Creation	Entrepreneurial Skills	\N	Active	2026-05-01 04:52:02.744343
8929b7e0-fdff-400b-8e91-37bc48da4781	35	iterative refinement	Cognitive & Analytical Intelligence	Problem Solving	\N	Active	2026-05-01 04:52:02.744343
2d523b47-8529-46bd-a0f5-7ec2f588c6b3	36	Risk assessment	Cognitive & Analytical Intelligence	Decision Making	\N	Active	2026-05-01 04:52:02.744343
d0dc8352-bb73-4199-8c53-d5256c02f77b	37	trade-off evaluation	Cognitive & Analytical Intelligence	Decision Making	\N	Active	2026-05-01 04:52:02.744343
71909044-aba8-435d-8898-0aae368667c2	38	cost-benefit analysis	Cognitive & Analytical Intelligence	Decision Making	\N	Active	2026-05-01 04:52:02.744343
e3bd8d8c-378d-493d-9253-68222e223448	39	probabilistic thinking	Cognitive & Analytical Intelligence	Decision Making	\N	Active	2026-05-01 04:52:02.744343
16672b08-0872-4a3b-bc79-ef068b21238b	40	judgment accuracy	Cognitive & Analytical Intelligence	Decision Making	\N	Active	2026-05-01 04:52:02.744343
e0b47542-5ea8-44c0-9fbe-a17334a7dc46	41	speed-quality balance	Cognitive & Analytical Intelligence	Decision Making	\N	Active	2026-05-01 04:52:02.744343
21f46ec2-e858-4a9b-b8e5-70a6805ddaf7	42	Interdependency mapping	Cognitive & Analytical Intelligence	Systems Thinking	\N	Active	2026-05-01 04:52:02.744343
1899f352-20fd-4ebc-834d-1f1fc92f05d5	43	feedback loop understanding	Cognitive & Analytical Intelligence	Systems Thinking	\N	Active	2026-05-01 04:52:02.744343
d0df1b10-fffc-47d8-931d-a174b24992ed	44	holistic reasoning	Cognitive & Analytical Intelligence	Systems Thinking	\N	Active	2026-05-01 04:52:02.744343
2b7e131e-bc97-4a67-8bed-a88c5ab31ab2	45	complexity handling	Cognitive & Analytical Intelligence	Systems Thinking	\N	Active	2026-05-01 04:52:02.744343
c74fb33a-6b49-45e5-8f6e-5893f83768be	46	system dynamics	Cognitive & Analytical Intelligence	Systems Thinking	\N	Active	2026-05-01 04:52:02.744343
903485ca-7e7d-45df-8624-1fa0b8b4197b	1	Number sense	Cognitive & Analytical Intelligence	Numerical Aptitude	\N	Active	2026-05-01 04:52:02.744343
90428f8d-d6c0-4972-848f-e8937b9cd144	2	arithmetic accuracy	Cognitive & Analytical Intelligence	Numerical Aptitude	\N	Active	2026-05-01 04:52:02.744343
442acd4d-3653-45ea-9db4-9be49b481f19	3	quantitative reasoning	Cognitive & Analytical Intelligence	Numerical Aptitude	\N	Active	2026-05-01 04:52:02.744343
ec2db3ca-a1b7-4c97-b0d6-df66bdbd04d9	4	estimation accuracy	Cognitive & Analytical Intelligence	Numerical Aptitude	\N	Active	2026-05-01 04:52:02.744343
7a5b3f0a-06e5-4f62-9897-7140da028ab0	5	proportional reasoning	Cognitive & Analytical Intelligence	Numerical Aptitude	\N	Active	2026-05-01 04:52:02.744343
2cd86659-9c27-4687-9c5d-e2e5f7eb1c15	6	financial numeracy	Cognitive & Analytical Intelligence	Numerical Aptitude	\N	Active	2026-05-01 04:52:02.744343
4e59fc77-1345-40c9-b13b-074aec7d2b62	7	data sufficiency analysis	Cognitive & Analytical Intelligence	Numerical Aptitude	\N	Active	2026-05-01 04:52:02.744343
81421a5e-a328-4741-a685-84e83b8d29cc	8	error detection	Cognitive & Analytical Intelligence	Numerical Aptitude	\N	Active	2026-05-01 04:52:02.744343
934f04c3-46c9-4b97-8657-bab7cb52b2d4	9	Deductive reasoning	Cognitive & Analytical Intelligence	Logical Reasoning	\N	Active	2026-05-01 04:52:02.744343
47a56176-2228-45ab-b4fc-1f3187e79897	10	inductive reasoning	Cognitive & Analytical Intelligence	Logical Reasoning	\N	Active	2026-05-01 04:52:02.744343
255b064c-9390-4d97-a7f7-13173c4458fb	11	abductive reasoning	Cognitive & Analytical Intelligence	Logical Reasoning	\N	Active	2026-05-01 04:52:02.744343
12ea45eb-24d8-4141-9455-ce9df315446b	12	syllogistic reasoning	Cognitive & Analytical Intelligence	Logical Reasoning	\N	Active	2026-05-01 04:52:02.744343
551d8f56-2ef9-463d-82a7-798e1beafe8a	13	analogy mapping	Cognitive & Analytical Intelligence	Logical Reasoning	\N	Active	2026-05-01 04:52:02.744343
52972094-4e2f-4da0-b50d-6daa66f02880	14	sequence logic	Cognitive & Analytical Intelligence	Logical Reasoning	\N	Active	2026-05-01 04:52:02.744343
410bbec5-1375-4dbd-b0cb-c1f7563f897f	15	pattern recognition	Cognitive & Analytical Intelligence	Logical Reasoning	\N	Active	2026-05-01 04:52:02.744343
f584e6b9-f5fc-4fd5-84ac-d5908f819495	16	conditional reasoning	Cognitive & Analytical Intelligence	Logical Reasoning	\N	Active	2026-05-01 04:52:02.744343
a54e4eb5-41b7-4ac9-80ba-a77e3dd931f7	286	resourcefulness	Innovation, Entrepreneurship & Value Creation	Entrepreneurial Skills	\N	Active	2026-05-01 04:52:02.744343
da4ffcb2-b5f0-4180-a91f-e6428a151dfa	300	Sustainability awareness	Ethics, Governance & Responsibility	Social Responsibility	\N	Active	2026-05-01 04:52:02.744343
d3204b89-3102-4307-bbf0-8cce1bc4580d	301	ethical impact	Ethics, Governance & Responsibility	Social Responsibility	\N	Active	2026-05-01 04:52:02.744343
d7f14fa8-83d9-43f5-b87b-09f967ffd8b5	302	Transparency	Ethics, Governance & Responsibility	Accountability Systems	\N	Active	2026-05-01 04:52:02.744343
7c7f83f1-cf5b-4c60-a0e9-ec73cd76d2d3	303	reporting responsibility	Ethics, Governance & Responsibility	Accountability Systems	\N	Active	2026-05-01 04:52:02.744343
c20f973d-c597-4f3b-a49d-4c941933c045	304	Energy levels	Health, Wellbeing & Sustainability	Physical Wellbeing	\N	Active	2026-05-01 04:52:02.744343
ac90c9bc-c892-44ac-9914-672355e38bf7	305	health maintenance awareness	Health, Wellbeing & Sustainability	Physical Wellbeing	\N	Active	2026-05-01 04:52:02.744343
01744e9b-8d3a-4abe-8bf2-ba63d9f39df7	306	Stress balance	Health, Wellbeing & Sustainability	Mental Wellbeing	\N	Active	2026-05-01 04:52:02.744343
23e29bcf-bbfe-4eae-9b8e-411d5dd46255	307	emotional health awareness	Health, Wellbeing & Sustainability	Mental Wellbeing	\N	Active	2026-05-01 04:52:02.744343
204849a5-0741-44be-a392-ae82296ea248	308	Balance management	Health, Wellbeing & Sustainability	Work-Life Balance	\N	Active	2026-05-01 04:52:02.744343
7c7a5e58-3e0a-4c17-afa5-6a45731608b9	309	sustainability	Health, Wellbeing & Sustainability	Work-Life Balance	\N	Active	2026-05-01 04:52:02.744343
ee20bce5-4e88-4e4e-8cf4-9cfd1c490546	310	Safe work practices	Health, Wellbeing & Sustainability	Occupational Health Awareness	\N	Active	2026-05-01 04:52:02.744343
ce06b5c7-000f-4bd4-9400-ef2c31b45dfa	311	Geopolitical awareness	Global & Future Readiness	Global Awareness	\N	Active	2026-05-01 04:52:02.744343
c6614eba-a009-4008-b3df-a9e84c8022ec	312	global trends	Global & Future Readiness	Global Awareness	\N	Active	2026-05-01 04:52:02.744343
a84255ad-b9b4-44f8-bbbf-efee37a59052	313	AI awareness	Global & Future Readiness	Future Skills Orientation	\N	Active	2026-05-01 04:52:02.744343
2de94970-be77-425b-9357-c21e84446f5c	314	adaptability to future roles	Global & Future Readiness	Future Skills Orientation	\N	Active	2026-05-01 04:52:02.744343
e25daabd-ddcc-49f8-80f3-4c668c8a4961	315	Continuous upskilling mindset	Global & Future Readiness	Lifelong Learning Orientation	\N	Active	2026-05-01 04:52:02.744343
8a87147d-73c3-454c-86c0-25404b537b0b	316	Virtual collaboration	Global & Future Readiness	Remote Work Readiness	\N	Active	2026-05-01 04:52:02.744343
075076b9-f6df-4059-ab57-7ceb856059eb	317	self-management	Global & Future Readiness	Remote Work Readiness	\N	Active	2026-05-01 04:52:02.744343
bdad8f7b-0c39-493f-a407-82858ae672eb	17	Assumption identification	Cognitive & Analytical Intelligence	Critical Thinking	\N	Active	2026-05-01 04:52:02.744343
bafa5281-3b63-43a9-bc8c-b4a13073b5e8	18	argument evaluation	Cognitive & Analytical Intelligence	Critical Thinking	\N	Active	2026-05-01 04:52:02.744343
8b892cd1-4892-466a-9541-2c6e911d6a9e	19	bias detection	Cognitive & Analytical Intelligence	Critical Thinking	\N	Active	2026-05-01 04:52:02.744343
1b25d5b8-26c1-43a4-8d11-e861afec5561	20	logical consistency	Cognitive & Analytical Intelligence	Critical Thinking	\N	Active	2026-05-01 04:52:02.744343
6f5e0ac0-7045-40d3-9fa9-9b51b706bc0b	21	evidence validation	Cognitive & Analytical Intelligence	Critical Thinking	\N	Active	2026-05-01 04:52:02.744343
b5c82b20-4c3f-4d7a-ba58-561fdedf6c1e	22	fallacy detection	Cognitive & Analytical Intelligence	Critical Thinking	\N	Active	2026-05-01 04:52:02.744343
8ff8db55-35e9-472a-811c-e2fc18ba7e62	23	counterfactual reasoning	Cognitive & Analytical Intelligence	Critical Thinking	\N	Active	2026-05-01 04:52:02.744343
f4f96709-7900-4928-a0f5-91d26bc51185	24	Problem decomposition	Cognitive & Analytical Intelligence	Analytical Thinking	\N	Active	2026-05-01 04:52:02.744343
a1c0851f-2b44-463c-a4f0-d18d1c0fe7ae	25	root cause analysis	Cognitive & Analytical Intelligence	Analytical Thinking	\N	Active	2026-05-01 04:52:02.744343
1b346952-c98a-4557-a64f-e3902af0edaf	26	variable isolation	Cognitive & Analytical Intelligence	Analytical Thinking	\N	Active	2026-05-01 04:52:02.744343
9d833e93-e022-4f1a-98bf-2194da905dfc	27	structured thinking	Cognitive & Analytical Intelligence	Analytical Thinking	\N	Active	2026-05-01 04:52:02.744343
8b982021-a173-4e05-b3c1-ea1ace08088c	28	prioritization	Cognitive & Analytical Intelligence	Analytical Thinking	\N	Active	2026-05-01 04:52:02.744343
6d5cc786-24fb-4132-8d90-d2cf26d3020a	29	causal analysis	Cognitive & Analytical Intelligence	Analytical Thinking	\N	Active	2026-05-01 04:52:02.744343
0b63473f-9939-46bc-9086-c2e929daabad	240	Accuracy	Execution, Operations & Productivity	Attention to Detail	\N	Active	2026-05-01 04:52:02.744343
a460f324-3993-4935-ae49-fc29f8a3facc	287	Market understanding	Innovation, Entrepreneurship & Value Creation	Business Acumen	\N	Active	2026-05-01 04:52:02.744343
113b8c04-3047-406d-ba9c-2100eae66995	288	value creation logic	Innovation, Entrepreneurship & Value Creation	Business Acumen	\N	Active	2026-05-01 04:52:02.744343
6a58af5d-b680-4b14-8fdf-813402bb7c20	289	Budgeting	Innovation, Entrepreneurship & Value Creation	Financial Literacy	\N	Active	2026-05-01 04:52:02.744343
bd2ab4b4-0619-4621-a59a-aaeaaceed013	290	cost understanding	Innovation, Entrepreneurship & Value Creation	Financial Literacy	\N	Active	2026-05-01 04:52:02.744343
7f5c79c3-9c00-44a4-8cc8-051ccb8b0ce7	291	ROI thinking	Innovation, Entrepreneurship & Value Creation	Financial Literacy	\N	Active	2026-05-01 04:52:02.744343
b098e576-9fea-4fa9-89db-fc3361e68475	292	User empathy	Innovation, Entrepreneurship & Value Creation	Design Thinking	\N	Active	2026-05-01 04:52:02.744343
73c02a51-a376-4c92-b948-0859a072733f	293	ideation	Innovation, Entrepreneurship & Value Creation	Design Thinking	\N	Active	2026-05-01 04:52:02.744343
b3fff596-c79e-4c74-b8fa-14f1a95cf6d0	294	prototyping	Innovation, Entrepreneurship & Value Creation	Design Thinking	\N	Active	2026-05-01 04:52:02.744343
f7d0afd9-a66a-48aa-998d-88d2d9586d0c	295	Moral judgment	Ethics, Governance & Responsibility	Ethical Reasoning	\N	Active	2026-05-01 04:52:02.744343
0d8ea863-b929-49a7-85e0-627dccbcc820	296	fairness	Ethics, Governance & Responsibility	Ethical Reasoning	\N	Active	2026-05-01 04:52:02.744343
1278eb0b-e579-40cd-abf9-e14148736a16	297	integrity	Ethics, Governance & Responsibility	Ethical Reasoning	\N	Active	2026-05-01 04:52:02.744343
1d8dd3eb-b220-4d1b-a406-4532253a43a4	298	Rules	Ethics, Governance & Responsibility	Compliance Awareness	\N	Active	2026-05-01 04:52:02.744343
04db1c95-8b35-4a98-ba5c-c44bcbbd693a	299	regulations understanding	Ethics, Governance & Responsibility	Compliance Awareness	\N	Active	2026-05-01 04:52:02.744343
\.


--
-- Data for Name: competency_user_responses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competency_user_responses (id, user_id, item_id, option_id, score_obtained, time_taken, created_at) FROM stdin;
\.


--
-- Data for Name: competency_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competency_versions (id, version, label, notes, changed_by, change_summary, snapshot, created_at) FROM stdin;
bbac959a-d4d2-491a-93eb-a92b7b5e4e75	1	v1.0 — Initial framework launch	Auto-created baseline	\N	{"domains": 12, "stage_norms": 505, "competencies": 101, "role_weights": 707}	\N	2026-05-01 15:06:22.66691
\.


--
-- Data for Name: compliance_audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compliance_audit_logs (id, log_id, log_type, category, action, resource_type, resource_id, resource_name, actor_id, actor_type, actor_name, actor_role, ip_address, user_agent, session_id, request_id, previous_value, new_value, change_reason, status, error_code, error_message, compliance_frameworks, data_classification, retention_period, log_hash, previous_log_hash, created_at) FROM stdin;
\.


--
-- Data for Name: compliance_violations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compliance_violations (id, mentor_id, violation_type, severity, description, evidence_url, reported_by, status, resolution, resolved_by, resolved_at, action_taken, created_at) FROM stdin;
\.


--
-- Data for Name: concern_areas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.concern_areas (id, category, concern_area, parent_worry, impact_on_child, assessment_type, search_keywords, services, roles, is_active, sort_order, created_at, updated_at) FROM stdin;
1	Focus	Short attention span	My child cannot sit and study	Poor learning	lbi	focus short attention span my child cannot sit and study poor learning	[]	[]	t	1	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
2	Focus	Easily distracted	Gets distracted very quickly	Low productivity	lbi	focus easily distracted gets distracted very quickly low productivity	[]	[]	t	2	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
3	Focus	Screen distraction	Always on phone/tablet	Reduced focus	lbi	focus screen distraction always on phone/tablet reduced focus	[]	[]	t	3	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
4	Focus	Inconsistent concentration	Sometimes focused, mostly not	Unstable performance	lbi	focus inconsistent concentration sometimes focused, mostly not unstable performance	[]	[]	t	4	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
5	Focus	Difficulty completing tasks	Leaves work halfway	Poor outcomes	lbi	focus difficulty completing tasks leaves work halfway poor outcomes	[]	[]	t	5	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
6	Focus	Daydreaming	Lost in thoughts	Low engagement	lbi	focus daydreaming lost in thoughts low engagement	[]	[]	t	6	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
7	Focus	Lack of mental stamina	Gets tired quickly while studying	Weak retention	lbi	focus lack of mental stamina gets tired quickly while studying weak retention	[]	[]	t	7	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
8	Focus	Avoidance of difficult tasks	Avoids tough subjects	Skill gaps	lbi	focus avoidance of difficult tasks avoids tough subjects skill gaps	[]	[]	t	8	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
9	Focus	No deep work ability	Cannot study for long hours	Low mastery	lbi	focus no deep work ability cannot study for long hours low mastery	[]	[]	t	9	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
10	Focus	Over multitasking	Keeps switching tasks	Inefficiency	lbi	focus over multitasking keeps switching tasks inefficiency	[]	[]	t	10	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
11	Academics	Low marks	Marks are very low	Academic risk	lbi	academics low marks marks are very low academic risk	[]	[]	t	11	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
12	Academics	Sudden drop in performance	Marks have dropped recently	Concern trigger	lbi	academics sudden drop in performance marks have dropped recently concern trigger	[]	[]	t	12	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
13	Academics	Inconsistent results	Sometimes good, sometimes bad	Unpredictability	lbi	academics inconsistent results sometimes good, sometimes bad unpredictability	[]	[]	t	13	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
14	Academics	Exam fear	Panics during exams	Underperformance	lbi	academics exam fear panics during exams underperformance	[]	[]	t	14	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
15	Academics	Poor writing skills	Cannot present answers well	Low scoring	lbi	academics poor writing skills cannot present answers well low scoring	[]	[]	t	15	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
16	Academics	Slow writing speed	Cannot finish paper on time	Exam loss	lbi	academics slow writing speed cannot finish paper on time exam loss	[]	[]	t	16	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
17	Academics	Weak subject foundation	Basics are not clear	Long-term gap	lbi	academics weak subject foundation basics are not clear long-term gap	[]	[]	t	17	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
18	Academics	Difficulty in math/science	Struggles with concepts	Learning difficulty	lbi	academics difficulty in math/science struggles with concepts learning difficulty	[]	[]	t	18	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
19	Academics	Rote learning dependency	Memorizes but doesn't understand	Shallow learning	lbi	academics rote learning dependency memorizes but doesn't understand shallow learning	[]	[]	t	19	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
20	Academics	Homework resistance	Doesn't want to do homework	Poor discipline	lbi	academics homework resistance doesn't want to do homework poor discipline	[]	[]	t	20	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
21	Behavior	Procrastination	Delays everything	Time loss	lbi	behavior procrastination delays everything time loss	[]	[]	t	21	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
22	Behavior	Lack of discipline	No routine at all	Inconsistency	lbi	behavior lack of discipline no routine at all inconsistency	[]	[]	t	22	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
23	Behavior	Irregular study habits	Studies randomly	Weak structure	lbi	behavior irregular study habits studies randomly weak structure	[]	[]	t	23	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
24	Behavior	No goal setting	No aim in life	Directionless	lbi	behavior no goal setting no aim in life directionless	[]	[]	t	24	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
25	Behavior	Easily gives up	Quits quickly	Low resilience	lbi	behavior easily gives up quits quickly low resilience	[]	[]	t	25	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
26	Behavior	Dependency on parents	Needs constant push	No independence	lbi	behavior dependency on parents needs constant push no independence	[]	[]	t	26	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
27	Behavior	Disorganized lifestyle	Very messy routine	Inefficiency	lbi	behavior disorganized lifestyle very messy routine inefficiency	[]	[]	t	27	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
28	Behavior	Poor time management	Cannot manage time	Missed targets	lbi	behavior poor time management cannot manage time missed targets	[]	[]	t	28	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
29	Behavior	Avoidance behavior	Escapes responsibilities	Weak accountability	lbi	behavior avoidance behavior escapes responsibilities weak accountability	[]	[]	t	29	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
30	Behavior	Lack of responsibility	Doesn't take things seriously	Immaturity	lbi	behavior lack of responsibility doesn't take things seriously immaturity	[]	[]	t	30	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
31	Emotional	Low confidence	Doesn't believe in self	Poor performance	lbi	emotional low confidence doesn't believe in self poor performance	[]	[]	t	31	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
32	Emotional	Fear of failure	Afraid to try	Avoidance	lbi	emotional fear of failure afraid to try avoidance	[]	[]	t	32	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
33	Emotional	Anxiety	Always worried	Mental stress	lbi	emotional anxiety always worried mental stress	[]	[]	t	33	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
34	Emotional	Mood swings	Emotions change quickly	Instability	lbi	emotional mood swings emotions change quickly instability	[]	[]	t	34	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
35	Emotional	Overthinking	Thinks too much	Mental fatigue	lbi	emotional overthinking thinks too much mental fatigue	[]	[]	t	35	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
36	Emotional	Stress	Too much pressure	Burnout	lbi	emotional stress too much pressure burnout	[]	[]	t	36	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
37	Emotional	Negative thinking	Always pessimistic	Low motivation	lbi	emotional negative thinking always pessimistic low motivation	[]	[]	t	37	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
38	Emotional	Fear of judgment	Worried about others	Inhibition	lbi	emotional fear of judgment worried about others inhibition	[]	[]	t	38	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
39	Emotional	Comparison stress	Compares with others	Low self-worth	lbi	emotional comparison stress compares with others low self-worth	[]	[]	t	39	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
40	Emotional	Emotional sensitivity	Gets hurt easily	Fragility	lbi	emotional emotional sensitivity gets hurt easily fragility	[]	[]	t	40	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
41	Mental Health	Test anxiety	Freezes in exams	Score drop	lbi	mental health test anxiety freezes in exams score drop	[]	[]	t	41	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
42	Mental Health	Social anxiety	Avoids interaction	Isolation	lbi	mental health social anxiety avoids interaction isolation	[]	[]	t	42	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
43	Mental Health	Lack of motivation	No interest in anything	Stagnation	lbi	mental health lack of motivation no interest in anything stagnation	[]	[]	t	43	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
44	Mental Health	Burnout	Feels tired always	Withdrawal	lbi	mental health burnout feels tired always withdrawal	[]	[]	t	44	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
45	Mental Health	Low self-esteem	Feels inferior	Confidence loss	lbi	mental health low self-esteem feels inferior confidence loss	[]	[]	t	45	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
46	Mental Health	Emotional regulation issues	Cannot control emotions	Behavioral issues	lbi	mental health emotional regulation issues cannot control emotions behavioral issues	[]	[]	t	46	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
47	Mental Health	Withdrawal behavior	Keeps to self	Isolation	lbi	mental health withdrawal behavior keeps to self isolation	[]	[]	t	47	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
48	Mental Health	Fear of speaking	Afraid to talk	Communication gap	lbi	mental health fear of speaking afraid to talk communication gap	[]	[]	t	48	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
49	Mental Health	Pressure from expectations	Feels burdened	Stress	lbi	mental health pressure from expectations feels burdened stress	[]	[]	t	49	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
50	Mental Health	Lack of mental resilience	Cannot handle failure	Fragility	lbi	mental health lack of mental resilience cannot handle failure fragility	[]	[]	t	50	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
51	Digital	Screen addiction	Always on screen	Focus loss	lbi	digital screen addiction always on screen focus loss	[]	[]	t	51	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
52	Digital	Gaming addiction	Plays games excessively	Time waste	lbi	digital gaming addiction plays games excessively time waste	[]	[]	t	52	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
53	Digital	Social media overuse	Always scrolling	Distraction	lbi	digital social media overuse always scrolling distraction	[]	[]	t	53	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
54	Digital	YouTube addiction	Watches endlessly	Reduced productivity	lbi	digital youtube addiction watches endlessly reduced productivity	[]	[]	t	54	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
55	Digital	Late-night phone use	Sleeps very late	Poor health	lbi	digital late-night phone use sleeps very late poor health	[]	[]	t	55	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
56	Digital	Dopamine dependency	Needs constant stimulation	Low patience	lbi	digital dopamine dependency needs constant stimulation low patience	[]	[]	t	56	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
57	Digital	Reduced offline engagement	Doesn't play outside	Social impact	lbi	digital reduced offline engagement doesn't play outside social impact	[]	[]	t	57	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
58	Digital	Academic neglect due to phone	Studies less due to phone	Performance drop	lbi	digital academic neglect due to phone studies less due to phone performance drop	[]	[]	t	58	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
59	Digital	Multitasking with devices	Studies + phone together	Inefficiency	lbi	digital multitasking with devices studies + phone together inefficiency	[]	[]	t	59	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
60	Digital	Lack of digital discipline	No control over usage	Habit damage	lbi	digital lack of digital discipline no control over usage habit damage	[]	[]	t	60	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
61	Social	Poor communication	Cannot express clearly	Weak interaction	lbi	social poor communication cannot express clearly weak interaction	[]	[]	t	61	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
62	Social	Shyness	Too shy	Low participation	lbi	social shyness too shy low participation	[]	[]	t	62	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
63	Social	Lack of friends	Doesn't socialize	Isolation	lbi	social lack of friends doesn't socialize isolation	[]	[]	t	63	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
64	Social	Peer pressure	Easily influenced	Risk behavior	lbi	social peer pressure easily influenced risk behavior	[]	[]	t	64	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
65	Social	Conflict with peers	Frequent fights	Social issues	lbi	social conflict with peers frequent fights social issues	[]	[]	t	65	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
66	Social	Poor listening skills	Doesn't listen	Miscommunication	lbi	social poor listening skills doesn't listen miscommunication	[]	[]	t	66	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
67	Social	Low participation in class	Doesn't engage	Missed learning	lbi	social low participation in class doesn't engage missed learning	[]	[]	t	67	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
68	Social	Fear of public speaking	Avoids stage	Confidence gap	lbi	social fear of public speaking avoids stage confidence gap	[]	[]	t	68	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
69	Social	Lack of teamwork	Cannot work in groups	Collaboration issue	lbi	social lack of teamwork cannot work in groups collaboration issue	[]	[]	t	69	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
70	Social	Social comparison	Feels inferior to peers	Low confidence	lbi	social social comparison feels inferior to peers low confidence	[]	[]	t	70	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
71	Habits	Poor sleep routine	Sleeps irregularly	Low energy	lbi	habits poor sleep routine sleeps irregularly low energy	[]	[]	t	71	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
72	Habits	Lack of physical activity	No exercise	Health impact	lbi	habits lack of physical activity no exercise health impact	[]	[]	t	72	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
73	Habits	Poor diet habits	Unhealthy eating	Low energy	lbi	habits poor diet habits unhealthy eating low energy	[]	[]	t	73	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
74	Habits	No structured routine	Day is unplanned	Chaos	lbi	habits no structured routine day is unplanned chaos	[]	[]	t	74	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
75	Habits	Lack of consistency	Cannot follow routine	Instability	lbi	habits lack of consistency cannot follow routine instability	[]	[]	t	75	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
76	Habits	Low discipline	No control	Weak habits	lbi	habits low discipline no control weak habits	[]	[]	t	76	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
77	Habits	Poor hygiene	Neglects self-care	Health risk	lbi	habits poor hygiene neglects self-care health risk	[]	[]	t	77	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
78	Habits	Lack of productivity habits	Wastes time	Low output	lbi	habits lack of productivity habits wastes time low output	[]	[]	t	78	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
79	Habits	No habit formation	Cannot build habits	No growth	lbi	habits no habit formation cannot build habits no growth	[]	[]	t	79	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
80	Habits	Irregular energy cycles	Active at wrong times	Inefficiency	lbi	habits irregular energy cycles active at wrong times inefficiency	[]	[]	t	80	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
81	Career	No career clarity	Doesn't know what to do	Confusion	career	career no career clarity doesn't know what to do confusion	[]	[]	t	81	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
82	Career	Too many interests	Confused between options	Indecision	career	career too many interests confused between options indecision	[]	[]	t	82	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
83	Career	External influence	Others deciding career	Misalignment	career	career external influence others deciding career misalignment	[]	[]	t	83	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
84	Career	Lack of exposure	Doesn't know options	Limited vision	career	career lack of exposure doesn't know options limited vision	[]	[]	t	84	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
85	Career	Unrealistic goals	Dreams not practical	Risk	career	career unrealistic goals dreams not practical risk	[]	[]	t	85	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
86	Career	No long-term planning	No future plan	Uncertainty	career	career no long-term planning no future plan uncertainty	[]	[]	t	86	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
87	Career	Fear of wrong choice	What if we choose wrong	Anxiety	career	career fear of wrong choice what if we choose wrong anxiety	[]	[]	t	87	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
88	Career	Lack of skill awareness	Doesn't know strengths	Misfit	career	career lack of skill awareness doesn't know strengths misfit	[]	[]	t	88	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
89	Career	No guidance	No proper advice	Confusion	career	career no guidance no proper advice confusion	[]	[]	t	89	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
90	Career	Misalignment with abilities	Choosing wrong stream	Failure risk	career	career misalignment with abilities choosing wrong stream failure risk	[]	[]	t	90	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
91	Family	Lack of communication	Doesn't talk openly	Disconnect	lbi	family lack of communication doesn't talk openly disconnect	[]	[]	t	91	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
92	Family	Parent-child conflict	Frequent arguments	Stress	lbi	family parent-child conflict frequent arguments stress	[]	[]	t	92	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
93	Family	Over-expectation	Pressure from parents	Anxiety	lbi	family over-expectation pressure from parents anxiety	[]	[]	t	93	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
94	Family	Lack of guidance	We don't know how to help	Confusion	lbi	family lack of guidance we don't know how to help confusion	[]	[]	t	94	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
95	Family	Comparison with siblings	Compared at home	Low self-worth	lbi	family comparison with siblings compared at home low self-worth	[]	[]	t	95	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
96	Family	Lack of monitoring	We don't track properly	Missed issues	lbi	family lack of monitoring we don't track properly missed issues	[]	[]	t	96	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
97	Family	Emotional disconnect	Not emotionally close	Isolation	lbi	family emotional disconnect not emotionally close isolation	[]	[]	t	97	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
98	Family	Over-dependence on tuition	We rely only on coaching	Weak foundation	lbi	family over-dependence on tuition we rely only on coaching weak foundation	[]	[]	t	98	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
99	Family	Confusion about child's ability	Don't understand child	Misjudgment	lbi	family confusion about child's ability don't understand child misjudgment	[]	[]	t	99	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
100	Family	Fear about future	What will happen later	Anxiety	lbi	family fear about future what will happen later anxiety	[]	[]	t	100	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
101	Learning	Learning disabilities (Dyslexia, ADHD, Dysgraphia)	Why is my child not learning like others?	Misdiagnosis, academic struggle	lbi	learning learning disabilities (dyslexia, adhd, dysgraphia) why is my child not learning like others? misdiagnosis, academic struggle	[]	[]	t	101	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
102	Learning	Poor comprehension skills	Reads but doesn't understand	Weak conceptual learning	lbi	learning poor comprehension skills reads but doesn't understand weak conceptual learning	[]	[]	t	102	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
103	Learning	Memory retention issues	Forgets whatever studied	Poor exam performance	lbi	learning memory retention issues forgets whatever studied poor exam performance	[]	[]	t	103	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
104	Cognitive	Low problem-solving ability	Cannot think independently	Weak analytical skills	lbi	cognitive low problem-solving ability cannot think independently weak analytical skills	[]	[]	t	104	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
105	Cognitive	Lack of critical thinking	Cannot apply knowledge	Surface-level learning	lbi	cognitive lack of critical thinking cannot apply knowledge surface-level learning	[]	[]	t	105	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
106	Cognitive	Slow processing speed	Takes too long to understand	Academic delay	lbi	cognitive slow processing speed takes too long to understand academic delay	[]	[]	t	106	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
107	Emotional	Anger issues	Gets angry very quickly	Relationship & behavior problems	lbi	emotional anger issues gets angry very quickly relationship & behavior problems	[]	[]	t	107	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
108	Emotional	Lack of emotional intelligence	Cannot understand emotions	Social disconnect	lbi	emotional lack of emotional intelligence cannot understand emotions social disconnect	[]	[]	t	108	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
109	Mental Health	Early signs of depression	Seems dull / uninterested	Serious mental health risk	lbi	mental health early signs of depression seems dull / uninterested serious mental health risk	[]	[]	t	109	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
110	Mental Health	Panic attacks	Sudden fear episodes	Academic disruption	lbi	mental health panic attacks sudden fear episodes academic disruption	[]	[]	t	110	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
111	Digital	Exposure to inappropriate content	What are they watching online?	Behavioral distortion	lbi	digital exposure to inappropriate content what are they watching online? behavioral distortion	[]	[]	t	111	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
112	Digital	Cyberbullying	Someone is troubling online	Emotional trauma	lbi	digital cyberbullying someone is troubling online emotional trauma	[]	[]	t	112	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
113	Social	Bullying (offline)	Child is being bullied in school	Fear, withdrawal	lbi	social bullying (offline) child is being bullied in school fear, withdrawal	[]	[]	t	113	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
114	Social	Lack of assertiveness	Cannot say no	Peer pressure vulnerability	lbi	social lack of assertiveness cannot say no peer pressure vulnerability	[]	[]	t	114	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
115	Social	Influence of wrong peer group	Bad friends influencing	Risky behaviors	lbi	social influence of wrong peer group bad friends influencing risky behaviors	[]	[]	t	115	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
116	Habits	Addiction tendencies (beyond screens)	Getting addicted easily	Long-term dependency risk	lbi	habits addiction tendencies (beyond screens) getting addicted easily long-term dependency risk	[]	[]	t	116	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
117	Habits	Lack of self-control	Cannot control impulses	Poor decisions	lbi	habits lack of self-control cannot control impulses poor decisions	[]	[]	t	117	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
118	Career	Lack of real-world skills	Not ready for real life	Employability gap	career	career lack of real-world skills not ready for real life employability gap	[]	[]	t	118	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
119	Career	Skill vs marks mismatch	Good marks but no skills	Future struggle	career	career skill vs marks mismatch good marks but no skills future struggle	[]	[]	t	119	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
120	Career	Fear of competition	Cannot handle competition	Avoidance mindset	career	career fear of competition cannot handle competition avoidance mindset	[]	[]	t	120	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
121	Parenting	Inconsistent parenting approach	We are not aligned as parents	Confusion in child	lbi	parenting inconsistent parenting approach we are not aligned as parents confusion in child	[]	[]	t	121	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
122	Parenting	Lack of parenting skills	We don't know how to guide properly	Wrong interventions	lbi	parenting lack of parenting skills we don't know how to guide properly wrong interventions	[]	[]	t	122	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
123	Parenting	Overprotection	We do everything for child	Dependency	lbi	parenting overprotection we do everything for child dependency	[]	[]	t	123	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
124	Parenting	Lack of boundaries	Child doesn't listen at all	Discipline issues	lbi	parenting lack of boundaries child doesn't listen at all discipline issues	[]	[]	t	124	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
125	Environment	School mismatch	School not suitable for child	Learning dissatisfaction	lbi	environment school mismatch school not suitable for child learning dissatisfaction	[]	[]	t	125	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
126	Environment	Academic pressure from school	Too much syllabus pressure	Stress, burnout	lbi	environment academic pressure from school too much syllabus pressure stress, burnout	[]	[]	t	126	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
127	Health	Frequent fatigue	Always tired	Low productivity	lbi	health frequent fatigue always tired low productivity	[]	[]	t	127	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
128	Health	Hormonal/teen changes impact	Behavior changed suddenly	Emotional instability	lbi	health hormonal/teen changes impact behavior changed suddenly emotional instability	[]	[]	t	128	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
129	Future Skills	Lack of creativity	No innovative thinking	Limited growth	lbi	future skills lack of creativity no innovative thinking limited growth	[]	[]	t	129	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
130	Future Skills	Lack of curiosity	Doesn't ask questions	Passive learning	lbi	future skills lack of curiosity doesn't ask questions passive learning	[]	[]	t	130	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
131	Board Exams	Failure in board exams	My child has failed in boards	Emotional breakdown, stigma	exam_ready	board exams failure in board exams my child has failed in boards emotional breakdown, stigma	[]	[]	t	131	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
132	Board Exams	Compartment exam stress	How to clear compartment?	Anxiety, urgency pressure	exam_ready	board exams compartment exam stress how to clear compartment? anxiety, urgency pressure	[]	[]	t	132	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
133	Board Exams	Low board percentage	Marks are too low for good college	Limited opportunities	exam_ready	board exams low board percentage marks are too low for good college limited opportunities	[]	[]	t	133	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
134	Board Exams	Unexpected poor results	We expected more marks	Confidence loss	exam_ready	board exams unexpected poor results we expected more marks confidence loss	[]	[]	t	134	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
135	Board Exams	Exam performance vs preparation mismatch	Studied well but marks are low	Frustration, confusion	exam_ready	board exams exam performance vs preparation mismatch studied well but marks are low frustration, confusion	[]	[]	t	135	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
136	Board Exams	Time mismanagement in board exam	Couldn't complete paper	Score loss	exam_ready	board exams time mismanagement in board exam couldn't complete paper score loss	[]	[]	t	136	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
137	Board Exams	Poor answer presentation	Knows answers but cannot write properly	Low evaluation score	exam_ready	board exams poor answer presentation knows answers but cannot write properly low evaluation score	[]	[]	t	137	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
138	Board Exams	Weak exam strategy	Doesn't know how to attempt paper	Inefficient scoring	exam_ready	board exams weak exam strategy doesn't know how to attempt paper inefficient scoring	[]	[]	t	138	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
139	Board Exams	Panic during board exam	Blank out in exam hall	Severe underperformance	exam_ready	board exams panic during board exam blank out in exam hall severe underperformance	[]	[]	t	139	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
140	Board Exams	Lack of revision strategy	Didn't revise properly	Poor retention	exam_ready	board exams lack of revision strategy didn't revise properly poor retention	[]	[]	t	140	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
141	Board Exams	Syllabus completion gaps	Portions left before exam	Low confidence	exam_ready	board exams syllabus completion gaps portions left before exam low confidence	[]	[]	t	141	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
142	Board Exams	Overconfidence before exam	Thought it was easy	Poor results	exam_ready	board exams overconfidence before exam thought it was easy poor results	[]	[]	t	142	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
143	Board Exams	Burnout before boards	Exhausted before exams started	Performance drop	exam_ready	board exams burnout before boards exhausted before exams started performance drop	[]	[]	t	143	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
144	Board Exams	External pressure (family/society)	Too much pressure for marks	Anxiety, stress	exam_ready	board exams external pressure (family/society) too much pressure for marks anxiety, stress	[]	[]	t	144	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
145	Board Exams	Comparison after results	Others scored more	Low self-esteem	exam_ready	board exams comparison after results others scored more low self-esteem	[]	[]	t	145	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
146	Betterment	Lack of clarity about betterment exams	What is improvement exam process?	Confusion, delay	exam_ready	betterment lack of clarity about betterment exams what is improvement exam process? confusion, delay	[]	[]	t	146	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
147	Betterment	Fear of repeating failure	What if marks don't improve again?	Avoidance	exam_ready	betterment fear of repeating failure what if marks don't improve again? avoidance	[]	[]	t	147	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
148	Betterment	No strategy for improvement exam	How to improve marks now?	Ineffective preparation	exam_ready	betterment no strategy for improvement exam how to improve marks now? ineffective preparation	[]	[]	t	148	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
149	Betterment	Time gap misuse	Wasting time after results	Lost opportunity	exam_ready	betterment time gap misuse wasting time after results lost opportunity	[]	[]	t	149	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
150	Betterment	Lack of structured re-preparation	Doesn't know where to restart	Same mistakes repeated	exam_ready	betterment lack of structured re-preparation doesn't know where to restart same mistakes repeated	[]	[]	t	150	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
151	Betterment	Concept gaps not fixed	Still weak in basics	No improvement	exam_ready	betterment concept gaps not fixed still weak in basics no improvement	[]	[]	t	151	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
152	Betterment	Psychological setback after failure	Lost confidence completely	Withdrawal	exam_ready	betterment psychological setback after failure lost confidence completely withdrawal	[]	[]	t	152	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
153	Betterment	Social stigma of failure	What will others say?	Shame, isolation	exam_ready	betterment social stigma of failure what will others say? shame, isolation	[]	[]	t	153	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
154	Betterment	Lack of motivation to retry	Doesn't want to attempt again	Dropout risk	exam_ready	betterment lack of motivation to retry doesn't want to attempt again dropout risk	[]	[]	t	154	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
155	Betterment	Wrong study strategy repetition	Repeating same mistakes	No score improvement	exam_ready	betterment wrong study strategy repetition repeating same mistakes no score improvement	[]	[]	t	155	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
156	Betterment	Lack of mentorship/guidance	No one to guide for improvement	Directionless effort	exam_ready	betterment lack of mentorship/guidance no one to guide for improvement directionless effort	[]	[]	t	156	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
157	Betterment	Fear of career delay	Will this delay future?	Anxiety	exam_ready	betterment fear of career delay will this delay future? anxiety	[]	[]	t	157	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
158	Betterment	College admission uncertainty	Will colleges accept betterment scores?	Confusion	exam_ready	betterment college admission uncertainty will colleges accept betterment scores? confusion	[]	[]	t	158	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
159	Betterment	Peer progression pressure	Friends moved ahead	Inferiority feeling	exam_ready	betterment peer progression pressure friends moved ahead inferiority feeling	[]	[]	t	159	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
160	Betterment	Emotional recovery after failure	Child is mentally down	Long-term confidence impact	exam_ready	betterment emotional recovery after failure child is mentally down long-term confidence impact	[]	[]	t	160	2026-05-01 15:06:22.571514	2026-05-01 15:06:22.571514
\.


--
-- Data for Name: consent_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.consent_logs (id, parent_student_link_id, parent_id, action, reason, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: consent_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.consent_records (id, entity_type, entity_id, entity_name, consent_type, consent_version, status, granted_at, revoked_at, expires_at, ip_address, user_agent, consent_text, data_categories, processing_purposes, lawful_basis, retention_period, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: consent_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.consent_types (id, entity_type, consent_code, consent_name, description, consent_text_template, version, is_mandatory, requires_witness, requires_guardian, lawful_basis, data_categories, processing_purposes, retention_period, display_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, title, created_at) FROM stdin;
\.


--
-- Data for Name: data_retention_policies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_retention_policies (id, policy_name, data_category, retention_period_days, archival_period_days, deletion_method, compliance_framework, legal_basis, exceptions, last_executed, next_scheduled, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_access_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.document_access_logs (id, document_id, user_id, access_type, ip_address, user_agent, device_type, location, access_status, failure_reason, session_id, created_at) FROM stdin;
\.


--
-- Data for Name: document_folders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.document_folders (id, entity_type, entity_id, entity_name, folder_path, folder_name, parent_folder_id, access_level, retention_policy, encryption_status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, folder_id, entity_type, entity_id, document_type, document_category, document_name, file_name, file_size, mime_type, storage_path, checksum, version, is_latest, previous_version_id, status, maker_verified_by, maker_verified_at, maker_notes, checker_approved_by, checker_approved_at, checker_notes, rejected_by, rejected_at, rejection_reason, expiry_date, is_expired, sensitivity_level, encryption_algorithm, access_count, last_accessed_at, last_accessed_by, uploaded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: education_boards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.education_boards (id, board_code, board_name, description, country, status, created_at) FROM stdin;
97dfc739-bb2b-46a4-b9d2-f884e73b6b67	CBSE	Central Board of Secondary Education	\N	India	Active	2026-05-01 04:27:53.777614
2b58170b-c969-44f4-acc2-4ab1c5ca15d0	ICSE	Indian Certificate of Secondary Education	\N	India	Active	2026-05-01 04:27:53.777614
ea088762-73e1-4d98-ab62-613a77ef90fd	STATE_MH	Maharashtra State Board	\N	India	Active	2026-05-01 04:27:53.777614
1c1adb46-6582-4d1c-9911-1a53094d39d3	STATE_KA	Karnataka State Board	\N	India	Active	2026-05-01 04:27:53.777614
e61e6e9e-a92b-45d2-999a-e8f607057eb2	STATE_TN	Tamil Nadu State Board	\N	India	Active	2026-05-01 04:27:53.777614
\.


--
-- Data for Name: email_consents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_consents (id, user_id, consent_type, is_consented, consented_at, revoked_at, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: enrollment_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.enrollment_requests (id, institute_id, student_id, batch_id, status, requested_on) FROM stdin;
\.


--
-- Data for Name: entity_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entity_codes (id, entity_type, entity_id, code, code_type, status, generated_by, valid_from, valid_until, revoked_at, revoked_reason, usage_count, max_usage, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: exam_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_attempts (id, exam_id, student_id, status, score_obtained, total_marks, started_at, submitted_at) FROM stdin;
\.


--
-- Data for Name: exam_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_questions (id, exam_id, question_text, option_a, option_b, option_c, option_d, correct_option, marks, order_index, created_at) FROM stdin;
\.


--
-- Data for Name: exam_responses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_responses (id, attempt_id, question_id, selected_option, is_correct, marks_obtained, created_at) FROM stdin;
\.


--
-- Data for Name: exams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exams (id, institute_id, exam_code, exam_name, batch_id, status, start_at, end_at, created_at) FROM stdin;
\.


--
-- Data for Name: express_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.express_sessions (sid, sess, expire) FROM stdin;
Z02xB8zHqwys0Xpmj6Cw5ogM7QEnDEFb	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-08T15:32:18.026Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"passport":{"user":"4c5e1296-9aa6-490d-9b75-bc147a2153b3"}}	2026-05-08 15:32:25
CjG2gzmta-QiQop8qYC-AeVxqkRSBWOR	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-08T15:06:29.162Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"passport":{"user":"4c5e1296-9aa6-490d-9b75-bc147a2153b3"}}	2026-05-08 15:06:30
WTzamDb-HepWpR_t2vH0kbUbqhpDs_up	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-08T15:07:11.816Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"passport":{"user":"4c5e1296-9aa6-490d-9b75-bc147a2153b3"}}	2026-05-08 16:04:23
hJgtuGonSylAvOwiUjsG9H8XiXRKTebr	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-08T15:30:43.510Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"passport":{"user":"4c5e1296-9aa6-490d-9b75-bc147a2153b3"}}	2026-05-08 15:30:44
wHrlzjrnV2E_CKeCPbhmThdlCHM_EEyd	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-08T15:31:52.508Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"passport":{"user":"4c5e1296-9aa6-490d-9b75-bc147a2153b3"}}	2026-05-08 15:31:53
uplNeghoVaH7G92bzFEQ52BxM7KdRaYB	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-08T15:21:12.109Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"passport":{"user":"4c5e1296-9aa6-490d-9b75-bc147a2153b3"}}	2026-05-08 15:21:13
IMA1CWiisetkg2TvM0gtkg7LyyS_YdU1	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-08T15:52:14.401Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"passport":{"user":"4c5e1296-9aa6-490d-9b75-bc147a2153b3"}}	2026-05-08 15:52:24
PDzVC4i-aygNnCTBDAuh4VZS8hpYipwE	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-08T15:52:39.587Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"passport":{"user":"4c5e1296-9aa6-490d-9b75-bc147a2153b3"}}	2026-05-08 15:52:45
\.


--
-- Data for Name: forum_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forum_attachments (id, post_id, reply_id, file_name, file_type, file_url, file_size, status, created_at) FROM stdin;
\.


--
-- Data for Name: forum_moderation_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forum_moderation_logs (id, post_id, reply_id, reported_by, moderated_by, report_reason, moderation_action, moderation_notes, status, reported_at, moderated_at) FROM stdin;
\.


--
-- Data for Name: forum_posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forum_posts (id, author_id, author_type, child_id, test_id, question_id, title, content, post_type, subject_id, chapter_id, is_anonymous, visibility, target_audience, assigned_mentor_id, assigned_teacher_id, status, upvotes, view_count, is_resolved, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forum_replies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forum_replies (id, post_id, author_id, author_type, parent_reply_id, content, is_anonymous, is_accepted_answer, upvotes, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forum_votes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forum_votes (id, user_id, post_id, reply_id, vote_type, created_at) FROM stdin;
\.


--
-- Data for Name: hr_audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hr_audit_logs (id, actor_user_id, action_type, target_type, target_id, previous_state, new_state, ip_address, user_agent, notes, created_at) FROM stdin;
\.


--
-- Data for Name: hr_consent_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hr_consent_logs (id, user_id, mentor_id, consent_type, consent_text, consent_given, ip_address, user_agent, consented_at, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: institute_staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.institute_staff (id, institute_id, user_id, role_id, staff_code, full_name, email, phone, department, status, joined_at, created_at) FROM stdin;
\.


--
-- Data for Name: institutes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.institutes (id, admin_user_id, institute_code, legal_name, display_name, status, created_at) FROM stdin;
\.


--
-- Data for Name: institutional_slas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.institutional_slas (id, institute_id, tier, response_time_hours, completion_target_percent, satisfaction_target_percent, reporting_frequency, dedicated_support, priority_escalation, custom_branding, effective_from, effective_until, created_at) FROM stdin;
\.


--
-- Data for Name: job_applications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_applications (id, job_id, applicant_user_id, full_name, email, phone, resume_url, cover_letter, source_channel, status, membership_fee, membership_paid_at, consent_captured, consent_captured_at, rejection_reason, processed_by, processed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: job_approval_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_approval_logs (id, job_id, from_status, to_status, action, comments, actor_id, actor_role, created_at) FROM stdin;
\.


--
-- Data for Name: job_distributions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_distributions (id, job_id, channel, external_post_id, posted_at, unpublished_at, reach_metrics, applications_from_channel, status, created_at) FROM stdin;
\.


--
-- Data for Name: job_postings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_postings (id, title, role_category, employment_type, work_mode, eligibility, qualifications, responsibilities, kpis, compensation_model, legal_clauses, status, hr_review_by, hr_review_at, hr_review_notes, legal_review_by, legal_review_at, legal_review_notes, leadership_approval_by, leadership_approval_at, leadership_approval_notes, published_at, closed_at, hiring_quota, hired_count, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: kyc_document_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kyc_document_types (id, entity_type, document_type, document_name, description, is_mandatory, validity_period, accepted_formats, max_file_size_mb, sample_doc_url, verification_instructions, display_order, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: kyc_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kyc_documents (id, entity_type, entity_id, entity_name, document_type, document_number, document_url, file_name, file_size, mime_type, status, maker_id, maker_verified_at, maker_notes, checker_id, checker_verified_at, checker_notes, rejection_reason, expiry_date, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lbi_age_band_weights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_age_band_weights (id, age_band_code, subdomain_code, weight, weight_type) FROM stdin;
14dee961-77cb-43f4-b9d9-a2ca59cedb8d	AB1	SD04_09	1	core
3d8c0cc0-3091-4443-bbab-dbfa0b153cb5	AB2	SD04_09	1	core
48b9930d-aea6-4cff-ac92-a35c8f5d1f1f	AB3	SD04_09	1	core
93e2374e-7f2b-4d64-82ac-d429fa43da1b	AB4	SD04_09	1	core
f9753c9c-1217-4f5a-8e1a-87cbe02c6d85	AB5	SD04_09	1	core
247f3f54-c3e0-4d8b-b31b-2f60bf55f254	AB6	SD04_09	1	core
cef2d005-a9d4-4e4b-b7f5-f225a73e24a7	AB1	SD05_02	1	core
fd476119-d084-485f-9282-633643003f9d	AB2	SD05_02	1	core
266cb1b5-404c-4c27-bdfd-9d94458e1457	AB3	SD05_02	1	core
da7c773f-2e83-4717-bf4e-ca6f93145f54	AB4	SD05_02	1	core
1f0b7f33-983f-43b7-9671-d45b31ffa856	AB5	SD05_02	1	core
7319d964-7570-4d1b-af73-643a86ccff62	AB6	SD05_02	1	core
28e881a7-dbce-41af-b501-c4a5e33d43d6	AB1	SD05_03	1	core
1f0954bf-ad9e-4f3b-ace9-e3cd2794ee7e	AB2	SD05_03	1	core
8d3d09fb-5614-4446-a6c1-53bba56777f9	AB3	SD05_03	1	core
91c2fdab-8341-4a20-a4de-c8d2fe0951d0	AB4	SD05_03	1	core
e423aa5e-7c38-4852-8bd8-bfd5db24690d	AB5	SD05_03	1	core
6bf3052f-8741-496d-b3f4-36a7b486f96b	AB6	SD05_03	1	core
26011548-3e0a-43ed-8721-e7915a340ec9	AB1	SD05_04	1	core
75bae26b-9fb1-4dc8-9f14-0160c1541004	AB2	SD05_04	1	core
a7bed077-2481-47ed-9c8a-da808f0de897	AB3	SD05_04	1	core
f6986b8f-6526-451e-9e31-20224a93c7d5	AB4	SD05_04	1	core
b5d79e24-97ac-48c7-bcc4-29cf2738689a	AB5	SD05_04	1	core
cce1e508-280b-4261-b860-a0df4cf04c34	AB6	SD05_04	1	core
f391f98b-6025-4b63-b1a5-04dcfc7fee24	AB1	SD06_01	1	core
93584786-664a-457f-adeb-7b4ce9f813f1	AB2	SD06_01	1	core
94875114-808d-47c7-8332-2204067ab4c9	AB3	SD06_01	1	core
51c00a9e-3f45-4545-bcbd-7f29c4db9dcf	AB4	SD06_01	1	core
caa29bde-c016-42ba-9bc6-4725ef937bd5	AB5	SD06_01	1	core
86610147-1a95-43d4-91e9-45519dd1a3e2	AB6	SD06_01	1	core
6cdd17a0-fc53-4a16-a3fc-d784836b3d1d	AB1	SD06_02	1	core
20e4a432-7744-4115-9940-93344c66be7c	AB2	SD06_02	1	core
45ffd1ff-820c-42a9-a2e1-7d958b7fb46c	AB3	SD06_02	1	core
d8b46f55-16ce-4b59-8c21-fdefd871c212	AB4	SD06_02	1	core
9c5be674-b0c4-4674-bccc-066145f46db6	AB5	SD06_02	1	core
1b0882db-64be-4cac-aaed-1d7bc2412be8	AB6	SD06_02	1	core
d96875d6-ed33-49da-b71b-6030d7ef3fa5	AB1	SD06_03	1	core
6bb27957-968f-4bab-b3d0-c2643a86c18d	AB2	SD06_03	1	core
218948bf-cf52-463f-a4d7-885cf83f9e14	AB3	SD06_03	1	core
053fdafe-6984-48f9-b519-51dad1e5570a	AB4	SD06_03	1	core
fab1afc1-1071-40ad-8b8c-bbf953b2b23e	AB5	SD06_03	1	core
65e82469-7a39-456b-977d-24f635bd915d	AB6	SD06_03	1	core
ba1f8342-76b4-4045-af7b-2f37331e087c	AB1	SD06_04	1	core
25f59432-de78-4021-987a-e8c4c34fade3	AB2	SD06_04	1	core
c1700a6e-cf45-4b64-bd2d-4427a72a1d0b	AB3	SD06_04	1	core
5198a398-af0c-49d1-93a2-b9b57fcc46ed	AB4	SD06_04	1	core
3a0ff7ef-9bcd-48df-82cf-88ef7efb6788	AB5	SD06_04	1	core
85f92cca-fe3e-4a3f-82c3-93636d2eddd8	AB6	SD06_04	1	core
80c5f70c-26e6-44af-8827-62ca00d48a1f	AB1	SD07_01	1	core
e9152da2-7ab8-406b-857a-472491e9a6fa	AB2	SD07_01	1	core
9915d7b5-c6c5-4095-a3de-f6c1c0017217	AB3	SD07_01	1	core
3a40bc17-7c78-4323-9549-524db6127296	AB4	SD07_01	1	core
9ba2ac4c-a4e8-4c38-b64e-4a9d4fc4ce34	AB5	SD07_01	1	core
0e101e78-55dd-43c1-9782-ad872c30d603	AB6	SD07_01	1	core
b5553ae5-daf2-421d-a102-f86cef31f6a6	AB1	SD07_02	1	core
8f596ead-2c41-4e42-b891-08e368057080	AB2	SD07_02	1	core
8a5d209b-4b16-4388-a124-8acf28620575	AB3	SD07_02	1	core
2b11f89d-940f-4ae4-86c1-6fcdb9951338	AB4	SD07_02	1	core
e80ef6fe-3c66-4873-ae56-6e68c00544ab	AB5	SD07_02	1	core
8635b136-4c8a-47c5-a78d-ff888f052f99	AB6	SD07_02	1	core
bad151c6-2e70-479b-b4a7-32ab983d4ac5	AB1	SD07_03	1	core
f690c3b9-785f-4e30-8410-f753860c0313	AB2	SD07_03	1	core
015e90e4-c694-4096-9317-d50326395601	AB3	SD07_03	1	core
fb508efd-4e25-401f-9c6a-3004afcbe2de	AB4	SD07_03	1	core
002e569d-0f4b-4e81-9ab6-6b5e2cf743e9	AB5	SD07_03	1	core
5351e0a7-c67f-4ada-99cd-df794bb53e20	AB6	SD07_03	1	core
2d06ced7-4f57-4b55-a293-d54f1711fed5	AB1	SD11_05	1	core
4977b833-8dc5-44a5-b5fd-457a416327fa	AB2	SD11_05	1	core
8fa6b9e4-af62-4574-9061-f8387725a967	AB3	SD11_05	1	core
9e8512d6-6c10-45fc-b9a3-86143ba1fe60	AB4	SD11_05	1	core
2eb89d2e-1a4f-44ff-835e-f165fd02439a	AB5	SD11_05	1	core
499d4a27-b637-4737-bbfd-8a56e445c46c	AB6	SD11_05	1	core
a6c3d99a-b19f-4a4f-9793-21ce699f793c	AB1	SD12_01	1	core
2ffeea4b-86b3-494d-82f4-0d517044c459	AB2	SD12_01	1	core
e8527b02-ef3b-461e-8686-a80268f9d6e7	AB3	SD12_01	1	core
a00cdc32-5c10-4c96-9dbf-001ec9555d91	AB4	SD12_01	1	core
21810111-7ed5-43b5-8c1d-5e83e4d4e69c	AB5	SD12_01	1	core
1ce4b029-60bd-41e7-8ac6-c81003a92c7a	AB6	SD12_01	1	core
b1135902-156a-41c1-8bc0-6d4c40b13842	AB1	SD12_02	1	core
3c94b440-2a40-41e6-8c56-9f8c70bea773	AB2	SD12_02	1	core
7fd35546-0a50-4476-8e43-108601216227	AB3	SD12_02	1	core
c442ca0b-c982-416c-938d-7ae33ffcb106	AB4	SD12_02	1	core
df13817f-1bf7-4c80-9085-6393fc39712b	AB5	SD12_02	1	core
997b77c3-53b2-4ba9-988a-d2b279ad9a5d	AB6	SD12_02	1	core
2e929b03-1ae1-4164-a2ff-677f0ba7bb9f	AB1	SD12_03	1	core
040de9fc-1135-4c3f-9899-2cf9293250a9	AB2	SD12_03	1	core
10eb6468-1453-4ff5-aece-6ff835eb07ef	AB3	SD12_03	1	core
af8f4fca-7e98-4059-a38f-1eddf9bdb7e7	AB4	SD12_03	1	core
6611ee6f-c712-4aec-be4d-15ab6d8e591d	AB5	SD12_03	1	core
ed05897d-0c67-4b94-b333-40a0fced6e5f	AB6	SD12_03	1	core
476ba764-a1f1-43c0-9725-5f433986d1d8	AB1	SD12_04	1	core
91b811f4-08c2-498d-a095-27409abf0bc2	AB2	SD12_04	1	core
4951d7d6-0dc6-4f16-9171-1c825861031b	AB3	SD12_04	1	core
9793bf76-5dd1-4351-97eb-bd74128a5a37	AB4	SD12_04	1	core
34a4f868-8bf1-4de5-b88e-24b4d491c0d6	AB5	SD12_04	1	core
672c6232-4933-435e-84df-ac88c2c8b1ca	AB6	SD12_04	1	core
5d4c3e9f-96ec-46da-8a90-4b4da805d2e1	AB1	SD13_01	1	core
049fef8d-5a40-44f6-9d88-553514d05edb	AB2	SD13_01	1	core
7d417152-2791-4004-944f-ab9de789a3c2	AB3	SD13_01	1	core
e4f7bc95-f832-4cba-a98f-661320da9dc0	AB4	SD13_01	1	core
48a743d1-27d5-43ae-a01b-4cf6b3a9c432	AB5	SD13_01	1	core
6f6021ae-a6ad-4b0e-a9a0-2ebf4738960e	AB6	SD13_01	1	core
44925576-d97f-4920-9a39-c99c53b81afc	AB1	SD13_02	1	core
293c81d3-54b1-480f-b6a9-bccb4ee03cf2	AB2	SD13_02	1	core
55354571-17f5-47e8-8cf7-6a51a3fd2d7a	AB3	SD13_02	1	core
e34db54d-274e-457e-bbbb-f105c0b39baa	AB4	SD13_02	1	core
27a98765-cdf4-41e4-a6eb-0c2183a56851	AB5	SD13_02	1	core
b442cd61-05f3-4334-8ae7-0d60dd8e6261	AB6	SD13_02	1	core
b92790b7-32d6-4cbf-8a7c-1958a5d3a9a2	AB1	SD13_03	1	core
c73cefe5-5ae7-46ec-90de-bd135d587e27	AB2	SD13_03	1	core
cd37288f-a645-4ee4-ad1d-41c52c8f991a	AB3	SD13_03	1	core
e64653a5-31a0-43fe-b867-f4b46bfd4d85	AB4	SD13_03	1	core
2766fdfa-025d-48ac-8ad9-51f020ccc8f7	AB5	SD13_03	1	core
16669b3b-7c3b-48d0-9c0a-725d23eac36a	AB6	SD13_03	1	core
5927109c-cde3-4fc6-8356-0b96a8803bc5	AB1	SD13_04	1	core
b169614f-80f7-4a0a-8224-b18a3eec756b	AB2	SD13_04	1	core
ab67677f-23ac-4cd7-9ec1-7eb083b77175	AB3	SD13_04	1	core
49ed64ad-6758-4398-8596-4cc3cd0defb9	AB4	SD13_04	1	core
a1ac171f-1b14-4507-9e7d-98f3c6e228d7	AB5	SD13_04	1	core
6eb545a4-8191-4db6-81a4-e80da0b305f7	AB6	SD13_04	1	core
b30c33f3-799a-4c74-a236-f041979e0d6a	AB1	SD13_05	1	core
c964205e-f7fc-4ba6-ba40-0be78dcbc7d0	AB2	SD13_05	1	core
721ce23c-ceed-472f-bc02-1f29ccd14e8e	AB3	SD13_05	1	core
1dcde6b4-eddd-43b0-9593-0bc5195746f1	AB4	SD13_05	1	core
d7d419de-49ee-4da7-add0-61911c3583b3	AB5	SD13_05	1	core
b089caee-b21c-4618-b52f-b0a600f9b045	AB6	SD13_05	1	core
bf450d28-21b6-453f-9508-760a63ee1138	AB1	SD13_06	1	core
43e2eec8-7a5f-4106-aa37-71db29c46c17	AB2	SD13_06	1	core
94b43d95-63a2-4071-a083-584a84c62cc1	AB3	SD13_06	1	core
db61c2bf-494d-433b-a90b-81aff204cdce	AB4	SD13_06	1	core
2cfbc422-7078-4019-8b30-9913519c2c8c	AB5	SD13_06	1	core
735047c7-c0f3-433e-a0c7-c00d6d9bccfe	AB6	SD13_06	1	core
4c6a56a9-bb80-4115-a450-0594907d1a01	AB1	SD14_01	1	core
91f1cf96-c3f0-4786-ae3a-e7b313c96173	AB2	SD14_01	1	core
1a969473-3812-4725-abe5-14b5f8fcc08b	AB3	SD14_01	1	core
8c2d29a5-bf70-436d-8835-5be3d74a6dd2	AB4	SD14_01	1	core
48450d93-270a-495e-9a8e-770aa43c71d3	AB5	SD14_01	1	core
840bbd3a-1843-4812-80b6-3c290ad8cf23	AB6	SD14_01	1	core
5a425db7-f5b0-49e5-9dc2-ea4eae2189ce	AB1	SD14_02	1	core
d4124f5f-96d6-4867-9a00-63166ea7fa96	AB2	SD14_02	1	core
6e97c643-3595-492b-ba16-727791063522	AB3	SD14_02	1	core
42d52efb-1c9f-4819-9b92-96c5518783fe	AB4	SD14_02	1	core
bc80df5e-5804-4181-81c2-c597abbd9164	AB5	SD14_02	1	core
c337606d-9be2-4b94-a97d-f687e71caf52	AB6	SD14_02	1	core
0999dcc5-a80d-4d06-aaff-47586e08d691	AB1	SD14_03	1	core
89b4fb66-a065-44d6-9a95-087aa5c43dbc	AB2	SD14_03	1	core
0c8fc8df-c261-4eac-8f63-57206479552c	AB3	SD14_03	1	core
acc86ac7-dc45-45cb-ac09-06c0bed3acf8	AB4	SD14_03	1	core
ae83b34a-111b-4283-b517-7327856d6df3	AB5	SD14_03	1	core
8f993958-25bb-47f2-8711-12c437dcdc2c	AB6	SD14_03	1	core
0a63e8f4-0163-4269-b448-8e00413c7726	AB1	SD15_01	1	core
1288563e-b87f-4012-ba98-7e6864ed44f4	AB2	SD15_01	1	core
025af239-acbb-404a-9193-05c1f6d9822f	AB3	SD15_01	1	core
5ae552e7-8cb7-40d3-a39e-3bcc0068c792	AB4	SD15_01	1	core
9048b510-a22e-452c-951f-64277e344640	AB5	SD15_01	1	core
a0f6ea23-f7eb-4666-a171-139e1ba22ded	AB6	SD15_01	1	core
927dd5a8-e779-4c57-a98f-ae7e5b920a49	AB1	SD15_02	1	core
ce4804a0-730a-4851-a611-d557661997e0	AB2	SD15_02	1	core
080ce0e5-73b1-481a-a3f4-77563f9f42b3	AB3	SD15_02	1	core
2731183e-0980-44cc-b2a6-5a15e270105c	AB4	SD15_02	1	core
01f33241-1dad-4241-8403-751a7ebec577	AB5	SD15_02	1	core
768ebd10-9fab-4e03-af15-11cc72d6dbca	AB6	SD15_02	1	core
90f72e11-356f-4920-ba40-94758f8c9a14	AB1	SD15_03	1	core
f5fe510d-fd9d-4fbf-930c-f3a2cc21f1ed	AB2	SD15_03	1	core
1dac07e8-e5f8-4cba-aaa1-bde7e731646b	AB3	SD15_03	1	core
6f5fbb54-1a26-429b-b337-9b43ce850aac	AB4	SD15_03	1	core
e7565962-5435-4204-9831-8982b0f16d2a	AB5	SD15_03	1	core
c3d000f2-123a-4ff0-a6fb-beba1deb75fa	AB6	SD15_03	1	core
593e00b0-8bc9-44bf-bc21-a701c4356e0a	AB1	SD15_04	1	core
84841567-5529-43f4-aa5b-595bcde8661e	AB2	SD15_04	1	core
2de01183-1371-4642-8f8f-8d1e25aae774	AB3	SD15_04	1	core
435166c9-ec4f-4c0e-b528-cb5773d0e3bb	AB4	SD15_04	1	core
3e214356-8793-4879-be18-4a52e3d83f3f	AB5	SD15_04	1	core
f203ddb6-9ee8-4b23-bbbb-5f857cfde6e3	AB6	SD15_04	1	core
e29dcabe-c9e2-4f30-841a-7da4bc3a703a	AB1	SD16_01	1	core
a409abd4-57a8-47f4-ac84-0d8fc0761947	AB2	SD16_01	1	core
1425e2cc-0c6b-47a0-b800-0c9c671e641a	AB3	SD16_01	1	core
e522d310-1496-45fc-b34d-5f69af5d3748	AB4	SD16_01	1	core
236fc8ce-e156-4a23-b596-666d9035d770	AB5	SD16_01	1	core
abda91d2-e498-441f-9d49-b81e98eed0b6	AB6	SD16_01	1	core
0988cc63-32ae-41a8-84f6-6de0d1aa523e	AB1	SD16_02	1	core
233eed6a-782f-4475-bc0c-a7d1a7c80a21	AB2	SD16_02	1	core
987cc518-1310-4972-8d43-7441fb5edeb2	AB3	SD16_02	1	core
f95cf515-40e7-4b1d-bee4-0cf5cafb5878	AB4	SD16_02	1	core
fcffbb33-5b68-4514-b477-9b742ae56fd3	AB5	SD16_02	1	core
e0fddc9f-50ec-4fe1-8547-544f05fce164	AB6	SD16_02	1	core
bad95d8f-7a66-45e0-b96e-b78e01482fe8	AB1	SD16_03	1	core
db2b37fe-ce5a-4859-802f-26a1a229825b	AB2	SD16_03	1	core
97219755-1367-4075-8511-6db5f5d8c6ba	AB3	SD16_03	1	core
e3be38d9-65bb-4973-80a4-f0f5dab0bc1f	AB4	SD16_03	1	core
e1fbd751-c988-4e53-8308-60465951066c	AB5	SD16_03	1	core
e1a9da43-163e-4b7b-aaa1-ccd8cfbd536d	AB6	SD16_03	1	core
f11abf39-ebe8-4e90-8c26-28fea76bb680	AB1	SD16_04	1	core
32e3354e-46d3-4638-b6cf-340685c1a3e1	AB2	SD16_04	1	core
5c3ae596-9ff5-4252-bd44-c16f946a3b57	AB3	SD16_04	1	core
6fc07365-4e38-426b-93e6-d2a3fce33c74	AB4	SD16_04	1	core
3c5b6b3f-fec9-4e7e-bb7c-9ad7733274c8	AB5	SD16_04	1	core
ae63b79f-d613-4704-9337-045556b7fc10	AB6	SD16_04	1	core
16a5ddbd-f701-4363-a5be-6b50fa30e81e	AB1	SD17_01	1	core
5388fb12-c869-421b-85ec-728e53b3307a	AB2	SD17_01	1	core
0c74161f-fe30-478f-9cdc-eca64454c5a1	AB3	SD17_01	1	core
b197c6c8-5b0f-4f97-af3e-e5fa12d5a02a	AB4	SD17_01	1	core
7bab7d2a-8f98-496b-b75c-861f60b1d2a0	AB5	SD17_01	1	core
e64338e3-3e4d-42ae-b615-4d319a32f94a	AB6	SD17_01	1	core
e4db63c5-2ede-4e66-940d-fa210c903849	AB1	SD17_02	1	core
5911d017-cdfe-4e9b-82a2-bc743dde05b0	AB2	SD17_02	1	core
7a8e1137-c78a-4db2-ae47-d3c856d63f78	AB3	SD17_02	1	core
e90440f4-2402-422f-bfa5-5c5a2afe39f1	AB4	SD17_02	1	core
1085c6fb-f1c5-41a7-b33d-bb614e71a9ba	AB5	SD17_02	1	core
2d232e0e-5d0c-42c2-ac74-8e6ee172120c	AB6	SD17_02	1	core
ea2da643-af3d-4af4-a190-364c5bb3a674	AB1	SD17_03	1	core
fefefcb8-019e-48be-8b18-a6e9fb803139	AB2	SD17_03	1	core
92f01146-6546-4180-99a5-76abc1d27ad4	AB3	SD17_03	1	core
23f264eb-1ef6-437a-a384-78de321859b0	AB4	SD17_03	1	core
e863529a-7990-4ce6-8d57-8c9bc563c579	AB5	SD17_03	1	core
a2acdad9-257b-4fa1-a800-061911114132	AB6	SD17_03	1	core
eb117816-7dc1-4986-98ff-8f5b41819b30	AB1	SD17_04	1	core
a9933208-d6e8-4ca0-a80d-8c68b60a1a59	AB2	SD17_04	1	core
694fe93b-3297-4ae3-9ba0-8e79ad77d245	AB3	SD17_04	1	core
db6355ed-78ff-4b84-adfe-fad5a3f38ddd	AB4	SD17_04	1	core
7d586731-cf48-44e8-a693-2589d757b0ad	AB5	SD17_04	1	core
e35b92bc-f265-4b15-aca0-c6e886c8ec64	AB6	SD17_04	1	core
e26818b3-8c9f-4cce-a6ab-39ec0492e834	AB1	SD01_01	1	core
88a66e68-c091-4127-8795-2d18fb0f6237	AB2	SD01_01	1	core
e7e23f24-333f-4f2c-ae40-262eb73f84f6	AB3	SD01_01	1	core
7af9704a-dceb-4d53-b1db-ca21f8f85d0a	AB4	SD01_01	1	core
dcaf876b-b998-431c-a15d-e242aab6b972	AB5	SD01_01	1	core
8da9f927-9020-409b-835b-26c2295e2a46	AB6	SD01_01	1	core
5f653ef5-0db7-4886-b150-96b1c62e3beb	AB1	SD01_02	1	core
dba9d19f-f54c-4a76-8540-f07ace22758c	AB2	SD01_02	1	core
4b82f175-2122-4be5-8d7e-3a70c2aefe07	AB3	SD01_02	1	core
c84bf067-ea17-4b81-9439-f94138d871ac	AB4	SD01_02	1	core
c6b142a2-c944-400b-8b6d-b4b2198604e0	AB5	SD01_02	1	core
6a7b7775-5dfd-44f5-bcfd-7fff6da9256e	AB6	SD01_02	1	core
92743958-da44-4fc8-8a37-c4f8c002edf0	AB1	SD01_03	1	core
5ae1710f-9b78-4402-a265-f90381bbf539	AB2	SD01_03	1	core
35556636-89ec-4d9e-8c94-038239603196	AB3	SD01_03	1	core
5766b9ed-56de-4c1f-8a08-c5873d22c0ac	AB4	SD01_03	1	core
d00b70ad-aba1-4fcb-8bc7-a74eefb08006	AB5	SD01_03	1	core
a7d6e626-7521-4841-8263-2802a03d0b81	AB6	SD01_03	1	core
85ef20be-a0d1-4064-b36f-c5436226dfe3	AB1	SD01_04	1	core
7f275359-0764-454a-ba78-9806b1b57428	AB2	SD01_04	1	core
fe330cac-3eba-4b65-be20-6e76a2ad2f7f	AB3	SD01_04	1	core
1878caea-db27-44f6-9c85-7558be15b9b0	AB4	SD01_04	1	core
3ea4da32-70ca-42a8-ba50-1cd676aff687	AB5	SD01_04	1	core
84592e13-49d7-47ae-8379-2cfc32986c79	AB6	SD01_04	1	core
a7d6e6b0-3774-4969-8c81-3167e29f71fd	AB1	SD01_05	1	core
ca9d684c-f83a-4800-b916-122a24bb4582	AB2	SD01_05	1	core
2ff191fe-36fb-40ed-8d4b-2231f80b0d1a	AB3	SD01_05	1	core
3624d33b-b6de-40de-ad24-35ebd638d774	AB4	SD01_05	1	core
b12e173b-4392-42af-b720-4e8829f81656	AB5	SD01_05	1	core
f631674b-069f-4bf2-a89a-33c04a30a00b	AB6	SD01_05	1	core
67b6fae3-a6e7-42ec-8c78-643123c8edf9	AB1	SD01_06	1	core
a3afcdb2-95a4-49d2-bd88-2bdbb48a594d	AB2	SD01_06	1	core
92750405-5836-45ea-84af-31f5eab4c29a	AB3	SD01_06	1	core
3ee9758f-6f85-450e-8824-febdc2678782	AB4	SD01_06	1	core
803e8151-4b3d-436a-b092-804631ab1e24	AB5	SD01_06	1	core
26e5092f-8159-48f6-9ec8-63eb1faf7546	AB6	SD01_06	1	core
24c5c20e-a6af-41e7-8108-57c9fc58ed2e	AB1	SD02_01	1	core
a8692708-8d8b-4856-849f-310987d09782	AB2	SD02_01	1	core
df9c3b6d-40f4-41d2-8149-df353554b4b2	AB3	SD02_01	1	core
c506ded3-4301-484a-b7e2-8d1344813dba	AB4	SD02_01	1	core
891e1ecd-07ba-4129-a33e-55e6f0ac6252	AB5	SD02_01	1	core
55ad92d4-8d31-4b2e-b1ac-677635af4091	AB6	SD02_01	1	core
4dab24b9-2336-45b4-9a05-94d291bf6861	AB1	SD02_02	1	core
aea17d10-e4a1-4bc4-8182-abd526a04726	AB2	SD02_02	1	core
f24e8bef-1133-463a-97bf-59a27a45608b	AB3	SD02_02	1	core
fefdc2af-67ec-410c-b746-7f100c9427fe	AB4	SD02_02	1	core
b890d396-aaf8-4725-b62a-109cfdd35ae1	AB5	SD02_02	1	core
d0d0557c-1f78-49e3-8fa8-6f96efb66374	AB6	SD02_02	1	core
89aeb91b-95ea-4676-b677-72fa7dd794e0	AB1	SD02_03	1	core
2337c4a2-f646-403b-9921-921249637ad3	AB2	SD02_03	1	core
8a965ba7-c167-41c4-b0de-46074775ac52	AB3	SD02_03	1	core
9cd6f8c8-3e5c-498c-a119-780fa7f860e2	AB4	SD02_03	1	core
c4e858da-3b4c-42eb-bfd9-da1e90eaa7c7	AB5	SD02_03	1	core
c1fcc550-3e99-4aff-9ff4-2b8a0fe13565	AB6	SD02_03	1	core
6854b881-ffeb-4928-8117-1038acc31096	AB1	SD02_04	1	core
19c1df3f-4394-41f5-bfa7-0e3486c9a3dd	AB2	SD02_04	1	core
1446b484-634b-4657-9b4b-87037e06edd2	AB3	SD02_04	1	core
65f6452f-88bc-47d8-a3d9-a8cc28afd5fa	AB4	SD02_04	1	core
7c6c1b3a-7dfd-4801-823d-583de4609fe9	AB5	SD02_04	1	core
e1e8d778-d58d-48e8-91f8-e5cbea621597	AB6	SD02_04	1	core
977be003-4090-4a91-8bad-9fd177dfa4d9	AB1	SD02_05	1	core
77a73b14-475f-4d71-8a7b-1abfda0033da	AB2	SD02_05	1	core
b3bec0cb-7dfd-4fdd-8080-986b36488085	AB3	SD02_05	1	core
ebdc69c9-63e5-4c17-8656-319b61bd3b97	AB4	SD02_05	1	core
2d90f0ad-cd4c-4c54-9d0c-4d82934dc810	AB5	SD02_05	1	core
62a70e2c-d8b6-4a8d-b95c-ba9157e47ab1	AB6	SD02_05	1	core
682eeace-debc-43b0-b49c-64aeb268d55a	AB1	SD02_06	1	core
e3396357-291a-4d9b-91b5-ab19b88d1de3	AB2	SD02_06	1	core
26879560-4651-41a3-bff2-45468f32b058	AB3	SD02_06	1	core
da5961fc-7ee6-4a15-8afc-6a80c1ad15eb	AB4	SD02_06	1	core
f80c3725-e995-42c6-9d20-5edbeddef377	AB5	SD02_06	1	core
ffbbe204-8cb3-49c9-a24b-8e81ed147aab	AB6	SD02_06	1	core
4a6c962a-ae77-4242-8a22-692be56d7485	AB1	SD02_07	1	core
b786f668-b368-4baf-be6c-c5e1edaecf2e	AB2	SD02_07	1	core
aa1afe3f-6826-45be-bebe-8819662f9f5e	AB3	SD02_07	1	core
a55992b6-43ae-4cc4-8afa-be0da9e0b016	AB4	SD02_07	1	core
469ae924-54a7-413d-8dcd-a5530d7114d4	AB5	SD02_07	1	core
3ab2caa2-a1c1-4225-a54d-87bbe876868b	AB6	SD02_07	1	core
86f064aa-130e-4ddb-a7fa-9a15a983bc29	AB1	SD02_08	1	core
5cedd5b4-f496-4ba1-bb32-50e530e39d43	AB2	SD02_08	1	core
255dc948-7e04-44b7-be5c-30875be1d305	AB3	SD02_08	1	core
c5bd7f9f-6e66-4eab-abc9-5adeafd40ca3	AB4	SD02_08	1	core
d0d66102-d9d6-4d06-93da-24dfec808f07	AB5	SD02_08	1	core
da7ac451-e9f4-4492-92e3-3043274929b4	AB6	SD02_08	1	core
886934ce-bd59-4f7a-bf4f-3ed550a9fdc4	AB1	SD03_01	1	core
aad5ef51-1115-4b5f-bc89-cb30e9a305a5	AB2	SD03_01	1	core
e157d782-5154-473c-843c-7bd5f759d198	AB3	SD03_01	1	core
ed137558-72ab-40c1-80db-264eee47e9a6	AB4	SD03_01	1	core
bfbfdd95-ac9e-4621-b712-5c4e2b575956	AB5	SD03_01	1	core
ab40a443-1ed2-418e-a216-9bada058c817	AB6	SD03_01	1	core
d5ef8310-b9c9-4b0f-ac7e-6a7bb04a4377	AB1	SD03_02	1	core
7d55ee85-7a41-49c8-8cab-1f1b3623f9db	AB2	SD03_02	1	core
c643e51c-8b9a-43eb-b96e-bfb5ab68c092	AB3	SD03_02	1	core
bd64cec4-f713-4826-95d5-2cb44d5056e9	AB4	SD03_02	1	core
f68b7ba2-3479-443a-b2be-08aceeefea2b	AB5	SD03_02	1	core
3ebb0f1f-762f-48c5-a111-314a6bc3247f	AB6	SD03_02	1	core
4fe5f20e-3a91-4ab4-a7dc-96c41e606950	AB1	SD03_03	1	core
2bebd2cd-a5b2-4e53-9b45-838270e28fc4	AB2	SD03_03	1	core
46ed44ec-2312-429b-b3f0-c4ecdf20f32d	AB3	SD03_03	1	core
e4e6c2de-d955-46de-b4ac-4c127efc739d	AB4	SD03_03	1	core
b43382c8-642f-4bf8-af93-d7a3319c68c3	AB5	SD03_03	1	core
6ecf6069-8036-41b2-a260-3c598acdd63b	AB6	SD03_03	1	core
8b918753-cb23-4e8f-bf8e-e3ac144a1ea6	AB1	SD03_04	1	core
724a9c25-b47a-4d8b-a3ed-59ce8623604c	AB2	SD03_04	1	core
819d3a10-30fd-4bc9-b1ef-2f5e12b93e22	AB3	SD03_04	1	core
974b434e-8b2a-45de-a456-4cb8d568d369	AB4	SD03_04	1	core
c0c7ac50-5876-4241-bcf4-fa32fb0989f4	AB5	SD03_04	1	core
dc21e756-dc86-4169-be42-212ebebb6072	AB6	SD03_04	1	core
2d67b9d6-108c-41a1-9665-0ae5412634f6	AB1	SD03_05	1	core
da633d2d-ddcd-411e-a06f-a5a4a2ea10cf	AB2	SD03_05	1	core
b28d7adb-8090-4755-a578-87a65f129d36	AB3	SD03_05	1	core
b251c921-b84d-4f9c-9579-838b5ac86b9c	AB4	SD03_05	1	core
64d885f0-ff73-4215-b7c0-527d67155366	AB5	SD03_05	1	core
848da8b6-a91a-4798-b0ed-27f6f5820604	AB6	SD03_05	1	core
0a91d9a4-9206-4ffd-8ca0-03f730d2f0de	AB1	SD03_06	1	core
f542ffe0-6789-47db-ad50-2cdce0c094ff	AB2	SD03_06	1	core
958333b2-a75f-40c2-bb3b-8eaa4873ed61	AB3	SD03_06	1	core
7f1003b7-65e2-45a8-8a43-65342f9c709d	AB4	SD03_06	1	core
58403057-77b0-4a3b-ae7b-3f3dcaf015ad	AB5	SD03_06	1	core
bdb6e5f6-983e-47be-8ba9-b73b788e137f	AB6	SD03_06	1	core
79a20d85-c6e9-4fee-b636-8efdd5b48d46	AB1	SD03_07	1	core
221a6f5c-c1a4-4fa7-8f4a-73310b854722	AB2	SD03_07	1	core
cb71ee25-df00-48cb-8424-93e10847e276	AB3	SD03_07	1	core
fd659590-d6b0-40c9-a862-82afd2d65351	AB4	SD03_07	1	core
d6318a7e-d99f-4f36-8a0b-2399870d59b9	AB5	SD03_07	1	core
66bfbae1-2f99-4363-b8a3-f8431cb10fee	AB6	SD03_07	1	core
036b9830-d5bf-4e47-98f2-2588d225a829	AB1	SD03_08	1	core
e264be8d-0b28-4ef6-9bd3-a55d4a5b37d9	AB2	SD03_08	1	core
23059a6c-dfb2-4ce8-8086-aaf44b139807	AB3	SD03_08	1	core
9fa809f6-877f-4421-8dec-d9822c7233e9	AB4	SD03_08	1	core
11651664-ca6f-4ef1-941d-a6eb5dffa95f	AB5	SD03_08	1	core
3ca109ae-1315-4a65-b492-463e86bae209	AB6	SD03_08	1	core
c0d3191a-c0dd-4c50-99f0-f123c463f853	AB1	SD03_09	1	core
cd73ad05-b7d2-4511-9376-64b02ba3d921	AB2	SD03_09	1	core
73a63562-ffe8-4574-9131-a5a7d767474c	AB3	SD03_09	1	core
3d50d208-3a3d-4083-b09f-24f0695bdadd	AB4	SD03_09	1	core
3e837c9c-4285-4ce8-9a16-51c87f2ad167	AB5	SD03_09	1	core
c2ba2e66-6b1e-4d11-8d78-6878d83b523b	AB6	SD03_09	1	core
ff919a6d-883a-4ff3-91d6-933a1ab7735a	AB1	SD04_01	1	core
3fdd1f68-e647-466d-965d-911d08285d21	AB2	SD04_01	1	core
015e8438-b6d0-49aa-92b4-37a4cbad00d9	AB3	SD04_01	1	core
ead84b64-aa2c-4795-8829-90938884989e	AB4	SD04_01	1	core
32321e14-d003-4f02-a284-add683d024b1	AB5	SD04_01	1	core
f1ca497d-b949-4f4d-8444-05b0d2419975	AB6	SD04_01	1	core
1190d143-a48d-46f8-9c4e-354f809d8163	AB1	SD04_02	1	core
565352e9-e966-4e27-8d3d-a3488df75397	AB2	SD04_02	1	core
e8812fdf-bee3-495d-a507-1b3866048008	AB3	SD04_02	1	core
0627dc8c-a90a-400b-a105-fbd29d8aeea9	AB4	SD04_02	1	core
ee1931e6-0cd6-40f3-8774-b06b866de471	AB5	SD04_02	1	core
649e63f9-0994-4772-bebe-0f6ffc0a135b	AB6	SD04_02	1	core
3695bf17-9696-4a5d-90c5-0460c2d59793	AB1	SD04_03	1	core
e4c383a6-f975-4f17-8257-97d04de39650	AB2	SD04_03	1	core
19aadddd-f393-4b2c-8fef-654bba63c9f8	AB3	SD04_03	1	core
3724f864-5d07-41d7-ba72-fd21862255b6	AB4	SD04_03	1	core
7346c053-e970-4e54-9365-a5830cc12672	AB5	SD04_03	1	core
21bd4adc-27e2-4564-8700-d1459faf0faa	AB6	SD04_03	1	core
b195fa89-5d08-447f-a283-b9a28579e1b7	AB1	SD04_04	1	core
1f3898c1-647b-447d-8e56-08065427e72b	AB2	SD04_04	1	core
0648ea81-eb4f-4e3b-a8aa-85cb99524c43	AB3	SD04_04	1	core
28ab74ea-d0a2-4de2-acbe-6ba84c779034	AB4	SD04_04	1	core
49fdc438-af9c-40c4-b7fb-b883f6243897	AB5	SD04_04	1	core
78a6b3d4-fd2d-4817-b26c-520d6ca08aa0	AB6	SD04_04	1	core
96ebf015-b8d6-4ea7-8861-98b0b65cafc2	AB1	SD04_05	1	core
7226b42a-98ae-4744-8c99-dce1b16788cb	AB2	SD04_05	1	core
b6cf8aa3-ef63-4206-b965-fef72cfa3fb5	AB3	SD04_05	1	core
7b585a76-5987-4adc-b9f9-265ca630baa3	AB4	SD04_05	1	core
f3a72214-1b5b-4ab5-8576-24526499c030	AB5	SD04_05	1	core
066e358b-c5a6-4a52-af6d-db8944c23dad	AB6	SD04_05	1	core
5026a916-ffb5-48e8-b997-dbc984b5b378	AB1	SD07_04	1	core
c1d12e9a-aae5-4e20-8334-8b8f52c054e0	AB2	SD07_04	1	core
270335ee-9ce4-480a-a40b-b5499f8af11b	AB3	SD07_04	1	core
00ad9b2c-af05-4251-b94b-aa878285e72e	AB4	SD07_04	1	core
e87ded9f-49d1-4d6a-b958-791e748a0411	AB5	SD07_04	1	core
4f326f0e-3d1e-4f06-96f0-28449f789302	AB6	SD07_04	1	core
5637b397-a783-4d80-9b9b-836c59a72748	AB1	SD07_05	1	core
f18d84ec-d83c-4436-816c-636ec98f540a	AB2	SD07_05	1	core
c76eb659-1af4-4b33-854e-6b4d6272d38c	AB3	SD07_05	1	core
4c1d8de3-c82d-4e0e-9b7d-51e707d41414	AB4	SD07_05	1	core
9357deda-e06c-445b-834d-8e745b4775f1	AB5	SD07_05	1	core
ec0ddf1f-82e0-4787-9413-cdc38727610b	AB6	SD07_05	1	core
2098a9a0-d65c-48c9-8537-5013a4a4681a	AB1	SD08_01	1	core
2cab19d1-82d1-44d1-874c-724f6cb630b8	AB2	SD08_01	1	core
2f3bc9ab-b028-4352-8f96-5be8b7c547e7	AB3	SD08_01	1	core
eb4bc8b8-0b7c-41dd-ba89-6e7b576c3e00	AB4	SD08_01	1	core
a504003f-bd1f-4c55-b62f-eee349378931	AB5	SD08_01	1	core
6a2a2439-46b4-4aea-8b62-d3648932951c	AB6	SD08_01	1	core
f67696b9-b3dc-4ba7-b963-43d7cef014db	AB1	SD08_02	1	core
d535febe-e007-4322-8ea8-a534be84dbcf	AB2	SD08_02	1	core
c9ae02a1-3005-4f6b-876f-4615c94ac2db	AB3	SD08_02	1	core
8dde91e0-de0d-4074-9590-5d6cd5b1b0e0	AB4	SD08_02	1	core
8a2d9843-0426-4894-ae2f-332e5c251a75	AB5	SD08_02	1	core
5d1b0ef9-25df-4ea5-b096-c0a1292f919c	AB6	SD08_02	1	core
ce0c52d8-2fa8-447a-86d6-be939aa6360f	AB1	SD08_03	1	core
957b517a-32d5-4899-a1f2-2a17918c3866	AB2	SD08_03	1	core
4d71f7ad-cae0-4cc0-8c7e-57a0ef8d0b89	AB3	SD08_03	1	core
d06c1417-570d-4be9-ac92-81485caf66b0	AB4	SD08_03	1	core
8223785d-623b-426a-8528-8938c0029f2f	AB5	SD08_03	1	core
f54584cb-4a76-4953-9dee-d1cec8d4302a	AB6	SD08_03	1	core
59547736-32b7-4481-ae05-9e71891c49ed	AB1	SD08_04	1	core
e19565e7-f49f-4e3c-af71-6e79bc574d04	AB2	SD08_04	1	core
47563ca5-51c3-42c2-937a-8019592fb3c7	AB3	SD08_04	1	core
8aec53f7-d29d-4ec0-8b63-ac2f01358a92	AB4	SD08_04	1	core
113ee08c-68c1-434d-bcbf-974b88bb158c	AB5	SD08_04	1	core
7a22694f-f5e5-47ed-ab9c-d918baae1988	AB6	SD08_04	1	core
fb010b7c-664e-4d3b-a684-09a3b4e9f7c4	AB1	SD08_05	1	core
1b82a05f-af2f-44ca-b743-e767c4929454	AB2	SD08_05	1	core
8a1469b0-776f-43a1-b700-37958b282228	AB3	SD08_05	1	core
1dc10856-7b77-42eb-9820-8c1122a491c3	AB4	SD08_05	1	core
07305021-09d2-46c8-9fc6-6fcf615681d5	AB5	SD08_05	1	core
f1cde1ef-c903-4e8e-97ab-482a633dcebb	AB6	SD08_05	1	core
67fc1fbc-3b39-42e9-93f8-9a4efe0de7d4	AB1	SD09_01	1	core
5d50d26f-1b1b-4652-a4b1-bd7e5a1c4f77	AB2	SD09_01	1	core
8d9966a0-2023-4643-9db5-a9fd87ff8d3b	AB3	SD09_01	1	core
68b68217-b5d5-4ee7-8e36-b394ea925042	AB4	SD09_01	1	core
5a79e29a-a2ce-4aa0-8030-f2855592bd03	AB5	SD09_01	1	core
aaea6e63-639b-4af0-b147-994d34aa43ae	AB6	SD09_01	1	core
44ff554d-124e-4c81-bbf5-43ca42448183	AB1	SD09_02	1	core
ee409595-c443-4a36-aad1-bb3b6d9312c4	AB2	SD09_02	1	core
42959776-1493-42ba-bb28-778e92d1d117	AB3	SD09_02	1	core
3fe630c5-1dac-40fa-8806-6c531dcb0fcd	AB4	SD09_02	1	core
b92756c3-6bf7-49cc-913e-2344c4358874	AB5	SD09_02	1	core
d489b54e-5143-470c-a1be-f6b9ff5a85a8	AB6	SD09_02	1	core
52843668-f1a4-4949-b8c8-79079d939a8a	AB1	SD09_03	1	core
7ddc46cb-12c2-4aa2-855d-25d9a0b11520	AB2	SD09_03	1	core
f6cd4a32-21fb-4cef-b6e0-dfdede14b2b7	AB3	SD09_03	1	core
738f00ac-19b0-4076-82f7-f1613df0ab8b	AB4	SD09_03	1	core
893e4cea-5cfa-477d-b277-05c9691d8e83	AB5	SD09_03	1	core
cf4052dd-e509-4e00-b301-2430325c8ef3	AB6	SD09_03	1	core
e773d83f-350f-4c4e-b95f-2e6450c72154	AB1	SD09_04	1	core
fa934884-b9e4-42dc-b0d4-3cb1d4f84d9c	AB2	SD09_04	1	core
6c01f9cc-db62-450d-8678-74da28653807	AB3	SD09_04	1	core
0a493fb5-c281-4026-a58e-b59b0f953f8b	AB4	SD09_04	1	core
0a10d666-be4b-4f9d-9bbc-f3df27d225fe	AB5	SD09_04	1	core
6a3dc0fa-d9f8-427b-9fe9-4abf54450c72	AB6	SD09_04	1	core
74ae38b4-7904-441b-a774-a673250672cd	AB1	SD09_05	1	core
90ded982-3a79-451a-80fa-706b148d86df	AB2	SD09_05	1	core
21db7f71-a043-45fe-923a-0e08594d61d3	AB3	SD09_05	1	core
b286cb45-4553-4a3a-9438-0bf67493054e	AB4	SD09_05	1	core
2f17a6c1-7adb-4d71-b8e1-654f7ed7cce7	AB5	SD09_05	1	core
d9a56297-c586-4c9c-b5f2-1038344a8510	AB6	SD09_05	1	core
4179e100-77c7-4c48-a8f9-7a7c71d78069	AB1	SD10_01	1	core
1c3ee17f-9824-4ce3-89a6-d641189f07e8	AB2	SD10_01	1	core
5085a426-df93-44c3-bca0-b738b7cf3108	AB3	SD10_01	1	core
664e859d-cc9f-4d9e-b876-70b15f06266b	AB4	SD10_01	1	core
b7d644bb-59a5-44b2-8d6b-25d16605a9c8	AB5	SD10_01	1	core
684707b3-8829-4167-8188-f6eef06a7db7	AB6	SD10_01	1	core
185d548a-cd03-45e4-8e22-546664c98b25	AB1	SD10_02	1	core
09aaeac2-220a-4306-9d3c-0379c69d557e	AB2	SD10_02	1	core
78cc6984-299d-4846-a862-da565e705285	AB3	SD10_02	1	core
dd85a1cf-ddac-40e3-a4c7-12d904bfd85c	AB4	SD10_02	1	core
d0ca3f0a-afd8-41ec-98e6-2ab56a4ecde8	AB5	SD10_02	1	core
97ef3135-19cb-4e49-9937-77106a177558	AB6	SD10_02	1	core
d73cc8d1-ea35-4625-9e0c-0b86c8ef4766	AB1	SD10_03	1	core
7f1cd7e7-40b8-4cd7-aee6-6dfd68b50c97	AB2	SD10_03	1	core
aab3e39a-447f-46d1-bbda-4539eeea241a	AB3	SD10_03	1	core
066227e5-ea2b-456b-9746-d3fa010f9571	AB4	SD10_03	1	core
f73fc17a-907e-4cd1-9b45-f7a51e9142bc	AB5	SD10_03	1	core
293e69c1-7663-4bc7-be7a-6b9cd7a03777	AB6	SD10_03	1	core
b31594a0-053f-4d8f-a871-57eb07d894d6	AB1	SD10_04	1	core
f5bb641a-2b5e-4c7f-92eb-dda65f5a7951	AB2	SD10_04	1	core
8e6af019-09e0-4e9a-bc3d-8c120ace5fee	AB3	SD10_04	1	core
27331a6b-aebb-4c09-afe5-815d21a163d4	AB4	SD10_04	1	core
cbb9449b-6278-4077-98f7-f2ecfdf238e5	AB5	SD10_04	1	core
ce575f9b-16dc-49eb-b7fe-fa2533f9abe2	AB6	SD10_04	1	core
31b61c8c-5357-4dca-98da-1df20e3d3ba3	AB1	SD11_01	1	core
3d45560e-a881-46a4-bd3a-d24aeb73ccf2	AB2	SD11_01	1	core
5ce27bfd-45a4-44f3-ba19-cc93ac191139	AB3	SD11_01	1	core
68e4d9db-49b1-4140-97b4-c7ff265cd49e	AB4	SD11_01	1	core
d2327e82-d364-4e72-9fee-5ac9f128a5f0	AB5	SD11_01	1	core
ef78e816-659f-4bf6-a2d5-8130d120462f	AB6	SD11_01	1	core
07a2cb43-d7bf-4a2c-9ad4-666cb8c8dc4c	AB1	SD11_02	1	core
be646ba6-41a0-4129-aa12-96a9db18efe2	AB2	SD11_02	1	core
52dcd39d-9835-4c4c-99cb-5fd4a401ace6	AB3	SD11_02	1	core
9f513553-006a-410f-8e51-49e6fc0fa045	AB4	SD11_02	1	core
d233c8e6-d80a-4477-ae4a-83a9dd1ef22e	AB5	SD11_02	1	core
ff2a0744-3288-4917-a7f8-79b96a189226	AB6	SD11_02	1	core
a824f6ad-40aa-4bf4-b377-15c55746c817	AB1	SD11_03	1	core
87f5e773-483c-4725-a912-8d7205eea8e7	AB2	SD11_03	1	core
1a1b7bf5-1f3d-4178-88a7-9558db697114	AB3	SD11_03	1	core
6b5c6128-d6ea-4e71-a338-b6e43b169b8b	AB4	SD11_03	1	core
93e04810-2f45-4b0a-a461-e5d07be5aa3f	AB5	SD11_03	1	core
bbd92cae-c2c3-4565-93e0-b35f00ff459c	AB6	SD11_03	1	core
5d094136-c727-427e-887a-64b282cd2b20	AB1	SD11_04	1	core
a3ab08a4-ae99-4e28-9a25-b8080986d4e0	AB2	SD11_04	1	core
d65c77c2-8608-46fd-96eb-b5e1f76344d6	AB3	SD11_04	1	core
fad74847-426b-4ff3-99a4-184d139eeab7	AB4	SD11_04	1	core
8d89e0f5-ba36-4541-a4a7-1f36ccfa7ae0	AB5	SD11_04	1	core
68fd5f6c-e9e8-4aa9-950f-1408c6d2cecc	AB6	SD11_04	1	core
f8e45f9d-7d20-4eb8-a75a-25a6b61fe299	AB1	SD04_06	1	core
5ecdd887-fc52-4adc-b361-e61e0dd6527c	AB2	SD04_06	1	core
bc27ec22-a72b-4669-98c2-0584e6af4986	AB3	SD04_06	1	core
3678022c-ac9a-43ae-87ca-59112e896640	AB4	SD04_06	1	core
06dcd60a-33f4-4d22-a575-088ab49c8fe6	AB5	SD04_06	1	core
85021697-18d0-4644-82ee-3d78d164fbe9	AB6	SD04_06	1	core
466cf14f-2e1f-4eae-978c-10eeb0628840	AB1	SD04_07	1	core
aa878879-5324-401e-ad9d-b406d78c6fc4	AB2	SD04_07	1	core
644b1aa5-906e-48d7-9ffd-e3a5ac4c0327	AB3	SD04_07	1	core
cd18eef3-13f1-43d8-aaf0-635510940a40	AB4	SD04_07	1	core
61a89479-d36f-4538-928e-31e1c77e8dcb	AB5	SD04_07	1	core
ce0794c4-71d1-4e3d-a970-a195b103eda3	AB6	SD04_07	1	core
29eef002-c79d-4dc0-8624-a9a2cce1d418	AB1	SD04_08	1	core
268a670e-c358-4f62-9353-0fb120afd666	AB2	SD04_08	1	core
d5d90414-70cf-4330-8c79-d3d56301fc23	AB3	SD04_08	1	core
84441242-0efe-4af8-a9ca-cd9d62123499	AB4	SD04_08	1	core
ebde6383-0d51-45c2-9967-52506e64d95c	AB5	SD04_08	1	core
b7fb2408-cc09-4885-9b27-4118cb548d4a	AB6	SD04_08	1	core
c6734f5d-84fd-4b42-adec-1d34df84eacf	AB1	SD05_01	1	core
5fc7e579-6b29-4466-afd5-6ee7afd90890	AB2	SD05_01	1	core
9b945144-fdad-465d-a095-1e94811be602	AB3	SD05_01	1	core
4ba69c5e-657d-4af6-9351-01bf3a84458e	AB4	SD05_01	1	core
b141c194-ceb9-48bc-85a7-2c9e84f9eeec	AB5	SD05_01	1	core
7fedd1a5-44b5-4cb4-9d6f-ef468582ddd6	AB6	SD05_01	1	core
5fe4b74a-eed3-4451-ae4d-bf2448eab082	AB1	SD17_05	1	core
d40e0695-2903-4699-b3d1-e92ae230caf7	AB2	SD17_05	1	core
a90bd908-6f2f-4305-bd76-e550ea54d395	AB3	SD17_05	1	core
dd432072-6ba4-4266-b256-cd0c65cb0b49	AB4	SD17_05	1	core
92b904d4-0142-41bd-9a85-d383d01330db	AB5	SD17_05	1	core
50cc5abc-df82-44d8-b0b2-856c7a9cf54a	AB6	SD17_05	1	core
09f3740b-5be3-4d03-8911-134860f11f2e	AB1	SD17_06	1	core
405a390e-74e9-4dd1-8383-714b58b96403	AB2	SD17_06	1	core
8abc55b3-a4be-4f6f-9015-a968a7f8691a	AB3	SD17_06	1	core
c2faf503-521b-4a52-a386-1258547e90ab	AB4	SD17_06	1	core
c331fe8f-e538-49c9-aa54-f37b3acb18e8	AB5	SD17_06	1	core
daa9867c-19db-4eae-935d-1632c74b73ba	AB6	SD17_06	1	core
c4ea2d44-cc42-454e-9770-6b5b75d31384	AB1	SD18_01	1	core
95ace168-f131-456e-88d3-bae9be1a3ac6	AB2	SD18_01	1	core
28463ed1-43f0-4426-b769-4a68fb9e2038	AB3	SD18_01	1	core
41b1597e-7085-49c8-b34f-7f499becdce3	AB4	SD18_01	1	core
d3eb89ad-62c8-452e-9825-01b15de83b1b	AB5	SD18_01	1	core
750c9fd4-16ae-41b7-8aac-7b50e0015670	AB6	SD18_01	1	core
8b8c593a-2cad-42cd-b25e-c18e17432aac	AB1	SD18_02	1	core
d3b1208d-65bd-4ab3-abcf-ee9bc6dbb460	AB2	SD18_02	1	core
022f4e57-52f3-4762-8f5f-4921a13a64a6	AB3	SD18_02	1	core
2c32565b-28dc-4dc6-a875-7d24737909ed	AB4	SD18_02	1	core
2d02ec7e-0025-4498-a5fd-3406d727596f	AB5	SD18_02	1	core
2afdaef6-8532-4dbc-9402-4a0a728e4477	AB6	SD18_02	1	core
d8f339e2-c52c-46df-a5bc-cf9650f1fa88	AB1	SD18_03	1	core
027d8f99-f653-42d1-8cc5-283c3791c417	AB2	SD18_03	1	core
3478a33b-e5a6-42b1-800a-5ed2df2152c0	AB3	SD18_03	1	core
54114f8a-b163-4a1c-bcf2-51fb8a13c8a8	AB4	SD18_03	1	core
3e748130-3ca2-492e-96a7-f529c25e360a	AB5	SD18_03	1	core
977988b6-5939-4136-be49-1124b0ffe1c7	AB6	SD18_03	1	core
a8cc72a9-ee9c-4e0e-9161-da2f38052d10	AB1	SD19_01	1	core
7f18bbc1-ebf0-4a31-ad3d-eb9107561ae0	AB2	SD19_01	1	core
b540d753-5748-41b7-ab2d-33bf376d9e30	AB3	SD19_01	1	core
d8c3c835-6eeb-4b26-b8ed-1d451f2f1008	AB4	SD19_01	1	core
f0216f81-0f36-49e6-8b05-f7233385779f	AB5	SD19_01	1	core
612ded8b-dbba-427f-884f-100fe398b70a	AB6	SD19_01	1	core
eb7dd69c-0f30-43d0-ae0e-d2afdccaa910	AB1	SD19_02	1	core
e7d8fd0f-4919-4922-8c09-8ab56e93574d	AB2	SD19_02	1	core
5b8e020d-bbeb-4fa7-ba89-52c19ec9d008	AB3	SD19_02	1	core
499b29ee-81db-4431-9b3f-a9529110c5a4	AB4	SD19_02	1	core
76ac1f24-65ad-4c06-9c9d-7df4288c8457	AB5	SD19_02	1	core
18a9fb0f-2c16-4cf1-82bf-3be476da177c	AB6	SD19_02	1	core
7f5b9930-a2ec-4bea-9cd1-3143f795f03e	AB1	SD19_03	1	core
a457cd3f-5fd6-4ce5-a962-b2a637a00d15	AB2	SD19_03	1	core
adcde5fe-903f-4483-a20c-0d29dd7fef19	AB3	SD19_03	1	core
dfad3954-a37d-4a09-a34e-5115431129b2	AB4	SD19_03	1	core
28398925-1abe-47a1-81d4-0c9098e4d96e	AB5	SD19_03	1	core
52c3bc70-46d0-451b-9cd4-e3190897b13e	AB6	SD19_03	1	core
\.


--
-- Data for Name: lbi_age_bands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_age_bands (id, band_code, band_name, min_age, max_age, grade_range, status, created_at) FROM stdin;
ab1	AB1	Early Primary (6-8)	6	8	Grades 1-3	Active	2026-05-01 04:43:53.51436
ab2	AB2	Late Primary (9-11)	9	11	Grades 4-6	Active	2026-05-01 04:43:53.51436
ab3	AB3	Middle School (12-14)	12	14	Grades 7-9	Active	2026-05-01 04:43:53.51436
ab4	AB4	High School (15-17)	15	17	Grades 10-12	Active	2026-05-01 04:43:53.51436
ab5	AB5	College (18-21)	18	21	UG	Active	2026-05-01 04:43:53.51436
ab6	AB6	Working Professional (22+)	22	99	Career	Active	2026-05-01 04:43:53.51436
\.


--
-- Data for Name: lbi_age_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_age_groups (id, group_code, group_name, min_age, max_age, difficulty_level, status, created_at) FROM stdin;
age-a	A	Age Band A (6-10)	6	10	1	Active	2026-05-01 04:45:07.749861
age-b	B	Age Band B (11-14)	11	14	2	Active	2026-05-01 04:45:07.749861
age-c	C	Age Band C (15-18)	15	18	3	Active	2026-05-01 04:45:07.749861
age-d	D	Age Band D (18-21)	18	21	4	Active	2026-05-01 04:45:07.749861
age-e	E	Age Band E (22+)	22	99	5	Active	2026-05-01 04:45:07.749861
\.


--
-- Data for Name: lbi_assessment_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_assessment_sessions (id, child_id, student_id, age_band_id, assessment_type, target_domains, status, total_questions, questions_answered, current_question_index, started_at, completed_at, time_spent_seconds, device_info, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_assessments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_assessments (id, assessment_code, assessment_name, lbi_type_id, total_questions, status, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_cluster_map; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_cluster_map (cluster_id, subdomain_code) FROM stdin;
\.


--
-- Data for Name: lbi_clusters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_clusters (id, code, name, description, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_domain_scores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_domain_scores (id, session_id, domain_id, raw_score, percentile_score, stanine_score, classification, questions_answered, total_questions, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_domains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_domains (id, domain_code, domain_name, description, color, icon, weightage, display_order, status, created_at) FROM stdin;
D01	D01	Academic & Cognitive Effectiveness	Measures learning efficiency, conceptual understanding, memory, and attention	\N	\N	12	1	Active	2026-05-01 04:43:53.509886
D02	D02	Thinking Quality Under Pressure	Assesses analytical thinking, decision quality, and exam strategy execution	\N	\N	10	2	Active	2026-05-01 04:43:53.509886
D03	D03	Examination Stress & Emotional Regulation	Evaluates stress reactivity, emotional regulation, and recovery speed	\N	\N	10	3	Active	2026-05-01 04:43:53.509886
D04	D04	Confidence, Self-Concept & Comparison	Measures academic self-confidence, self-concept clarity, and comparison sensitivity	\N	\N	8	4	Active	2026-05-01 04:43:53.509886
D05	D05	Adjustment & Coping Capacity	Core module assessing academic, emotional, social, and family adjustment	\N	\N	7	5	Active	2026-05-01 04:43:53.509886
D06	D06	Social & Emotional Intelligence (SQ & EQ)	Evaluates emotional regulation, relationships, trust, and inclusion	\N	\N	5	6	Active	2026-05-01 04:43:53.509886
D07	D07	Discipline, Habits & Consistency	Measures time management, accountability, and execution discipline	\N	\N	8	7	Active	2026-05-01 04:43:53.509886
D08	D08	Communication & Expression	Assesses listening, expression, influence, and conflict handling	\N	\N	5	8	Active	2026-05-01 04:43:53.509886
D09	D09	Motivation, Values & Responsibility	Evaluates drive, commitment stability, integrity, and effort persistence	\N	\N	6	9	Active	2026-05-01 04:43:53.509886
D10	D10	Lifestyle & Pressure Environment	Measures digital distraction, sleep, parental and institutional pressure	\N	\N	5	10	Active	2026-05-01 04:43:53.509886
D11	D11	Competitive Exam Readiness	Optional add-on for performance stability and pressure tolerance	\N	\N	5	11	Active	2026-05-01 04:43:53.509886
D12	D12	Integrated Root Cause Mapping	Cross-domain synthesis and clustering analysis	\N	\N	0	12	Active	2026-05-01 04:43:53.509886
D13	D13	Academic Planning & Recovery Intelligence	Measures planning realism, prioritization, and recovery capacity	\N	\N	7	13	Active	2026-05-01 04:43:53.509886
D14	D14	Metacognition & Self-Regulation	Assesses error awareness, strategy switching, and self-correction	\N	\N	6	14	Active	2026-05-01 04:43:53.509886
D15	D15	Help-Seeking & Support Utilization	Evaluates help-seeking hesitation and response to guidance	\N	\N	4	15	Active	2026-05-01 04:43:53.509886
D16	D16	Academic Identity & Meaning	Measures subject relevance perception and sense of agency	\N	\N	3	16	Active	2026-05-01 04:43:53.509886
D17	D17	Transition & Change Adaptability	Assesses flexibility, uncertainty tolerance, and adaptation speed	\N	\N	3	17	Active	2026-05-01 04:43:53.509886
D18	D18	Teacher-Student Interaction Sensitivity	Evaluates instruction responsiveness and feedback sensitivity	\N	\N	2	18	Active	2026-05-01 04:43:53.509886
D19	D19	Over-Compliance Risk	Measures excessive compliance and suppressed autonomy	\N	\N	2	19	Active	2026-05-01 04:43:53.509886
\.


--
-- Data for Name: lbi_learning_mappings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_learning_mappings (id, subdomain_code, level, action_type, title, resource_link, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_modules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_modules (id, module_code, module_name, description, display_order, status, created_at) FROM stdin;
D14	D14	Metacognition & Self-Regulation	Assesses error awareness, strategy switching, and self-correction	14	Active	2026-05-01 04:45:07.746627
D01	D01	Academic & Cognitive Effectiveness	Measures learning efficiency, conceptual understanding, memory, and attention	1	Active	2026-05-01 04:45:07.746627
D02	D02	Thinking Quality Under Pressure	Assesses analytical thinking, decision quality, and exam strategy execution	2	Active	2026-05-01 04:45:07.746627
D03	D03	Examination Stress & Emotional Regulation	Evaluates stress reactivity, emotional regulation, and recovery speed	3	Active	2026-05-01 04:45:07.746627
D04	D04	Confidence, Self-Concept & Comparison	Measures academic self-confidence, self-concept clarity, and comparison sensitivity	4	Active	2026-05-01 04:45:07.746627
D05	D05	Adjustment & Coping Capacity	Core module assessing academic, emotional, social, and family adjustment	5	Active	2026-05-01 04:45:07.746627
D06	D06	Social & Emotional Intelligence (SQ & EQ)	Evaluates emotional regulation, relationships, trust, and inclusion	6	Active	2026-05-01 04:45:07.746627
D07	D07	Discipline, Habits & Consistency	Measures time management, accountability, and execution discipline	7	Active	2026-05-01 04:45:07.746627
D08	D08	Communication & Expression	Assesses listening, expression, influence, and conflict handling	8	Active	2026-05-01 04:45:07.746627
D09	D09	Motivation, Values & Responsibility	Evaluates drive, commitment stability, integrity, and effort persistence	9	Active	2026-05-01 04:45:07.746627
D10	D10	Lifestyle & Pressure Environment	Measures digital distraction, sleep, parental and institutional pressure	10	Active	2026-05-01 04:45:07.746627
D11	D11	Competitive Exam Readiness	Optional add-on for performance stability and pressure tolerance	11	Active	2026-05-01 04:45:07.746627
D12	D12	Integrated Root Cause Mapping	Cross-domain synthesis and clustering analysis	12	Active	2026-05-01 04:45:07.746627
D13	D13	Academic Planning & Recovery Intelligence	Measures planning realism, prioritization, and recovery capacity	13	Active	2026-05-01 04:45:07.746627
D15	D15	Help-Seeking & Support Utilization	Evaluates help-seeking hesitation and response to guidance	15	Active	2026-05-01 04:45:07.746627
D16	D16	Academic Identity & Meaning	Measures subject relevance perception and sense of agency	16	Active	2026-05-01 04:45:07.746627
D17	D17	Transition & Change Adaptability	Assesses flexibility, uncertainty tolerance, and adaptation speed	17	Active	2026-05-01 04:45:07.746627
D18	D18	Teacher-Student Interaction Sensitivity	Evaluates instruction responsiveness and feedback sensitivity	18	Active	2026-05-01 04:45:07.746627
D19	D19	Over-Compliance Risk	Measures excessive compliance and suppressed autonomy	19	Active	2026-05-01 04:45:07.746627
\.


--
-- Data for Name: lbi_overall_index; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_overall_index (id, session_id, child_id, student_id, lbi_score, percentile_rank, stanine_score, classification, strength_domains, development_areas, recommendations, report_generated_at, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_performance_correlation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_performance_correlation (id, child_id, lbi_category, lbi_metric, lbi_score, subject_id, academic_score, correlation_strength, correlation_type, insight, recommended_actions, analysis_date, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_question_bank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_question_bank (id, sub_module_id, question_code, set_number, difficulty_level, question_type, question_text, passage_text, keying, option_a, option_a_score, option_b, option_b_score, option_c, option_c_score, option_d, option_d_score, option_e, option_e_score, correct_answer, explanation, subject, age_group_id, language, anchor, status, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_questions (id, question_code, domain_id, subdomain_id, age_band_id, response_scale_id, question_text, question_text_hi, question_text_mr, question_text_ta, question_text_te, question_type, response_options, scoring, reverse_scored, difficulty, language, set_number, display_order, tags, version, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lbi_questions_legacy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_questions_legacy (id, question_code, lbi_type_id, difficulty_level, question_text, status, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_response_scales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_response_scales (id, scale_code, scale_name, scale_type, options, scoring, reverse_scoring_map, status, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_scoring_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_scoring_rules (id, rule_code, rule_name, domain_id, subdomain_id, age_band_id, calculation_type, norm_type, norm_data, min_score, max_score, cutoffs, status, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_session_responses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_session_responses (id, session_id, question_id, response_value, response_text, raw_score, adjusted_score, response_time_ms, question_order, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_sessions (id, assessment_id, student_id, status, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: lbi_sub_modules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_sub_modules (id, module_id, sub_module_code, sub_module_name, question_type, description, display_order, status, created_at) FROM stdin;
SD07_01	D07	SD07_01	Time & Priority Management	likert	Ability to manage time and priorities	1	Active	2026-05-01 04:45:07.747628
SD07_02	D07	SD07_02	Accountability	likert	Taking responsibility for actions	2	Active	2026-05-01 04:45:07.747628
SD07_03	D07	SD07_03	Execution Discipline	likert	Discipline in executing tasks	3	Active	2026-05-01 04:45:07.747628
SD04_04	D04	SD04_04	Social Comparison Sensitivity	likert	Tendency to compare with peers	4	Active	2026-05-01 04:45:07.747628
SD04_05	D04	SD04_05	Fear of Negative Evaluation	likert	Concern about others judgments	5	Active	2026-05-01 04:45:07.747628
SD07_04	D07	SD07_04	Plan-Execution Alignment	likert	Following through on plans	4	Active	2026-05-01 04:45:07.747628
SD07_05	D07	SD07_05	Consistency	likert	Maintaining consistent effort	5	Active	2026-05-01 04:45:07.747628
SD08_01	D08	SD08_01	Listening	likert	Active listening skills	1	Active	2026-05-01 04:45:07.747628
SD08_02	D08	SD08_02	Expression	likert	Ability to express thoughts clearly	2	Active	2026-05-01 04:45:07.747628
SD08_03	D08	SD08_03	Influence	likert	Ability to influence others	3	Active	2026-05-01 04:45:07.747628
SD08_04	D08	SD08_04	Conflict Handling	likert	Managing conflicts effectively	4	Active	2026-05-01 04:45:07.747628
SD08_05	D08	SD08_05	Instruction Comprehension	likert	Understanding instructions	5	Active	2026-05-01 04:45:07.747628
SD09_01	D09	SD09_01	Drive	likert	Internal motivation and drive	1	Active	2026-05-01 04:45:07.747628
SD09_02	D09	SD09_02	Commitment Stability	likert	Consistency of commitment	2	Active	2026-05-01 04:45:07.747628
SD09_03	D09	SD09_03	Integrity	likert	Adherence to values	3	Active	2026-05-01 04:45:07.747628
SD09_04	D09	SD09_04	Ownership Patterns	likert	Taking ownership of outcomes	4	Active	2026-05-01 04:45:07.747628
SD09_05	D09	SD09_05	Effort Persistence	likert	Sustaining effort over time	5	Active	2026-05-01 04:45:07.747628
SD10_01	D10	SD10_01	Digital Distraction	likert	Impact of digital distractions	1	Active	2026-05-01 04:45:07.747628
SD10_02	D10	SD10_02	Sleep	likert	Sleep quality and patterns	2	Active	2026-05-01 04:45:07.747628
SD10_03	D10	SD10_03	Parental Pressure	likert	Level of parental pressure	3	Active	2026-05-01 04:45:07.747628
SD10_04	D10	SD10_04	Institutional Pressure	likert	School/institution pressure	4	Active	2026-05-01 04:45:07.747628
SD11_01	D11	SD11_01	Performance Stability	likert	Consistency in performance	1	Active	2026-05-01 04:45:07.747628
SD11_02	D11	SD11_02	Pressure Tolerance	likert	Ability to handle pressure	2	Active	2026-05-01 04:45:07.747628
SD11_03	D11	SD11_03	Consistency	likert	Maintaining consistent results	3	Active	2026-05-01 04:45:07.747628
SD01_01	D01	SD01_01	Learning Efficiency	likert	How effectively the student absorbs new information	1	Active	2026-05-01 04:45:07.747628
SD01_02	D01	SD01_02	Conceptual Understanding	likert	Depth of understanding core concepts	2	Active	2026-05-01 04:45:07.747628
SD01_03	D01	SD01_03	Working & Retrieval Memory	likert	Memory retention and recall ability	3	Active	2026-05-01 04:45:07.747628
SD01_04	D01	SD01_04	Sustained Attention	likert	Ability to maintain focus over time	4	Active	2026-05-01 04:45:07.747628
SD01_05	D01	SD01_05	Learning Style	likert	Preferred learning approach	5	Active	2026-05-01 04:45:07.747628
SD01_06	D01	SD01_06	Processing Stability	likert	Consistency in information processing	6	Active	2026-05-01 04:45:07.747628
SD02_01	D02	SD02_01	Analytical & Critical Thinking	likert	Quality of analytical reasoning	1	Active	2026-05-01 04:45:07.747628
SD02_02	D02	SD02_02	Decision Quality & Judgment	likert	Quality of decisions under pressure	2	Active	2026-05-01 04:45:07.747628
SD02_03	D02	SD02_03	Managing Complexity	likert	Ability to handle complex problems	3	Active	2026-05-01 04:45:07.747628
SD02_04	D02	SD02_04	Exam Strategy & Execution Skills	likert	Strategic approach to exams	4	Active	2026-05-01 04:45:07.747628
SD02_05	D02	SD02_05	Strategy Execution	likert	Ability to execute planned strategies	5	Active	2026-05-01 04:45:07.747628
SD02_06	D02	SD02_06	Complexity Tolerance	likert	Tolerance for complex situations	6	Active	2026-05-01 04:45:07.747628
SD02_07	D02	SD02_07	Error Handling & Adaptive Execution	likert	Handling errors during execution	7	Active	2026-05-01 04:45:07.747628
SD02_08	D02	SD02_08	Situational Judgment	likert	Judgment under pressure	8	Active	2026-05-01 04:45:07.747628
SD03_01	D03	SD03_01	Stress Reactivity	likert	Initial stress response	1	Active	2026-05-01 04:45:07.747628
SD03_02	D03	SD03_02	Emotional Regulation Ability	likert	Ability to regulate emotions	2	Active	2026-05-01 04:45:07.747628
SD03_03	D03	SD03_03	Cognitive Control Under Stress	likert	Maintaining cognitive function under stress	3	Active	2026-05-01 04:45:07.747628
SD03_04	D03	SD03_04	Execution Stability	likert	Stability of performance under stress	4	Active	2026-05-01 04:45:07.747628
SD03_05	D03	SD03_05	Recovery & Reset Speed	likert	Speed of recovery from stress	5	Active	2026-05-01 04:45:07.747628
SD03_06	D03	SD03_06	Stress Spillover Control	likert	Preventing stress from affecting other areas	6	Active	2026-05-01 04:45:07.747628
SD03_07	D03	SD03_07	Anticipatory Stress Management	likert	Managing stress before events	7	Active	2026-05-01 04:45:07.747628
SD03_08	D03	SD03_08	Emotional Insight & Awareness	likert	Awareness of emotional states	8	Active	2026-05-01 04:45:07.747628
SD03_09	D03	SD03_09	Regulation Strategy Flexibility	likert	Flexibility in using different strategies	9	Active	2026-05-01 04:45:07.747628
SD04_01	D04	SD04_01	Academic Self-Confidence	likert	Confidence in academic abilities	1	Active	2026-05-01 04:45:07.747628
SD04_02	D04	SD04_02	Confidence Stability	likert	Consistency of confidence levels	2	Active	2026-05-01 04:45:07.747628
SD04_03	D04	SD04_03	Self-Concept Clarity	likert	Clear understanding of self	3	Active	2026-05-01 04:45:07.747628
SD11_05	D11	SD11_05	Recovery Speed	likert	Speed of recovery after setbacks	5	Active	2026-05-01 04:45:07.747628
SD12_01	D12	SD12_01	Cross-Domain Synthesis	likert	Ability to connect across domains	1	Active	2026-05-01 04:45:07.747628
SD12_02	D12	SD12_02	Cross-Module Clustering	likert	Pattern recognition across modules	2	Active	2026-05-01 04:45:07.747628
SD12_03	D12	SD12_03	Temporal Weighting	likert	Time-based pattern analysis	3	Active	2026-05-01 04:45:07.747628
SD12_04	D12	SD12_04	Human Confirmation Required	likert	Need for expert validation	4	Active	2026-05-01 04:45:07.747628
SD13_01	D13	SD13_01	Planning Realism	likert	Realistic planning ability	1	Active	2026-05-01 04:45:07.747628
SD13_02	D13	SD13_02	Academic Prioritisation Intelligence	likert	Smart prioritization of academics	2	Active	2026-05-01 04:45:07.747628
SD13_03	D13	SD13_03	Recovery Capacity After Setbacks	likert	Bouncing back from failures	3	Active	2026-05-01 04:45:07.747628
SD13_04	D13	SD13_04	Strategy Correction Ability	likert	Adjusting strategies when needed	4	Active	2026-05-01 04:45:07.747628
SD13_05	D13	SD13_05	Execution Feasibility	likert	Realistic execution assessment	5	Active	2026-05-01 04:45:07.747628
SD13_06	D13	SD13_06	Short-Term Recovery Window	likert	30-60 day recovery planning	6	Active	2026-05-01 04:45:07.747628
SD14_01	D14	SD14_01	Error Awareness	likert	Awareness of own mistakes	1	Active	2026-05-01 04:45:07.747628
SD14_02	D14	SD14_02	Strategy Switching	likert	Ability to change strategies	2	Active	2026-05-01 04:45:07.747628
SD14_03	D14	SD14_03	Self-Correction Timing	likert	Timing of self-corrections	3	Active	2026-05-01 04:45:07.747628
SD15_01	D15	SD15_01	Help-Seeking Hesitation	likert	Reluctance to seek help	1	Active	2026-05-01 04:45:07.747628
SD15_02	D15	SD15_02	Trust in Authority	likert	Trust in teachers and mentors	2	Active	2026-05-01 04:45:07.747628
SD15_03	D15	SD15_03	Response to Guidance	likert	How well guidance is received	3	Active	2026-05-01 04:45:07.747628
SD15_04	D15	SD15_04	Silent Failure Prevention	likert	Avoiding hidden struggles	4	Active	2026-05-01 04:45:07.747628
SD11_04	D11	SD11_04	Performance Variance	likert	Variation in performance levels	4	Active	2026-05-01 04:45:07.747628
SD04_06	D04	SD04_06	Competence Attribution Style	likert	How success/failure is attributed	6	Active	2026-05-01 04:45:07.747628
SD04_07	D04	SD04_07	External Validation Dependence	likert	Need for external approval	7	Active	2026-05-01 04:45:07.747628
SD04_08	D04	SD04_08	Self-Doubt Intrusion	likert	Frequency of self-doubt thoughts	8	Active	2026-05-01 04:45:07.747628
SD05_01	D05	SD05_01	Academic Adjustment	likert	Adjustment to academic demands	1	Active	2026-05-01 04:45:07.747628
SD04_09	D04	SD04_09	Confidence-Performance Alignment	likert	Match between confidence and actual performance	9	Active	2026-05-01 04:45:07.747628
SD05_02	D05	SD05_02	Emotional Adjustment	likert	Emotional adaptation capacity	2	Active	2026-05-01 04:45:07.747628
SD05_03	D05	SD05_03	Social Adjustment	likert	Social adaptation ability	3	Active	2026-05-01 04:45:07.747628
SD05_04	D05	SD05_04	Family Adjustment	likert	Family relationship adjustment	4	Active	2026-05-01 04:45:07.747628
SD06_01	D06	SD06_01	Emotional Regulation	likert	Ability to regulate emotions	1	Active	2026-05-01 04:45:07.747628
SD06_02	D06	SD06_02	Relationships	likert	Quality of interpersonal relationships	2	Active	2026-05-01 04:45:07.747628
SD06_03	D06	SD06_03	Trust	likert	Level of trust in others	3	Active	2026-05-01 04:45:07.747628
SD06_04	D06	SD06_04	Inclusion	likert	Sense of belonging and inclusion	4	Active	2026-05-01 04:45:07.747628
SD16_01	D16	SD16_01	Subject Relevance Perception	likert	Seeing relevance of subjects	1	Active	2026-05-01 04:45:07.747628
SD16_02	D16	SD16_02	Sense of Agency	likert	Feeling in control of learning	2	Active	2026-05-01 04:45:07.747628
SD16_03	D16	SD16_03	Identity Alignment	likert	Academic goals align with identity	3	Active	2026-05-01 04:45:07.747628
SD16_04	D16	SD16_04	Long-Term Engagement Risk	likert	Risk of disengagement over time	4	Active	2026-05-01 04:45:07.747628
SD17_01	D17	SD17_01	Flexibility	likert	Mental flexibility	1	Active	2026-05-01 04:45:07.747628
SD17_02	D17	SD17_02	Uncertainty Tolerance	likert	Comfort with uncertainty	2	Active	2026-05-01 04:45:07.747628
SD17_03	D17	SD17_03	Adaptation Speed	likert	Speed of adaptation to change	3	Active	2026-05-01 04:45:07.747628
SD17_04	D17	SD17_04	Multi-Domain Instability	likert	Instability across areas	4	Active	2026-05-01 04:45:07.747628
SD17_05	D17	SD17_05	Persistence of Disengagement	likert	Lasting disengagement patterns	5	Active	2026-05-01 04:45:07.747628
SD17_06	D17	SD17_06	Recovery Delay	likert	Delay in recovery process	6	Active	2026-05-01 04:45:07.747628
SD18_01	D18	SD18_01	Instruction Responsiveness	likert	Response to teacher instructions	1	Active	2026-05-01 04:45:07.747628
SD18_02	D18	SD18_02	Feedback Sensitivity	likert	Sensitivity to feedback	2	Active	2026-05-01 04:45:07.747628
SD18_03	D18	SD18_03	Authority Interaction Comfort	likert	Comfort interacting with authority	3	Active	2026-05-01 04:45:07.747628
SD19_01	D19	SD19_01	Excessive Compliance	likert	Overly compliant behavior	1	Active	2026-05-01 04:45:07.747628
SD19_02	D19	SD19_02	Fear-Driven Obedience	likert	Obedience based on fear	2	Active	2026-05-01 04:45:07.747628
SD19_03	D19	SD19_03	Suppressed Autonomy	likert	Suppressed independent thinking	3	Active	2026-05-01 04:45:07.747628
\.


--
-- Data for Name: lbi_subdomain_norms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_subdomain_norms (id, age_band_code, subdomain_code, min_score, median_score, top10_score) FROM stdin;
bf294362-e38a-4593-8c6e-9f65e621d336	AB1	SD04_09	25	50	80
c40873b6-5c24-4a2a-a921-d7eede9bb884	AB2	SD04_09	30	55	82
ab5e8b3b-59d8-4771-8be8-2278412982a2	AB3	SD04_09	35	60	85
49d59bd4-ba0f-40b1-9b71-6234f703e5e0	AB4	SD04_09	40	65	88
6775c8b0-fad7-4822-99d4-8a9fd7a5c883	AB5	SD04_09	45	70	90
eca211f2-9454-4036-9d76-bd74c1cf1e0f	AB6	SD04_09	50	72	92
a9f375ab-f079-4efc-b44f-5cd3dd67e300	AB1	SD05_02	25	50	80
dc6c6403-b363-4e11-ac22-6e1a47ba24d0	AB2	SD05_02	30	55	82
c5505f3f-115e-4035-8a41-7c89333ef722	AB3	SD05_02	35	60	85
c91f8d4c-4b7d-4d7b-9357-9f85a1fe7c07	AB4	SD05_02	40	65	88
e8c384e3-287d-41e1-9ac4-cb1dbeb603b0	AB5	SD05_02	45	70	90
83dacbf7-cc03-4662-a708-7729a6b4057e	AB6	SD05_02	50	72	92
c6a4d753-33cb-4621-8fce-972dd746606e	AB1	SD05_03	25	50	80
12b314cc-21f8-4b0e-a8a5-2b9e7b01e268	AB2	SD05_03	30	55	82
1eb505b7-dbaf-4486-a1a2-f33563e1042b	AB3	SD05_03	35	60	85
0e8c1ed3-8491-4adb-83eb-18847c8eab78	AB4	SD05_03	40	65	88
9b30e63b-9069-4a7a-ae4b-d097b93fbd3f	AB5	SD05_03	45	70	90
174c9926-4bf8-44a5-82c3-7f0228ff507a	AB6	SD05_03	50	72	92
41f7feb8-d2c7-4681-9be0-c09c51064e17	AB1	SD05_04	25	50	80
d357d05f-2b2a-497b-a0ec-83a1a6d22280	AB2	SD05_04	30	55	82
b756f1af-2f26-4d68-9955-f94fd794dea9	AB3	SD05_04	35	60	85
932f67a5-0264-42c1-9167-9c06693c4369	AB4	SD05_04	40	65	88
e299cf3e-a019-4855-aecd-790884a27ec2	AB5	SD05_04	45	70	90
ec3bca45-d063-44f7-a6d1-ee27a5e73e75	AB6	SD05_04	50	72	92
d9e3258e-12a7-492e-a183-a5baa3a81cec	AB1	SD06_01	25	50	80
1c635131-5a13-4f83-95cc-e18b40783553	AB2	SD06_01	30	55	82
a3ef95de-f052-4d5d-bedc-9fdbfecc4044	AB3	SD06_01	35	60	85
d8cf9bbc-df36-4bdf-82fd-e755a0e868b8	AB4	SD06_01	40	65	88
5796e666-27e6-4677-8b2b-76437354c5e2	AB5	SD06_01	45	70	90
db40db22-203e-4d9d-a72b-4dd1be0aae5b	AB6	SD06_01	50	72	92
70ccc1f4-c97a-45e1-95fd-647b3145925d	AB1	SD06_02	25	50	80
014426e0-467a-4414-9dad-3a506e1e639b	AB2	SD06_02	30	55	82
798db45b-9ecc-4827-8a56-d4c6a5a39bdf	AB3	SD06_02	35	60	85
36ad8bf8-4c3e-4af2-961b-c626a79adae3	AB4	SD06_02	40	65	88
7fcdbd1f-b499-4309-8160-37aed8efcb5c	AB5	SD06_02	45	70	90
28f0fc58-891b-4d7e-80a7-95df1d8deeb3	AB6	SD06_02	50	72	92
68becc04-520e-4358-9289-ad859ef575cd	AB1	SD06_03	25	50	80
a3bfbdd8-66a5-416d-b573-3bf0aa21fd26	AB2	SD06_03	30	55	82
4e8c0666-e443-4c79-9836-2ae71ef1a869	AB3	SD06_03	35	60	85
4d66b8a6-f6bb-4337-aef1-ee31267c4959	AB4	SD06_03	40	65	88
5255b19b-5dfc-40d7-b6ed-f845b124b9c0	AB5	SD06_03	45	70	90
bb415ad2-0e33-4f61-9730-e6d44ceb3c95	AB6	SD06_03	50	72	92
fc355c95-4182-466b-929b-5dc31527990f	AB1	SD06_04	25	50	80
421f74b2-7dda-4aad-bac0-f106b6bc5c60	AB2	SD06_04	30	55	82
6fcddcb7-9b9d-42e8-a797-925e540f03be	AB3	SD06_04	35	60	85
0234cb60-b773-477a-a9dc-b17e15dbc2ed	AB4	SD06_04	40	65	88
e40201aa-925a-44e4-9b84-c6645aaeeb61	AB5	SD06_04	45	70	90
9e6074c6-9f93-482c-b2cd-c13a0d1f9e88	AB6	SD06_04	50	72	92
1512d709-8ee5-4a9f-93c1-350222e1904f	AB1	SD07_01	25	50	80
aaa229d2-3771-4ca4-8310-a7084a2ca54a	AB2	SD07_01	30	55	82
63cc882b-8a7a-4613-816d-568348206f65	AB3	SD07_01	35	60	85
e59702ae-f781-412b-a960-076f4aa38bf0	AB4	SD07_01	40	65	88
b073ab77-47a8-4254-87ce-25f5f48f5bdd	AB5	SD07_01	45	70	90
43c1e688-efd7-4a76-a15b-73d505adf5fb	AB6	SD07_01	50	72	92
90cd4aec-e7f1-409f-9a27-11011f796f9a	AB1	SD07_02	25	50	80
bcd055b3-02c9-4865-b433-938513077318	AB2	SD07_02	30	55	82
d9229a70-9825-4086-baec-db8a37e4df3d	AB3	SD07_02	35	60	85
b8c217e0-7c49-460c-908c-95efd146e1b9	AB4	SD07_02	40	65	88
8a4b97ad-c4ec-4cf7-b04c-7b0b469f2b43	AB5	SD07_02	45	70	90
321117cb-cff8-4aec-8780-66014a814e65	AB6	SD07_02	50	72	92
1473f247-c419-46c0-982b-345b2284e2c7	AB1	SD07_03	25	50	80
b6dccc52-18cd-4fd3-8839-2e6dc4f3c382	AB2	SD07_03	30	55	82
05fd0583-08ec-4a17-a576-431f5b64b7bf	AB3	SD07_03	35	60	85
e866456e-be23-4129-b48e-5ebc39702f51	AB4	SD07_03	40	65	88
83ae1f82-d859-436c-9034-533823ae4e4c	AB5	SD07_03	45	70	90
3a091cf0-6b36-4eea-9802-00e102145483	AB6	SD07_03	50	72	92
5377daef-b1cd-40cc-9126-a258dcfcceb7	AB1	SD11_05	25	50	80
e9a836ae-c798-4ace-bcd2-c2a79dda11c2	AB2	SD11_05	30	55	82
af05509f-2f01-4979-a4ef-6dd64b843695	AB3	SD11_05	35	60	85
76e71b55-5125-429a-9fef-d42e7c3072ec	AB4	SD11_05	40	65	88
6643e8ec-e1c8-4d2c-b525-f3801ac82e4a	AB5	SD11_05	45	70	90
0619b33f-b504-4cd1-ab65-24c2de068203	AB6	SD11_05	50	72	92
ab480d8a-b3eb-459f-a7fd-312ada958ba0	AB1	SD12_01	25	50	80
1b81fb41-315d-4a20-bea1-a6f3728cbc7c	AB2	SD12_01	30	55	82
a5e8e920-a478-4c9a-9ebf-10a724cf0765	AB3	SD12_01	35	60	85
dbabd017-fa67-4f44-96e9-94843e1f60dc	AB4	SD12_01	40	65	88
8e12b820-e414-48bd-ac46-7305a9a52e03	AB5	SD12_01	45	70	90
72608c73-5d7d-491f-bd1f-838a2ebbb7ef	AB6	SD12_01	50	72	92
0edb6b9a-6bcf-4fa1-9f40-e0c589b031f3	AB1	SD12_02	25	50	80
bb3e5c70-877e-4421-ba19-d6a899cf462b	AB2	SD12_02	30	55	82
068ffd52-22fd-4974-b43d-9376a5f54059	AB3	SD12_02	35	60	85
d1ff9540-1f6f-42a9-9391-f5e95cb39093	AB4	SD12_02	40	65	88
db717b13-86ec-470b-8f8d-e4edf0dae811	AB5	SD12_02	45	70	90
4cd266bb-b634-476b-baf2-aa13fd6f5829	AB6	SD12_02	50	72	92
d56075d7-2d9a-42b5-bcbc-74749516b813	AB1	SD12_03	25	50	80
d691a942-cb6d-4256-b80f-99c904451c86	AB2	SD12_03	30	55	82
abe35c8e-fd80-4850-9b11-81f2b7fcdd6c	AB3	SD12_03	35	60	85
657fb47f-1b86-4c4d-a793-35a8dc3b6ae5	AB4	SD12_03	40	65	88
80cf38a5-4d46-4b38-93f4-d9a5fb9a4e12	AB5	SD12_03	45	70	90
3e9d5fc4-8c3f-42e0-a3b1-457e2a9d71f8	AB6	SD12_03	50	72	92
5c124318-e9f4-482d-ae4e-dd2d592a0678	AB1	SD12_04	25	50	80
20e5237d-acd1-4b54-be7c-ac49b7f99f42	AB2	SD12_04	30	55	82
1f1e2651-6d99-4e23-b5b5-b4b3b11d8a3b	AB3	SD12_04	35	60	85
63f77c03-9cfc-486f-983f-68d76e1ad77d	AB4	SD12_04	40	65	88
cdacbc71-a546-4959-aa86-8779ff0e7019	AB5	SD12_04	45	70	90
429b93d1-8af5-4fae-b26f-2ecc68e67274	AB6	SD12_04	50	72	92
e8605b05-7817-4e0d-86de-b53872287acf	AB1	SD13_01	25	50	80
69aa5b25-e0e7-4e91-8bba-be6e59ab1ac4	AB2	SD13_01	30	55	82
5ee1420e-bd3f-4a42-9197-d3bf438d5b5e	AB3	SD13_01	35	60	85
da1f279d-ab30-49a9-9b5f-a27d1ec883f5	AB4	SD13_01	40	65	88
2d9c9105-606c-4e22-962d-4af7e9ce50b2	AB5	SD13_01	45	70	90
dc677aa4-20f0-4fdf-9e5f-db200a12a55c	AB6	SD13_01	50	72	92
ee88515d-1203-4ff9-abe0-a2f69e449418	AB1	SD13_02	25	50	80
8932b394-04dd-4836-b841-1133347ae66b	AB2	SD13_02	30	55	82
62296ed8-0163-418b-a63f-2bc0825480ca	AB3	SD13_02	35	60	85
563589c8-c398-4f26-8f9a-133c7b94570a	AB4	SD13_02	40	65	88
8cccfa72-d8c6-48b8-a7d2-48b484e440bc	AB5	SD13_02	45	70	90
51afcd55-d02f-41e7-8078-110c408a191d	AB6	SD13_02	50	72	92
f8ed4ecf-6590-4420-b290-aebe7dec5436	AB1	SD13_03	25	50	80
8be7d4d0-cf94-4f04-87c5-80e261b53e82	AB2	SD13_03	30	55	82
2ea39e01-d197-4aff-a0e6-bd33096b7e2e	AB3	SD13_03	35	60	85
6a19b21a-869b-42c2-8485-07465e80b71f	AB4	SD13_03	40	65	88
52fc1a3d-03d5-4dea-a4b2-e14a0b9964d7	AB5	SD13_03	45	70	90
bcd3a943-b648-4938-90f9-ccaea4cf76a0	AB6	SD13_03	50	72	92
e84dc225-4490-4d4b-8658-4809ed07d5f5	AB1	SD13_04	25	50	80
fe005d49-8270-4541-af9b-0f8cfdff0d68	AB2	SD13_04	30	55	82
ac7c55b7-6c38-446e-9618-83d33d4ebae9	AB3	SD13_04	35	60	85
1a69c585-e570-4088-9073-76b8cee1c4d1	AB4	SD13_04	40	65	88
c61f284e-8952-4825-9c38-69c9fea3cce9	AB5	SD13_04	45	70	90
6b24746e-93f8-4510-86ac-b0f839e8c312	AB6	SD13_04	50	72	92
0faf62b2-2cbe-431e-9a4c-3520a9bb1309	AB1	SD13_05	25	50	80
c3b7e3c1-c79b-45e8-bb3e-1872e1e5844d	AB2	SD13_05	30	55	82
b76b3f5a-da83-4ca5-b171-d505115081cc	AB3	SD13_05	35	60	85
2f97f9cc-cf56-4024-89b9-f01b17183a1b	AB4	SD13_05	40	65	88
08161656-be4a-4815-905c-61fea3de6b41	AB5	SD13_05	45	70	90
05f6a8d6-0f55-46db-afa9-be9580a9d893	AB6	SD13_05	50	72	92
2ba2318a-4dae-4681-9ea7-9e5add42c196	AB1	SD13_06	25	50	80
9f33635a-a85d-4f87-afb9-80f686ed7a7c	AB2	SD13_06	30	55	82
99184359-09ac-402b-84bf-07c8d9c3cf4a	AB3	SD13_06	35	60	85
f6f470fa-984f-4a5e-8f97-d59e4d785970	AB4	SD13_06	40	65	88
3a7600df-46fe-47e8-8a98-6915757dc296	AB5	SD13_06	45	70	90
1910c5dd-a736-424e-b70b-d7d1580e9933	AB6	SD13_06	50	72	92
786a2504-8f00-4b53-9864-a0d10dfd9866	AB1	SD14_01	25	50	80
95371be3-8a95-4df6-9c75-62f4aa300981	AB2	SD14_01	30	55	82
4d4fd8c9-d7de-48e9-b15d-681abc05c108	AB3	SD14_01	35	60	85
da7d04f6-c695-44a9-8b1e-aaafe6a9e120	AB4	SD14_01	40	65	88
2071974e-0980-4dc6-afa3-34d339a1dcc5	AB5	SD14_01	45	70	90
9ecafceb-5704-47a4-802e-35180c875009	AB6	SD14_01	50	72	92
824a2eff-5706-4185-af83-b5980ef803c6	AB1	SD14_02	25	50	80
9dbe0d18-3229-43f7-93f9-4d6673da1105	AB2	SD14_02	30	55	82
822718da-434c-418b-8905-4df7b088544e	AB3	SD14_02	35	60	85
76357018-6282-446e-a096-0013eb8e8897	AB4	SD14_02	40	65	88
9ca833d0-aed1-4570-a6aa-689b6779e771	AB5	SD14_02	45	70	90
b87c72a4-2a33-4f67-9c7b-1eddf3d53320	AB6	SD14_02	50	72	92
ef860ccc-b24c-4c85-82de-4792ce4f4a2b	AB1	SD14_03	25	50	80
b0b26420-7f3e-446b-bc78-c8b4b362b913	AB2	SD14_03	30	55	82
8126aef5-4d0e-4181-aa3e-fd3255151b97	AB3	SD14_03	35	60	85
50838418-5ec3-4215-954f-4a8ce298c1db	AB4	SD14_03	40	65	88
12af9b65-9dfb-4822-bf86-853f0cccec54	AB5	SD14_03	45	70	90
821884c6-c07b-4667-b00e-78aa9220f006	AB6	SD14_03	50	72	92
6ae4822f-555f-4dfb-a7a1-081d144122b1	AB1	SD15_01	25	50	80
b681848b-ad7f-4b65-a3a3-5eda490de103	AB2	SD15_01	30	55	82
8b84e10f-cfc9-4e35-a5c3-905cd3316073	AB3	SD15_01	35	60	85
4a638a91-3980-4563-9ace-a9d3c40279d0	AB4	SD15_01	40	65	88
eb4698e0-42ce-4f77-93f8-459d5eca12a3	AB5	SD15_01	45	70	90
c62300c9-3ff6-4e0d-b95c-ff1b4032af9e	AB6	SD15_01	50	72	92
38953631-3a49-4a25-b996-c32ed1ae5d11	AB1	SD15_02	25	50	80
ef82ed1e-0c7c-415d-81f4-d91ad685a324	AB2	SD15_02	30	55	82
efcbffd3-420d-41f0-bb84-b40ba2725e2e	AB3	SD15_02	35	60	85
93980d54-38d6-41a1-9a90-9bfceff820a4	AB4	SD15_02	40	65	88
15025107-0cc0-4912-bb88-b2663fa4cc51	AB5	SD15_02	45	70	90
6b404bf2-8223-4fdd-ba8e-bc88df48c563	AB6	SD15_02	50	72	92
813fa8ab-4612-432f-937a-b4a0574eec49	AB1	SD15_03	25	50	80
365d0743-f47e-47f9-a7bb-9feb689f7db5	AB2	SD15_03	30	55	82
2cec93fd-2da0-4edc-b9cd-9cd874826b3e	AB3	SD15_03	35	60	85
31938d99-0c3c-47dd-aab8-5bf7c8f07789	AB4	SD15_03	40	65	88
124b304e-9827-4513-a9bb-18ad25e71119	AB5	SD15_03	45	70	90
3083ae67-3294-4d39-9fb9-cdb864a24704	AB6	SD15_03	50	72	92
0c3733a3-bcf6-4506-af79-dfdd44a469fa	AB1	SD15_04	25	50	80
4c395508-bb55-4be0-aa94-e00d8e0a8423	AB2	SD15_04	30	55	82
d0d347f9-86e3-4593-8bfc-5635bc1748d6	AB3	SD15_04	35	60	85
a842be71-6576-4330-9914-f1a43c44bc90	AB4	SD15_04	40	65	88
0d2c7f11-30fe-4fe1-9b3b-4e17417b231e	AB5	SD15_04	45	70	90
682dd3f2-e3d5-4a6d-aca9-9fbc1d05e90c	AB6	SD15_04	50	72	92
d0dfcee2-73be-41c1-8d4a-7b15bbf41b4a	AB1	SD16_01	25	50	80
d9d00527-04e3-40b2-b12b-49778b77d9b8	AB2	SD16_01	30	55	82
d8f01ff6-df26-428b-9f68-2769de6aedf7	AB3	SD16_01	35	60	85
32fd3637-2f74-4a00-a091-ceca5bc3bac4	AB4	SD16_01	40	65	88
31774474-d0a4-40d9-89c9-3378de257e28	AB5	SD16_01	45	70	90
1adc8c7c-84f0-4a7c-a166-f5110df41659	AB6	SD16_01	50	72	92
4e3d58cf-ac72-4ff8-b1cc-c56fea2ba948	AB1	SD16_02	25	50	80
a31cfa8e-5189-4fdc-b34b-1f7db33aaf31	AB2	SD16_02	30	55	82
b26ce251-f9fe-431d-b09b-574647b688f8	AB3	SD16_02	35	60	85
b2ad33f6-98a0-4f6e-aa5a-22b60c8eada8	AB4	SD16_02	40	65	88
4c9869da-fd2c-46c4-bcf0-6daed83535c8	AB5	SD16_02	45	70	90
7cbcc058-8348-4fb0-8afa-8f35b1d446a3	AB6	SD16_02	50	72	92
9d13cff8-de87-4c4d-bba6-1c67a0e53e9f	AB1	SD16_03	25	50	80
c1df5ad6-6f3a-41a3-a49f-34258850d631	AB2	SD16_03	30	55	82
da572473-6fc7-4bc2-81c1-34a895c6e1fd	AB3	SD16_03	35	60	85
2961a503-007b-4aab-8eae-a33cad303459	AB4	SD16_03	40	65	88
bb266b28-a925-453d-806e-a6be54a3fbb5	AB5	SD16_03	45	70	90
1c932a96-ec3c-4506-b1f1-37ed3211c22b	AB6	SD16_03	50	72	92
1e59cde3-7907-46ba-b1e7-5b8748b45927	AB1	SD16_04	25	50	80
3d1d795a-e04c-48fa-bb9b-fb90dcdf2725	AB2	SD16_04	30	55	82
80e16dc2-f20f-420b-a680-7211818b3719	AB3	SD16_04	35	60	85
11eed031-9fb4-4060-8b8e-7353dd2fceb2	AB4	SD16_04	40	65	88
3e423535-e02a-4716-9947-0c5cfd98dc8e	AB5	SD16_04	45	70	90
447f4bd8-0e00-495b-aeb2-5fcba40cbc3a	AB6	SD16_04	50	72	92
9a053556-78a1-48d8-a708-628ee3689164	AB1	SD17_01	25	50	80
9bd8556e-a0c2-425a-9e6a-ed46f8a381b6	AB2	SD17_01	30	55	82
461f32fc-98ef-4d00-b8d3-f9f9329705ef	AB3	SD17_01	35	60	85
2205bdc7-8e66-423d-951a-24dea3cc5a0c	AB4	SD17_01	40	65	88
a7c4e595-bf08-438f-a17b-7ebe45ced625	AB5	SD17_01	45	70	90
2b364d8b-de67-4b93-81a5-ec5d92697366	AB6	SD17_01	50	72	92
1850f8db-e6d3-4c64-aff9-7eb688f8fa25	AB1	SD17_02	25	50	80
937e377f-ef3c-4858-afb9-5b9b4bf91cf9	AB2	SD17_02	30	55	82
3e9bbe2a-96fc-49cb-899b-262d76bfc130	AB3	SD17_02	35	60	85
9e4291d2-d5ac-463f-b6a9-c16e47caba79	AB4	SD17_02	40	65	88
eff4a8dc-1437-4125-99a5-4a0aeae0f802	AB5	SD17_02	45	70	90
1e47eae5-74b4-4900-8ca4-c7798f95b744	AB6	SD17_02	50	72	92
d316e225-0f71-4177-823d-9efeb8e409f0	AB1	SD17_03	25	50	80
29c9d9be-ed0b-4cbd-92ea-7d04d171c9a8	AB2	SD17_03	30	55	82
f189cdf7-2e2f-4798-a704-f135beedc8fa	AB3	SD17_03	35	60	85
186f9b04-9554-4ee6-a207-5264de01da76	AB4	SD17_03	40	65	88
1d56ec80-3b06-42bf-8a00-a89198d09118	AB5	SD17_03	45	70	90
01af0c8b-9259-41ac-b0f2-a29bc06aa282	AB6	SD17_03	50	72	92
dae5748e-3317-4635-9550-d06484b23775	AB1	SD17_04	25	50	80
e501795b-f6bc-4eb2-abe4-3b0f4cb3cba1	AB2	SD17_04	30	55	82
57ae316e-25a0-4fb9-af03-16273366cbde	AB3	SD17_04	35	60	85
416da24a-c253-4fd3-8c2a-24d80b0ec02e	AB4	SD17_04	40	65	88
2b9490ec-6e24-4a1f-8528-489aca799084	AB5	SD17_04	45	70	90
aa8e9eb0-a732-4a2b-a6e7-d6a57da6ff3a	AB6	SD17_04	50	72	92
af6ce1a9-dc90-4637-975b-18b26523dfa8	AB1	SD01_01	25	50	80
b4898c1e-1395-41fa-933c-74015a302cab	AB2	SD01_01	30	55	82
4e90f489-368b-494a-bf97-6aab5aeccc79	AB3	SD01_01	35	60	85
501752a9-e6f0-44dc-9d8f-c1e00cd4d597	AB4	SD01_01	40	65	88
ba438367-6aa3-409a-a39d-ef28f3be43cc	AB5	SD01_01	45	70	90
ebc9d792-19d7-4d3d-ab41-c281b1c6e36a	AB6	SD01_01	50	72	92
77f77128-5953-49f4-804d-97384e085821	AB1	SD01_02	25	50	80
ecb1b4a9-b848-4235-8b45-8f238636fd4c	AB2	SD01_02	30	55	82
f2380c63-4a27-439b-bd94-e59079d11ee3	AB3	SD01_02	35	60	85
07741cb7-6684-41b9-bdfb-6efde3a6f17d	AB4	SD01_02	40	65	88
80a78a7c-5be7-4d78-b54a-2b223eda860a	AB5	SD01_02	45	70	90
7d6f814a-54f7-4b51-8a71-e23f7b0f4f57	AB6	SD01_02	50	72	92
a3834cfb-6216-471f-8c32-ec45d7db7e37	AB1	SD01_03	25	50	80
984baf5f-cdf7-47fd-b298-e1523da99b2c	AB2	SD01_03	30	55	82
dfc725ed-efdc-47dd-8464-3209a1448c73	AB3	SD01_03	35	60	85
22126aa5-8d0d-4164-a14b-4025adc5ad52	AB4	SD01_03	40	65	88
2253c41d-91ce-430a-92c9-56f4f222ce27	AB5	SD01_03	45	70	90
9fc470f5-05d5-4291-9955-b8a82d999d5e	AB6	SD01_03	50	72	92
3d7953f4-5180-40e2-a883-eb9af935bd05	AB1	SD01_04	25	50	80
3c9060aa-530e-4d04-85dd-d5155c8fae0c	AB2	SD01_04	30	55	82
b707b83f-fb34-4656-9844-8b545f67f1cf	AB3	SD01_04	35	60	85
c146c97b-e2fc-4518-a027-9601d0e697bf	AB4	SD01_04	40	65	88
7d3ee424-ed89-489e-b593-004e4d72cf19	AB5	SD01_04	45	70	90
34d13b88-b52a-4104-a43f-7675f84c22df	AB6	SD01_04	50	72	92
d673a9d5-dd30-4179-bee4-f076cc42fe33	AB1	SD01_05	25	50	80
453d29df-cf9b-4094-b86f-c7bce0359288	AB2	SD01_05	30	55	82
67f7c806-a2a7-405c-8db4-0b2413d65c3c	AB3	SD01_05	35	60	85
37d931ae-cccc-44d3-b10e-658437363779	AB4	SD01_05	40	65	88
cb9956af-27fc-413a-802b-b94558638454	AB5	SD01_05	45	70	90
f1c32578-f114-4e28-90d3-96939b47cd2a	AB6	SD01_05	50	72	92
7dac1aab-88fe-4827-a72c-385f0aedb254	AB1	SD01_06	25	50	80
347e75da-6045-4099-ac2b-3ae2bf7507da	AB2	SD01_06	30	55	82
477795e5-5503-45eb-9144-b51538fc109f	AB3	SD01_06	35	60	85
8894571a-87b0-4113-999d-2d5932eb5d92	AB4	SD01_06	40	65	88
a601bd78-5f73-46d0-8530-d4949f49fe3c	AB5	SD01_06	45	70	90
e0a577ac-a7a6-407f-a21c-f67fc7851e23	AB6	SD01_06	50	72	92
58fe72a0-8641-4bf1-8687-167888e7e703	AB1	SD02_01	25	50	80
17e3b053-d1c0-4904-b1a6-959519006e6e	AB2	SD02_01	30	55	82
158d9172-e790-48a3-9482-1a3908903d11	AB3	SD02_01	35	60	85
5418feed-aeac-4493-8322-e8b2c553bbbb	AB4	SD02_01	40	65	88
a0a7d99b-4c32-4a38-b6cf-d60247a883d4	AB5	SD02_01	45	70	90
a7fe96dd-294a-47f6-91b4-489396df84d9	AB6	SD02_01	50	72	92
07a7f738-c0b4-440a-a78a-2ef50ec75a87	AB1	SD02_02	25	50	80
52b1d4b3-37a1-422b-b1f3-bc5ebc467022	AB2	SD02_02	30	55	82
04891e09-1a89-480b-9b1d-857b0c9767fa	AB3	SD02_02	35	60	85
4091625d-1838-4849-a84c-9941817a24f0	AB4	SD02_02	40	65	88
3340b3d6-313a-448b-8bc6-8681003fba7f	AB5	SD02_02	45	70	90
5f626016-c204-4f98-87d3-2570609e6f2f	AB6	SD02_02	50	72	92
a05a91ab-167e-4d43-910c-fc0152750375	AB1	SD02_03	25	50	80
d2cf10f6-07cf-4784-a9e6-eec051c9e822	AB2	SD02_03	30	55	82
6eb896ad-7b14-4caf-816f-87be7419d045	AB3	SD02_03	35	60	85
1aa82615-6eb5-4438-8666-6f4381f5de28	AB4	SD02_03	40	65	88
12b1badd-3e1d-49e8-8901-6ee7b7f8549a	AB5	SD02_03	45	70	90
9a38d00b-56c0-4fae-85c9-1bb2c05377b7	AB6	SD02_03	50	72	92
0f0bd903-d7fb-461b-8077-236046f8a555	AB1	SD02_04	25	50	80
96e2908a-29a9-4d20-a2d2-51714e49bc8e	AB2	SD02_04	30	55	82
0563270a-44e3-44a3-8bc3-4227e8a304cd	AB3	SD02_04	35	60	85
1155e91b-f97b-45a5-8073-230fb356e2e3	AB4	SD02_04	40	65	88
9b6216ff-ebfe-4d8b-acf3-491cce8af9fa	AB5	SD02_04	45	70	90
25cef89c-57ff-495d-aa50-8c25eb7dd645	AB6	SD02_04	50	72	92
cf1aea17-73e1-4833-8ddf-58852466dafd	AB1	SD02_05	25	50	80
e920627f-1c75-498a-bbf3-bbe5304f5987	AB2	SD02_05	30	55	82
b4ca6ec0-3188-459d-9c6b-476cc2198445	AB3	SD02_05	35	60	85
28e5abea-9d8f-4fc6-9afb-5c1a79bc3574	AB4	SD02_05	40	65	88
4dbb6c51-5ea5-4120-81f6-42aa8ec68e0a	AB5	SD02_05	45	70	90
c7f5f3e0-8915-4d8e-aa9f-9d781cdc544c	AB6	SD02_05	50	72	92
cb00494a-edba-4edb-afb6-f21d5e98169f	AB1	SD02_06	25	50	80
80f8be42-e189-41de-ab20-9625dffe2e09	AB2	SD02_06	30	55	82
38e3dcda-d189-4c2a-9de4-25f39b993486	AB3	SD02_06	35	60	85
39aef299-8067-492d-b701-9d917aff0af5	AB4	SD02_06	40	65	88
6fb4bd18-b8c7-4fe5-bc9c-347273fd661f	AB5	SD02_06	45	70	90
a5efdea7-c6ba-4b05-a928-42a2c04bb51d	AB6	SD02_06	50	72	92
3d52315d-70df-4806-b4c1-2b07769c6410	AB1	SD02_07	25	50	80
3eedc66e-548c-4220-b716-728d7047c930	AB2	SD02_07	30	55	82
a7ac0f65-9fd5-4679-897a-314625626dd3	AB3	SD02_07	35	60	85
4fe25f23-860a-48f3-860b-67b04639494a	AB4	SD02_07	40	65	88
ff0af4dd-5349-4774-9d1e-aeb6ae91f116	AB5	SD02_07	45	70	90
135663d1-3042-4aae-b46b-12e8eed08c88	AB6	SD02_07	50	72	92
fafbd739-08ee-40ca-a37f-001305744d66	AB1	SD02_08	25	50	80
023000ab-5291-4c48-9be9-a0faafca9746	AB2	SD02_08	30	55	82
db905091-0c0b-4970-8484-c087b8998783	AB3	SD02_08	35	60	85
6db0dcf6-8d78-4996-a9d9-455f637a379d	AB4	SD02_08	40	65	88
bd6c230a-4f12-4370-b9cc-97eeebefa3f1	AB5	SD02_08	45	70	90
ae553823-003f-465e-94c9-5f5e10d553ae	AB6	SD02_08	50	72	92
74dd92c2-c639-415c-9acf-701bf54dec44	AB1	SD03_01	25	50	80
83bc7de5-c3b1-4752-a337-ad671200eeb5	AB2	SD03_01	30	55	82
4cf77b0c-6f02-465d-af02-7dd2ad9c2b6b	AB3	SD03_01	35	60	85
acb85d78-4131-48ea-b336-c410b426498b	AB4	SD03_01	40	65	88
cae431e9-79e4-4ae5-ac33-efb299dfab3b	AB5	SD03_01	45	70	90
15eb185b-670c-4dd3-a8f2-7973dc7f2f90	AB6	SD03_01	50	72	92
c99f1718-6636-489d-b8b6-2bdb5523ea27	AB1	SD03_02	25	50	80
794fbb2d-5233-4c14-a424-d62858c8ee69	AB2	SD03_02	30	55	82
4cdf9edb-3ebc-47a4-b219-b3aaa2be48e0	AB3	SD03_02	35	60	85
0ec1b97e-7671-4fc3-8fd2-4d5ea2c6d645	AB4	SD03_02	40	65	88
ece6ae8c-c277-4aba-8efa-6e499a4c3d7c	AB5	SD03_02	45	70	90
aa32510f-5dde-4516-8b46-91eda1e611d1	AB6	SD03_02	50	72	92
8ddfe369-367b-4f22-ae87-c1ee93cb7f78	AB1	SD03_03	25	50	80
f840e115-6ac5-48fa-9f5a-cde0c5886c72	AB2	SD03_03	30	55	82
4017ec93-e90f-4a32-b024-1a04cd741768	AB3	SD03_03	35	60	85
489c6073-2c91-4bd4-ae02-9765a02628e6	AB4	SD03_03	40	65	88
9540486f-6c1f-4909-86d7-9626fbb6d3ea	AB5	SD03_03	45	70	90
d4fc591c-5d0e-4f56-8b5f-49f30ced19d1	AB6	SD03_03	50	72	92
414b56fc-7b7d-4fe1-99c4-5446bda25460	AB1	SD03_04	25	50	80
8f093bcf-254c-472d-820a-87c76ccadfdb	AB2	SD03_04	30	55	82
e4743277-3e5d-4343-9c85-5e056c757fbc	AB3	SD03_04	35	60	85
90c70707-7f46-4583-bad3-8ad35d1ba29b	AB4	SD03_04	40	65	88
c1497343-2497-41d3-a9a1-3aeb266d3949	AB5	SD03_04	45	70	90
b9fc2c75-e5b4-4d2d-9f41-ba4b33d428b7	AB6	SD03_04	50	72	92
7af2dc4a-cfec-4307-9ff1-3a7e6b033b75	AB1	SD03_05	25	50	80
17782198-377f-4e6a-97d2-e26fe71d8ec9	AB2	SD03_05	30	55	82
961fa861-957a-4464-84d6-9b67083bdb6e	AB3	SD03_05	35	60	85
d3b1673b-cda9-4a7d-b027-5a66aa18eb7a	AB4	SD03_05	40	65	88
fab60294-8f2b-4ae7-b21a-5f380053285f	AB5	SD03_05	45	70	90
c7c5e09a-b65c-48d7-89da-31bf8d8941df	AB6	SD03_05	50	72	92
75fb94c6-186a-4b2d-887b-0ef6806a86aa	AB1	SD03_06	25	50	80
459aa2c7-0d95-40b1-be4d-73e2f81e0402	AB2	SD03_06	30	55	82
94838ed3-a4cd-43d7-87df-61af0737db55	AB3	SD03_06	35	60	85
2d8d24bb-3a64-4476-af8a-51db7c918128	AB4	SD03_06	40	65	88
2cccc62f-d961-4438-a97e-af519bacfcb2	AB5	SD03_06	45	70	90
617125f5-6cd2-40d8-b465-3cd153324269	AB6	SD03_06	50	72	92
d514d026-1476-4a47-b876-42712f544f81	AB1	SD03_07	25	50	80
e78fb6ad-d250-4597-bf69-a224eff6a954	AB2	SD03_07	30	55	82
a9c6c8f5-bf4f-4a24-91ca-6268b096141f	AB3	SD03_07	35	60	85
49bc3d0d-adfa-4671-bace-9408b236330e	AB4	SD03_07	40	65	88
23c5c9e6-828e-406a-8d3d-f3641af2b7a8	AB5	SD03_07	45	70	90
203ad3dd-cbcd-4a9e-b36e-23effe157327	AB6	SD03_07	50	72	92
278cf045-2ac9-4fec-9d48-241e26386e59	AB1	SD03_08	25	50	80
bd77532b-d0cd-4d80-9ce2-f18a12876959	AB2	SD03_08	30	55	82
7c727063-6a3d-455c-8925-b30579736ee5	AB3	SD03_08	35	60	85
41e067a5-6daa-4919-aef5-e2cdc1d73190	AB4	SD03_08	40	65	88
fcf667a6-3d28-4b84-bcd9-9b270a688de8	AB5	SD03_08	45	70	90
7289098b-7a2a-472e-b942-d5ba97f34c9d	AB6	SD03_08	50	72	92
155a1e0a-6062-478c-8926-e85175847142	AB1	SD03_09	25	50	80
615b0a57-e34b-4cb1-8646-a972c5d4f5f5	AB2	SD03_09	30	55	82
04127a4f-b3b9-4cd2-95cb-6385f39a4a53	AB3	SD03_09	35	60	85
db2fcdb5-d35d-4a20-8688-d967d947c14a	AB4	SD03_09	40	65	88
8a0cdcc9-d327-4f65-bf3e-14e78d71a7f3	AB5	SD03_09	45	70	90
a65dbf8b-3c5f-4cb1-8e5a-b5d3bf5ebddc	AB6	SD03_09	50	72	92
b73ca9a5-dd15-4ade-a77b-955ffdc855d8	AB1	SD04_01	25	50	80
6b821d1f-b57b-422c-bb61-fc641f8ed4d9	AB2	SD04_01	30	55	82
f5740722-5f2d-4cd5-9834-7bb179f4521a	AB3	SD04_01	35	60	85
d7de5fd3-8555-4d92-a251-3b809db22704	AB4	SD04_01	40	65	88
8fc2faf7-477b-441d-9225-245052b33f3a	AB5	SD04_01	45	70	90
b87de24b-ea1f-478f-95ee-fa7592a2bdfd	AB6	SD04_01	50	72	92
1432047a-0cdd-424c-a68b-17e0d7fbff05	AB1	SD04_02	25	50	80
c8c7a38c-7930-4837-b6c0-cd6f9f29d032	AB2	SD04_02	30	55	82
b7d27051-ccfe-4088-9ba4-d3dbf4708264	AB3	SD04_02	35	60	85
0a521130-4016-4437-80dc-45a50ee8ad70	AB4	SD04_02	40	65	88
55aac37c-fcf6-47d6-859f-cf7cb4d228e3	AB5	SD04_02	45	70	90
f2e1a068-b1a2-4e80-827b-a75d2040698e	AB6	SD04_02	50	72	92
2030c057-f65b-466c-9491-9c5818130b76	AB1	SD04_03	25	50	80
5a757dca-0d3a-4bf7-b21f-019aefe36c35	AB2	SD04_03	30	55	82
b39c9203-2f6f-412f-aea0-fc245f2cc8ff	AB3	SD04_03	35	60	85
799cc805-e668-4286-aa68-63b8558b16c4	AB4	SD04_03	40	65	88
b637c35d-e017-494f-a1c8-d2835cd7e403	AB5	SD04_03	45	70	90
33adca64-c6e8-4a1d-b54f-7e4acb462767	AB6	SD04_03	50	72	92
59d30889-f4a3-4efa-ab44-54b18b603ccd	AB1	SD04_04	25	50	80
95fa1dcc-b2f5-4c7c-bb10-d6db1cfd64aa	AB2	SD04_04	30	55	82
c2547739-1fa4-4d6d-85fe-af2d2d271701	AB3	SD04_04	35	60	85
a63cfeb0-2044-4e42-a03a-f559e866a607	AB4	SD04_04	40	65	88
9d12c900-fcef-466a-bfa9-aac333ecd5dd	AB5	SD04_04	45	70	90
b5423dbc-e36e-4554-95f9-bfb0d4cbb549	AB6	SD04_04	50	72	92
13910fd3-4aaa-4af2-b800-75473f82a81f	AB1	SD04_05	25	50	80
dbe0769c-6e14-43ec-9a2d-3f8db95b32d3	AB2	SD04_05	30	55	82
94c2ee2c-e9a1-4101-b8d0-04b12ba9c071	AB3	SD04_05	35	60	85
5be90be1-a891-4bc8-9e25-d551e42fa468	AB4	SD04_05	40	65	88
a60242b8-cea0-4fb7-806d-11cc1f43202d	AB5	SD04_05	45	70	90
1c4fed09-8c46-4982-8911-cb1bf1cbcd21	AB6	SD04_05	50	72	92
53ee3c7b-726e-4d6d-b65e-66b61ed08908	AB1	SD07_04	25	50	80
c8cf376b-f385-44be-ab20-71c29297fbbb	AB2	SD07_04	30	55	82
b17b17e7-70b8-45b6-b369-075630a9f041	AB3	SD07_04	35	60	85
fd31e80c-2693-415b-a8c3-8b0dcf67eb27	AB4	SD07_04	40	65	88
f875bae0-c56c-4d90-b48d-446f0092f26c	AB5	SD07_04	45	70	90
4f2dc9d6-ad66-4a28-b98f-46e0ba84912f	AB6	SD07_04	50	72	92
957e1ec6-2384-4ace-a8e3-d96174ec3861	AB1	SD07_05	25	50	80
fdd648c6-63d3-41cf-bcc4-7c74b9abfdc4	AB2	SD07_05	30	55	82
443c63be-7833-4963-869c-70788098b7c9	AB3	SD07_05	35	60	85
87f9d725-12c3-476c-a691-e80945eecb0c	AB4	SD07_05	40	65	88
395ec942-5fb0-4f6e-a3a7-02f8f78f1540	AB5	SD07_05	45	70	90
86e01dde-a76e-4dbb-97bb-6848861bbe55	AB6	SD07_05	50	72	92
eae435cf-b3bb-4158-ae41-d2f41960402a	AB1	SD08_01	25	50	80
76bfa815-6f51-4eac-abf2-e05f765edb96	AB2	SD08_01	30	55	82
3ffa9495-8245-48b4-b3b0-30cc1e0510d8	AB3	SD08_01	35	60	85
3d4f4acb-a5ac-4719-80c7-5db75313bbe5	AB4	SD08_01	40	65	88
b11cf434-f300-4e13-9993-17db7bedec58	AB5	SD08_01	45	70	90
3d434604-4047-42a7-88c3-b954cf594b06	AB6	SD08_01	50	72	92
6459e73a-ca3f-47c2-81f5-07ba959053bc	AB1	SD08_02	25	50	80
630aa759-5644-4794-b4b9-73dfa0a8d476	AB2	SD08_02	30	55	82
b7b8479e-5f00-481d-bcd5-29c13766d317	AB3	SD08_02	35	60	85
3e98d5c0-ecb3-456d-aa07-b9ba11d63e88	AB4	SD08_02	40	65	88
e463a668-6072-4717-b45c-903579d10fe6	AB5	SD08_02	45	70	90
6a5e5c08-4788-42af-b8f0-782acca7d425	AB6	SD08_02	50	72	92
c48ac2a5-383a-45d7-842a-c28070ffd99e	AB1	SD08_03	25	50	80
dee3e70d-3da1-4c84-ae22-2a26551e366c	AB2	SD08_03	30	55	82
f297773a-f5a6-4b32-b83c-51a64befdefa	AB3	SD08_03	35	60	85
fe541e8e-ade7-469e-a9b7-97e2c53b4837	AB4	SD08_03	40	65	88
e1dd9f6c-6833-43d4-a36a-9c345d7dbc17	AB5	SD08_03	45	70	90
90227b3c-b64c-4606-934d-1a4a31f77e1b	AB6	SD08_03	50	72	92
9312e7b1-0867-4603-ba86-5533a4d2ff9c	AB1	SD08_04	25	50	80
f61166f2-0695-44bf-b916-20cad9aff272	AB2	SD08_04	30	55	82
8a5cc950-384e-4641-a79a-561d30ddd4da	AB3	SD08_04	35	60	85
74ffae69-43a3-44db-80c9-891a9b9db30f	AB4	SD08_04	40	65	88
46473250-bbb7-408b-9a6f-145c272b1c17	AB5	SD08_04	45	70	90
dae63257-ba6d-442b-a3b7-1cb3215a5936	AB6	SD08_04	50	72	92
71e49c02-354b-43d8-9801-91987d9620fb	AB1	SD08_05	25	50	80
f72ff2a7-0cd6-4777-a938-d04d1953ec95	AB2	SD08_05	30	55	82
d4aedce6-4f69-4a29-8ec7-7ad0bd70e6ed	AB3	SD08_05	35	60	85
47c54c60-c016-4e95-b4ab-4d1ca028a238	AB4	SD08_05	40	65	88
6aee4163-b920-4fac-acb1-b955243da682	AB5	SD08_05	45	70	90
0446efb7-f3a2-4f0d-89c7-eaddb1b59884	AB6	SD08_05	50	72	92
05eff9bb-c2d1-46ba-82e0-340f966e8ab6	AB1	SD09_01	25	50	80
64510b04-d49c-4f05-8a2d-70a2ddf0ec34	AB2	SD09_01	30	55	82
31c300c7-419d-490d-afd9-5af664ecad9b	AB3	SD09_01	35	60	85
b3740583-9229-4686-9d4e-9db72a72b8b9	AB4	SD09_01	40	65	88
75afaf91-96a6-49df-9ff4-01002b8cbe28	AB5	SD09_01	45	70	90
fe011e04-24c5-40eb-b18e-a326a2f1decb	AB6	SD09_01	50	72	92
ccaa2bc4-04df-4bba-a226-066e79398eb3	AB1	SD09_02	25	50	80
42f6039e-c587-4b25-99ac-ef0d584abb46	AB2	SD09_02	30	55	82
02b84e7e-321b-4771-9736-d7edf68e1dc0	AB3	SD09_02	35	60	85
6902f4d2-58fa-45fb-9993-14a856b6c296	AB4	SD09_02	40	65	88
86164082-60c0-4b88-8c67-e6cb1d9d8e04	AB5	SD09_02	45	70	90
9ac1b7c6-99c6-47c9-8b0b-b743436801f5	AB6	SD09_02	50	72	92
afb5df9f-e499-4d65-a644-0a31c1ca6a4d	AB1	SD09_03	25	50	80
78c2b25f-d352-4f90-b52c-2c4db4dace35	AB2	SD09_03	30	55	82
e2c40715-facc-47c0-9d69-c3b6ad9a0b8a	AB3	SD09_03	35	60	85
c04db79c-27b9-4da4-959b-cd4c34de260b	AB4	SD09_03	40	65	88
fe0e5536-5426-4649-b932-6ae0ed8ec64e	AB5	SD09_03	45	70	90
431f7246-4a55-4408-88eb-4fd4b9062f23	AB6	SD09_03	50	72	92
bb61d489-8d76-429b-ae1b-df00aa697af9	AB1	SD09_04	25	50	80
0bc6921d-2991-4b33-9a7d-e0422bcc2d0d	AB2	SD09_04	30	55	82
f0049e7a-c780-4b23-a35e-ae8e6a53702d	AB3	SD09_04	35	60	85
6c5e946d-9786-4996-b895-ba37e73b2cba	AB4	SD09_04	40	65	88
4bf2b5dc-0da5-4a98-aecb-43f48f6a7b8e	AB5	SD09_04	45	70	90
2f66c2ce-8f66-4f92-82cc-aefbc02ac897	AB6	SD09_04	50	72	92
6712e0cf-b444-49eb-b95f-5644b06e8c31	AB1	SD09_05	25	50	80
3c8af24c-fd39-429b-a990-4812485f4f44	AB2	SD09_05	30	55	82
9a722f08-e739-4388-8edd-cf367413670b	AB3	SD09_05	35	60	85
58fbb926-a196-452a-a491-75126b36d9cf	AB4	SD09_05	40	65	88
691fa719-f4f6-48b8-bfeb-953a5ff9832f	AB5	SD09_05	45	70	90
e70581ca-ee4f-4474-aac2-98cc187579f1	AB6	SD09_05	50	72	92
b926cc0e-f32d-453e-a6b9-e7d553f64424	AB1	SD10_01	25	50	80
97a8d2f4-0a71-4005-959b-e5c24c547860	AB2	SD10_01	30	55	82
bddc3f2a-eb4b-41d0-892a-54fa56dd87a8	AB3	SD10_01	35	60	85
1a5ff4b4-7457-4fbd-9dd5-a3b1fbbebfd8	AB4	SD10_01	40	65	88
18c012af-4d40-458a-b593-92300eadd520	AB5	SD10_01	45	70	90
f4722e0a-3622-450d-b999-875c6ae345d2	AB6	SD10_01	50	72	92
feedf9aa-30f2-4ecb-a24a-0e1f74a937be	AB1	SD10_02	25	50	80
ef2aaf34-0257-4799-b52c-bb549f3e6b3c	AB2	SD10_02	30	55	82
f735f362-9caf-4fc3-9c60-183273ee2cda	AB3	SD10_02	35	60	85
45c9871f-2119-43bd-ba01-0206d3d739b7	AB4	SD10_02	40	65	88
d661d404-0eda-49bc-9335-f017d9cb50ac	AB5	SD10_02	45	70	90
0da84c9c-9a0c-43c1-912e-b9ab6e00f6a9	AB6	SD10_02	50	72	92
9e039adb-d367-43e4-94dd-1b88a9e9d276	AB1	SD10_03	25	50	80
37324b9f-2767-47ed-a2f9-f4a2dd548a7b	AB2	SD10_03	30	55	82
48f0b442-a06a-4643-a602-98cfb703ed90	AB3	SD10_03	35	60	85
1ec74ba8-b069-42a3-9c38-36b09f70ec11	AB4	SD10_03	40	65	88
83673959-5fab-4bcf-88fc-7fedaa3b0e13	AB5	SD10_03	45	70	90
12694361-7d7b-4a44-969d-f49c80badff2	AB6	SD10_03	50	72	92
7a414934-4434-4673-8895-16fdf4dda6b3	AB1	SD10_04	25	50	80
aa7f303f-6931-49aa-b65b-54c26bc1d88e	AB2	SD10_04	30	55	82
167f32af-4be7-43eb-a573-17bb0514b7cb	AB3	SD10_04	35	60	85
f67b2ede-d3e8-426a-ac34-17df8d36c28d	AB4	SD10_04	40	65	88
abccf435-ad93-48e7-8d33-e10df8a63b21	AB5	SD10_04	45	70	90
fb3d75ae-2f21-4360-8ca4-185533d5e4cb	AB6	SD10_04	50	72	92
1dc14615-3be1-4191-b4ea-b479affb72fb	AB1	SD11_01	25	50	80
4bdba137-a59b-4abf-a3dd-9bef19cbe133	AB2	SD11_01	30	55	82
7747e8fd-2722-4ef5-8ac5-2b6c76a1f72d	AB3	SD11_01	35	60	85
7f0d24ea-7139-4030-8ddd-c12f04b28dad	AB4	SD11_01	40	65	88
667a1308-c62f-4531-a7b5-164bfc7a7067	AB5	SD11_01	45	70	90
f052e58a-e00e-40a9-9adf-0dc3d1208ac6	AB6	SD11_01	50	72	92
e7bded58-5569-45b1-8c07-9f771a22fccb	AB1	SD11_02	25	50	80
c6f98ff1-8f85-4054-b9ad-983300ad2457	AB2	SD11_02	30	55	82
3898d878-f106-4423-8d4c-30953f82326c	AB3	SD11_02	35	60	85
145580eb-5b5f-4b22-a8ac-459b65d84c63	AB4	SD11_02	40	65	88
108752cf-15df-4b30-950d-319fc830aeb0	AB5	SD11_02	45	70	90
e431f916-0668-47cf-9dab-ef2632b11ffb	AB6	SD11_02	50	72	92
c025c7b4-967a-4675-9851-844256887f2b	AB1	SD11_03	25	50	80
28313acf-0b3d-4176-bc49-5052947ed1ca	AB2	SD11_03	30	55	82
4f264508-7032-4814-9d70-bbf731b53482	AB3	SD11_03	35	60	85
e751b6da-6eda-487a-be2d-41f636a76199	AB4	SD11_03	40	65	88
e48d5233-e69f-499b-be43-0c2ed8a28428	AB5	SD11_03	45	70	90
ac7fc7fc-0325-4788-9f25-f9b038c726b1	AB6	SD11_03	50	72	92
08d02d56-bcf7-4e3a-9e4c-14c2c081ab30	AB1	SD11_04	25	50	80
0b92329d-5e56-4ae0-b9dd-99b29ab3a2f6	AB2	SD11_04	30	55	82
07414b9e-f22e-4187-b8ac-acd9c17b33a1	AB3	SD11_04	35	60	85
b539c042-9dfc-4436-827c-cf528c2bb374	AB4	SD11_04	40	65	88
0cad7752-e4e6-4ecb-9ca8-232841a5c3fd	AB5	SD11_04	45	70	90
bc3ddbdb-3d6e-478b-8f46-a5f7077ef0c8	AB6	SD11_04	50	72	92
a419d70f-e4c6-4d2b-8c4f-0b172e05d2c5	AB1	SD04_06	25	50	80
eef278ed-8b27-4fe9-b057-95df19aea8ca	AB2	SD04_06	30	55	82
207b924d-fec1-462d-9d61-3600deabbbae	AB3	SD04_06	35	60	85
cd48c33a-dae3-4c76-b27f-8010807ffe51	AB4	SD04_06	40	65	88
682725ce-9b34-4dd6-97ef-0d97075e26aa	AB5	SD04_06	45	70	90
3c39d80e-1901-4667-9675-b7903e0cc81b	AB6	SD04_06	50	72	92
64a0d4d4-74a9-4ab8-9a60-8444cbbbc025	AB1	SD04_07	25	50	80
b159abfd-356a-4bc6-bfe2-8138c8c98717	AB2	SD04_07	30	55	82
3509cc77-23a1-4cfc-95b1-2e47a1535b50	AB3	SD04_07	35	60	85
b586c323-5d27-4af1-b68c-f49fecece1c2	AB4	SD04_07	40	65	88
cc64cd0a-8c94-4f3b-9574-560307ac7367	AB5	SD04_07	45	70	90
0d2ff734-314c-455b-bb6a-2315b7eaf642	AB6	SD04_07	50	72	92
e2e6f262-ea78-4971-8127-316d61a1aef5	AB1	SD04_08	25	50	80
273a9772-c0e9-4308-8234-0b3289c63923	AB2	SD04_08	30	55	82
8aa4c910-f826-406a-ab14-bd89cce7f4b5	AB3	SD04_08	35	60	85
2cfc17c4-dfb5-4b0f-8e1b-2b5d171390a9	AB4	SD04_08	40	65	88
4a9ef371-708a-43e9-a912-70686cc31478	AB5	SD04_08	45	70	90
1c777c04-875b-4925-b609-9f6a924823e8	AB6	SD04_08	50	72	92
ae965184-140a-4631-a490-c499d2d256c3	AB1	SD05_01	25	50	80
ba73e6a4-123f-45a5-8ff2-bca5732a5719	AB2	SD05_01	30	55	82
ea5b101f-7c84-4219-9b49-cc4ea66009eb	AB3	SD05_01	35	60	85
88db4559-2104-4a5d-9779-f834e5effbb1	AB4	SD05_01	40	65	88
c21091ae-4266-4118-a0da-9a55dface87c	AB5	SD05_01	45	70	90
8931153b-306e-408d-9f32-302696130cb3	AB6	SD05_01	50	72	92
f4599eee-57d1-49f6-9f39-6ead8ac407a9	AB1	SD17_05	25	50	80
24a80726-ffe4-4b16-b685-f9ce13f5689c	AB2	SD17_05	30	55	82
8a5a4721-469d-4eb3-8a0c-610c1efc4f6f	AB3	SD17_05	35	60	85
79419752-5e6d-4125-bc67-46e25a4f3aab	AB4	SD17_05	40	65	88
00e28207-c66f-49d1-9e32-f3cbe67fd076	AB5	SD17_05	45	70	90
ec7bec18-aa13-454b-beb6-4bda3dd8e819	AB6	SD17_05	50	72	92
09a8b7af-a7b0-40e4-8967-5e0a97bfd6c4	AB1	SD17_06	25	50	80
ba1ace96-a45d-40a9-a682-cdc1715913e5	AB2	SD17_06	30	55	82
03a3630f-409e-4b2e-8db3-2fee44dc111c	AB3	SD17_06	35	60	85
317def62-b23a-4b35-8483-81db139770f4	AB4	SD17_06	40	65	88
14e27cf0-48aa-49bb-a1c3-443edaa4a1a8	AB5	SD17_06	45	70	90
e3b889a4-fae1-4f30-867a-ab9ba0c20dbd	AB6	SD17_06	50	72	92
56754d4e-2da5-42f2-b2c6-396fce5156bf	AB1	SD18_01	25	50	80
ae0c2093-e4dc-48e4-adf2-e182abda127e	AB2	SD18_01	30	55	82
d7b315c3-898d-4d77-926f-d1bfc9eaeced	AB3	SD18_01	35	60	85
9729f966-ad2f-4e5d-baf5-88996740f96a	AB4	SD18_01	40	65	88
3d4a3a98-f541-4c28-9434-af788ea9343c	AB5	SD18_01	45	70	90
70996e80-6d87-48bd-800d-6def6605b353	AB6	SD18_01	50	72	92
e5478a30-4ac3-40fb-b58b-c27143f9d9eb	AB1	SD18_02	25	50	80
e0ad86ab-31c4-42fa-92dc-09beeee05d7d	AB2	SD18_02	30	55	82
ed94197d-179d-4aae-8e83-7bce06b9ac2a	AB3	SD18_02	35	60	85
59c8b460-1e61-43f0-80b4-17ba725c441a	AB4	SD18_02	40	65	88
93df68d7-8f01-4d86-acaf-42e7176769f7	AB5	SD18_02	45	70	90
ca87db36-23dd-42e0-be0d-2ee3bbef1401	AB6	SD18_02	50	72	92
605ecbf5-f320-44d6-b43e-734514e676a5	AB1	SD18_03	25	50	80
cc21af63-968a-42b5-8050-841322766b16	AB2	SD18_03	30	55	82
bd4f6004-d907-4fb3-84ca-073f60005742	AB3	SD18_03	35	60	85
05bd6875-0a61-497b-9e77-529d1e1eb472	AB4	SD18_03	40	65	88
2f96d078-9e80-46da-aac7-5b7c536e0282	AB5	SD18_03	45	70	90
b0df2a08-d6df-4e1b-9521-f5a5d1a70d4e	AB6	SD18_03	50	72	92
05760fd8-40de-49dd-8877-35cf12400c2b	AB1	SD19_01	25	50	80
91a8c041-7bef-45ca-8e6c-bd0daa7728d2	AB2	SD19_01	30	55	82
c603c92f-9d32-4197-b3cd-88cb1f66e55c	AB3	SD19_01	35	60	85
85ad4dc1-6f57-42ad-a32f-80cffdfa909b	AB4	SD19_01	40	65	88
7f30cd04-9ba0-4568-b9de-f8680a599399	AB5	SD19_01	45	70	90
0a53488a-0316-4d3b-a044-8b4dccf7a060	AB6	SD19_01	50	72	92
87e6fdae-39d8-4425-bfe3-e36c6fedca81	AB1	SD19_02	25	50	80
ef7acbb5-dd5a-4f66-ad87-a7bb9919303e	AB2	SD19_02	30	55	82
e97903b3-624b-47c5-bad5-8f7d306e60b0	AB3	SD19_02	35	60	85
9d254568-21be-433e-a6dc-e118ac2bf517	AB4	SD19_02	40	65	88
f86ae7a7-ae44-4dfb-9a8b-d19e6c89e87c	AB5	SD19_02	45	70	90
c4c17f0a-7100-4363-9876-6a998e31a51c	AB6	SD19_02	50	72	92
494b6698-8d0e-481c-9dab-8b5cc0f0c4bd	AB1	SD19_03	25	50	80
ced6b2ae-a6aa-4ba0-bd2c-4c24d2c1694a	AB2	SD19_03	30	55	82
94398d65-ad70-4b60-8f2a-f61d614f4195	AB3	SD19_03	35	60	85
718ec17c-3ab7-4710-9bfa-a5e8df185ea7	AB4	SD19_03	40	65	88
8502b7d8-2bb9-41a6-bc54-959c5efc867d	AB5	SD19_03	45	70	90
57ca91f5-748a-489c-9fdb-d1228cb599c0	AB6	SD19_03	50	72	92
\.


--
-- Data for Name: lbi_subdomain_scores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_subdomain_scores (id, session_id, subdomain_id, raw_score, percentile_score, stanine_score, classification, questions_answered, total_questions, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_subdomains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_subdomains (id, domain_id, subdomain_code, subdomain_name, description, weightage, display_order, status, created_at) FROM stdin;
SD04_09	D04	SD04_09	Confidence-Performance Alignment	Match between confidence and actual performance	1	9	Active	2026-05-01 04:43:53.511651
SD05_02	D05	SD05_02	Emotional Adjustment	Emotional adaptation capacity	1	2	Active	2026-05-01 04:43:53.511651
SD05_03	D05	SD05_03	Social Adjustment	Social adaptation ability	1	3	Active	2026-05-01 04:43:53.511651
SD05_04	D05	SD05_04	Family Adjustment	Family relationship adjustment	1	4	Active	2026-05-01 04:43:53.511651
SD06_01	D06	SD06_01	Emotional Regulation	Ability to regulate emotions	1	1	Active	2026-05-01 04:43:53.511651
SD06_02	D06	SD06_02	Relationships	Quality of interpersonal relationships	1	2	Active	2026-05-01 04:43:53.511651
SD06_03	D06	SD06_03	Trust	Level of trust in others	1	3	Active	2026-05-01 04:43:53.511651
SD06_04	D06	SD06_04	Inclusion	Sense of belonging and inclusion	1	4	Active	2026-05-01 04:43:53.511651
SD07_01	D07	SD07_01	Time & Priority Management	Ability to manage time and priorities	1	1	Active	2026-05-01 04:43:53.511651
SD07_02	D07	SD07_02	Accountability	Taking responsibility for actions	1	2	Active	2026-05-01 04:43:53.511651
SD07_03	D07	SD07_03	Execution Discipline	Discipline in executing tasks	1	3	Active	2026-05-01 04:43:53.511651
SD11_05	D11	SD11_05	Recovery Speed	Speed of recovery after setbacks	1	5	Active	2026-05-01 04:43:53.511651
SD12_01	D12	SD12_01	Cross-Domain Synthesis	Ability to connect across domains	1	1	Active	2026-05-01 04:43:53.511651
SD12_02	D12	SD12_02	Cross-Module Clustering	Pattern recognition across modules	1	2	Active	2026-05-01 04:43:53.511651
SD12_03	D12	SD12_03	Temporal Weighting	Time-based pattern analysis	1	3	Active	2026-05-01 04:43:53.511651
SD12_04	D12	SD12_04	Human Confirmation Required	Need for expert validation	1	4	Active	2026-05-01 04:43:53.511651
SD13_01	D13	SD13_01	Planning Realism	Realistic planning ability	1	1	Active	2026-05-01 04:43:53.511651
SD13_02	D13	SD13_02	Academic Prioritisation Intelligence	Smart prioritization of academics	1	2	Active	2026-05-01 04:43:53.511651
SD13_03	D13	SD13_03	Recovery Capacity After Setbacks	Bouncing back from failures	1	3	Active	2026-05-01 04:43:53.511651
SD13_04	D13	SD13_04	Strategy Correction Ability	Adjusting strategies when needed	1	4	Active	2026-05-01 04:43:53.511651
SD13_05	D13	SD13_05	Execution Feasibility	Realistic execution assessment	1	5	Active	2026-05-01 04:43:53.511651
SD13_06	D13	SD13_06	Short-Term Recovery Window	30-60 day recovery planning	1	6	Active	2026-05-01 04:43:53.511651
SD14_01	D14	SD14_01	Error Awareness	Awareness of own mistakes	1	1	Active	2026-05-01 04:43:53.511651
SD14_02	D14	SD14_02	Strategy Switching	Ability to change strategies	1	2	Active	2026-05-01 04:43:53.511651
SD14_03	D14	SD14_03	Self-Correction Timing	Timing of self-corrections	1	3	Active	2026-05-01 04:43:53.511651
SD15_01	D15	SD15_01	Help-Seeking Hesitation	Reluctance to seek help	1	1	Active	2026-05-01 04:43:53.511651
SD15_02	D15	SD15_02	Trust in Authority	Trust in teachers and mentors	1	2	Active	2026-05-01 04:43:53.511651
SD15_03	D15	SD15_03	Response to Guidance	How well guidance is received	1	3	Active	2026-05-01 04:43:53.511651
SD15_04	D15	SD15_04	Silent Failure Prevention	Avoiding hidden struggles	1	4	Active	2026-05-01 04:43:53.511651
SD16_01	D16	SD16_01	Subject Relevance Perception	Seeing relevance of subjects	1	1	Active	2026-05-01 04:43:53.511651
SD16_02	D16	SD16_02	Sense of Agency	Feeling in control of learning	1	2	Active	2026-05-01 04:43:53.511651
SD16_03	D16	SD16_03	Identity Alignment	Academic goals align with identity	1	3	Active	2026-05-01 04:43:53.511651
SD16_04	D16	SD16_04	Long-Term Engagement Risk	Risk of disengagement over time	1	4	Active	2026-05-01 04:43:53.511651
SD17_01	D17	SD17_01	Flexibility	Mental flexibility	1	1	Active	2026-05-01 04:43:53.511651
SD17_02	D17	SD17_02	Uncertainty Tolerance	Comfort with uncertainty	1	2	Active	2026-05-01 04:43:53.511651
SD17_03	D17	SD17_03	Adaptation Speed	Speed of adaptation to change	1	3	Active	2026-05-01 04:43:53.511651
SD17_04	D17	SD17_04	Multi-Domain Instability	Instability across areas	1	4	Active	2026-05-01 04:43:53.511651
SD01_01	D01	SD01_01	Learning Efficiency	How effectively the student absorbs new information	1	1	Active	2026-05-01 04:43:53.511651
SD01_02	D01	SD01_02	Conceptual Understanding	Depth of understanding core concepts	1	2	Active	2026-05-01 04:43:53.511651
SD01_03	D01	SD01_03	Working & Retrieval Memory	Memory retention and recall ability	1	3	Active	2026-05-01 04:43:53.511651
SD01_04	D01	SD01_04	Sustained Attention	Ability to maintain focus over time	1	4	Active	2026-05-01 04:43:53.511651
SD01_05	D01	SD01_05	Learning Style	Preferred learning approach	1	5	Active	2026-05-01 04:43:53.511651
SD01_06	D01	SD01_06	Processing Stability	Consistency in information processing	1	6	Active	2026-05-01 04:43:53.511651
SD02_01	D02	SD02_01	Analytical & Critical Thinking	Quality of analytical reasoning	1	1	Active	2026-05-01 04:43:53.511651
SD02_02	D02	SD02_02	Decision Quality & Judgment	Quality of decisions under pressure	1	2	Active	2026-05-01 04:43:53.511651
SD02_03	D02	SD02_03	Managing Complexity	Ability to handle complex problems	1	3	Active	2026-05-01 04:43:53.511651
SD02_04	D02	SD02_04	Exam Strategy & Execution Skills	Strategic approach to exams	1	4	Active	2026-05-01 04:43:53.511651
SD02_05	D02	SD02_05	Strategy Execution	Ability to execute planned strategies	1	5	Active	2026-05-01 04:43:53.511651
SD02_06	D02	SD02_06	Complexity Tolerance	Tolerance for complex situations	1	6	Active	2026-05-01 04:43:53.511651
SD02_07	D02	SD02_07	Error Handling & Adaptive Execution	Handling errors during execution	1	7	Active	2026-05-01 04:43:53.511651
SD02_08	D02	SD02_08	Situational Judgment	Judgment under pressure	1	8	Active	2026-05-01 04:43:53.511651
SD03_01	D03	SD03_01	Stress Reactivity	Initial stress response	1	1	Active	2026-05-01 04:43:53.511651
SD03_02	D03	SD03_02	Emotional Regulation Ability	Ability to regulate emotions	1	2	Active	2026-05-01 04:43:53.511651
SD03_03	D03	SD03_03	Cognitive Control Under Stress	Maintaining cognitive function under stress	1	3	Active	2026-05-01 04:43:53.511651
SD03_04	D03	SD03_04	Execution Stability	Stability of performance under stress	1	4	Active	2026-05-01 04:43:53.511651
SD03_05	D03	SD03_05	Recovery & Reset Speed	Speed of recovery from stress	1	5	Active	2026-05-01 04:43:53.511651
SD03_06	D03	SD03_06	Stress Spillover Control	Preventing stress from affecting other areas	1	6	Active	2026-05-01 04:43:53.511651
SD03_07	D03	SD03_07	Anticipatory Stress Management	Managing stress before events	1	7	Active	2026-05-01 04:43:53.511651
SD03_08	D03	SD03_08	Emotional Insight & Awareness	Awareness of emotional states	1	8	Active	2026-05-01 04:43:53.511651
SD03_09	D03	SD03_09	Regulation Strategy Flexibility	Flexibility in using different strategies	1	9	Active	2026-05-01 04:43:53.511651
SD04_01	D04	SD04_01	Academic Self-Confidence	Confidence in academic abilities	1	1	Active	2026-05-01 04:43:53.511651
SD04_02	D04	SD04_02	Confidence Stability	Consistency of confidence levels	1	2	Active	2026-05-01 04:43:53.511651
SD04_03	D04	SD04_03	Self-Concept Clarity	Clear understanding of self	1	3	Active	2026-05-01 04:43:53.511651
SD04_04	D04	SD04_04	Social Comparison Sensitivity	Tendency to compare with peers	1	4	Active	2026-05-01 04:43:53.511651
SD04_05	D04	SD04_05	Fear of Negative Evaluation	Concern about others judgments	1	5	Active	2026-05-01 04:43:53.511651
SD07_04	D07	SD07_04	Plan-Execution Alignment	Following through on plans	1	4	Active	2026-05-01 04:43:53.511651
SD07_05	D07	SD07_05	Consistency	Maintaining consistent effort	1	5	Active	2026-05-01 04:43:53.511651
SD08_01	D08	SD08_01	Listening	Active listening skills	1	1	Active	2026-05-01 04:43:53.511651
SD08_02	D08	SD08_02	Expression	Ability to express thoughts clearly	1	2	Active	2026-05-01 04:43:53.511651
SD08_03	D08	SD08_03	Influence	Ability to influence others	1	3	Active	2026-05-01 04:43:53.511651
SD08_04	D08	SD08_04	Conflict Handling	Managing conflicts effectively	1	4	Active	2026-05-01 04:43:53.511651
SD08_05	D08	SD08_05	Instruction Comprehension	Understanding instructions	1	5	Active	2026-05-01 04:43:53.511651
SD09_01	D09	SD09_01	Drive	Internal motivation and drive	1	1	Active	2026-05-01 04:43:53.511651
SD09_02	D09	SD09_02	Commitment Stability	Consistency of commitment	1	2	Active	2026-05-01 04:43:53.511651
SD09_03	D09	SD09_03	Integrity	Adherence to values	1	3	Active	2026-05-01 04:43:53.511651
SD09_04	D09	SD09_04	Ownership Patterns	Taking ownership of outcomes	1	4	Active	2026-05-01 04:43:53.511651
SD09_05	D09	SD09_05	Effort Persistence	Sustaining effort over time	1	5	Active	2026-05-01 04:43:53.511651
SD10_01	D10	SD10_01	Digital Distraction	Impact of digital distractions	1	1	Active	2026-05-01 04:43:53.511651
SD10_02	D10	SD10_02	Sleep	Sleep quality and patterns	1	2	Active	2026-05-01 04:43:53.511651
SD10_03	D10	SD10_03	Parental Pressure	Level of parental pressure	1	3	Active	2026-05-01 04:43:53.511651
SD10_04	D10	SD10_04	Institutional Pressure	School/institution pressure	1	4	Active	2026-05-01 04:43:53.511651
SD11_01	D11	SD11_01	Performance Stability	Consistency in performance	1	1	Active	2026-05-01 04:43:53.511651
SD11_02	D11	SD11_02	Pressure Tolerance	Ability to handle pressure	1	2	Active	2026-05-01 04:43:53.511651
SD11_03	D11	SD11_03	Consistency	Maintaining consistent results	1	3	Active	2026-05-01 04:43:53.511651
SD11_04	D11	SD11_04	Performance Variance	Variation in performance levels	1	4	Active	2026-05-01 04:43:53.511651
SD04_06	D04	SD04_06	Competence Attribution Style	How success/failure is attributed	1	6	Active	2026-05-01 04:43:53.511651
SD04_07	D04	SD04_07	External Validation Dependence	Need for external approval	1	7	Active	2026-05-01 04:43:53.511651
SD04_08	D04	SD04_08	Self-Doubt Intrusion	Frequency of self-doubt thoughts	1	8	Active	2026-05-01 04:43:53.511651
SD05_01	D05	SD05_01	Academic Adjustment	Adjustment to academic demands	1	1	Active	2026-05-01 04:43:53.511651
SD17_05	D17	SD17_05	Persistence of Disengagement	Lasting disengagement patterns	1	5	Active	2026-05-01 04:43:53.511651
SD17_06	D17	SD17_06	Recovery Delay	Delay in recovery process	1	6	Active	2026-05-01 04:43:53.511651
SD18_01	D18	SD18_01	Instruction Responsiveness	Response to teacher instructions	1	1	Active	2026-05-01 04:43:53.511651
SD18_02	D18	SD18_02	Feedback Sensitivity	Sensitivity to feedback	1	2	Active	2026-05-01 04:43:53.511651
SD18_03	D18	SD18_03	Authority Interaction Comfort	Comfort interacting with authority	1	3	Active	2026-05-01 04:43:53.511651
SD19_01	D19	SD19_01	Excessive Compliance	Overly compliant behavior	1	1	Active	2026-05-01 04:43:53.511651
SD19_02	D19	SD19_02	Fear-Driven Obedience	Obedience based on fear	1	2	Active	2026-05-01 04:43:53.511651
SD19_03	D19	SD19_03	Suppressed Autonomy	Suppressed independent thinking	1	3	Active	2026-05-01 04:43:53.511651
\.


--
-- Data for Name: lbi_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_types (id, type_name, description, status, created_at) FROM stdin;
\.


--
-- Data for Name: lbi_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lbi_versions (id, version, label, notes, changed_by, change_summary, created_at) FROM stdin;
ce535885-196b-4ded-8649-9720f1366e81	1	v1.0 — LBI baseline	Auto-created with parity migration	\N	{"norms": 582, "domains": 19, "weights": 582, "age_bands": 6, "subdomains": 97}	2026-05-01 15:18:40.163873
\.


--
-- Data for Name: learning_mappings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.learning_mappings (id, competency_id, level, action_type, title, resource_link, created_at) FROM stdin;
\.


--
-- Data for Name: learning_plan_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.learning_plan_templates (id, template_name, description, target_grade, target_board, subject_focus, duration_weeks, difficulty, weekly_hours, status, milestones, created_by, approved_by, approved_at, published_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lei_registrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lei_registrations (id, user_id, lei_code, entity_name, entity_type, registration_authority, registration_number, jurisdiction, legal_address, headquarters_address, contact_name, contact_email, contact_phone, status, valid_from, valid_until, last_verified, verified_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mentor_kpis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mentor_kpis (id, mentor_id, period_start, period_end, student_satisfaction, session_completion_rate, outcome_improvement, compliance_adherence, revenue_contribution, sessions_completed, students_assigned, alert_level, alert_issued_at, alert_notes, created_at) FROM stdin;
\.


--
-- Data for Name: mentor_payouts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mentor_payouts (id, mentor_id, period_start, period_end, gross_revenue, commission_rate, commission_amount, deductions, net_payout, status, blocked_reason, approved_by, approved_at, paid_at, transaction_ref, created_at) FROM stdin;
\.


--
-- Data for Name: mentor_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mentor_profiles (id, mentor_id, user_id, application_id, mentor_code, full_name, email, phone, profile_photo, bio, specializations, qualifications, languages, availability, preferred_age_groups, status, activated_at, activated_by, suspended_at, suspended_reason, deactivated_at, deactivation_reason, rating, total_sessions, completed_sessions, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mentor_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mentor_tasks (id, mentor_id, task_type, title, description, target_audience, scheduled_date, duration, location, is_online, meeting_link, status, completed_at, feedback, rating, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mentors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mentors (id, user_id, application_id, mentor_code, full_name, email, phone, specialization, qualifications, status, activated_at, warning_issued_at, warning_reason, suspended_at, suspension_reason, deactivated_at, deactivation_reason, performance_health_index, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, conversation_id, role, content, created_at) FROM stdin;
\.


--
-- Data for Name: mfa_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mfa_codes (id, user_id, code, email, attempt_token, attempts, expires_at, used, created_at) FROM stdin;
\.


--
-- Data for Name: ngo_registrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ngo_registrations (id, user_id, ngo_code, legal_name, display_name, registration_number, tax_exemption_number, contact_name, contact_email, contact_phone, address, city, state, pincode, focus_areas, beneficiary_count, status, documents_verified, kyc_verified, verified_by, verified_at, onboarded_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_broadcasts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_broadcasts (id, sender_id, type, category, title, message, target_roles, target_user_ids, priority, action_url, action_label, send_email, total_recipients, total_delivered, status, scheduled_at, sent_at, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, recipient_id, sender_id, type, category, title, message, action_url, action_label, priority, is_read, is_acknowledged, acknowledged_at, is_email_sent, email_sent_at, metadata, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: onboarding_approvals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.onboarding_approvals (id, entity_type, entity_id, entity_name, entity_email, entity_phone, status, submitted_at, reviewed_by, reviewed_at, review_notes, rejection_reason, documents_verified, kyc_verified, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: parent_student_links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parent_student_links (id, parent_id, student_id, relationship, lbi_consent, consent_date, consent_revoked_date, created_at) FROM stdin;
\.


--
-- Data for Name: parent_test_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parent_test_assignments (id, test_id, child_id, assigned_by, status, due_date, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: parent_test_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parent_test_results (id, assignment_id, student_id, answers, marks_obtained, total_marks, score, correct_answers, incorrect_answers, question_results, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: parent_tests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parent_tests (id, created_by, title, subject, description, duration, total_marks, questions, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: parents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parents (id, user_id, full_name, mobile, status, created_at) FROM stdin;
\.


--
-- Data for Name: payment_reconciliations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_reconciliations (id, reconciliation_period, status, total_payments_received, total_payments_done, net_balance, transaction_count, payout_count, discrepancy_amount, discrepancy_notes, reconciled_by, reconciled_at, approved_by, approved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: performance_analytics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.performance_analytics (id, child_id, subject_id, chapter_id, test_type, total_tests, completed_tests, average_score, highest_score, lowest_score, average_time_seconds, improvement_trend, last_updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: permission_definitions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permission_definitions (id, permission_key, display_name, description, category, resource, action, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: platform_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_settings (id, setting_key, setting_value, setting_type, category, description, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_transactions (id, transaction_type, entity_type, entity_id, entity_name, amount, currency, status, payment_method, payment_gateway, gateway_transaction_id, gateway_order_id, description, invoice_number, invoice_url, processed_by, processed_at, failure_reason, refunded_amount, refunded_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pre_onboarding_checklists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pre_onboarding_checklists (id, entity_type, entity_id, entity_name, temporary_onboarding_status, temporary_approved_by, temporary_approved_at, total_kyc_documents, uploaded_kyc_documents, verified_kyc_documents, kyc_completion_percent, total_consents, granted_consents, consent_completion_percent, total_amount, paid_amount, payment_status, overall_status, spoc_name, spoc_email, spoc_phone, spoc_designation, approved_by, approved_at, rejected_by, rejected_at, rejection_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: psychometric_age_bands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psychometric_age_bands (id, band_code, band_name, age_range_start, age_range_end, context, display_order, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: psychometric_assessment_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psychometric_assessment_results (id, student_id, age_band_id, domain_id, subdomain_id, raw_score, percentile_score, scaled_score, interpretation, recommendations, assessed_at) FROM stdin;
\.


--
-- Data for Name: psychometric_domain_age_band_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psychometric_domain_age_band_config (id, domain_id, age_band_id, is_enabled, questions_count, weightage, created_at) FROM stdin;
\.


--
-- Data for Name: psychometric_domains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psychometric_domains (id, domain_code, domain_name, description, category, display_order, icon_name, color_code, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: psychometric_question_bank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psychometric_question_bank (id, question_code, domain_id, subdomain_id, age_band_id, question_text, question_type, response_options, scoring_logic, reverse_scored, difficulty, language, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: psychometric_subdomains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psychometric_subdomains (id, domain_id, subdomain_code, subdomain_name, description, measurement_scale, display_order, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: psychopsis_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psychopsis_categories (id, user_id, title, description, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_competency_weights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_competency_weights (id, role_code, role_name, competency_id, weight, weight_type) FROM stdin;
ba63d62b-0f58-449f-b671-e497d8f75656	SDE	Software Engineer	e2b719b0-522d-47f1-bd1e-c13a44465b49	1	core
7f82e00f-1fff-4e43-bfce-9f8c2120a7f4	PM	Product Manager	e2b719b0-522d-47f1-bd1e-c13a44465b49	1	core
e2038409-5d7e-46e0-9574-64451ab482a7	DA	Data Analyst	e2b719b0-522d-47f1-bd1e-c13a44465b49	1	core
3856b6de-37bd-4ce7-b5af-fea2d8e6d859	TL	Team Lead	e2b719b0-522d-47f1-bd1e-c13a44465b49	1	core
c61d92a5-00ff-4016-a87b-4eafa5ff88af	DIR	Director	e2b719b0-522d-47f1-bd1e-c13a44465b49	1	core
2684c967-bbbc-495e-b576-e37d7b961a45	CONS	Consultant	e2b719b0-522d-47f1-bd1e-c13a44465b49	1	core
b0730963-9436-4400-b6a8-646b19cbb741	SALES	Sales / BD	e2b719b0-522d-47f1-bd1e-c13a44465b49	1	core
29715f63-7f04-4b9f-9611-17a5f6d9f2fc	SDE	Software Engineer	ae9dbf32-0f4a-4924-9b2e-905750982ede	1	core
10ed36e1-5990-45d7-a849-8da40112b15b	PM	Product Manager	ae9dbf32-0f4a-4924-9b2e-905750982ede	1	core
c5935e60-0e11-450c-910d-399a51406055	DA	Data Analyst	ae9dbf32-0f4a-4924-9b2e-905750982ede	1	core
cb36ce47-4e1c-4fe3-90b7-93c39e99d6f6	TL	Team Lead	ae9dbf32-0f4a-4924-9b2e-905750982ede	1	core
8cb350c3-2a7a-490c-8d1b-c06b27b596b1	DIR	Director	ae9dbf32-0f4a-4924-9b2e-905750982ede	1	core
ccc76e44-f6fc-4738-b9be-f40b3164ac96	CONS	Consultant	ae9dbf32-0f4a-4924-9b2e-905750982ede	1	core
9ca06497-959e-411b-8d52-540fc083216b	SALES	Sales / BD	ae9dbf32-0f4a-4924-9b2e-905750982ede	1	core
ad965c98-4509-407c-8d3a-d7a0ce218c7e	SDE	Software Engineer	cc112339-7074-4598-9935-cbe47fa7a404	1	core
6e7f7c82-8180-489f-b62d-3cee02d8bcfb	PM	Product Manager	cc112339-7074-4598-9935-cbe47fa7a404	1	core
d01236b9-b294-4f61-b80d-a2d07af88d6f	DA	Data Analyst	cc112339-7074-4598-9935-cbe47fa7a404	1	core
757dfd55-b346-4a35-9c81-5500e487ca3b	TL	Team Lead	cc112339-7074-4598-9935-cbe47fa7a404	1	core
f499c118-4e1b-4567-826d-4246acaf4539	DIR	Director	cc112339-7074-4598-9935-cbe47fa7a404	1	core
ed361b36-b55c-4e36-9539-dbf00996110d	CONS	Consultant	cc112339-7074-4598-9935-cbe47fa7a404	1	core
a51d37a7-4f61-49cc-b8c6-fa61da84f750	SALES	Sales / BD	cc112339-7074-4598-9935-cbe47fa7a404	1	core
af3e8297-eca3-4329-bbac-e92026a3e21f	SDE	Software Engineer	7271fa08-e44a-403a-b149-9d13e0f3688b	1	core
ca7ac4ee-50bb-4c30-8f0e-5da158eefff2	PM	Product Manager	7271fa08-e44a-403a-b149-9d13e0f3688b	1	core
d4fbd165-c6c6-48ae-8de0-186d7308ebd9	DA	Data Analyst	7271fa08-e44a-403a-b149-9d13e0f3688b	1	core
74d487ba-1b35-404d-88c4-4acc4742a1b6	TL	Team Lead	7271fa08-e44a-403a-b149-9d13e0f3688b	1	core
85eb0093-99ac-46b4-9cd2-ff3c49580c66	DIR	Director	7271fa08-e44a-403a-b149-9d13e0f3688b	1	core
11ca5ea9-ff0d-4128-826c-a391bb154f55	CONS	Consultant	7271fa08-e44a-403a-b149-9d13e0f3688b	1	core
bbc83df9-fbc3-42ce-a14f-9b71db477818	SALES	Sales / BD	7271fa08-e44a-403a-b149-9d13e0f3688b	1	core
a81b3110-e12c-4216-8e43-8ffef155433b	SDE	Software Engineer	f8c00def-9a89-48e8-b2ae-72259b14d366	1	core
e1bc833b-e1e9-4723-9f08-225ed7f4649e	PM	Product Manager	f8c00def-9a89-48e8-b2ae-72259b14d366	1	core
822da269-c054-4cb2-846e-05a9aad21f43	DA	Data Analyst	f8c00def-9a89-48e8-b2ae-72259b14d366	1	core
a031181c-c0e4-48b1-86e6-b193a87638be	TL	Team Lead	f8c00def-9a89-48e8-b2ae-72259b14d366	1	core
5b3d28a1-7d2f-474c-be4e-5699e2539a00	DIR	Director	f8c00def-9a89-48e8-b2ae-72259b14d366	1	core
53cd5ac3-70f5-4085-a736-ff3b0893944b	CONS	Consultant	f8c00def-9a89-48e8-b2ae-72259b14d366	1	core
880305dd-a415-4f76-a90d-392090fc557f	SALES	Sales / BD	f8c00def-9a89-48e8-b2ae-72259b14d366	1	core
26dbebd4-1c83-44b3-ae91-fccce919e360	SDE	Software Engineer	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	1	core
9829c58a-35c8-41cb-88da-14cdf61f1ab8	PM	Product Manager	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	1	core
b6111790-3b16-41dd-9027-4a4878d80099	DA	Data Analyst	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	1	core
599b00b7-cd2b-455c-ab80-22ea4249238a	TL	Team Lead	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	1	core
f9473cbb-7d5c-4048-964f-e68484632a90	DIR	Director	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	1	core
5faa5ec2-54e7-49de-a64e-f2674d24eb37	CONS	Consultant	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	1	core
67cda37a-35ba-44c8-a646-f0b26ff66d5f	SALES	Sales / BD	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	1	core
03a03a14-0111-43cd-9d09-8b4e368068cb	SDE	Software Engineer	4d6c9473-f695-4211-ab51-d1356b090bf4	1	core
eeb9a8f2-167d-42f4-9ee2-a92ccf13e0ac	PM	Product Manager	4d6c9473-f695-4211-ab51-d1356b090bf4	1	core
e0bcf462-6660-44fd-81db-e466f40d8fa3	DA	Data Analyst	4d6c9473-f695-4211-ab51-d1356b090bf4	1	core
328e54ad-b6d2-4b8b-b6bc-0d626c8dcced	TL	Team Lead	4d6c9473-f695-4211-ab51-d1356b090bf4	1	core
7266cbd4-2081-4a6f-b4c5-a787c4e21dbb	DIR	Director	4d6c9473-f695-4211-ab51-d1356b090bf4	1	core
45425f4b-3e83-47cf-a523-4830945f0395	CONS	Consultant	4d6c9473-f695-4211-ab51-d1356b090bf4	1	core
1d92ec09-001a-41ab-b906-9f5fc4756004	SALES	Sales / BD	4d6c9473-f695-4211-ab51-d1356b090bf4	1	core
cdb07e15-1582-4305-bbd1-1bd03baa37e0	SDE	Software Engineer	6ca14809-7aca-4b68-abf6-ea3e9370a580	1	core
58b03c72-3519-4907-a9ae-4b61bd26c0d7	PM	Product Manager	6ca14809-7aca-4b68-abf6-ea3e9370a580	1	core
c940adf8-24d6-4b76-b091-d7a3c6066dd2	DA	Data Analyst	6ca14809-7aca-4b68-abf6-ea3e9370a580	1	core
08cc53ac-dca5-4090-868b-eb8134dbc437	TL	Team Lead	6ca14809-7aca-4b68-abf6-ea3e9370a580	1	core
91c55ca4-3c09-4c34-9ce5-e7cee1e7c420	DIR	Director	6ca14809-7aca-4b68-abf6-ea3e9370a580	1	core
cfef4fa3-7450-4190-9a3b-950ef6d84991	CONS	Consultant	6ca14809-7aca-4b68-abf6-ea3e9370a580	1	core
609f332d-b112-4a91-96b1-31eae3bcfe40	SALES	Sales / BD	6ca14809-7aca-4b68-abf6-ea3e9370a580	1	core
102021b4-d0f0-4fd4-b3dd-7f94fa0006f6	SDE	Software Engineer	e8fd5615-1881-4dcc-bd44-cd29674d3885	1	core
4bb0cc4c-65ba-455c-be55-d159b418bba5	PM	Product Manager	e8fd5615-1881-4dcc-bd44-cd29674d3885	1	core
e7bafa5d-0b01-4336-9e47-e40f191ea2b1	DA	Data Analyst	e8fd5615-1881-4dcc-bd44-cd29674d3885	1	core
7b46f32e-5b1d-4864-a124-f11258c0aa00	TL	Team Lead	e8fd5615-1881-4dcc-bd44-cd29674d3885	1	core
f60a7244-e786-4d48-9922-464f9161163f	DIR	Director	e8fd5615-1881-4dcc-bd44-cd29674d3885	1	core
add2051a-22fd-4dad-bcb3-06ec4da1d421	CONS	Consultant	e8fd5615-1881-4dcc-bd44-cd29674d3885	1	core
b900762c-0c1e-4835-96aa-db6ea163d2c0	SALES	Sales / BD	e8fd5615-1881-4dcc-bd44-cd29674d3885	1	core
eeaf0978-9405-4db6-b1a4-4e3d8f55f2e3	SDE	Software Engineer	b780467e-639b-4507-991b-eb860e7b68bf	1	core
ce02462e-4d3e-4fc9-9897-4a5eb52830c7	PM	Product Manager	b780467e-639b-4507-991b-eb860e7b68bf	1	core
2a69fec4-a481-403d-ac42-93304faf9f06	DA	Data Analyst	b780467e-639b-4507-991b-eb860e7b68bf	1	core
31993a30-03cb-48d2-a668-269fd1e6da67	TL	Team Lead	b780467e-639b-4507-991b-eb860e7b68bf	1	core
656ce1b8-4fa7-464d-9936-a461bc73525e	DIR	Director	b780467e-639b-4507-991b-eb860e7b68bf	1	core
fc32d023-6fbd-4e49-bbb0-87167b6d4423	CONS	Consultant	b780467e-639b-4507-991b-eb860e7b68bf	1	core
4aa3ba2e-7500-43f4-8d5c-1b8f1718dc5e	SALES	Sales / BD	b780467e-639b-4507-991b-eb860e7b68bf	1	core
fba3e00d-5d38-4f68-91ee-1246560e344f	SDE	Software Engineer	1fc73df2-2590-4284-8aa3-dca7dd802fcd	1	core
612190e6-298b-4351-b1e9-15b936e58a48	PM	Product Manager	1fc73df2-2590-4284-8aa3-dca7dd802fcd	1	core
1cf5c202-73e7-489f-8104-28075ea996bd	DA	Data Analyst	1fc73df2-2590-4284-8aa3-dca7dd802fcd	1	core
7c8d46d1-6529-46da-b86c-c0780f6b012a	TL	Team Lead	1fc73df2-2590-4284-8aa3-dca7dd802fcd	1	core
58c789aa-6f09-4970-97b9-15c450c6922d	DIR	Director	1fc73df2-2590-4284-8aa3-dca7dd802fcd	1	core
09218487-fa90-4f72-a0ea-76bb8c44cef4	CONS	Consultant	1fc73df2-2590-4284-8aa3-dca7dd802fcd	1	core
20b5fb2e-f0dd-420a-8ed0-120fb96cff45	SALES	Sales / BD	1fc73df2-2590-4284-8aa3-dca7dd802fcd	1	core
466e7d67-aa39-4608-93ee-142d9921f785	SDE	Software Engineer	99390c52-0291-4018-88d4-81a4a4da81e6	1	core
2cb1c64f-b06e-47e4-93cd-3f3df0f4c281	PM	Product Manager	99390c52-0291-4018-88d4-81a4a4da81e6	1	core
e8116e31-0cec-43f3-8499-346ee5e22b59	DA	Data Analyst	99390c52-0291-4018-88d4-81a4a4da81e6	1	core
8954bf8a-fba5-418e-869d-3935886d7a01	TL	Team Lead	99390c52-0291-4018-88d4-81a4a4da81e6	1	core
d90c449d-bbe3-45a5-8cbb-3093bbb92a1a	DIR	Director	99390c52-0291-4018-88d4-81a4a4da81e6	1	core
8a751d6a-d380-4c3a-b4e0-afee2f43e824	CONS	Consultant	99390c52-0291-4018-88d4-81a4a4da81e6	1	core
aab15c37-2645-42fc-946c-6c2f9f7ff318	SALES	Sales / BD	99390c52-0291-4018-88d4-81a4a4da81e6	1	core
59ecfb71-40f6-411a-853d-896652c2add4	SDE	Software Engineer	a3a8013e-f8ae-4887-96c7-2895f8ab481f	1	core
fcc6ed34-b036-49ec-8910-3d0ed8c93039	PM	Product Manager	a3a8013e-f8ae-4887-96c7-2895f8ab481f	1	core
66b0dbe7-8ba4-4371-932d-29d3b214fe81	DA	Data Analyst	a3a8013e-f8ae-4887-96c7-2895f8ab481f	1	core
a407d207-7c4f-4d9d-8948-f6e84bf8a016	TL	Team Lead	a3a8013e-f8ae-4887-96c7-2895f8ab481f	1	core
5b91cf4a-4a5d-4515-a9ec-fecf0379b071	DIR	Director	a3a8013e-f8ae-4887-96c7-2895f8ab481f	1	core
fc373d29-e6f3-4623-a167-0bc49acc1c15	CONS	Consultant	a3a8013e-f8ae-4887-96c7-2895f8ab481f	1	core
4a19d39b-cf10-4d3b-955a-2a1609a58685	SALES	Sales / BD	a3a8013e-f8ae-4887-96c7-2895f8ab481f	1	core
5f7979c5-a2ac-4a5c-9102-65490a09bfa6	SDE	Software Engineer	8d5cd822-b4ae-489a-992c-9b5ac87a6105	1	core
567a14b6-304a-4608-8834-701e3f7809e0	PM	Product Manager	8d5cd822-b4ae-489a-992c-9b5ac87a6105	1	core
4edb2c57-83d5-4534-8f59-fdba10b29599	DA	Data Analyst	8d5cd822-b4ae-489a-992c-9b5ac87a6105	1	core
ffde8a56-12ee-40dc-860c-ff6974c8ab6f	TL	Team Lead	8d5cd822-b4ae-489a-992c-9b5ac87a6105	1	core
00b29a3e-3f20-4139-b50b-64f7d014996e	DIR	Director	8d5cd822-b4ae-489a-992c-9b5ac87a6105	1	core
13dd5898-56b7-4890-b433-ef724019f71c	CONS	Consultant	8d5cd822-b4ae-489a-992c-9b5ac87a6105	1	core
e153e324-c9a7-4f06-bd83-48bd43f27e6f	SALES	Sales / BD	8d5cd822-b4ae-489a-992c-9b5ac87a6105	1	core
4a6ff10b-7516-40b5-ba2f-b6c28139bfeb	SDE	Software Engineer	d7525db7-8927-4459-bfa1-ab274367f8df	1	core
fb4ddd37-a911-43b1-8fd1-8d8928393c4d	PM	Product Manager	d7525db7-8927-4459-bfa1-ab274367f8df	1	core
d7f09f66-35a0-4112-8f18-4ec25ec0577e	DA	Data Analyst	d7525db7-8927-4459-bfa1-ab274367f8df	1	core
1e131b0d-62aa-460a-82ae-7d9f0add0150	TL	Team Lead	d7525db7-8927-4459-bfa1-ab274367f8df	1	core
7eccbb65-38b8-482c-bb22-3826c2e22eed	DIR	Director	d7525db7-8927-4459-bfa1-ab274367f8df	1	core
2a866c22-4028-42ed-bc19-aadeff00fee7	CONS	Consultant	d7525db7-8927-4459-bfa1-ab274367f8df	1	core
91cbc7d7-ee34-4cee-8983-16791fc8a0f4	SALES	Sales / BD	d7525db7-8927-4459-bfa1-ab274367f8df	1	core
bb3cf8f4-8364-4234-a8e6-9bbb0d9f3573	SDE	Software Engineer	de0175d7-42d0-4d86-88b5-8e6d618be96a	1	core
1e07070a-ab53-4329-bef0-68d5b6519d30	PM	Product Manager	de0175d7-42d0-4d86-88b5-8e6d618be96a	1	core
ba0bf798-a485-43ef-8f6c-cb26e5d010ca	DA	Data Analyst	de0175d7-42d0-4d86-88b5-8e6d618be96a	1	core
de29c21f-d081-44b6-8853-c6b4820da26a	TL	Team Lead	de0175d7-42d0-4d86-88b5-8e6d618be96a	1	core
f2a5b76f-fbba-458e-9eef-fa43d127fd4a	DIR	Director	de0175d7-42d0-4d86-88b5-8e6d618be96a	1	core
0b74b8c0-255d-4e89-9480-cb9af65ec09d	CONS	Consultant	de0175d7-42d0-4d86-88b5-8e6d618be96a	1	core
c92f8a8e-fafd-4150-a6c5-6e3b77d9db5b	SALES	Sales / BD	de0175d7-42d0-4d86-88b5-8e6d618be96a	1	core
69c19216-3d4a-40ab-8fa7-87150312b765	SDE	Software Engineer	8d4de2da-6e42-40fc-aa60-0d002fd26948	1	core
059e4f38-d0eb-495a-99bd-bbc14e684968	PM	Product Manager	8d4de2da-6e42-40fc-aa60-0d002fd26948	1	core
8221d2f3-b9a1-4cc4-83f1-8bc96cc08962	DA	Data Analyst	8d4de2da-6e42-40fc-aa60-0d002fd26948	1	core
ea513646-16cf-4589-b8cf-370db28b6a73	TL	Team Lead	8d4de2da-6e42-40fc-aa60-0d002fd26948	1	core
f6323c51-50e9-4874-a56e-b7ff466b0129	DIR	Director	8d4de2da-6e42-40fc-aa60-0d002fd26948	1	core
33302231-c2d2-4d4c-9d95-4623a5210038	CONS	Consultant	8d4de2da-6e42-40fc-aa60-0d002fd26948	1	core
cdc2972d-965a-4f03-a458-2782b98c08f1	SALES	Sales / BD	8d4de2da-6e42-40fc-aa60-0d002fd26948	1	core
a85c6d5a-d2bb-4093-bf17-fa687d480a75	SDE	Software Engineer	bf81449b-f2f4-4ee2-9281-e56273b096a7	1	core
3a836142-faf1-4ec9-ba1e-84cdb32ec7b3	PM	Product Manager	bf81449b-f2f4-4ee2-9281-e56273b096a7	1	core
56f321c8-f633-446f-9e80-eaee4c5e15bb	DA	Data Analyst	bf81449b-f2f4-4ee2-9281-e56273b096a7	1	core
c42fffda-ab84-40c9-8956-29db70088239	TL	Team Lead	bf81449b-f2f4-4ee2-9281-e56273b096a7	1	core
552ea132-a3b0-4df5-af9d-d03dbf10c094	DIR	Director	bf81449b-f2f4-4ee2-9281-e56273b096a7	1	core
e8b35ee4-63f0-48a7-8858-27b61b099d21	CONS	Consultant	bf81449b-f2f4-4ee2-9281-e56273b096a7	1	core
7418e6c5-c76b-48da-ab5c-96eaa297a139	SALES	Sales / BD	bf81449b-f2f4-4ee2-9281-e56273b096a7	1	core
92c2261c-9e52-4f8f-86b4-7e37d5408d63	SDE	Software Engineer	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	1	core
c259f342-6374-4823-a136-4615b423985c	PM	Product Manager	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	1	core
a748fd4d-f999-4dd7-84bb-35c90d5a248f	DA	Data Analyst	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	1	core
476a222c-52cd-4eed-be63-e62397d42c28	TL	Team Lead	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	1	core
e9417e7a-9fa0-4dff-827e-cfc87e2b4a0a	DIR	Director	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	1	core
76bbdea7-e526-44d4-9841-2c2fbed64206	CONS	Consultant	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	1	core
6d4c2125-89bd-45b3-aca8-5afd28fbf6e2	SALES	Sales / BD	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	1	core
20121ef1-a39a-4215-b083-59f89a7b8105	SDE	Software Engineer	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	1	core
e68d3723-ff02-4c3a-829c-c81199757ca8	PM	Product Manager	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	1	core
834f49f3-bcd1-4699-ac6e-2931d100116d	DA	Data Analyst	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	1	core
eee43c36-effe-43ea-af77-32956c0b3710	TL	Team Lead	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	1	core
07bd2d85-b6a1-4666-854d-b62aca479f9e	DIR	Director	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	1	core
b3b34e34-b1d1-4d83-ab1c-7d017c4dabea	CONS	Consultant	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	1	core
f53c4d80-6dc2-4eb3-adbc-a5c216f205f3	SALES	Sales / BD	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	1	core
f55447f6-8c49-431e-924d-395dd70846e1	SDE	Software Engineer	cf5a6ec2-d6c0-42af-b554-8787ae398127	1	core
0510cc79-b2a9-45cb-aff5-56ad99aeda9d	PM	Product Manager	cf5a6ec2-d6c0-42af-b554-8787ae398127	1	core
0a22c345-c491-4366-a695-6f5c26b5fd28	DA	Data Analyst	cf5a6ec2-d6c0-42af-b554-8787ae398127	1	core
1c52515d-cc35-4878-9a09-4d7e85e5a5bc	TL	Team Lead	cf5a6ec2-d6c0-42af-b554-8787ae398127	1	core
3ab3a0bc-608e-48df-8d42-d9ae088d9491	DIR	Director	cf5a6ec2-d6c0-42af-b554-8787ae398127	1	core
fc533cf2-cb31-4fec-a8d2-e07eacd39d8a	CONS	Consultant	cf5a6ec2-d6c0-42af-b554-8787ae398127	1	core
81b902ed-0cc8-4040-ac33-5e094ad8def2	SALES	Sales / BD	cf5a6ec2-d6c0-42af-b554-8787ae398127	1	core
c44d1aa2-5c42-41f6-9272-6a3ce63f0366	SDE	Software Engineer	4fffa5ac-3619-4097-8895-be009f4aabd6	1	core
4dc5acb2-ea57-4b09-a873-6af342d87163	PM	Product Manager	4fffa5ac-3619-4097-8895-be009f4aabd6	1	core
80703b1c-d7aa-45b0-b639-cc3f8390ac64	DA	Data Analyst	4fffa5ac-3619-4097-8895-be009f4aabd6	1	core
eb1551d5-d386-43a5-b51a-1f6e94ec19db	TL	Team Lead	4fffa5ac-3619-4097-8895-be009f4aabd6	1	core
68cd1193-5fe9-4bca-ba0d-745a4568aa15	DIR	Director	4fffa5ac-3619-4097-8895-be009f4aabd6	1	core
c069e087-90f9-4caf-a55b-e670f529b56a	CONS	Consultant	4fffa5ac-3619-4097-8895-be009f4aabd6	1	core
5b79e7a1-e400-4258-adb6-8ae6c402212c	SALES	Sales / BD	4fffa5ac-3619-4097-8895-be009f4aabd6	1	core
ac050132-7848-403b-b14c-4aca207aec07	SDE	Software Engineer	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	1	core
a487574f-9453-4b3c-b21a-fd227899480f	PM	Product Manager	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	1	core
d0bd11da-ccd0-441f-beab-7bff2c483f15	DA	Data Analyst	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	1	core
ad6bf3a0-057c-4ff2-bb4b-97cd17005fdc	TL	Team Lead	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	1	core
38f81cc9-0c8b-43c1-b5dd-d0c4dd3391bf	DIR	Director	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	1	core
bf11b4e1-7509-452c-b086-43355e6777d6	CONS	Consultant	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	1	core
84e15f7c-9a05-480d-839f-0175378108d6	SALES	Sales / BD	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	1	core
0ea6ea27-188f-416f-82a9-78bdfddafb4d	SDE	Software Engineer	214c70ad-0444-4973-92ba-1ee8991ebf23	1	core
5f58319c-e176-4d7b-957c-31546e981f81	PM	Product Manager	214c70ad-0444-4973-92ba-1ee8991ebf23	1	core
4add0e0e-ec26-42d6-957c-a5b7a19b68ff	DA	Data Analyst	214c70ad-0444-4973-92ba-1ee8991ebf23	1	core
78930852-a392-4b79-b995-3af9f8f49841	TL	Team Lead	214c70ad-0444-4973-92ba-1ee8991ebf23	1	core
432f8820-a146-410d-8e76-aabdbf7e430b	DIR	Director	214c70ad-0444-4973-92ba-1ee8991ebf23	1	core
cb61deff-4ca8-49c8-97f0-48ea0f7848e1	CONS	Consultant	214c70ad-0444-4973-92ba-1ee8991ebf23	1	core
955f09dc-2677-44c8-a4c1-17b3f8b2c7a4	SALES	Sales / BD	214c70ad-0444-4973-92ba-1ee8991ebf23	1	core
0776048d-95a6-4510-948b-e33ec25e6b85	SDE	Software Engineer	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	1	core
a5eef10a-1282-4f9a-9753-9daa20f66985	PM	Product Manager	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	1	core
dfbd4108-bc63-4a0b-af92-4cdbe745454d	DA	Data Analyst	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	1	core
d451586b-b200-4098-be05-a7bd71ab7c58	TL	Team Lead	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	1	core
8d1f217b-ff5c-4834-8ae3-44b97c549b44	DIR	Director	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	1	core
a96aeeb5-a83b-469c-9f54-b005efb9fe49	CONS	Consultant	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	1	core
9c217c4e-facb-4c4f-a35f-a74c684d7476	SALES	Sales / BD	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	1	core
0b5581bc-d78b-415a-a600-db575e433f76	SDE	Software Engineer	5a44cbd3-272e-44ee-a983-c53f268e38a2	1	core
b9913eb3-7c2e-44de-9b7f-ad70604dccd2	PM	Product Manager	5a44cbd3-272e-44ee-a983-c53f268e38a2	1	core
34d1c014-b64d-40e0-9b39-60c5c7337bb7	DA	Data Analyst	5a44cbd3-272e-44ee-a983-c53f268e38a2	1	core
7c2f1edd-d553-4186-8690-1485db858f34	TL	Team Lead	5a44cbd3-272e-44ee-a983-c53f268e38a2	1	core
047c7a58-66cb-48ef-a013-2eda4fdecdcf	DIR	Director	5a44cbd3-272e-44ee-a983-c53f268e38a2	1	core
3b847c3f-2fa2-4eb9-b950-a2bb70bb95e8	CONS	Consultant	5a44cbd3-272e-44ee-a983-c53f268e38a2	1	core
552249d3-9c2c-4b32-a65b-f8c0c15d9ec4	SALES	Sales / BD	5a44cbd3-272e-44ee-a983-c53f268e38a2	1	core
d15b59e3-b06a-4a52-bc33-65a44b90a32e	SDE	Software Engineer	ba4d5a0b-de42-4777-9f17-b440d557a612	1	core
3b63460f-d043-4540-8488-c5827c4df40d	PM	Product Manager	ba4d5a0b-de42-4777-9f17-b440d557a612	1	core
a3145b68-54bb-41fb-be27-381d7f6671d9	DA	Data Analyst	ba4d5a0b-de42-4777-9f17-b440d557a612	1	core
56359221-507a-4b8c-b492-8d0970bde7f0	TL	Team Lead	ba4d5a0b-de42-4777-9f17-b440d557a612	1	core
e0692477-aa99-4132-8333-e0e02b427d0d	DIR	Director	ba4d5a0b-de42-4777-9f17-b440d557a612	1	core
b04d5151-bd47-4955-a21a-ca72fc1e2410	CONS	Consultant	ba4d5a0b-de42-4777-9f17-b440d557a612	1	core
57faf1b4-dcd4-41ed-9d07-18d437e8ccb5	SALES	Sales / BD	ba4d5a0b-de42-4777-9f17-b440d557a612	1	core
488f05d5-8598-47e4-9abd-9bf64f10f590	SDE	Software Engineer	a34a79c2-cde4-4893-a47b-a76b77713445	1	core
61b7e8d1-a643-44bc-85b9-1b286386175f	PM	Product Manager	a34a79c2-cde4-4893-a47b-a76b77713445	1	core
57f508d7-f362-4aec-b566-a85c31d2e297	DA	Data Analyst	a34a79c2-cde4-4893-a47b-a76b77713445	1	core
406ffbae-0e32-4f2f-9d6c-49487ae7a851	TL	Team Lead	a34a79c2-cde4-4893-a47b-a76b77713445	1	core
f0bb4d48-60cf-4cea-ba35-585b6627b52b	DIR	Director	a34a79c2-cde4-4893-a47b-a76b77713445	1	core
89939afe-2706-41a8-a1c9-dacc09172a45	CONS	Consultant	a34a79c2-cde4-4893-a47b-a76b77713445	1	core
c2afb707-af88-4bcb-9b89-f0bf95144314	SALES	Sales / BD	a34a79c2-cde4-4893-a47b-a76b77713445	1	core
963c00fe-eb55-4863-9d2b-b585da5422f0	SDE	Software Engineer	bc5c127d-fcc1-4d0e-9751-6f227917585b	1	core
4450514f-428b-49e3-86de-581b6ef83c25	PM	Product Manager	bc5c127d-fcc1-4d0e-9751-6f227917585b	1	core
f2ace8d4-6e20-48ef-88a8-66674bf997f5	DA	Data Analyst	bc5c127d-fcc1-4d0e-9751-6f227917585b	1	core
986cd0ac-d53a-4e7a-a5b0-fc5133b6aa11	TL	Team Lead	bc5c127d-fcc1-4d0e-9751-6f227917585b	1	core
18213c23-4483-440d-a993-13df4a29ba1b	DIR	Director	bc5c127d-fcc1-4d0e-9751-6f227917585b	1	core
1f1209f9-3f6a-4fd3-8b72-d02c1573395d	CONS	Consultant	bc5c127d-fcc1-4d0e-9751-6f227917585b	1	core
9e61659b-85aa-4ebd-a907-209a1e6e4e53	SALES	Sales / BD	bc5c127d-fcc1-4d0e-9751-6f227917585b	1	core
d21d87f1-6b77-4bd4-8a06-5d132000fbae	SDE	Software Engineer	0f7f4297-1de4-48fc-8497-2e0c797494fa	1	core
ca8a86f8-c6a8-4126-9455-bddbe5874241	PM	Product Manager	0f7f4297-1de4-48fc-8497-2e0c797494fa	1	core
b35cc9bd-ff19-4bd4-818e-ed4cd3cc9420	DA	Data Analyst	0f7f4297-1de4-48fc-8497-2e0c797494fa	1	core
0c8ff664-1cef-49d8-a2d7-00856f47fbce	TL	Team Lead	0f7f4297-1de4-48fc-8497-2e0c797494fa	1	core
fbb12f82-fdcd-47a3-aa39-6800c872eca4	DIR	Director	0f7f4297-1de4-48fc-8497-2e0c797494fa	1	core
3791e4e9-ad8a-4ce4-befc-ee46d7b507c5	CONS	Consultant	0f7f4297-1de4-48fc-8497-2e0c797494fa	1	core
14fc39fa-bc62-4def-b9e8-cdef8c3a272d	SALES	Sales / BD	0f7f4297-1de4-48fc-8497-2e0c797494fa	1	core
9e066846-8c54-4adb-a248-aa17a0bda176	SDE	Software Engineer	2657d0bc-b2d9-4282-9789-0a633a41b160	1	core
aa1e57da-d21f-48b7-883a-a82df35578eb	PM	Product Manager	2657d0bc-b2d9-4282-9789-0a633a41b160	1	core
d07bf63e-cbfa-402a-a9f2-25ef1f4c8401	DA	Data Analyst	2657d0bc-b2d9-4282-9789-0a633a41b160	1	core
e51e15a9-03a0-4a3a-ae45-1094e25b430d	TL	Team Lead	2657d0bc-b2d9-4282-9789-0a633a41b160	1	core
6054a3c0-8636-424b-a5bd-65c882c98c09	DIR	Director	2657d0bc-b2d9-4282-9789-0a633a41b160	1	core
5b367199-c08f-49b3-83a3-f815cbdee23f	CONS	Consultant	2657d0bc-b2d9-4282-9789-0a633a41b160	1	core
a70bba39-b180-42f4-acb6-650d1e3c3fbb	SALES	Sales / BD	2657d0bc-b2d9-4282-9789-0a633a41b160	1	core
c00ee920-49fd-426a-8b57-76f237f3a543	SDE	Software Engineer	5ca7c62a-f414-4798-91a3-c07be84e6a45	1	core
bb466728-5aae-4bf4-919f-3beb710ea9e6	PM	Product Manager	5ca7c62a-f414-4798-91a3-c07be84e6a45	1	core
a1108f7a-0a70-46e0-896f-13ef3c20e46c	DA	Data Analyst	5ca7c62a-f414-4798-91a3-c07be84e6a45	1	core
3348d92c-43a4-499e-8bde-d90dfde74999	TL	Team Lead	5ca7c62a-f414-4798-91a3-c07be84e6a45	1	core
ff0b99f1-02df-4ea0-b21e-81dbb7fea8cd	DIR	Director	5ca7c62a-f414-4798-91a3-c07be84e6a45	1	core
a779aa49-b013-4a25-9c1c-402242fbcd52	CONS	Consultant	5ca7c62a-f414-4798-91a3-c07be84e6a45	1	core
17982b34-de7e-43a2-b43c-56e07d3ebbd4	SALES	Sales / BD	5ca7c62a-f414-4798-91a3-c07be84e6a45	1	core
ad7aac84-bc82-4973-b89d-5e460f62451e	SDE	Software Engineer	b97e2925-e046-4fb1-9634-db85e2aa19fe	1	core
349849ae-7aa1-4dca-8c1c-8524a2dee2dc	PM	Product Manager	b97e2925-e046-4fb1-9634-db85e2aa19fe	1	core
9b2a1d5a-b30d-4962-b8f0-c130f09373b6	DA	Data Analyst	b97e2925-e046-4fb1-9634-db85e2aa19fe	1	core
bb25994e-71c4-4481-8efc-5cfaa14c85d1	TL	Team Lead	b97e2925-e046-4fb1-9634-db85e2aa19fe	1	core
196b8973-9f35-497e-a2fe-fa8393188146	DIR	Director	b97e2925-e046-4fb1-9634-db85e2aa19fe	1	core
c39a5063-57c1-4135-ae4c-8606c49d6f3e	CONS	Consultant	b97e2925-e046-4fb1-9634-db85e2aa19fe	1	core
53d3fd02-c31e-4a69-a4cf-4f9f332deee1	SALES	Sales / BD	b97e2925-e046-4fb1-9634-db85e2aa19fe	1	core
450c6e3d-3931-4159-9582-d01719824dec	SDE	Software Engineer	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	1	core
6ed7d500-48a1-46d5-9191-f9474b27af5d	PM	Product Manager	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	1	core
5573b10a-91ca-46bb-a9f5-a48ac3d8c302	DA	Data Analyst	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	1	core
721569b8-d15d-49ac-ac33-2c523b5e8780	TL	Team Lead	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	1	core
35ad0117-4797-4f3c-bb90-a5070f953c90	DIR	Director	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	1	core
8879e0a9-485f-4935-b0ee-62a01d46f761	CONS	Consultant	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	1	core
4fcba612-8729-4b02-a1d3-946a7cde2f86	SALES	Sales / BD	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	1	core
c537e59b-c751-4b4c-99bc-ae280cb931d8	SDE	Software Engineer	11c5184b-9c1b-4e60-a370-b68a68091bdf	1	core
3132e3e5-2c8d-4844-942e-8172304bbeff	PM	Product Manager	11c5184b-9c1b-4e60-a370-b68a68091bdf	1	core
811ccb5e-31ae-4796-9ef3-5b2b0c8f15a2	DA	Data Analyst	11c5184b-9c1b-4e60-a370-b68a68091bdf	1	core
2fb48fd5-b039-48c1-91e3-60ef4f81c9e1	TL	Team Lead	11c5184b-9c1b-4e60-a370-b68a68091bdf	1	core
8d1e1e6f-abcd-4a38-90a1-9fada7bf6952	DIR	Director	11c5184b-9c1b-4e60-a370-b68a68091bdf	1	core
1ad014f6-33a4-4d35-b9b3-870ae6b737c1	CONS	Consultant	11c5184b-9c1b-4e60-a370-b68a68091bdf	1	core
989ea150-d003-40b0-851f-757d1ab9bb7d	SALES	Sales / BD	11c5184b-9c1b-4e60-a370-b68a68091bdf	1	core
69a130a1-cddd-4c5f-b141-82e1fa6f4806	SDE	Software Engineer	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	1	core
66ad4864-c6da-41d5-b085-280515d75343	PM	Product Manager	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	1	core
3b83654f-bb59-41c6-ba67-e4c7fba5018e	DA	Data Analyst	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	1	core
95e02613-befd-48a5-8943-daae9fbd4b72	TL	Team Lead	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	1	core
5c60762d-388c-43fd-8638-09d858b2a017	DIR	Director	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	1	core
b3e3dffe-bfe0-4ad9-bfe7-1f1a9db71178	CONS	Consultant	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	1	core
18081a2e-b9c8-49bf-a288-606060a782e7	SALES	Sales / BD	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	1	core
02f21aee-60c5-4fdc-a13f-c380f85138b8	SDE	Software Engineer	15663cfd-4327-4d0f-9398-57344ccf0884	1	core
11868bf9-d4b8-466a-9abd-a772d7319c93	PM	Product Manager	15663cfd-4327-4d0f-9398-57344ccf0884	1	core
c0353722-af10-469c-9a13-99baefe27db5	DA	Data Analyst	15663cfd-4327-4d0f-9398-57344ccf0884	1	core
dd346b8e-9fd6-425f-bd32-eab47de49f9c	TL	Team Lead	15663cfd-4327-4d0f-9398-57344ccf0884	1	core
12c9ce08-0588-4081-8cc8-d4503480dbc9	DIR	Director	15663cfd-4327-4d0f-9398-57344ccf0884	1	core
9463bc23-85bd-418f-9836-c0d44994aa34	CONS	Consultant	15663cfd-4327-4d0f-9398-57344ccf0884	1	core
1ddb5240-c5e6-4bfd-bb09-b3c13ce47aca	SALES	Sales / BD	15663cfd-4327-4d0f-9398-57344ccf0884	1	core
ed0f0a88-3b9a-4c82-a5a5-4b3475a2c15e	SDE	Software Engineer	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	1	core
cabab562-dcce-46df-8856-6f28a13f0097	PM	Product Manager	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	1	core
a86d70ea-54f4-4ee2-86b1-17d718346c8b	DA	Data Analyst	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	1	core
939d297f-8058-4bff-8d67-30ba4f853b1f	TL	Team Lead	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	1	core
bd547a54-538d-4b90-8b75-2a0eb81fe783	DIR	Director	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	1	core
1906ad62-0602-44c4-ba84-03f006903c00	CONS	Consultant	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	1	core
6d80de53-bf2c-4408-acdc-ea8944a2e979	SALES	Sales / BD	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	1	core
70620374-833a-45a5-8aa3-7dc27438efac	SDE	Software Engineer	0aed465c-8ea1-4422-b633-0aad6ca4324d	1	core
5787ad74-bf22-4754-9001-6834aae3ae64	PM	Product Manager	0aed465c-8ea1-4422-b633-0aad6ca4324d	1	core
79bc0083-9008-43d6-8fb9-5d0668e970f5	DA	Data Analyst	0aed465c-8ea1-4422-b633-0aad6ca4324d	1	core
bfd15802-4754-48f2-a585-5ce3f05c2330	TL	Team Lead	0aed465c-8ea1-4422-b633-0aad6ca4324d	1	core
ad292211-5cd9-4e9e-badf-9bfe9d8416ca	DIR	Director	0aed465c-8ea1-4422-b633-0aad6ca4324d	1	core
cb88cac5-a6a7-4108-bce6-bc806491d9f8	CONS	Consultant	0aed465c-8ea1-4422-b633-0aad6ca4324d	1	core
a46f97eb-2f9c-4c16-ab5a-2325cfbeaab5	SALES	Sales / BD	0aed465c-8ea1-4422-b633-0aad6ca4324d	1	core
929cd0d3-a16f-4b47-8fb1-23ba4ce29675	SDE	Software Engineer	02c9688e-2900-4b9d-af2b-f652e20b22f9	1	core
1ed74d09-3e23-4684-8641-fa3a64ab56f2	PM	Product Manager	02c9688e-2900-4b9d-af2b-f652e20b22f9	1	core
d7fadb7e-cb25-4761-bd2b-327f5a8b0678	DA	Data Analyst	02c9688e-2900-4b9d-af2b-f652e20b22f9	1	core
83bbbdd9-a412-4467-8b0e-1157f17a55be	TL	Team Lead	02c9688e-2900-4b9d-af2b-f652e20b22f9	1	core
f0cd5731-4078-46e8-8399-7afb1657455a	DIR	Director	02c9688e-2900-4b9d-af2b-f652e20b22f9	1	core
98fcfd60-54cd-415d-abdc-88086408dc10	CONS	Consultant	02c9688e-2900-4b9d-af2b-f652e20b22f9	1	core
1e91fb8d-2717-4392-a753-8f4fc32355a2	SALES	Sales / BD	02c9688e-2900-4b9d-af2b-f652e20b22f9	1	core
8388d56b-ca9f-419d-a169-4c8daa907a30	SDE	Software Engineer	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	1	core
82edaa37-bc2a-448f-87b3-5f6353228a15	PM	Product Manager	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	1	core
4069c61b-e186-41dc-99c8-6b632e0ed3e3	DA	Data Analyst	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	1	core
107be441-a341-4284-8006-a781c1799b07	TL	Team Lead	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	1	core
100536ed-e660-458d-aa68-dbda6a48d477	DIR	Director	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	1	core
c621ede3-54df-4864-a4ff-b8a7ca873cf4	CONS	Consultant	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	1	core
939914a1-7f5f-40d8-a6b5-038076ddb945	SALES	Sales / BD	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	1	core
46795c47-21f3-4b2c-8b5c-7e7125651d05	SDE	Software Engineer	229abe94-2a63-4b86-810d-d247f4b312bc	1	core
a5b6d620-e8bf-4277-9530-7bc461d986a3	PM	Product Manager	229abe94-2a63-4b86-810d-d247f4b312bc	1	core
007c6a4e-c6bc-40f1-94a4-8d37524b93af	DA	Data Analyst	229abe94-2a63-4b86-810d-d247f4b312bc	1	core
8780bbd7-5c52-4d90-baba-e6c34dac0ada	TL	Team Lead	229abe94-2a63-4b86-810d-d247f4b312bc	1	core
d730e506-38ea-45aa-afe5-2ea5d6eb326f	DIR	Director	229abe94-2a63-4b86-810d-d247f4b312bc	1	core
0420ecbc-e759-4701-82ba-fd0d2cef733b	CONS	Consultant	229abe94-2a63-4b86-810d-d247f4b312bc	1	core
9ab532ec-c962-42d7-903e-140240373d20	SALES	Sales / BD	229abe94-2a63-4b86-810d-d247f4b312bc	1	core
e1370da3-8c58-4723-9b75-e8a40bc4473d	SDE	Software Engineer	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	1	core
0b6fc274-4102-45f2-9004-7f00f0072c3f	PM	Product Manager	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	1	core
6952dc8c-324a-4e29-aae2-738d8ba7a1f4	DA	Data Analyst	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	1	core
42feaca7-f4c9-4c9b-91ca-aa49a6330a06	TL	Team Lead	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	1	core
3dcbdfc5-09ac-41b9-9ab1-a1bfb858b4cd	DIR	Director	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	1	core
a637d188-4739-479e-8d3a-467d79af9028	CONS	Consultant	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	1	core
1e12aa15-586c-4c2a-aced-e622fa47c44e	SALES	Sales / BD	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	1	core
428002e6-5728-4b76-a605-157a88ab999c	SDE	Software Engineer	68a8270d-3c39-4147-8238-df60a0b0b876	1	core
146f376f-3030-432a-b2d1-d4a886c8181b	PM	Product Manager	68a8270d-3c39-4147-8238-df60a0b0b876	1	core
1ab4ef91-e6f4-42ab-93e3-76274dcd1087	DA	Data Analyst	68a8270d-3c39-4147-8238-df60a0b0b876	1	core
18ffae11-d87e-45a3-9bf9-9500ae82e1f8	TL	Team Lead	68a8270d-3c39-4147-8238-df60a0b0b876	1	core
a8966470-cd09-445d-aea1-79a44b038ad7	DIR	Director	68a8270d-3c39-4147-8238-df60a0b0b876	1	core
5e7e38e7-cc26-4351-9976-1528feddd450	CONS	Consultant	68a8270d-3c39-4147-8238-df60a0b0b876	1	core
971c0bb1-be3b-4c47-97c5-70dd38e053f9	SALES	Sales / BD	68a8270d-3c39-4147-8238-df60a0b0b876	1	core
efe2f25a-3e15-417a-bf7a-2a0c3abab2d2	SDE	Software Engineer	edea5550-5eaa-4655-b4f1-7233774a6a7c	1	core
ac0a0d3e-6d2e-4e03-9e04-0a6961c6c741	PM	Product Manager	edea5550-5eaa-4655-b4f1-7233774a6a7c	1	core
170feb61-3a89-4fdc-ba54-979a79e63294	DA	Data Analyst	edea5550-5eaa-4655-b4f1-7233774a6a7c	1	core
bafc3dfe-e25b-4ace-b427-c37216f0c5da	TL	Team Lead	edea5550-5eaa-4655-b4f1-7233774a6a7c	1	core
e05919e9-d119-4724-bd2a-a6429ece2c30	DIR	Director	edea5550-5eaa-4655-b4f1-7233774a6a7c	1	core
5603ddb7-9b1f-4e61-bc99-90a92909ace4	CONS	Consultant	edea5550-5eaa-4655-b4f1-7233774a6a7c	1	core
7efa4eb9-fe25-4f3f-911d-025379099883	SALES	Sales / BD	edea5550-5eaa-4655-b4f1-7233774a6a7c	1	core
0b5f6020-3ff4-4acf-aaac-be21b2111858	SDE	Software Engineer	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	1	core
de9d5d8a-4e76-4032-a8cd-c0671bc62b32	PM	Product Manager	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	1	core
a1b6b819-fd92-4648-994d-531fbbedf45f	DA	Data Analyst	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	1	core
f0e00417-0041-40c9-8332-0ccaa86ba6f4	TL	Team Lead	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	1	core
8c08268c-ea9a-4456-8ccf-bd054da671fe	DIR	Director	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	1	core
c1f8204c-72e3-4753-9106-b1f99b7d8a4c	CONS	Consultant	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	1	core
f47c9ec2-e09d-44e1-a2a3-5f8c14fbfe12	SALES	Sales / BD	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	1	core
b3c13674-bec2-4dbc-8d69-81b163be2fe7	SDE	Software Engineer	af883093-9f75-4ba7-82bd-d01ea45888b0	1	core
2eaf7ad6-1204-4277-8caf-e9426a09d02f	PM	Product Manager	af883093-9f75-4ba7-82bd-d01ea45888b0	1	core
047b63a9-6f8a-48af-a6b6-09fd0b510e57	DA	Data Analyst	af883093-9f75-4ba7-82bd-d01ea45888b0	1	core
ca5f0792-ac9d-496f-ab8b-db3b7361012d	TL	Team Lead	af883093-9f75-4ba7-82bd-d01ea45888b0	1	core
a4880271-1f2a-4a9a-aa4e-5a6132bcfa31	DIR	Director	af883093-9f75-4ba7-82bd-d01ea45888b0	1	core
7d5f5056-a9d6-4ae3-ae07-6153a2bacff1	CONS	Consultant	af883093-9f75-4ba7-82bd-d01ea45888b0	1	core
0f899688-9236-446a-8524-e545c508275f	SALES	Sales / BD	af883093-9f75-4ba7-82bd-d01ea45888b0	1	core
9bef32f8-f2e4-4e58-9d82-a7317530e6fc	SDE	Software Engineer	bddab227-b2ba-421e-8f14-dad2aa12e5f6	1	core
11e5935e-3863-437f-b496-c47775692375	PM	Product Manager	bddab227-b2ba-421e-8f14-dad2aa12e5f6	1	core
e0b7b960-a116-4fdf-8f1d-61e5e3973228	DA	Data Analyst	bddab227-b2ba-421e-8f14-dad2aa12e5f6	1	core
41b8785d-ca90-437b-8182-d47bc917e0bf	TL	Team Lead	bddab227-b2ba-421e-8f14-dad2aa12e5f6	1	core
791d8c3f-5239-4aab-9d62-d814a6fbc57e	DIR	Director	bddab227-b2ba-421e-8f14-dad2aa12e5f6	1	core
595b84c2-bf76-4c4f-b64b-283f9a295e4c	CONS	Consultant	bddab227-b2ba-421e-8f14-dad2aa12e5f6	1	core
ceec97c1-934f-4003-a2f6-63be0c898a2d	SALES	Sales / BD	bddab227-b2ba-421e-8f14-dad2aa12e5f6	1	core
77771be5-1876-4802-82a4-e3e3f3c7c815	SDE	Software Engineer	d98acd03-5b09-453e-bca8-960566f07c7b	1	core
34a1ac1c-f054-43da-ba15-a91a7be42608	PM	Product Manager	d98acd03-5b09-453e-bca8-960566f07c7b	1	core
af80005a-3ea0-4e2d-9d36-d34f042e1582	DA	Data Analyst	d98acd03-5b09-453e-bca8-960566f07c7b	1	core
3138a43c-a1c9-4101-a81c-91398f48e7ba	TL	Team Lead	d98acd03-5b09-453e-bca8-960566f07c7b	1	core
658721e1-268b-4ee5-b08a-2f1aa8bcc3ea	DIR	Director	d98acd03-5b09-453e-bca8-960566f07c7b	1	core
411ce966-7d74-45bb-b5bf-1e6c2452e617	CONS	Consultant	d98acd03-5b09-453e-bca8-960566f07c7b	1	core
5481e370-b0dd-4b9e-8796-a8caedd9168f	SALES	Sales / BD	d98acd03-5b09-453e-bca8-960566f07c7b	1	core
2a62de2c-1665-4d7f-bb3d-762a7b8817a7	SDE	Software Engineer	a573e600-0003-4185-a22f-3c4610414309	1	core
43ad2c78-4c2b-44ac-8eaf-4630f59d8f18	PM	Product Manager	a573e600-0003-4185-a22f-3c4610414309	1	core
88559d6c-2d5d-46fa-b406-c23b497642e0	DA	Data Analyst	a573e600-0003-4185-a22f-3c4610414309	1	core
80cfefb2-3c06-479e-ace8-3e56f3cd3108	TL	Team Lead	a573e600-0003-4185-a22f-3c4610414309	1	core
c2272515-8afd-4405-acfd-fb435674de66	DIR	Director	a573e600-0003-4185-a22f-3c4610414309	1	core
76d79f8b-97ea-4385-b6d0-41d19efcd111	CONS	Consultant	a573e600-0003-4185-a22f-3c4610414309	1	core
c804b542-8576-4570-8003-2704d2dbca16	SALES	Sales / BD	a573e600-0003-4185-a22f-3c4610414309	1	core
82928d69-fa03-4c44-84f8-69b724d6de2a	SDE	Software Engineer	26304df3-d564-4d70-96ce-07ca92325f44	1	core
0facad7e-317f-44e2-8f97-0d7c60e568ad	PM	Product Manager	26304df3-d564-4d70-96ce-07ca92325f44	1	core
9938484b-ea71-4873-abdb-40716e540abb	DA	Data Analyst	26304df3-d564-4d70-96ce-07ca92325f44	1	core
938e2159-a6c2-4341-8778-ed3da41bb0ca	TL	Team Lead	26304df3-d564-4d70-96ce-07ca92325f44	1	core
e7905a47-3667-41d0-bb41-e86721b94c91	DIR	Director	26304df3-d564-4d70-96ce-07ca92325f44	1	core
cf3189a0-487b-45fd-8bc9-5e979e23adfc	CONS	Consultant	26304df3-d564-4d70-96ce-07ca92325f44	1	core
f192e8eb-d83f-42cf-9f03-769f116ed0c5	SALES	Sales / BD	26304df3-d564-4d70-96ce-07ca92325f44	1	core
2ee1a685-2524-48d6-882b-0599d6b906c5	SDE	Software Engineer	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	1	core
41f3c9ac-52e8-4691-adc2-25a352234cba	PM	Product Manager	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	1	core
03fde954-a180-404d-8401-ad0e28d31969	DA	Data Analyst	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	1	core
50798208-11c3-4a91-bf97-c4931bc3fe17	TL	Team Lead	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	1	core
4f0bdaa8-00c6-409b-9fdd-1cdef2165e46	DIR	Director	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	1	core
cc8f67bb-86c1-4fd7-86d9-84c1a0240d94	CONS	Consultant	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	1	core
cd1ef3e3-b579-4056-8359-3238d822647c	SALES	Sales / BD	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	1	core
73ff9f51-dfb5-43ac-a1d0-d6ef6d92ba98	SDE	Software Engineer	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	1	core
44b1df55-83dd-4b2d-9fe5-1aab268773d8	PM	Product Manager	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	1	core
e6858439-64b1-4e84-b87a-4b710099472a	DA	Data Analyst	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	1	core
bd8a2e30-05df-416a-b164-4f17cbbd26df	TL	Team Lead	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	1	core
7c06b86c-6d0e-44ae-b96c-366beb6eaa3f	DIR	Director	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	1	core
c4f09c0b-fbd6-44e7-bf19-cc28b9db7d21	CONS	Consultant	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	1	core
e5c4922b-3f0b-4dcf-b034-9878368700fb	SALES	Sales / BD	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	1	core
d9f3a744-e376-46c4-8b9a-b552bb88e201	SDE	Software Engineer	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	1	core
605ad0ea-dfb3-45bd-b7ea-d80182b6fec4	PM	Product Manager	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	1	core
6e956a32-77ea-423f-89fa-564c5a31bd74	DA	Data Analyst	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	1	core
7a08d9c7-d277-4f08-8df3-8eb55b82ab87	TL	Team Lead	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	1	core
219594ed-e745-4c18-8bc7-e0a31f34c36a	DIR	Director	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	1	core
d1b2b200-7e81-4e3c-93c0-446df25213e7	CONS	Consultant	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	1	core
28d388d7-26cc-4125-b3c8-78144b8ea522	SALES	Sales / BD	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	1	core
fa07675f-8a44-4e4c-9fca-116d55e3c053	SDE	Software Engineer	ac3a9ffa-e911-4250-80ee-245231946a8d	1	core
dea22c66-6f25-4f53-b07d-c25d3127612a	PM	Product Manager	ac3a9ffa-e911-4250-80ee-245231946a8d	1	core
2084bf40-ff99-46a1-a926-f47273eaa9f4	DA	Data Analyst	ac3a9ffa-e911-4250-80ee-245231946a8d	1	core
5ef45af7-e211-4e62-975c-f2a624747be6	TL	Team Lead	ac3a9ffa-e911-4250-80ee-245231946a8d	1	core
1ba08e51-3692-4f57-9522-7f1733a87eaa	DIR	Director	ac3a9ffa-e911-4250-80ee-245231946a8d	1	core
0fcdf548-656c-473a-bc10-ffb5dd618726	CONS	Consultant	ac3a9ffa-e911-4250-80ee-245231946a8d	1	core
a1c18707-16a0-4796-b24e-91037cdb57cc	SALES	Sales / BD	ac3a9ffa-e911-4250-80ee-245231946a8d	1	core
8d256f7e-f60e-461f-8a1d-03b6aa8ea277	SDE	Software Engineer	bde3a934-5e03-46af-ba36-9bb1a46954f7	1	core
51c4c6ab-d174-413c-ac5b-9108b8b4bf47	PM	Product Manager	bde3a934-5e03-46af-ba36-9bb1a46954f7	1	core
27898454-8e7b-4cde-b18e-cf708486985a	DA	Data Analyst	bde3a934-5e03-46af-ba36-9bb1a46954f7	1	core
8fc7fef5-16f5-4d09-a93d-8b393f81ba2f	TL	Team Lead	bde3a934-5e03-46af-ba36-9bb1a46954f7	1	core
42ac4690-f0c2-4831-b64d-89ba833e3265	DIR	Director	bde3a934-5e03-46af-ba36-9bb1a46954f7	1	core
55a694b6-7cbd-4969-b2b0-c41f3d7e7286	CONS	Consultant	bde3a934-5e03-46af-ba36-9bb1a46954f7	1	core
49fa8b0b-1cda-4987-ba7e-8948a20e04ac	SALES	Sales / BD	bde3a934-5e03-46af-ba36-9bb1a46954f7	1	core
c8ac72ac-f07c-42db-a0b2-610dd00d8c89	SDE	Software Engineer	6386f4be-6929-4430-b13d-2b80ac8a0bdb	1	core
3d077a0f-618c-4f2d-a428-1de436aec856	PM	Product Manager	6386f4be-6929-4430-b13d-2b80ac8a0bdb	1	core
c54b3faf-2662-45d2-9737-cbafd378b624	DA	Data Analyst	6386f4be-6929-4430-b13d-2b80ac8a0bdb	1	core
d130cdcb-2bbe-476a-ab81-3aa1f7bbc7c3	TL	Team Lead	6386f4be-6929-4430-b13d-2b80ac8a0bdb	1	core
fb8af976-a063-42a4-ac54-659ad47f5ca1	DIR	Director	6386f4be-6929-4430-b13d-2b80ac8a0bdb	1	core
20c93743-85a7-4bac-bf71-e5fd990d120c	CONS	Consultant	6386f4be-6929-4430-b13d-2b80ac8a0bdb	1	core
0e547504-25ac-4c6e-9e94-e680156d2507	SALES	Sales / BD	6386f4be-6929-4430-b13d-2b80ac8a0bdb	1	core
829b4045-866f-4690-be89-10383f277bee	SDE	Software Engineer	f7842945-608d-412c-b26a-fc8fa2d405e8	1	core
3ed878f2-ccce-4cc7-9948-358582da5a50	PM	Product Manager	f7842945-608d-412c-b26a-fc8fa2d405e8	1	core
f64b3a49-3548-46ed-b5b6-87deec886b05	DA	Data Analyst	f7842945-608d-412c-b26a-fc8fa2d405e8	1	core
3e2582d5-1dad-4765-b82b-c35d285fa856	TL	Team Lead	f7842945-608d-412c-b26a-fc8fa2d405e8	1	core
83374c66-7f17-4e94-903d-1c7a85a187e7	DIR	Director	f7842945-608d-412c-b26a-fc8fa2d405e8	1	core
2b67e77c-77fa-4390-9f28-77d95697e2ed	CONS	Consultant	f7842945-608d-412c-b26a-fc8fa2d405e8	1	core
ffe87dde-b50b-4ca0-969e-5f0e04c278f8	SALES	Sales / BD	f7842945-608d-412c-b26a-fc8fa2d405e8	1	core
9461f582-7a74-4e8c-93f5-75a58c9c8bbd	SDE	Software Engineer	2426d7dd-df6b-4654-ae51-376b0d3247e3	1	core
fe4f414a-1fee-4319-933e-98ddc9af468d	PM	Product Manager	2426d7dd-df6b-4654-ae51-376b0d3247e3	1	core
2fccd2aa-c849-450a-ab25-5116adc3bf3f	DA	Data Analyst	2426d7dd-df6b-4654-ae51-376b0d3247e3	1	core
e4476bac-3646-416f-a5b5-7b8f3d45f5ed	TL	Team Lead	2426d7dd-df6b-4654-ae51-376b0d3247e3	1	core
e5998ee4-5a14-459a-acdb-553e9f0691c2	DIR	Director	2426d7dd-df6b-4654-ae51-376b0d3247e3	1	core
1dac496a-da56-411e-b441-42fa9c877592	CONS	Consultant	2426d7dd-df6b-4654-ae51-376b0d3247e3	1	core
3b7ee51b-326f-43db-ae98-9a7c31d2b299	SALES	Sales / BD	2426d7dd-df6b-4654-ae51-376b0d3247e3	1	core
a46e1832-1de2-424c-beea-d7066b8a2cb9	SDE	Software Engineer	103d92e2-1d5e-4283-8a91-718a59743655	1	core
58e84a7a-90ac-48dc-8e3a-7b219e5e7297	PM	Product Manager	103d92e2-1d5e-4283-8a91-718a59743655	1	core
33524d3a-1431-4671-9b7d-3eff13c329c3	DA	Data Analyst	103d92e2-1d5e-4283-8a91-718a59743655	1	core
06e44dbb-83a5-49cc-9b8b-44bde171077f	TL	Team Lead	103d92e2-1d5e-4283-8a91-718a59743655	1	core
dc2e3dfb-ef8f-4579-bdb6-df3e0a302e63	DIR	Director	103d92e2-1d5e-4283-8a91-718a59743655	1	core
4b5b0abe-2345-4872-9ceb-03396f7703fe	CONS	Consultant	103d92e2-1d5e-4283-8a91-718a59743655	1	core
8495f31c-96da-4d2d-9c76-10b8d5b98d09	SALES	Sales / BD	103d92e2-1d5e-4283-8a91-718a59743655	1	core
7bd23cb6-6659-43f4-a9d9-52945db2c65f	SDE	Software Engineer	0bd37ca4-92b9-4931-86ff-859be789dd67	1	core
84b97f60-3f23-4dbf-a213-d6ba46a4741d	PM	Product Manager	0bd37ca4-92b9-4931-86ff-859be789dd67	1	core
a117304b-4a6e-4036-a976-0a762463000c	DA	Data Analyst	0bd37ca4-92b9-4931-86ff-859be789dd67	1	core
89ea67ae-8dab-4f79-ab66-fffc6bc74c29	TL	Team Lead	0bd37ca4-92b9-4931-86ff-859be789dd67	1	core
982194dd-44e2-4a54-9d47-2568825b351e	DIR	Director	0bd37ca4-92b9-4931-86ff-859be789dd67	1	core
233a54ae-0746-42fc-a502-e808ff19a00a	CONS	Consultant	0bd37ca4-92b9-4931-86ff-859be789dd67	1	core
0d6a9226-dac9-4a81-b08b-2afc61159dc7	SALES	Sales / BD	0bd37ca4-92b9-4931-86ff-859be789dd67	1	core
c4a507e3-df66-4454-acb7-3c4d24e315ee	SDE	Software Engineer	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	1	core
4ad2e9e6-8596-472c-ad55-e937a6527b53	PM	Product Manager	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	1	core
aeb977b4-fd67-4c17-961c-f855347621b0	DA	Data Analyst	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	1	core
30c4af57-a1bf-4a8e-805c-463c9089f8c0	TL	Team Lead	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	1	core
ede4b814-c67d-4438-a19f-37e8c07143af	DIR	Director	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	1	core
9a862d1d-e4df-45cf-9606-fe2b73654690	CONS	Consultant	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	1	core
58e25fe3-8b02-4b5e-946b-959044b00735	SALES	Sales / BD	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	1	core
182a8433-6f93-44d3-a828-2ea468a276bb	SDE	Software Engineer	abfe5de5-353d-4565-ae4b-a36db9884441	1	core
6c9ba2fc-f036-46f0-bd1d-df323bc38af3	PM	Product Manager	abfe5de5-353d-4565-ae4b-a36db9884441	1	core
d62ea289-78ae-404c-8afc-83700824a37b	DA	Data Analyst	abfe5de5-353d-4565-ae4b-a36db9884441	1	core
02491df8-7756-4e9f-bf36-72b5d18a64cc	TL	Team Lead	abfe5de5-353d-4565-ae4b-a36db9884441	1	core
1c465145-0307-4715-868d-57e2703ac67b	DIR	Director	abfe5de5-353d-4565-ae4b-a36db9884441	1	core
c1ce0b60-a752-4dda-b250-f6d875c47b48	CONS	Consultant	abfe5de5-353d-4565-ae4b-a36db9884441	1	core
7b2d3d2a-cf9f-4964-bb99-24dd8160d709	SALES	Sales / BD	abfe5de5-353d-4565-ae4b-a36db9884441	1	core
4d33486e-9079-47da-b2d4-182f7f1a805b	SDE	Software Engineer	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	1	core
aa70ac35-3d0c-4956-96b9-03a722faed69	PM	Product Manager	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	1	core
4d2d4038-2b2f-4e5e-89f8-c8d50e7bd52d	DA	Data Analyst	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	1	core
1bd8a0b2-a25e-4acd-b4a5-68e149786dd0	TL	Team Lead	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	1	core
685f832f-0ada-4144-b78c-7fbf3c87970c	DIR	Director	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	1	core
d92bc3e0-5af3-4e64-8fcc-3d93689b7120	CONS	Consultant	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	1	core
8e573c05-fd5d-44df-ab6a-b128b55ad0c0	SALES	Sales / BD	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	1	core
829b3652-46b2-4bed-a091-1834d4790ae6	SDE	Software Engineer	86516083-311e-4cc4-9c2d-8da1035c1226	1	core
29393266-e39e-4403-a8d8-6fc8816e589f	PM	Product Manager	86516083-311e-4cc4-9c2d-8da1035c1226	1	core
9e32f4ad-20a2-4d7d-b7f6-040becbb0d2f	DA	Data Analyst	86516083-311e-4cc4-9c2d-8da1035c1226	1	core
1afea58a-32b9-40dc-8d00-da4633e622d3	TL	Team Lead	86516083-311e-4cc4-9c2d-8da1035c1226	1	core
529ee43f-5cd6-4c9d-b26f-1acacf7fabe9	DIR	Director	86516083-311e-4cc4-9c2d-8da1035c1226	1	core
c764bccf-0d17-4fd4-b7aa-5bb62f30149e	CONS	Consultant	86516083-311e-4cc4-9c2d-8da1035c1226	1	core
18c01dc0-b2c9-4dbb-a32c-691ed70cc19a	SALES	Sales / BD	86516083-311e-4cc4-9c2d-8da1035c1226	1	core
659635a1-9370-4d26-8557-8b3a35600c8a	SDE	Software Engineer	9e2595a9-eec4-44fe-9911-3605e2a6c27e	1	core
88aaa9f9-0dd8-41a4-ae31-d22837514d1f	PM	Product Manager	9e2595a9-eec4-44fe-9911-3605e2a6c27e	1	core
54a1f60e-19ff-4c22-b657-0a1238d808a1	DA	Data Analyst	9e2595a9-eec4-44fe-9911-3605e2a6c27e	1	core
efe4e1c5-2a0d-43b0-8cd0-b446ba75a110	TL	Team Lead	9e2595a9-eec4-44fe-9911-3605e2a6c27e	1	core
5cb45683-81ab-49b4-baec-6e6df91f519e	DIR	Director	9e2595a9-eec4-44fe-9911-3605e2a6c27e	1	core
88d525c6-8095-49fe-ba62-9b9e22dbb1c6	CONS	Consultant	9e2595a9-eec4-44fe-9911-3605e2a6c27e	1	core
3c776fe2-eb4d-4e49-8462-3e0e7debfd4a	SALES	Sales / BD	9e2595a9-eec4-44fe-9911-3605e2a6c27e	1	core
90a76553-54e8-4ccf-b99c-0ae287ffa161	SDE	Software Engineer	c77e5916-e12c-4142-9386-1cd156481617	1	core
a94657a0-0d5e-4a04-a4b5-5d1dda8a4165	PM	Product Manager	c77e5916-e12c-4142-9386-1cd156481617	1	core
e94c7934-7ba0-4c56-ba0d-a0f69b4b713b	DA	Data Analyst	c77e5916-e12c-4142-9386-1cd156481617	1	core
623b638b-4d81-4534-9da6-0fb7da759131	TL	Team Lead	c77e5916-e12c-4142-9386-1cd156481617	1	core
91634f42-4b49-466b-a3f9-3adf3d88c01c	DIR	Director	c77e5916-e12c-4142-9386-1cd156481617	1	core
15a0a7e9-6212-4701-802d-3e3ae201a959	CONS	Consultant	c77e5916-e12c-4142-9386-1cd156481617	1	core
8a021dc0-29be-4aac-ac57-e9c354d185a6	SALES	Sales / BD	c77e5916-e12c-4142-9386-1cd156481617	1	core
e4aab2f6-f74e-4208-914f-b3d8f128c9f5	SDE	Software Engineer	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	1	core
27d1559f-c378-4bac-b842-ad534926314f	PM	Product Manager	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	1	core
f6ec2739-632f-481e-8cc6-05bbcd2b2cf8	DA	Data Analyst	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	1	core
29d1e62e-f8e2-4c60-b9bc-2f05211f86fc	TL	Team Lead	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	1	core
fe4eae55-c515-4676-b8c0-0ddda488ebd9	DIR	Director	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	1	core
0981ed3c-5e2d-46b0-9b7a-64a072742ebf	CONS	Consultant	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	1	core
215fe4fe-7e8f-4114-abed-b25269364fdb	SALES	Sales / BD	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	1	core
588a5bb5-9d86-4fc8-9722-cd5fb247aa2a	SDE	Software Engineer	945a4bbe-c5b6-4f55-a770-7d07b88a987e	1	core
fabcab03-34a9-4834-bba6-2b44b22b3732	PM	Product Manager	945a4bbe-c5b6-4f55-a770-7d07b88a987e	1	core
c3f48b30-440b-441a-ba89-70fa63bfa2b7	DA	Data Analyst	945a4bbe-c5b6-4f55-a770-7d07b88a987e	1	core
1bebf007-3403-4646-8977-e98220407c22	TL	Team Lead	945a4bbe-c5b6-4f55-a770-7d07b88a987e	1	core
0ea77bcb-a9ba-4a36-8c40-266ab394f073	DIR	Director	945a4bbe-c5b6-4f55-a770-7d07b88a987e	1	core
0681c0e7-33c0-4ac5-a332-4cb1dd30ab2d	CONS	Consultant	945a4bbe-c5b6-4f55-a770-7d07b88a987e	1	core
65c1ae2c-d0a1-4d21-a802-52c60415d01b	SALES	Sales / BD	945a4bbe-c5b6-4f55-a770-7d07b88a987e	1	core
a6bc59c2-9328-4b0d-870b-188d11b159d6	SDE	Software Engineer	1df38045-50e0-449b-926a-8d988ff372a5	1	core
851c33bc-3048-4d7f-8b1b-42c3e9bee3dd	PM	Product Manager	1df38045-50e0-449b-926a-8d988ff372a5	1	core
c05ec689-9521-4e39-b532-059e6dd656c4	DA	Data Analyst	1df38045-50e0-449b-926a-8d988ff372a5	1	core
3a211c1c-3486-4041-9225-c869cccf9d4c	TL	Team Lead	1df38045-50e0-449b-926a-8d988ff372a5	1	core
bdc72dd1-f4f7-46d4-944d-bf1a761ecc8e	DIR	Director	1df38045-50e0-449b-926a-8d988ff372a5	1	core
02a67101-a8e3-434b-a06d-a9b1fce88680	CONS	Consultant	1df38045-50e0-449b-926a-8d988ff372a5	1	core
adb791bb-6ffc-4db5-baf5-df79785dfd7d	SALES	Sales / BD	1df38045-50e0-449b-926a-8d988ff372a5	1	core
139a266d-dc6b-4d9b-9cc9-8e960701af91	SDE	Software Engineer	4684e00c-aab3-4e8b-a0d5-818084769a96	1	core
b460e303-9219-4566-956e-ccc96d659219	PM	Product Manager	4684e00c-aab3-4e8b-a0d5-818084769a96	1	core
fbad18b1-1961-4fd0-bd80-049833225dbb	DA	Data Analyst	4684e00c-aab3-4e8b-a0d5-818084769a96	1	core
153fb87f-f99a-4d3e-9aa1-44fefc542bde	TL	Team Lead	4684e00c-aab3-4e8b-a0d5-818084769a96	1	core
4f3ae93c-7301-48a7-b4ab-fbcc94e4f9b2	DIR	Director	4684e00c-aab3-4e8b-a0d5-818084769a96	1	core
ba8a4409-3614-44b6-b80e-49233ef3ac43	CONS	Consultant	4684e00c-aab3-4e8b-a0d5-818084769a96	1	core
0bfc41ff-151b-49b6-829c-676ef0eccded	SALES	Sales / BD	4684e00c-aab3-4e8b-a0d5-818084769a96	1	core
a7624166-77a3-4b46-b95e-38f7659eba04	SDE	Software Engineer	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	1	core
df4fde33-a826-480c-864f-c537648fcb39	PM	Product Manager	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	1	core
69b9c410-8c16-433f-8b75-07a2e2e70daa	DA	Data Analyst	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	1	core
08699751-134a-4dbc-8248-403edc57de24	TL	Team Lead	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	1	core
b5c44ded-5d8a-4387-89fa-e5fc1f543f6c	DIR	Director	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	1	core
a51a406a-4c63-46cf-a7ac-421827d5b417	CONS	Consultant	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	1	core
bf81aeaf-315a-4573-8dc5-78ffdec58580	SALES	Sales / BD	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	1	core
c7198e59-d20d-4ca8-831a-d4e208e47fd0	SDE	Software Engineer	72184930-fe7a-419a-8c8d-45b20a0715bb	1	core
92a3c6b2-2a2d-449a-a136-7d1922bc638d	PM	Product Manager	72184930-fe7a-419a-8c8d-45b20a0715bb	1	core
9e6ca4ed-0f50-4894-aa45-39ee76dc365e	DA	Data Analyst	72184930-fe7a-419a-8c8d-45b20a0715bb	1	core
518cd227-1b9a-412b-9474-0ec4693b5ce3	TL	Team Lead	72184930-fe7a-419a-8c8d-45b20a0715bb	1	core
1669eef1-ff75-4bd1-87a7-6abcc919c57c	DIR	Director	72184930-fe7a-419a-8c8d-45b20a0715bb	1	core
97b9efdc-cd46-4316-b89c-78916e5561ff	CONS	Consultant	72184930-fe7a-419a-8c8d-45b20a0715bb	1	core
718ba0a0-f98c-48d5-b0e5-deb2550d1e32	SALES	Sales / BD	72184930-fe7a-419a-8c8d-45b20a0715bb	1	core
e91325ab-1328-454f-9118-e78b9d4c8bb8	SDE	Software Engineer	7a391dd0-2e40-4536-a7b3-5521a0d6e197	1	core
4e519f86-3329-4615-b73f-2f6fd1df2d8c	PM	Product Manager	7a391dd0-2e40-4536-a7b3-5521a0d6e197	1	core
5611c848-985e-4371-808c-94552d4b2605	DA	Data Analyst	7a391dd0-2e40-4536-a7b3-5521a0d6e197	1	core
83dee8d3-06d5-48c6-9de9-ce5ede7c1bd6	TL	Team Lead	7a391dd0-2e40-4536-a7b3-5521a0d6e197	1	core
bb3e5ae6-64bb-464f-960f-5badedddc099	DIR	Director	7a391dd0-2e40-4536-a7b3-5521a0d6e197	1	core
8ce30845-19f6-4c6b-a269-fc9e46c28713	CONS	Consultant	7a391dd0-2e40-4536-a7b3-5521a0d6e197	1	core
72cd16f2-16f4-41cb-bc94-a91e70be4c61	SALES	Sales / BD	7a391dd0-2e40-4536-a7b3-5521a0d6e197	1	core
58eaf53d-122e-46d6-9338-f972001887fc	SDE	Software Engineer	e2682ae1-28b5-40de-a4c0-dfc0f788b086	1	core
08c5a0c1-caa6-4992-ae3a-373d8f02e2ed	PM	Product Manager	e2682ae1-28b5-40de-a4c0-dfc0f788b086	1	core
7f2c96bf-b66d-42e8-9da4-e71eb33125d5	DA	Data Analyst	e2682ae1-28b5-40de-a4c0-dfc0f788b086	1	core
4e2272c5-5c1e-4a0a-b074-3389b26dafa7	TL	Team Lead	e2682ae1-28b5-40de-a4c0-dfc0f788b086	1	core
a04079ee-a0a6-4170-a50d-1df9eae18dce	DIR	Director	e2682ae1-28b5-40de-a4c0-dfc0f788b086	1	core
1cfca584-4c49-4cb5-8f54-a1da9d6f1000	CONS	Consultant	e2682ae1-28b5-40de-a4c0-dfc0f788b086	1	core
f58240fd-f3ed-4ac5-a68b-84dcfb9a9599	SALES	Sales / BD	e2682ae1-28b5-40de-a4c0-dfc0f788b086	1	core
0c9998f4-1161-4d66-94e2-341a5df49d6a	SDE	Software Engineer	441de88e-ef98-42e8-b681-1a95b08721d6	1	core
b25745f6-cfb7-42f0-92fc-3abfe08d2e33	PM	Product Manager	441de88e-ef98-42e8-b681-1a95b08721d6	1	core
8cf98ed1-5c37-4a08-a3b9-e711927ae284	DA	Data Analyst	441de88e-ef98-42e8-b681-1a95b08721d6	1	core
58db7623-ee19-438c-a966-7bfd4f4e2b44	TL	Team Lead	441de88e-ef98-42e8-b681-1a95b08721d6	1	core
8020fd9b-55fe-480f-b946-e19ae71d37eb	DIR	Director	441de88e-ef98-42e8-b681-1a95b08721d6	1	core
63039c2c-ce5b-4a8e-af94-c36e48ded384	CONS	Consultant	441de88e-ef98-42e8-b681-1a95b08721d6	1	core
63ac9ed6-bd67-4e01-8fcb-b0f90f572ad9	SALES	Sales / BD	441de88e-ef98-42e8-b681-1a95b08721d6	1	core
1cae9ebe-d1bb-4498-be87-09f066653087	SDE	Software Engineer	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	1	core
159f7828-aebe-4ae3-8f52-fdd7821f42d1	PM	Product Manager	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	1	core
ea843b9a-a619-4fce-93a9-a8ae0c41a2e2	DA	Data Analyst	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	1	core
f4669fd1-4df8-4fd4-b474-232016030ef9	TL	Team Lead	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	1	core
f14a1c59-68ff-486f-b046-1dcd82f9c626	DIR	Director	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	1	core
e6201764-ed8b-42cf-88a1-fae441d09ca4	CONS	Consultant	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	1	core
24a25d53-afba-4ff4-8694-9bbb57b8a51c	SALES	Sales / BD	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	1	core
6484f503-376e-448c-b96b-1e2cde60da40	SDE	Software Engineer	5ec547f1-09bf-4844-bfbe-90f5a6c34490	1	core
cf8feb74-e65b-4fec-b729-3893f65cecb6	PM	Product Manager	5ec547f1-09bf-4844-bfbe-90f5a6c34490	1	core
5d7243f9-8442-44e7-a80b-92fd928422d8	DA	Data Analyst	5ec547f1-09bf-4844-bfbe-90f5a6c34490	1	core
2dbd3571-d7ad-45d8-8c5e-4e3fddbd0ed2	TL	Team Lead	5ec547f1-09bf-4844-bfbe-90f5a6c34490	1	core
9328f622-194f-43bb-aa29-00f73de4807f	DIR	Director	5ec547f1-09bf-4844-bfbe-90f5a6c34490	1	core
206198a5-eaa9-41c5-850a-03fc22cb1bba	CONS	Consultant	5ec547f1-09bf-4844-bfbe-90f5a6c34490	1	core
275d9649-28f9-416f-8457-f79c91f01c4d	SALES	Sales / BD	5ec547f1-09bf-4844-bfbe-90f5a6c34490	1	core
788a8d68-a34b-4837-ba8a-f6ac63015638	SDE	Software Engineer	04f45cea-6096-4aad-99c2-fc4952b1f15a	1	core
4bb0f664-d03b-4a9d-a6e8-0044a522d1be	PM	Product Manager	04f45cea-6096-4aad-99c2-fc4952b1f15a	1	core
abbb1368-d7a0-4ed3-bf39-b61b134cc5fd	DA	Data Analyst	04f45cea-6096-4aad-99c2-fc4952b1f15a	1	core
56136d7f-43ac-443b-a47d-649fd4c46f65	TL	Team Lead	04f45cea-6096-4aad-99c2-fc4952b1f15a	1	core
b6ee7a22-3005-4e0d-8d4a-f4ae221eaa3a	DIR	Director	04f45cea-6096-4aad-99c2-fc4952b1f15a	1	core
b0f1938f-dc0f-4794-a7e7-337dfa810619	CONS	Consultant	04f45cea-6096-4aad-99c2-fc4952b1f15a	1	core
0c1b2452-cc0d-44f4-99b0-39ce003cd331	SALES	Sales / BD	04f45cea-6096-4aad-99c2-fc4952b1f15a	1	core
dc188b3b-65bb-49b9-bbc6-e224cabb9481	SDE	Software Engineer	f174dfe6-fa3e-45f2-bad6-f8a098259389	1	core
4682492a-f961-4ef8-824e-67f06dd2f2b4	PM	Product Manager	f174dfe6-fa3e-45f2-bad6-f8a098259389	1	core
0fff47e2-1853-438a-b3db-02aacfb256ab	DA	Data Analyst	f174dfe6-fa3e-45f2-bad6-f8a098259389	1	core
d222d822-eb7f-4a85-9814-acd02ad65ecc	TL	Team Lead	f174dfe6-fa3e-45f2-bad6-f8a098259389	1	core
193ce71f-ca15-461a-8149-16841eb06028	DIR	Director	f174dfe6-fa3e-45f2-bad6-f8a098259389	1	core
da3874c5-0961-4d88-9147-d07b8f3e66d4	CONS	Consultant	f174dfe6-fa3e-45f2-bad6-f8a098259389	1	core
bc8e9359-97bd-434e-8d2f-1c82a47f8675	SALES	Sales / BD	f174dfe6-fa3e-45f2-bad6-f8a098259389	1	core
827db41d-caf4-475e-a01b-e0684545c5a9	SDE	Software Engineer	500f3c7a-6fc8-403b-bb3e-7c09477c8942	1	core
34957113-0a0e-4b25-9500-dbdbe3836d32	PM	Product Manager	500f3c7a-6fc8-403b-bb3e-7c09477c8942	1	core
adaf7853-bacd-455e-8348-565ecb98559f	DA	Data Analyst	500f3c7a-6fc8-403b-bb3e-7c09477c8942	1	core
eb0cf484-ca97-4efa-8c09-2f2bab1211a8	TL	Team Lead	500f3c7a-6fc8-403b-bb3e-7c09477c8942	1	core
9b3241b3-93e9-42db-8621-711d294e93ec	DIR	Director	500f3c7a-6fc8-403b-bb3e-7c09477c8942	1	core
c9374e86-16b7-43af-84c8-23806ff3f8e5	CONS	Consultant	500f3c7a-6fc8-403b-bb3e-7c09477c8942	1	core
2522a578-e0eb-4cb8-bc24-5f04ce567978	SALES	Sales / BD	500f3c7a-6fc8-403b-bb3e-7c09477c8942	1	core
db8bd246-5dad-4492-b51f-296c64e23f07	SDE	Software Engineer	fbbbd2de-2901-44f3-95ac-3ae03815cf86	1	core
7640e122-c920-4a94-853e-aadb06f12eeb	PM	Product Manager	fbbbd2de-2901-44f3-95ac-3ae03815cf86	1	core
70eb80ae-b7bf-4a76-8cf5-8ec4ad21b7b4	DA	Data Analyst	fbbbd2de-2901-44f3-95ac-3ae03815cf86	1	core
a17b990d-9f02-40f0-b5f2-2447d976b2a6	TL	Team Lead	fbbbd2de-2901-44f3-95ac-3ae03815cf86	1	core
47fe0d10-024c-4c5b-a68f-34e648c74ba0	DIR	Director	fbbbd2de-2901-44f3-95ac-3ae03815cf86	1	core
33fe59e3-d700-4b23-a1e4-2f729b4e70e5	CONS	Consultant	fbbbd2de-2901-44f3-95ac-3ae03815cf86	1	core
decb8340-befd-4764-aa1a-3d39aa2989c5	SALES	Sales / BD	fbbbd2de-2901-44f3-95ac-3ae03815cf86	1	core
e46d7406-5d0e-4637-9723-98407ab35743	SDE	Software Engineer	e5339884-e709-492b-951c-3ebcc488888a	1	core
d989132a-89ef-41e4-baef-3525101832e3	PM	Product Manager	e5339884-e709-492b-951c-3ebcc488888a	1	core
7c7e5bb9-b884-47b3-a2ba-88b2b2b9d8e8	DA	Data Analyst	e5339884-e709-492b-951c-3ebcc488888a	1	core
34980f56-fffa-40f6-90cd-e6c2c0bda93d	TL	Team Lead	e5339884-e709-492b-951c-3ebcc488888a	1	core
ac0125dd-5a90-47d7-9230-8322d3c79a88	DIR	Director	e5339884-e709-492b-951c-3ebcc488888a	1	core
f5f348a3-63f0-43e8-a156-b5c930b2e1e8	CONS	Consultant	e5339884-e709-492b-951c-3ebcc488888a	1	core
888a2fbe-3c1a-47f4-bad0-1b8855fa87b0	SALES	Sales / BD	e5339884-e709-492b-951c-3ebcc488888a	1	core
c85ec20c-2c75-4803-a634-025dd324033a	SDE	Software Engineer	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	1	core
7294d78f-7d6c-49a1-926c-fcbd5df05c5f	PM	Product Manager	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	1	core
825a0c0e-cf95-4188-b42d-ebd92eaa2cdd	DA	Data Analyst	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	1	core
adc95d52-cdaa-435e-8ce2-6c9d7c3babde	TL	Team Lead	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	1	core
5321f7ff-456c-49b9-870b-1004bab41a1f	DIR	Director	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	1	core
bb03f2a0-6871-4fea-8f22-bed812049f38	CONS	Consultant	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	1	core
0270ff24-7a08-42ee-9704-8adf0ebd61a7	SALES	Sales / BD	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	1	core
5e80c928-7583-4bc8-9d33-9a6a7643c3d8	SDE	Software Engineer	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	1	core
f341becd-5441-4073-9a97-059c72dd4fb6	PM	Product Manager	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	1	core
92bbbfeb-3559-4306-8307-4601582547d2	DA	Data Analyst	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	1	core
b481eaf7-9afa-462a-a7d6-cb28f20f2e29	TL	Team Lead	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	1	core
8251e6f8-4752-4490-a0ed-4e90edf959bd	DIR	Director	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	1	core
bcbbc434-9422-43cd-938b-8bf040634629	CONS	Consultant	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	1	core
1af9d4dc-199e-4327-8dcc-39f5c292bfcd	SALES	Sales / BD	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	1	core
0097e215-3227-4d5a-8530-4a9e5fd587cd	SDE	Software Engineer	7914ba09-3101-4895-bdf9-366e5f881724	1	core
dc9e3f83-0249-4046-ac0c-639fd54682e1	PM	Product Manager	7914ba09-3101-4895-bdf9-366e5f881724	1	core
63a98e2b-36c2-4c0d-8c99-1507dd2ec49c	DA	Data Analyst	7914ba09-3101-4895-bdf9-366e5f881724	1	core
c339d737-9db7-419c-bbce-22d69cf916e5	TL	Team Lead	7914ba09-3101-4895-bdf9-366e5f881724	1	core
9144e59d-9f06-4bfc-b88d-9ecb433eddb3	DIR	Director	7914ba09-3101-4895-bdf9-366e5f881724	1	core
becfdd19-6afc-46d1-9dfd-5f43d399f38f	CONS	Consultant	7914ba09-3101-4895-bdf9-366e5f881724	1	core
00aadf0b-8f6f-416c-9060-390bb9664602	SALES	Sales / BD	7914ba09-3101-4895-bdf9-366e5f881724	1	core
e9b8ebb0-5d0f-4e9f-ade8-3183b7194e49	SDE	Software Engineer	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	1	core
97287ec2-c951-46e4-bad2-7f7426d0271c	PM	Product Manager	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	1	core
573b1987-db60-49a2-b9e6-ba38445702ad	DA	Data Analyst	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	1	core
4aeb1376-08c7-4e44-b09c-04c5409d9c74	TL	Team Lead	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	1	core
c1b11a99-4a2c-4125-a39a-c446bc69b6bb	DIR	Director	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	1	core
1df89475-949e-4290-a183-408f8ac84699	CONS	Consultant	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	1	core
907130f6-e602-4bec-b217-2b0987e2a4fe	SALES	Sales / BD	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	1	core
1ebb4c47-a177-4267-9f84-fd0b27121dc3	SDE	Software Engineer	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	1	core
1c19896d-a2e4-4519-b6ca-93e9e1227260	PM	Product Manager	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	1	core
392a0efb-02a7-45ed-878e-865f3ca236a2	DA	Data Analyst	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	1	core
4dbeb3a6-f033-4f3d-9f51-f2de1235c627	TL	Team Lead	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	1	core
853afd4f-7601-4c76-bd52-6e0616173104	DIR	Director	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	1	core
b59eea67-fb9f-4cfa-acd1-c04b6ea4b71a	CONS	Consultant	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	1	core
f316257b-10f1-4167-999c-f7487fbe0711	SALES	Sales / BD	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	1	core
016add8f-6b51-4ccb-ac7d-6a55c87592d7	SDE	Software Engineer	40fac2ff-5ea4-438f-b891-2f900665b80b	1	core
5b4e0fc9-6228-48aa-a0fe-43fa4f30b35e	PM	Product Manager	40fac2ff-5ea4-438f-b891-2f900665b80b	1	core
f65149bd-7a9a-46b3-bcf7-87107f6524fe	DA	Data Analyst	40fac2ff-5ea4-438f-b891-2f900665b80b	1	core
cc1c836e-df0f-42b7-81af-b23ea706f00d	TL	Team Lead	40fac2ff-5ea4-438f-b891-2f900665b80b	1	core
f2515058-8ce1-4128-a971-6c904c28a9c1	DIR	Director	40fac2ff-5ea4-438f-b891-2f900665b80b	1	core
50c40f34-b41e-41a7-900d-400a4807ab56	CONS	Consultant	40fac2ff-5ea4-438f-b891-2f900665b80b	1	core
f1d808a3-41e3-45ed-95d3-eb5cb70ff938	SALES	Sales / BD	40fac2ff-5ea4-438f-b891-2f900665b80b	1	core
89fa7bef-020e-45ac-9333-74d75b982c6c	SDE	Software Engineer	684ea464-ff78-4c77-8cf8-8894c81fec58	1	core
53c1ee73-d6a3-48eb-8fba-6ddd7dbe6e8b	PM	Product Manager	684ea464-ff78-4c77-8cf8-8894c81fec58	1	core
b3566032-b52d-4ec5-bae8-f00675a8f45d	DA	Data Analyst	684ea464-ff78-4c77-8cf8-8894c81fec58	1	core
aa5a36e0-94b0-47cd-b6a8-94b41e61352b	TL	Team Lead	684ea464-ff78-4c77-8cf8-8894c81fec58	1	core
6bb572bb-1a94-4a29-ab55-4dbba127e1c6	DIR	Director	684ea464-ff78-4c77-8cf8-8894c81fec58	1	core
32f68371-a817-4443-8238-e3bf5f91fff1	CONS	Consultant	684ea464-ff78-4c77-8cf8-8894c81fec58	1	core
5ffbe4c3-727a-4c51-b4c4-51e8e72a0c47	SALES	Sales / BD	684ea464-ff78-4c77-8cf8-8894c81fec58	1	core
1a3bd96a-d62d-495c-85ea-feef3289d30b	SDE	Software Engineer	6a407735-42f8-4e8f-82a7-0a678f62d285	1	core
591b176f-813f-423d-afef-00310c1a2dc6	PM	Product Manager	6a407735-42f8-4e8f-82a7-0a678f62d285	1	core
29df5207-0f63-4e12-a420-2ec9dc50432b	DA	Data Analyst	6a407735-42f8-4e8f-82a7-0a678f62d285	1	core
7991dbc7-a84d-4925-8536-2e789e0e5946	TL	Team Lead	6a407735-42f8-4e8f-82a7-0a678f62d285	1	core
fb9117d6-2e7e-4196-a16e-e03bbf2a312b	DIR	Director	6a407735-42f8-4e8f-82a7-0a678f62d285	1	core
5d95acca-60c9-490b-8f61-53f3b3953d73	CONS	Consultant	6a407735-42f8-4e8f-82a7-0a678f62d285	1	core
925328e2-6c55-494e-a701-3c32337d2658	SALES	Sales / BD	6a407735-42f8-4e8f-82a7-0a678f62d285	1	core
71229e95-693a-494a-90d6-28e7042a52aa	SDE	Software Engineer	1323078d-84da-4b61-8ca3-2f4fa9bac09b	1	core
15475d47-d1cf-4cee-afc4-7bbb85814e70	PM	Product Manager	1323078d-84da-4b61-8ca3-2f4fa9bac09b	1	core
28904936-e305-4445-b1d8-ff38274fa110	DA	Data Analyst	1323078d-84da-4b61-8ca3-2f4fa9bac09b	1	core
fc3a4ce9-b291-4a01-8e2b-f6d19873530f	TL	Team Lead	1323078d-84da-4b61-8ca3-2f4fa9bac09b	1	core
a2dd480c-e267-4eb9-8b2b-c1d107142d67	DIR	Director	1323078d-84da-4b61-8ca3-2f4fa9bac09b	1	core
ee795512-22e3-4029-80bb-20a562e50e85	CONS	Consultant	1323078d-84da-4b61-8ca3-2f4fa9bac09b	1	core
f288d698-b7df-42f1-98fe-33117806f1ea	SALES	Sales / BD	1323078d-84da-4b61-8ca3-2f4fa9bac09b	1	core
0d33d6c8-cd51-4914-927b-67a3ff5dbbe8	SDE	Software Engineer	573862b8-a47a-494b-b93f-4b1fd5912f24	1	core
6e92247e-88e0-41c8-a599-ce45173a77a9	PM	Product Manager	573862b8-a47a-494b-b93f-4b1fd5912f24	1	core
02caac77-392c-409b-91f9-7b6aa8d15e09	DA	Data Analyst	573862b8-a47a-494b-b93f-4b1fd5912f24	1	core
98d04a2d-7e5f-4e55-80c9-a13e26b3f7a3	TL	Team Lead	573862b8-a47a-494b-b93f-4b1fd5912f24	1	core
3c74373a-848c-484e-83d9-98b1b4f77dfa	DIR	Director	573862b8-a47a-494b-b93f-4b1fd5912f24	1	core
3f8f4380-04f6-4c93-9474-9983dc435a50	CONS	Consultant	573862b8-a47a-494b-b93f-4b1fd5912f24	1	core
cfa872fd-404b-470e-8f6b-079504c7c6a8	SALES	Sales / BD	573862b8-a47a-494b-b93f-4b1fd5912f24	1	core
5642f39f-6c5f-406a-b1f7-f54074231fdd	SDE	Software Engineer	d56fbb88-b402-4c02-b8a3-7715e20093c0	1	core
f95b94b0-1ecb-438c-9a79-9d476531e9c3	PM	Product Manager	d56fbb88-b402-4c02-b8a3-7715e20093c0	1	core
5ccad549-7599-4585-ba25-cbab7b9c17fa	DA	Data Analyst	d56fbb88-b402-4c02-b8a3-7715e20093c0	1	core
1b0ca6e4-7130-4a8a-aa27-d512ab123bbe	TL	Team Lead	d56fbb88-b402-4c02-b8a3-7715e20093c0	1	core
1f7d8cc7-a7f5-4a89-bc84-3ba86b76f187	DIR	Director	d56fbb88-b402-4c02-b8a3-7715e20093c0	1	core
53fc1ce1-1a12-4af3-935e-e0ae6b54e798	CONS	Consultant	d56fbb88-b402-4c02-b8a3-7715e20093c0	1	core
942f03d1-c62e-4eeb-a60f-912c2b4be21c	SALES	Sales / BD	d56fbb88-b402-4c02-b8a3-7715e20093c0	1	core
4aa15683-5a6c-4257-857f-2f8466b3b848	SDE	Software Engineer	f735e34e-2752-4ba7-bb9e-8b5c38b57218	1	core
b76263fa-897f-41eb-bf5d-6cdc54442e5b	PM	Product Manager	f735e34e-2752-4ba7-bb9e-8b5c38b57218	1	core
da054514-3e1b-46e9-a77b-40250598a477	DA	Data Analyst	f735e34e-2752-4ba7-bb9e-8b5c38b57218	1	core
3bfd1e94-151a-4fbc-a29b-345c3e33caef	TL	Team Lead	f735e34e-2752-4ba7-bb9e-8b5c38b57218	1	core
4c1b545e-1473-42d8-90ad-b0e74013db60	DIR	Director	f735e34e-2752-4ba7-bb9e-8b5c38b57218	1	core
ac54d998-fb41-4caa-86df-fb7b4d039f1f	CONS	Consultant	f735e34e-2752-4ba7-bb9e-8b5c38b57218	1	core
144c053b-5331-4748-b339-d67314eb0ef0	SALES	Sales / BD	f735e34e-2752-4ba7-bb9e-8b5c38b57218	1	core
9fcbe1e0-0ee1-4bbb-a1a9-5c657c21ae9e	SDE	Software Engineer	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	1	core
32e4ba8d-9c95-442b-8da7-caf89441a7b7	PM	Product Manager	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	1	core
3e860ce7-02b0-4aa2-88ef-994471a9f9e9	DA	Data Analyst	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	1	core
0e6ab27d-7c0a-425a-b9fd-c11e62d825c6	TL	Team Lead	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	1	core
1c8c1728-c501-44b8-bf8c-17f4ef65e5c4	DIR	Director	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	1	core
36a81684-073c-4ebf-80f7-84d722e64061	CONS	Consultant	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	1	core
5f8a87d2-1950-4e4a-b25f-a3e913fd6aed	SALES	Sales / BD	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	1	core
73508da0-d630-45ee-a802-3ee15d0626cf	SDE	Software Engineer	ff0f818b-173d-43ef-a528-ef553787ca5f	1	core
605beb4f-3cb5-4fbc-ae60-f6a0ab116130	PM	Product Manager	ff0f818b-173d-43ef-a528-ef553787ca5f	1	core
e08ce83b-341a-4406-b0db-2e6c47e37b26	DA	Data Analyst	ff0f818b-173d-43ef-a528-ef553787ca5f	1	core
47e83487-af32-4f8f-8ff7-1afa4bfaeb52	TL	Team Lead	ff0f818b-173d-43ef-a528-ef553787ca5f	1	core
7386a777-0f69-4eac-bfa2-985d18de0e1a	DIR	Director	ff0f818b-173d-43ef-a528-ef553787ca5f	1	core
de2ab584-6199-4a6d-bb7d-d7750149fdf5	CONS	Consultant	ff0f818b-173d-43ef-a528-ef553787ca5f	1	core
9444c73f-9bb8-4cb3-9fda-25d44ec3e574	SALES	Sales / BD	ff0f818b-173d-43ef-a528-ef553787ca5f	1	core
aa465a25-00e8-48db-b166-6de66f69f7a8	SDE	Software Engineer	a8d775e5-2281-47fb-a984-9dfe240a1841	1	core
9059557a-5483-4d4e-98ae-05eb67267c5d	PM	Product Manager	a8d775e5-2281-47fb-a984-9dfe240a1841	1	core
efa86988-27fb-4714-af0a-6de5385c5a46	DA	Data Analyst	a8d775e5-2281-47fb-a984-9dfe240a1841	1	core
453922e6-b301-4dcf-92d0-ed04502313f7	TL	Team Lead	a8d775e5-2281-47fb-a984-9dfe240a1841	1	core
5a982ece-73c9-48c8-9bcf-7b50641efe33	DIR	Director	a8d775e5-2281-47fb-a984-9dfe240a1841	1	core
b5785879-ce8b-420d-aa95-b7db282c61ce	CONS	Consultant	a8d775e5-2281-47fb-a984-9dfe240a1841	1	core
d362146a-589e-4f4b-b4d0-cac4904f4650	SALES	Sales / BD	a8d775e5-2281-47fb-a984-9dfe240a1841	1	core
769622d3-179c-4aa8-b273-6157dbfdc644	SDE	Software Engineer	8c949a6a-a93c-4923-99ef-967276e60d8d	1	core
8945c6cc-639d-4944-8b09-b4bb6660b332	PM	Product Manager	8c949a6a-a93c-4923-99ef-967276e60d8d	1	core
5a9edad1-093c-42e5-a97f-d6df71279ac9	DA	Data Analyst	8c949a6a-a93c-4923-99ef-967276e60d8d	1	core
9245a819-1766-48c3-bf39-c562cd57daa0	TL	Team Lead	8c949a6a-a93c-4923-99ef-967276e60d8d	1	core
1dfd591c-cbb5-4e73-839d-d7addf6db19d	DIR	Director	8c949a6a-a93c-4923-99ef-967276e60d8d	1	core
b49aeb86-4217-4530-b2f0-d15bcb43ee49	CONS	Consultant	8c949a6a-a93c-4923-99ef-967276e60d8d	1	core
c11d919f-6bc7-41e4-baed-85086adc2341	SALES	Sales / BD	8c949a6a-a93c-4923-99ef-967276e60d8d	1	core
2b40d0ce-35b4-43ad-a9b3-a59ee49bd7a2	SDE	Software Engineer	5fd97c47-e245-4016-a348-5dd80f708a89	1	core
3c545ed0-ab1d-492f-bdfe-99468607e2a8	PM	Product Manager	5fd97c47-e245-4016-a348-5dd80f708a89	1	core
bb2ef1aa-fd2a-4d21-b6e6-6d2532a2b954	DA	Data Analyst	5fd97c47-e245-4016-a348-5dd80f708a89	1	core
80a47ae3-5f4c-416c-af4e-f39d0b39d5f2	TL	Team Lead	5fd97c47-e245-4016-a348-5dd80f708a89	1	core
f7cf9ff1-a0ad-4b79-83f5-cd2669dff751	DIR	Director	5fd97c47-e245-4016-a348-5dd80f708a89	1	core
d14bc9c5-25b4-48dc-b68c-8967660ad1e4	CONS	Consultant	5fd97c47-e245-4016-a348-5dd80f708a89	1	core
58a05fce-d001-4502-8ac7-6adbce9d0153	SALES	Sales / BD	5fd97c47-e245-4016-a348-5dd80f708a89	1	core
d41c46df-9053-4fb4-9512-8d516c8d8148	SDE	Software Engineer	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	1	core
05e59a5b-9e81-4320-972d-023ab7182ef7	PM	Product Manager	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	1	core
826c08f5-5827-4068-b9c7-0edc1e09b2be	DA	Data Analyst	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	1	core
61fbd275-a4cb-48bd-b3c3-9e21ce7fd04b	TL	Team Lead	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	1	core
90e108d6-a856-4933-b0d5-fd0169126b99	DIR	Director	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	1	core
266c8444-64b2-4598-a6b0-886bead22e70	CONS	Consultant	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	1	core
55e69779-cfe9-4b39-8e03-75ccd4176c39	SALES	Sales / BD	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	1	core
\.


--
-- Data for Name: role_definitions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_definitions (id, role_name, display_name, description, level, is_system, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions (id, role_id, permission_id, granted_by, granted_at) FROM stdin;
\.


--
-- Data for Name: scoring_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scoring_configs (id, name, value, updated_at) FROM stdin;
2a9c731f-3b3e-4b2f-b609-c756b7831e7b	normalisation_top_pct	90	2026-05-01 15:06:22.42418
4588d9b7-cbcf-4159-b20d-b3544fb01822	weighted_score_floor	0	2026-05-01 15:06:22.42418
e2474d98-62d7-4f02-9f94-62233e445a74	benchmark_top10_pct	10	2026-05-01 15:06:22.42418
fcb2c3be-5850-4821-bf4e-9b872c35ca8b	proficiency_pass_threshold	60	2026-05-01 15:06:22.42418
fa9185a4-5094-4b96-b017-1892d319cb32	idp_top_n_gaps	5	2026-05-01 15:06:22.42418
\.


--
-- Data for Name: sdi_cluster_map; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_cluster_map (cluster_id, subdomain_code) FROM stdin;
\.


--
-- Data for Name: sdi_clusters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_clusters (id, code, name, description, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: sdi_domains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_domains (id, domain_code, domain_name, description, icon_key, color, category, weightage, display_order, status, is_active, created_at, updated_at) FROM stdin;
1	ACF-01	Focus & Attention Assessment	Measures attention span, focus regulation, and cognitive concentration	Brain	#2563EB	Cognitive	1	1	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
2	APO-02	Academic Performance Assessment	Evaluates learning outcomes, marks, and academic consistency	GraduationCap	#0EA5E9	Academic	1	2	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
3	BSM-03	Behavior & Discipline Assessment	Assesses behavioral discipline and self-management	Shield	#10B981	Behavior	1	3	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
4	EIR-04	Emotional Intelligence Assessment	Measures emotional intelligence and internal regulation	Heart	#F472B6	Emotional	1	4	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
5	MHW-05	Mental Wellness Assessment	Evaluates mental health and psychological wellbeing	HeartHandshake	#8B5CF6	Mental Health	1	5	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
6	DUD-06	Digital Behavior Assessment	Assesses digital usage patterns and screen dependency	Smartphone	#06B6D4	Digital	1	6	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
7	SCI-07	Social Skills Assessment	Evaluates social skills, communication, and peer interaction	Users	#F59E0B	Social	1	7	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
8	HLD-08	Lifestyle & Habit Assessment	Measures daily habits, lifestyle, and personal discipline	Activity	#84CC16	Habits	1	8	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
9	CAD-09	Career Readiness Assessment	Assesses career awareness, direction, and decision-making	Compass	#14B8A6	Career	1	9	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
10	FED-10	Family Environment Assessment	Evaluates family environment and parent-child dynamics	Home	#EF4444	Family	1	10	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
11	LCR-11	Learning Ability Assessment	Measures learning ability, comprehension, and retention	BookOpen	#6366F1	Cognitive	1	11	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
12	CHT-12	Cognitive Skills Assessment	Assesses cognitive processing and higher-order thinking skills	Lightbulb	#A855F7	Cognitive	1	12	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
13	PAI-13	Parenting Effectiveness Assessment	Evaluates parenting approach, skills, and intervention quality	UserCheck	#EC4899	Family	1	13	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
14	EEI-14	School Environment Assessment	Measures educational environment and external influences	Building	#0891B2	School	1	14	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
15	PHB-15	Physical Health Assessment	Assesses physical health, energy, and biological factors	Dumbbell	#22C55E	Health	1	15	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
16	FRC-16	Future Skills Assessment	Evaluates future readiness, creativity, and curiosity skills	Sparkles	#F97316	Future	1	16	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
17	BES-17	Board Exam Readiness Assessment	Measures board exam performance and exam strategy management	ClipboardList	#DC2626	Academic	1	17	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
18	IAR-18	Academic Recovery Assessment	Assesses improvement strategy and academic recovery planning	TrendingUp	#059669	Academic	1	18	Active	t	2026-05-01 15:06:22.624976	2026-05-01 15:06:22.624976
\.


--
-- Data for Name: sdi_item_options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_item_options (id, item_id, option_text, score_value, display_order) FROM stdin;
\.


--
-- Data for Name: sdi_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_items (id, subdomain_code, item_code, item_type, difficulty, question, expected_time, scoring_type, language_code, is_active, display_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sdi_learning_mappings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_learning_mappings (id, subdomain_code, level, action_type, title, resource_link, created_at) FROM stdin;
\.


--
-- Data for Name: sdi_stage_weights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_stage_weights (id, stage_code, subdomain_code, weight, weight_type) FROM stdin;
65628e76-aa69-41b3-99bc-32431333460d	PRIMARY	ACF_S1	1	core
22444471-e0b5-4144-a9c8-686baa7bf5a6	PRIMARY	ACF_S2	1	core
5c189d24-0a3a-4e76-8f98-fecfafc5a7d0	PRIMARY	ACF_S3	1	core
b0627328-debe-4a50-9def-b5afcbc3e795	PRIMARY	APO_S1	1	core
9af75999-ee97-4448-a000-66450de0c84c	PRIMARY	APO_S2	1	core
92970dc7-bca9-4358-99ca-1d7d15b90309	PRIMARY	APO_S3	1	core
591cd923-8bc5-4e17-81c2-10a585a4d3cc	PRIMARY	BSM_S1	1	core
f00aaefa-8b99-4178-bf67-080e82880cc5	PRIMARY	BSM_S2	1	core
793c9c4b-1264-428f-be92-e23b632b6122	PRIMARY	BSM_S3	1	core
79e978cc-a7a0-4ea8-a2a2-ebf4b3e168e5	PRIMARY	EIR_S1	1	core
b7c211b2-8370-4a84-9494-1fe7947468d1	PRIMARY	EIR_S2	1	core
6ea6f3a8-7c2e-498f-817b-ba6432c2a348	PRIMARY	EIR_S3	1	core
bb1be8f2-9bb4-4a91-9e85-7a6fd5c2561f	PRIMARY	MHW_S1	1	core
98f4e305-eaaf-45e5-9be0-5d729df77ca5	PRIMARY	MHW_S2	1	core
e5fee4eb-3d21-41da-ac31-c24b1b629f7a	PRIMARY	MHW_S3	1	core
4c4884ea-7e34-4d68-b537-3d9b9f132e4a	PRIMARY	DUD_S1	1	core
cecb839f-b9eb-45c6-b6d1-a799a632037f	PRIMARY	DUD_S2	1	core
7857d84d-db8e-49bc-9ff7-df6c55749d5d	PRIMARY	DUD_S3	1	core
c76225d3-7954-4c36-a9c4-92bbbb36bb7e	PRIMARY	SCI_S1	1	core
164c315b-e188-450e-85be-81f8af58defa	PRIMARY	SCI_S2	1	core
3ce13275-44fe-43dd-aa9a-2d980d9797a3	PRIMARY	SCI_S3	1	core
f802e00a-9cc7-4bf2-a7c1-37ec28353668	PRIMARY	HLD_S1	1	core
550034d5-7e22-417f-a0d6-50a955c67b29	PRIMARY	HLD_S2	1	core
4fabb590-3ffb-4302-b9a2-ae4023360045	PRIMARY	HLD_S3	1	core
390d6ecf-c287-4793-bdce-ee7749c25378	PRIMARY	CAD_S1	1	core
8e18ec4a-262e-458c-b749-24d549150356	PRIMARY	CAD_S2	1	core
f39d6fc9-0388-4ed3-9fd0-84df4bb345bf	PRIMARY	CAD_S3	1	core
e4cac6f9-bdad-4e8a-bde0-ff5f99683e1d	PRIMARY	FED_S1	1	core
dfacbb7f-1067-4425-9270-9220f6ce30cc	PRIMARY	FED_S2	1	core
be48bed9-02cc-4d0b-98f7-1264e1231c91	PRIMARY	FED_S3	1	core
e0748c16-00f9-407b-96a7-04c56b4aee8b	PRIMARY	LCR_S1	1	core
4cb36cd0-1976-4ea8-92ea-420120365bbe	PRIMARY	LCR_S2	1	core
293fec59-5601-4bea-9528-434b3a2e13dc	PRIMARY	LCR_S3	1	core
be994e3e-c83a-4de8-8b3f-de978ffdef5d	PRIMARY	CHT_S1	1	core
7c5add5f-75cc-4bc6-9e13-d405b4ed80cb	PRIMARY	CHT_S2	1	core
d1c77c45-944f-4c3a-a9c1-576669a69a39	PRIMARY	CHT_S3	1	core
74624588-7747-471b-bdcd-29d8ecb48eac	PRIMARY	PAI_S1	1	core
44245cf1-ded7-4e30-8dd0-078857000039	PRIMARY	PAI_S2	1	core
f7148106-99c6-455d-966f-534da7d015df	PRIMARY	PAI_S3	1	core
c4f4a614-c712-4903-8f1d-c80a64114976	PRIMARY	EEI_S1	1	core
4ef2476d-be27-49a1-aa03-f5052a238f5f	PRIMARY	EEI_S2	1	core
4dba5035-3458-4f19-9a18-2f2733c993cd	PRIMARY	EEI_S3	1	core
cc77309d-fcff-4a89-81db-6dc4cb1f01d0	PRIMARY	PHB_S1	1	core
5d3f685e-ba9c-42c1-bcf3-551af43b323c	PRIMARY	PHB_S2	1	core
634d1157-5db6-489e-80da-158ac7cee7b4	PRIMARY	PHB_S3	1	core
8b6ed71a-4b6c-40d4-94f0-92b800da1e40	PRIMARY	FRC_S1	1	core
ed1c6dce-d8a1-4c93-87a8-3b358fd4ba77	PRIMARY	FRC_S2	1	core
5015ce68-e1a6-4d1e-aade-d7fc9ed0d947	PRIMARY	FRC_S3	1	core
d988c5cd-314c-4cb9-864e-eeb74eab1754	PRIMARY	BES_S1	1	core
88f90d5b-7199-4fa7-b0ab-54d814dacfae	PRIMARY	BES_S2	1	core
64ac81e8-3996-4864-96a8-a955ecd2fa0b	PRIMARY	BES_S3	1	core
2f23ad0e-0cac-4609-a40e-8c9ed271037a	PRIMARY	IAR_S1	1	core
3ed0db1a-070d-4147-83e7-c857ab5ad8b1	PRIMARY	IAR_S2	1	core
7768447c-03c6-4683-b36f-150f2f626764	PRIMARY	IAR_S3	1	core
73f7b6ad-53e1-4e14-a381-be87b49de727	MIDDLE	ACF_S1	1	core
6ca0c8a3-23b0-40d5-be14-ad6afee00d03	MIDDLE	ACF_S2	1	core
f001295e-e80d-4de2-abed-1429a26324b5	MIDDLE	ACF_S3	1	core
7cd77215-e065-4efd-aea3-b32aafd2b1e0	MIDDLE	APO_S1	1	core
8355e071-5007-4231-9fa6-4fedcde81603	MIDDLE	APO_S2	1	core
ebb31083-b8f1-4378-9103-efe11dcd87b0	MIDDLE	APO_S3	1	core
3077f6a1-df4c-4dd4-8ff2-54a9b1a36b14	MIDDLE	BSM_S1	1	core
8a5e9875-15bb-4d33-a491-5567efebe354	MIDDLE	BSM_S2	1	core
edc6371b-b5d0-4672-806e-d9f83adcee03	MIDDLE	BSM_S3	1	core
9becb49f-aefd-4337-b658-77a693a8e6bc	MIDDLE	EIR_S1	1	core
5dc7afa6-ac37-48a8-b78e-19a08fc40da6	MIDDLE	EIR_S2	1	core
a14ada62-eac2-446c-bec0-f29f3c0204b4	MIDDLE	EIR_S3	1	core
9ccf4758-16b2-4eb1-8c57-d126194b3530	MIDDLE	MHW_S1	1	core
f497ad25-a1ed-4635-8d01-6047a594c314	MIDDLE	MHW_S2	1	core
1ef7eefc-c493-45c5-a619-b92afadc95ba	MIDDLE	MHW_S3	1	core
4d94eb23-d27d-41b4-a087-2b24fcb116a9	MIDDLE	DUD_S1	1	core
ae59f8da-df95-4e57-b4b4-8dc1e42f8d2d	MIDDLE	DUD_S2	1	core
e82b95c6-4704-4a16-8955-309aeca97dfa	MIDDLE	DUD_S3	1	core
f92b2d56-8a74-4be8-ac35-27429cd2a5ae	MIDDLE	SCI_S1	1	core
669c6352-bfac-4197-84f9-a2e19f094228	MIDDLE	SCI_S2	1	core
21f87563-2d2d-4eab-aadb-e221ef064b4b	MIDDLE	SCI_S3	1	core
d7e06f5d-38b6-474b-9478-e4d9ed557841	MIDDLE	HLD_S1	1	core
cfbfb31b-ac21-4f9d-8c8f-c6f8fe8878d2	MIDDLE	HLD_S2	1	core
6eae7cc9-9950-4bba-a9f0-93e1e8fb018f	MIDDLE	HLD_S3	1	core
6ff25a3f-5964-4c87-b9a5-6191a872d6b8	MIDDLE	CAD_S1	1	core
828522b9-4551-40e3-be3b-164cab204832	MIDDLE	CAD_S2	1	core
fb8eafb0-623c-4de9-beb4-c6cbe1bec9c8	MIDDLE	CAD_S3	1	core
d86bcddd-f548-405c-b22b-4fe2c7ef0c8b	MIDDLE	FED_S1	1	core
16c6c26d-986a-4217-816b-65a18b7c8e2c	MIDDLE	FED_S2	1	core
218ada40-58ce-4588-abb9-65506bed5e96	MIDDLE	FED_S3	1	core
cb38fca3-34b4-4d91-b0d4-aaee3a4cfab2	MIDDLE	LCR_S1	1	core
08887705-6d75-4794-987b-3cd6456d2e16	MIDDLE	LCR_S2	1	core
01de26a6-2a07-4200-bff9-5c5e40f18960	MIDDLE	LCR_S3	1	core
e4e13154-618e-443a-af31-a9ee71bc291b	MIDDLE	CHT_S1	1	core
618247e5-e7f8-44d9-b16e-7284537992a5	MIDDLE	CHT_S2	1	core
b0563d97-e38f-4701-b9c6-34d6d43b52a6	MIDDLE	CHT_S3	1	core
6a9d7635-0524-4f78-85c8-f39d1416f809	MIDDLE	PAI_S1	1	core
99087234-ceac-44e1-a678-4f40875077a8	MIDDLE	PAI_S2	1	core
d95b5a11-ced2-42dd-aed6-a3dddca0cdda	MIDDLE	PAI_S3	1	core
65a3ee35-6f36-4b02-811f-d48b4cd6eb3e	MIDDLE	EEI_S1	1	core
263ea51f-4f16-4148-ba82-21aa5fa0d125	MIDDLE	EEI_S2	1	core
4fb367f9-7606-48f1-834d-c4cc75d24f3e	MIDDLE	EEI_S3	1	core
71ecec64-cb58-41c3-a85c-9e21fcd143a0	MIDDLE	PHB_S1	1	core
951e21bc-6720-4ce9-88c2-71264486d87c	MIDDLE	PHB_S2	1	core
1b35755b-44fe-4757-bf7c-93bd33490112	MIDDLE	PHB_S3	1	core
27c02a77-da13-42cb-af96-54adb425e727	MIDDLE	FRC_S1	1	core
92f32c68-c41d-4733-a0b6-15aacb6b70de	MIDDLE	FRC_S2	1	core
aa712950-28f4-433f-9535-b9b1611383c6	MIDDLE	FRC_S3	1	core
38f42225-26d0-467b-83ce-eca74814add0	MIDDLE	BES_S1	1	core
2e4b208d-19f6-479d-86bc-933b2c1ede59	MIDDLE	BES_S2	1	core
7c786c9e-69f3-4fed-b0bf-76f1333248bc	MIDDLE	BES_S3	1	core
146a30a2-3fe1-4104-b3b4-e7fb721eaa4b	MIDDLE	IAR_S1	1	core
44ca7df7-45eb-4328-a434-d0a2269725a3	MIDDLE	IAR_S2	1	core
5f1e07d0-e3d5-46f9-8065-08a7dbade146	MIDDLE	IAR_S3	1	core
2243e678-5be3-4f5e-8c38-91a3c6fb074d	HIGH	ACF_S1	1	core
b9bb535a-9562-4e00-b691-2a62fbd5dbea	HIGH	ACF_S2	1	core
36689d78-9061-4d0f-a0d1-403659e3400a	HIGH	ACF_S3	1	core
3fc9b6e0-a0f1-4c16-a44e-0e1b184d3e95	HIGH	APO_S1	1	core
f8c18b49-d157-4939-88b2-74e7a84a4f38	HIGH	APO_S2	1	core
ead8ec82-5c58-4348-80e7-f64fa0e2ebe4	HIGH	APO_S3	1	core
a6fd6d61-4b5a-4df8-9e08-fd7a71d821f9	HIGH	BSM_S1	1	core
a5b91f99-c87e-4233-bf45-f83fea464dfa	HIGH	BSM_S2	1	core
9f6d86f4-9a85-4ffd-85f6-8b26e10b8928	HIGH	BSM_S3	1	core
1e19e37b-59dd-4b69-b34f-245ed0ca87a4	HIGH	EIR_S1	1	core
4dc8f135-cf64-4939-ad6d-048c1111c5b9	HIGH	EIR_S2	1	core
a30f122d-b175-4f71-a151-c3da81c14879	HIGH	EIR_S3	1	core
14dd49ce-a640-48dc-86d4-fe1fa4ccd266	HIGH	MHW_S1	1	core
c2d28864-dc02-43f7-ae55-38e51abbccd7	HIGH	MHW_S2	1	core
c3647cc6-ca57-48b3-bb24-567e85b18d42	HIGH	MHW_S3	1	core
6736a916-9f33-4b08-a0dc-2f387c607524	HIGH	DUD_S1	1	core
c59b9e7a-be06-4985-8054-364e8d08d9cc	HIGH	DUD_S2	1	core
2f223ce4-598a-44a1-83e2-b5d47a759093	HIGH	DUD_S3	1	core
70a19eb9-3ec1-4c9d-9fe1-a1076e0a7a32	HIGH	SCI_S1	1	core
fcd9150e-7f87-41b6-b134-98ce220e7524	HIGH	SCI_S2	1	core
e514d178-addd-4382-9114-c9374e938e85	HIGH	SCI_S3	1	core
f6de83f1-2652-4d0a-869d-b01afa8c9135	HIGH	HLD_S1	1	core
f982742c-0375-4e35-bf93-b73d99ba370f	HIGH	HLD_S2	1	core
67462b22-d535-4bfd-9f25-7497f75b67b9	HIGH	HLD_S3	1	core
0d516348-56dc-4b1d-809d-fd3b96b67591	HIGH	CAD_S1	1	core
b458b876-7b09-4acb-ae82-0914669bae0d	HIGH	CAD_S2	1	core
e4937782-2891-4c1c-a132-cdba8b107e25	HIGH	CAD_S3	1	core
ba517c57-ed87-4f79-95f7-2ff4406bc7fd	HIGH	FED_S1	1	core
ba32475a-0f77-44d8-a00c-7f1dc919bd8a	HIGH	FED_S2	1	core
15e0d144-f7d6-4275-9e5a-868c79b26e0f	HIGH	FED_S3	1	core
4019c15b-7fe6-4b53-8cbd-c6776f8f9a01	HIGH	LCR_S1	1	core
a888ff5e-68ff-4bc2-ab35-aaca18944e4a	HIGH	LCR_S2	1	core
b26105f4-a423-412b-8b31-76f2534f1d35	HIGH	LCR_S3	1	core
13de3f65-d677-43fb-84b4-a4493139eefd	HIGH	CHT_S1	1	core
e4b68c3b-9e8c-4c63-9ef4-4c7585d503cb	HIGH	CHT_S2	1	core
9d43b90f-7560-4a4f-bc57-bb05a9b43359	HIGH	CHT_S3	1	core
16f0f7b0-b237-446f-b2ce-99a7e93d1e0a	HIGH	PAI_S1	1	core
3e0634af-e92a-43de-9277-bdde39cd9ce5	HIGH	PAI_S2	1	core
5fe4dc95-18c6-460a-b984-ee0cf136f26f	HIGH	PAI_S3	1	core
c6de33ba-abe3-4b58-bb85-30ee2fd44567	HIGH	EEI_S1	1	core
a1c61535-fff1-4ef2-96c3-63b4dc4fb829	HIGH	EEI_S2	1	core
5a91bec9-ad8e-4c75-a29b-1402afae1095	HIGH	EEI_S3	1	core
20061770-b045-441b-9c66-67e56b2b702e	HIGH	PHB_S1	1	core
76540d4d-8995-470a-826a-b42289943536	HIGH	PHB_S2	1	core
c5c685e9-8c28-4980-bb16-b1b4da627849	HIGH	PHB_S3	1	core
ee42e62d-e816-4140-b5a6-f290c3320e11	HIGH	FRC_S1	1	core
dcc84f9c-d41a-4a38-bf17-dc77ea594896	HIGH	FRC_S2	1	core
acfe91c2-09ba-4f84-9d7d-5c139bced531	HIGH	FRC_S3	1	core
e2545fb3-19d7-40af-8491-03bb2cc5eb2c	HIGH	BES_S1	1	core
4b45af7e-0c30-4f31-b408-e902a088de80	HIGH	BES_S2	1	core
6dadcbfd-4d82-40d2-b1fd-0940f0aba191	HIGH	BES_S3	1	core
beb8e5d4-eca9-4eda-a92e-ae2ecf663c2f	HIGH	IAR_S1	1	core
309e0967-36dc-47f1-8b72-a6c5d1913521	HIGH	IAR_S2	1	core
994a4836-b142-4bbf-9c29-dc01ce4aa0e6	HIGH	IAR_S3	1	core
8881e31d-2dde-40a6-b7d3-20195d22dd24	SR_HIGH	ACF_S1	1	core
34bf64d3-256b-4d8b-be98-75edf277aa8b	SR_HIGH	ACF_S2	1	core
53de2ddc-7059-46f8-8dea-123b5b0a2b80	SR_HIGH	ACF_S3	1	core
2757fdd9-7dcb-4887-bb3d-b1369f3e29fd	SR_HIGH	APO_S1	1	core
935c0a8e-d854-4784-86a6-1e64e5c3e869	SR_HIGH	APO_S2	1	core
28ce9700-ee76-4649-a9a7-b47679044c40	SR_HIGH	APO_S3	1	core
dcd664b8-c2dd-4d9f-8cb2-cec919d91508	SR_HIGH	BSM_S1	1	core
295e890a-2313-4652-b2fe-668b12b524b6	SR_HIGH	BSM_S2	1	core
21fb1810-efbb-4f50-805d-7e3186dc8fae	SR_HIGH	BSM_S3	1	core
e7f7dd47-f1ec-4ec3-ae2d-da13c97b8be8	SR_HIGH	EIR_S1	1	core
91cb6f6d-a770-4841-b704-955f0e682790	SR_HIGH	EIR_S2	1	core
b55d5a19-215a-466b-b2b4-6dc87e8bb0c6	SR_HIGH	EIR_S3	1	core
2c9d1b5f-3cfa-4783-a71e-bbb0975d658f	SR_HIGH	MHW_S1	1	core
dbab2bf5-b946-4535-907a-2a431ef0c29c	SR_HIGH	MHW_S2	1	core
76616b13-327e-47f1-af89-543edad2e45a	SR_HIGH	MHW_S3	1	core
00b4efd4-b2dd-4cb6-8377-07d1e385fdd0	SR_HIGH	DUD_S1	1	core
76b0b555-bba9-4cae-adaa-985eac00c38a	SR_HIGH	DUD_S2	1	core
78443042-2033-4393-a805-d4710ef195f6	SR_HIGH	DUD_S3	1	core
ad29fd15-4b4b-4e5a-a0b7-1281d1720abe	SR_HIGH	SCI_S1	1	core
03cdb4d0-fdeb-4038-b2b1-3d94289d3e33	SR_HIGH	SCI_S2	1	core
8b88ea58-5bbf-40f1-ac43-e50eb6486ae4	SR_HIGH	SCI_S3	1	core
54251004-474d-4c7f-9737-4dc61a8b5c86	SR_HIGH	HLD_S1	1	core
f1c33a67-b1f2-4a0d-999f-df274666dba2	SR_HIGH	HLD_S2	1	core
5390e930-6542-483e-822c-470e44e0b1e8	SR_HIGH	HLD_S3	1	core
793293ac-964e-4587-87a5-1e9d5f2e44d0	SR_HIGH	CAD_S1	1	core
2dc15203-f048-4b1e-8335-67a574f7a19c	SR_HIGH	CAD_S2	1	core
e5c479fe-c19b-4d68-88bc-639579f31695	SR_HIGH	CAD_S3	1	core
1958553f-0c89-4117-afd2-3ab4251847cd	SR_HIGH	FED_S1	1	core
b7ddbac3-961e-4a7d-a91d-c9a6510d452c	SR_HIGH	FED_S2	1	core
6f4e653c-6058-4f11-93e0-cb1664125839	SR_HIGH	FED_S3	1	core
46f04f9f-7567-435e-a82d-3adb8123a441	SR_HIGH	LCR_S1	1	core
6b8f7d19-6ebb-4077-90cf-a2df09c77b2b	SR_HIGH	LCR_S2	1	core
fb934b41-357b-4b04-887d-e53e7396ea0f	SR_HIGH	LCR_S3	1	core
c2705ff6-ec63-4150-8e77-4c0b7772167b	SR_HIGH	CHT_S1	1	core
ed963e4d-ad1b-49e8-a7f7-24919610bbd5	SR_HIGH	CHT_S2	1	core
db11237c-a188-4dfb-9d52-a01999589556	SR_HIGH	CHT_S3	1	core
f2d4ae9f-90f5-4826-9fdd-908e46d51824	SR_HIGH	PAI_S1	1	core
49b88218-2170-4b82-b733-ed997932159d	SR_HIGH	PAI_S2	1	core
11d9f180-5f2b-415f-bf93-9abe30e1cba4	SR_HIGH	PAI_S3	1	core
307a2a89-1266-453f-abc3-8ba564c77b69	SR_HIGH	EEI_S1	1	core
6fe6f9f6-9b62-4752-aaec-ab4b08d6b820	SR_HIGH	EEI_S2	1	core
1f7771c6-2181-4469-954b-9f0a07712bac	SR_HIGH	EEI_S3	1	core
39ed58ef-7283-4f47-b9aa-22c294eb9e12	SR_HIGH	PHB_S1	1	core
95f269e9-a6d3-4906-b985-a179d1ef06ac	SR_HIGH	PHB_S2	1	core
ad17f655-891b-428a-b38c-8c6a7cb5aadb	SR_HIGH	PHB_S3	1	core
ad7e5203-6324-4eb5-80bb-5ac51adc3643	SR_HIGH	FRC_S1	1	core
45aee5e2-c8f2-4a54-99af-d68a190f4ed8	SR_HIGH	FRC_S2	1	core
cce985fd-f922-42c6-acb4-16a26b92bd9f	SR_HIGH	FRC_S3	1	core
a8fd0b49-055d-477c-becb-c1e3486107bd	SR_HIGH	BES_S1	1	core
0059c720-e73d-400f-b007-5515a5ba2cf1	SR_HIGH	BES_S2	1	core
f9ae567f-6a8e-4e6e-b5dd-dbda178e7bc8	SR_HIGH	BES_S3	1	core
75d6dc3c-fc25-4230-ad5d-cb4a1e352b8a	SR_HIGH	IAR_S1	1	core
4a268d0d-a93d-4ea9-b767-84f84ac94a8e	SR_HIGH	IAR_S2	1	core
e7d8bf8c-a3c2-4bbf-bfc9-4ef9e80c4b14	SR_HIGH	IAR_S3	1	core
d643416c-2d44-479c-94f2-49a008888135	UG	ACF_S1	1	core
3e6b8677-8c69-40c4-9971-70f8110558b5	UG	ACF_S2	1	core
95bc97a7-ca88-4087-9fc9-94d8ba422597	UG	ACF_S3	1	core
31576743-6cea-4e53-b631-2c2c839e74da	UG	APO_S1	1	core
731bb122-9061-4be3-80d3-c57201416bee	UG	APO_S2	1	core
ce210c25-8c4c-446f-a387-4ac3dd01ae76	UG	APO_S3	1	core
284e50f3-093b-421b-b4fb-a7302ca566a1	UG	BSM_S1	1	core
e161b04b-9385-4250-9ec0-b3e2cb75a1cc	UG	BSM_S2	1	core
9b595cb3-3353-4070-abb1-de1d4e759907	UG	BSM_S3	1	core
d6614445-cd2b-43c6-9111-2bfc1eeb9857	UG	EIR_S1	1	core
e76db311-605e-4359-9d08-94ae43d1051e	UG	EIR_S2	1	core
821cc127-a1cb-4170-87f6-fc71c5f96c5c	UG	EIR_S3	1	core
52f25fc4-700a-4f57-950a-03bcdae8c7d1	UG	MHW_S1	1	core
7fca112c-ca6b-40ad-b0c8-e8a9bf712f8a	UG	MHW_S2	1	core
7dddc880-979e-4601-b028-17467ed9c4a3	UG	MHW_S3	1	core
5ad1e290-20b4-475a-8769-329018ecdb72	UG	DUD_S1	1	core
3416ed79-c3a6-47e2-b2b7-7298b951efe0	UG	DUD_S2	1	core
1a06293b-b1c6-4466-9645-e780922eee70	UG	DUD_S3	1	core
3acf7c85-89de-4d9c-979d-de672fe930da	UG	SCI_S1	1	core
aeb07562-12df-4769-80d5-d504dedcab8e	UG	SCI_S2	1	core
e792db82-8e06-400d-bfd6-3d207d2cae5e	UG	SCI_S3	1	core
ad3a8a23-cc12-42a2-b57f-55e869cc84e7	UG	HLD_S1	1	core
e76bbb99-705e-491e-aab8-d708ee2a663a	UG	HLD_S2	1	core
b17d60ba-51bf-4628-9dbd-73902092e4e3	UG	HLD_S3	1	core
e7bc454a-59bb-4e68-8264-399b5474f9b4	UG	CAD_S1	1	core
476ea73e-9bdd-4412-9891-efb7db7f7288	UG	CAD_S2	1	core
8a9e4e1b-e4fc-4459-9182-7edcd01613ff	UG	CAD_S3	1	core
91f6d6e0-6e48-4dda-ae1b-25ae7c745668	UG	FED_S1	1	core
070bef64-8993-4c97-b70b-32c8fe73100d	UG	FED_S2	1	core
f613e530-ce84-4e75-b41a-a52947aec6fd	UG	FED_S3	1	core
21ff54b5-f47a-4c44-aa92-dfcd126cb72c	UG	LCR_S1	1	core
0749c24c-7d1f-4ce2-b86b-5f636adb276d	UG	LCR_S2	1	core
d922bf5f-7334-4035-9541-cb625b33d998	UG	LCR_S3	1	core
6f07b128-b8aa-4321-96ab-0a2262e55338	UG	CHT_S1	1	core
ff045499-8015-4ed5-855f-54c487d310a3	UG	CHT_S2	1	core
0d516c3d-096e-49e2-a61a-58b490577232	UG	CHT_S3	1	core
3d22b631-4a2a-407f-8125-4ff118247c1b	UG	PAI_S1	1	core
572663ee-8d70-4c75-ae1e-01f77d9127b4	UG	PAI_S2	1	core
854074cd-92ae-4b91-9e74-dbb734c1cd25	UG	PAI_S3	1	core
eac5601a-e469-4d2f-9246-dd65e9be96b8	UG	EEI_S1	1	core
496a235c-12f2-4bee-a94b-8ec64879d82c	UG	EEI_S2	1	core
ec64612b-95c4-4a31-89ae-04f2d219494c	UG	EEI_S3	1	core
f9891a10-6bbc-43d8-bf34-0ead6d68018a	UG	PHB_S1	1	core
68833e5b-b991-415a-be99-af6f16c8ce7a	UG	PHB_S2	1	core
563065c0-85eb-4378-be31-8ef1e89ea28d	UG	PHB_S3	1	core
60754873-a4c8-40ed-a0c0-bb21bdc40468	UG	FRC_S1	1	core
8f6479cc-5e0b-4adf-b683-899993fb24fa	UG	FRC_S2	1	core
1b263fac-7022-4842-8a02-a2f15806b4ba	UG	FRC_S3	1	core
2249eea1-0561-4f44-9dc9-884844f6c65c	UG	BES_S1	1	core
a4dee76b-af98-4a15-9562-38d008c06c5e	UG	BES_S2	1	core
921300c5-ee03-436b-ae32-6a1f22fd44a4	UG	BES_S3	1	core
df6e26eb-8cc2-4783-a1dd-7f68904aef36	UG	IAR_S1	1	core
30bcc5d1-4689-440a-afd0-deee9b33e2e1	UG	IAR_S2	1	core
a9fbdb7f-9723-4a48-ad7f-0e62fb36ec43	UG	IAR_S3	1	core
9079bce4-b96c-4ef2-9a50-3bd2c1b123ba	WORKING	ACF_S1	1	core
52bcd2ea-0242-48e5-8f6b-3ecc95e293a9	WORKING	ACF_S2	1	core
2adf4c94-9ec1-44c3-8224-184b25f04642	WORKING	ACF_S3	1	core
e0e2bc2f-0920-41d0-9a26-1d8883d6ae23	WORKING	APO_S1	1	core
0e0c9e2f-6c36-495b-a417-dee3149dc40d	WORKING	APO_S2	1	core
cf45d3f9-058a-474a-ac60-3caa50db9202	WORKING	APO_S3	1	core
6ce15251-07b1-422c-8e70-57c89665bf16	WORKING	BSM_S1	1	core
83acbddb-6065-4e62-84d1-d8e692a53321	WORKING	BSM_S2	1	core
96e8720a-4227-49c4-9098-e009e3d44af9	WORKING	BSM_S3	1	core
4c0c48d1-adb6-47c3-a6da-34f1dd0c92d9	WORKING	EIR_S1	1	core
d03b53e6-20b2-474e-9c72-5ecd369a14fa	WORKING	EIR_S2	1	core
f37e83e7-8428-4dff-8471-5286288447fa	WORKING	EIR_S3	1	core
5297d709-a10c-4756-b514-2e93cb423744	WORKING	MHW_S1	1	core
107d841b-dd6b-4471-bd62-1de096540131	WORKING	MHW_S2	1	core
f0088911-d018-4e57-8a0a-4364f30d8d52	WORKING	MHW_S3	1	core
f0fdefc7-eeed-458e-9ef8-3c69b601ada4	WORKING	DUD_S1	1	core
c282e2ee-9053-478b-8fb5-6ab612c79df2	WORKING	DUD_S2	1	core
89a49423-b318-47cc-a629-5b0efe760d4c	WORKING	DUD_S3	1	core
ba2edfba-a855-42ed-9e17-dcad1f250846	WORKING	SCI_S1	1	core
b6f14625-fc41-4f49-aecb-3958e9622a81	WORKING	SCI_S2	1	core
e8ed555f-8b5f-4f86-b425-1ea3984a1445	WORKING	SCI_S3	1	core
7ec7e8f9-d63f-4094-aa9d-0153fcff3b11	WORKING	HLD_S1	1	core
c9af030c-4837-4bb3-b0ad-3629671e9c32	WORKING	HLD_S2	1	core
9dfce3e7-86f6-4cf5-828b-045a95040fd6	WORKING	HLD_S3	1	core
f7fd739b-68c7-4cc5-ac23-b0d73a45ecad	WORKING	CAD_S1	1	core
55644c5b-b9f2-47fb-b60b-07fffa937a0e	WORKING	CAD_S2	1	core
0bff0541-821a-4f65-bc87-742244af75d3	WORKING	CAD_S3	1	core
dec69012-7135-415d-a5af-53025ad65ad6	WORKING	FED_S1	1	core
4a7a1129-1c8b-4ae2-bd07-13a1711db844	WORKING	FED_S2	1	core
f91f7a19-41db-4db8-8742-09e73ba8d25b	WORKING	FED_S3	1	core
523759a4-8bf2-49d4-a1d6-019acc332dc9	WORKING	LCR_S1	1	core
8ad969cd-a413-4d12-a65c-dd636dc2d901	WORKING	LCR_S2	1	core
e4dc905a-cc36-4477-920e-09dc1d98e41b	WORKING	LCR_S3	1	core
14916106-7492-439b-b24e-4b8eebcbc583	WORKING	CHT_S1	1	core
41df9829-b3fc-4c14-9cc3-205ad0c54402	WORKING	CHT_S2	1	core
cc282e89-1d2c-4ebb-b2a5-6df2965bbcc5	WORKING	CHT_S3	1	core
a2397cc0-0222-4316-8864-fadec7405cc3	WORKING	PAI_S1	1	core
59379058-d6e7-4ca6-9b59-46cbd422179f	WORKING	PAI_S2	1	core
0d6749a9-4197-477a-92a0-048638a15334	WORKING	PAI_S3	1	core
6eaf1a67-af0f-4d5a-969f-d5d4ec585316	WORKING	EEI_S1	1	core
fc85442c-6ab1-45b0-bbf8-709326fd3597	WORKING	EEI_S2	1	core
42d82613-8345-4435-9440-6d81479b3363	WORKING	EEI_S3	1	core
a688e0be-86e8-43cd-8e72-d57a318b3d81	WORKING	PHB_S1	1	core
13cde065-d1a6-44c0-b955-f4c66e2b74dc	WORKING	PHB_S2	1	core
db7a8bcb-60de-4de1-8083-ed5c8eede939	WORKING	PHB_S3	1	core
66b17b70-95fc-4755-8a47-9c044ae89925	WORKING	FRC_S1	1	core
619a5b1c-79da-4a11-a279-27270bdd8da3	WORKING	FRC_S2	1	core
e36dfa9b-3dab-4c38-a90e-cfe41718e582	WORKING	FRC_S3	1	core
58ef6f76-2b0f-4dac-868f-1b535355c2c2	WORKING	BES_S1	1	core
f2aaaedc-75c6-4139-a837-9a0ff8f8f809	WORKING	BES_S2	1	core
f1fa27cd-647a-4d94-be0e-82aaacd13a82	WORKING	BES_S3	1	core
ff2ba046-1c83-4f91-9e89-c80ed0443465	WORKING	IAR_S1	1	core
2df4e3ac-d2da-4124-be4c-2f749f88dfaa	WORKING	IAR_S2	1	core
6bdac82e-644a-4e08-8080-f12335456968	WORKING	IAR_S3	1	core
\.


--
-- Data for Name: sdi_stages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_stages (id, stage_code, stage_name, min_grade, max_grade, description, display_order, is_active) FROM stdin;
fa9b70e9-0f77-4bc2-afef-03564dd1e6a4	PRIMARY	Primary School	1	5	Grades 1–5: foundational stage	1	t
a128f387-b1c1-431b-b722-4e223981a179	MIDDLE	Middle School	6	8	Grades 6–8: identity and exploration	2	t
d90ff522-231a-4703-a1fe-d6d2090ebd0d	HIGH	High School	9	10	Grades 9–10: pre-board prep	3	t
58acca57-26d1-4c09-8426-db35d00b1d90	SR_HIGH	Senior High	11	12	Grades 11–12: board exam + career	4	t
0ef55d5f-8ea4-4398-8249-4c445b18d7de	UG	Undergraduate	\N	\N	College — career readiness	5	t
a9db8645-a53b-4d79-83ca-6472fb184891	WORKING	Working Professional	\N	\N	Post-graduation, in workforce	6	t
\.


--
-- Data for Name: sdi_subdomain_norms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_subdomain_norms (id, stage_code, subdomain_code, min_score, median_score, top10_score) FROM stdin;
1a53fcad-1637-4870-9e3f-2dfd8b19b195	PRIMARY	ACF_S1	25	50	80
55ee8489-afbe-402c-9eef-9e7134c1d7a8	PRIMARY	ACF_S2	25	50	80
5cb3bcb8-cd15-47dc-8931-9f0565b8c773	PRIMARY	ACF_S3	25	50	80
b3971f5f-65f6-46d4-9a7b-bf23011ed899	PRIMARY	APO_S1	25	50	80
e24330e7-152d-4f64-a4f4-37defe8b0c10	PRIMARY	APO_S2	25	50	80
54f95fd9-0c7d-462b-b848-5ffe2d62f35b	PRIMARY	APO_S3	25	50	80
5310f187-75f5-4682-8b2a-b2664bcc4a8c	PRIMARY	BSM_S1	25	50	80
f25d7614-339a-4ad4-a91d-cb58334d81bc	PRIMARY	BSM_S2	25	50	80
7ccd02d3-e1b1-417b-a18f-abfb4e5b7c1b	PRIMARY	BSM_S3	25	50	80
28873b68-7021-4dd9-8c0c-f968dc7e7d80	PRIMARY	EIR_S1	25	50	80
d73cd370-7fd2-4ebd-9f8d-374cfd224a2f	PRIMARY	EIR_S2	25	50	80
c0462285-6e03-44c5-9f98-44204b6278dd	PRIMARY	EIR_S3	25	50	80
adfff992-2ea4-41a9-adf7-af73250cc78f	PRIMARY	MHW_S1	25	50	80
c94daa73-8e6e-41ca-bbaa-8bb98bdfddf1	PRIMARY	MHW_S2	25	50	80
220507ad-bb1e-46aa-892f-9ae2d43a29fd	PRIMARY	MHW_S3	25	50	80
5d7497a1-a097-4cba-97f1-ca1cccb92669	PRIMARY	DUD_S1	25	50	80
4f94667f-726a-4b96-8be0-a373848e3302	PRIMARY	DUD_S2	25	50	80
b3893c8a-b88d-42e9-bf9e-52c4da58441b	PRIMARY	DUD_S3	25	50	80
28241566-3a1b-43cc-8c81-7fa65d365add	PRIMARY	SCI_S1	25	50	80
c074e805-65de-44b3-8fd7-9972f9235769	PRIMARY	SCI_S2	25	50	80
ab93f717-9e0a-47a1-a849-7e4952374ed4	PRIMARY	SCI_S3	25	50	80
642b89bc-24f4-4923-a9ea-7d32b06a04bb	PRIMARY	HLD_S1	25	50	80
88092573-e641-49f6-afa3-90ce8da1fa3d	PRIMARY	HLD_S2	25	50	80
1793eb81-b4ff-48fe-81f1-2899631cc020	PRIMARY	HLD_S3	25	50	80
0febac7e-256e-4a83-a744-ec304bc5dec9	PRIMARY	CAD_S1	25	50	80
ce029786-23e3-4b34-a59f-bd4e93e13bc8	PRIMARY	CAD_S2	25	50	80
310281e6-e45f-4da0-b313-13ff678aa852	PRIMARY	CAD_S3	25	50	80
04472656-3fc3-4535-90a5-5180cd7ac871	PRIMARY	FED_S1	25	50	80
d1664275-113c-4277-bbeb-21e395c29385	PRIMARY	FED_S2	25	50	80
698649b8-fec1-4ab0-83a5-852fd888af47	PRIMARY	FED_S3	25	50	80
5f167b05-1239-49e7-8d83-3ac47b6230b4	PRIMARY	LCR_S1	25	50	80
e8a7e498-137b-44ca-83a1-e52c521e964d	PRIMARY	LCR_S2	25	50	80
99f61e65-c10d-4291-861c-0a5c189e4a86	PRIMARY	LCR_S3	25	50	80
573ead9c-41e3-41ed-a0be-b383bd6b317c	PRIMARY	CHT_S1	25	50	80
1915b875-16ea-4d4c-acd0-4f26a5663946	PRIMARY	CHT_S2	25	50	80
cf58f515-b31f-4e95-9ac7-c6ffcb515274	PRIMARY	CHT_S3	25	50	80
5a427298-4718-467f-b343-1a11f05b2961	PRIMARY	PAI_S1	25	50	80
f95fb5e4-a838-4341-a9e6-6f0845184b78	PRIMARY	PAI_S2	25	50	80
a2e014b8-805e-4832-805d-8b77bfd056c2	PRIMARY	PAI_S3	25	50	80
c10e396a-4777-44bb-84ea-bbb4ad9f8724	PRIMARY	EEI_S1	25	50	80
8fd15712-4f2e-4d78-b72a-1b3d71f75970	PRIMARY	EEI_S2	25	50	80
5ce09b1b-bce6-4da0-b934-c6e133c35dbb	PRIMARY	EEI_S3	25	50	80
3b42caab-acaa-4781-906f-3cbdfebc09f0	PRIMARY	PHB_S1	25	50	80
6860f595-8dfd-4501-bd94-a280b0013d6b	PRIMARY	PHB_S2	25	50	80
d183641d-54b9-468b-b7a8-aecad63b09d8	PRIMARY	PHB_S3	25	50	80
7618ef20-5309-4c1c-8046-f6d533d13c48	PRIMARY	FRC_S1	25	50	80
4e189ed4-c482-45d0-b005-7a9f4650e547	PRIMARY	FRC_S2	25	50	80
567cfb77-aca7-45bc-937b-f209fdc61b1d	PRIMARY	FRC_S3	25	50	80
cbbbecc4-3728-4b33-86dd-a1a3bc09e496	PRIMARY	BES_S1	25	50	80
b8f8e894-c202-4ef8-b746-fb5b8b858cdc	PRIMARY	BES_S2	25	50	80
62db3bee-b0ad-4b7f-a8f6-c02ac333a151	PRIMARY	BES_S3	25	50	80
8ef33f38-ccaa-4dd2-85f0-f6e1721ee9cd	PRIMARY	IAR_S1	25	50	80
3b350df2-4886-4642-b663-dc056077b636	PRIMARY	IAR_S2	25	50	80
750af787-3de3-43fd-ade7-9eb97a8781b7	PRIMARY	IAR_S3	25	50	80
d80a2f36-6b0e-41d3-a652-28c61bb43abf	MIDDLE	ACF_S1	30	55	82
322fab7e-0d9f-4c33-bcb6-e4daeb9e3986	MIDDLE	ACF_S2	30	55	82
a05d8220-a2e0-4869-b12f-feda024aaa34	MIDDLE	ACF_S3	30	55	82
58c13589-e61b-4611-9884-ca8ecb4075eb	MIDDLE	APO_S1	30	55	82
fa14680b-c1c8-45f4-ba12-aaea70c60f9e	MIDDLE	APO_S2	30	55	82
68468bb6-cb76-4834-a693-41a2a7b0ce69	MIDDLE	APO_S3	30	55	82
47ac2f8a-7bf6-4f87-8026-2d54c44f0ff2	MIDDLE	BSM_S1	30	55	82
0a143c7b-6414-4552-8ca7-231be2dc5aa1	MIDDLE	BSM_S2	30	55	82
74869d44-1304-45f2-8444-c0b4e9674862	MIDDLE	BSM_S3	30	55	82
a2bc9b36-f115-4ec0-b59e-1f434da59ebc	MIDDLE	EIR_S1	30	55	82
e38bd720-ead4-4e93-96c8-44b6d4eaaf01	MIDDLE	EIR_S2	30	55	82
9cb3e939-03a7-4548-b2c1-0dc99ab694a3	MIDDLE	EIR_S3	30	55	82
69fda8b7-4814-4369-bc64-6d324680835b	MIDDLE	MHW_S1	30	55	82
916de166-9775-4127-8e29-24352049076f	MIDDLE	MHW_S2	30	55	82
9526d693-67b8-4ae0-848b-4d3a6ccb8ca1	MIDDLE	MHW_S3	30	55	82
0a2d32b2-5b19-42af-b132-562b0377e024	MIDDLE	DUD_S1	30	55	82
36513e4d-83fc-4d46-9ba7-0dd32afb41c3	MIDDLE	DUD_S2	30	55	82
58fd1383-c027-46cf-98a5-8aa08b48cb43	MIDDLE	DUD_S3	30	55	82
e6d4eb20-aa5d-4346-bb88-320d5d4e6e64	MIDDLE	SCI_S1	30	55	82
a1d6ec9f-b269-4bcb-bc0d-2c31ae4fea3e	MIDDLE	SCI_S2	30	55	82
c490f8e3-29b4-4b5d-ad63-d37b78e72b07	MIDDLE	SCI_S3	30	55	82
09a159f3-a61d-47d6-941b-e6b5137101b9	MIDDLE	HLD_S1	30	55	82
cbee24c2-ea12-42f0-a44f-ff5d2eab7546	MIDDLE	HLD_S2	30	55	82
87df3d4f-e1f0-4505-bccf-535f0d326d28	MIDDLE	HLD_S3	30	55	82
6f44a7fd-6e2e-458d-962f-35803861338a	MIDDLE	CAD_S1	30	55	82
feabaf9b-b696-4348-9e66-8caeb9f69e9d	MIDDLE	CAD_S2	30	55	82
a7dfd3bc-6edb-4073-8747-866dde2c90c9	MIDDLE	CAD_S3	30	55	82
21d63c65-a4fd-4c72-871b-38f24b171201	MIDDLE	FED_S1	30	55	82
e5a0937a-b514-434b-beca-a1be063c7524	MIDDLE	FED_S2	30	55	82
6ef4823e-8621-4ab5-8e2b-d0e244aa4096	MIDDLE	FED_S3	30	55	82
8b62a43b-9956-4b53-95ae-e05dfd20ad10	MIDDLE	LCR_S1	30	55	82
26984c13-a47b-418e-9dc0-d9042e06924c	MIDDLE	LCR_S2	30	55	82
dc6e5652-919a-473d-977e-5d73ee4916c0	MIDDLE	LCR_S3	30	55	82
35440a13-ef53-4378-af7d-33bea2eb32a5	MIDDLE	CHT_S1	30	55	82
6fbebbfa-dd1e-4b93-82f3-67e0d1d93c5e	MIDDLE	CHT_S2	30	55	82
c769e57b-735b-45e5-9d42-f231c4476415	MIDDLE	CHT_S3	30	55	82
ea0480f7-4c89-4754-a228-412ac82035bb	MIDDLE	PAI_S1	30	55	82
56866695-948e-463e-bb03-978bd74cbb5b	MIDDLE	PAI_S2	30	55	82
7068020c-7e16-43e8-8df8-965236b0760a	MIDDLE	PAI_S3	30	55	82
af72182c-7541-4a0f-b2c7-c341157f4f70	MIDDLE	EEI_S1	30	55	82
e5e4b4d8-8aec-4b2f-b8e4-dbc691952351	MIDDLE	EEI_S2	30	55	82
61d98197-0bdd-4899-8a7c-d616cfa47e4d	MIDDLE	EEI_S3	30	55	82
bc794091-cb9d-4ff5-bdc1-c970c5cd118e	MIDDLE	PHB_S1	30	55	82
b182a053-028e-4809-8318-e91cbd964d34	MIDDLE	PHB_S2	30	55	82
e470f8e2-5846-4a37-84d8-37708fdc07f9	MIDDLE	PHB_S3	30	55	82
88832a02-4d80-4644-af3d-48d6d672b33b	MIDDLE	FRC_S1	30	55	82
2e4c60dc-7078-4611-9f84-da34d8f8ac4f	MIDDLE	FRC_S2	30	55	82
4e0e2beb-baf0-4e50-beb3-60203613f6f0	MIDDLE	FRC_S3	30	55	82
528765af-7dce-47f4-94f8-f82253d169a2	MIDDLE	BES_S1	30	55	82
05a8d53a-54b1-4c16-9ebf-bb102c5f31e0	MIDDLE	BES_S2	30	55	82
25ce5307-71a3-4796-81ec-4af07dcdfad5	MIDDLE	BES_S3	30	55	82
5c5bce23-d768-4640-8d09-1a7e85e33ce3	MIDDLE	IAR_S1	30	55	82
ecdc1271-9081-418e-a290-6c059a7ae55a	MIDDLE	IAR_S2	30	55	82
333511d7-d08f-464e-a69e-9ee0b5396359	MIDDLE	IAR_S3	30	55	82
730c74cf-e39c-46f6-b757-97b3289a6fe8	HIGH	ACF_S1	35	60	85
4c8ed558-b534-4673-8624-e73f6a7198c4	HIGH	ACF_S2	35	60	85
fc7cf382-0f68-4f17-9dde-48cc3453cb5f	HIGH	ACF_S3	35	60	85
bd8173e4-4f6c-455b-9e09-a66fa64ed0d2	HIGH	APO_S1	35	60	85
5443f5cf-5101-4d07-b799-0d05947141f5	HIGH	APO_S2	35	60	85
16d72d63-e69d-48a0-92ab-d04472ddd5e3	HIGH	APO_S3	35	60	85
623cda14-64af-4e86-91f7-eb74a64c2741	HIGH	BSM_S1	35	60	85
7d4005aa-724d-4187-91c8-945c75e40381	HIGH	BSM_S2	35	60	85
be5ddbb3-370d-4909-9b4e-488568305890	HIGH	BSM_S3	35	60	85
824027ee-3436-438a-ad27-5d19771331b7	HIGH	EIR_S1	35	60	85
28982527-6f43-4ea8-b63b-ea9ad280bf8e	HIGH	EIR_S2	35	60	85
2522ab08-c5db-4279-8191-234eb4858907	HIGH	EIR_S3	35	60	85
32a11f39-3e2e-4b68-a7d2-ba128a286452	HIGH	MHW_S1	35	60	85
ac12e9bd-3764-49d0-8f75-72777f36c9ed	HIGH	MHW_S2	35	60	85
5a1f4f69-90cf-46ec-831b-e271d12ac3db	HIGH	MHW_S3	35	60	85
64890381-16c3-4dd1-8bc9-a002f0a03bc6	HIGH	DUD_S1	35	60	85
c34ae81c-79d0-4979-ad40-ef909b9df979	HIGH	DUD_S2	35	60	85
37bd5655-18bf-49ce-bb2a-96662c696bd8	HIGH	DUD_S3	35	60	85
171ffc1a-6071-42f4-a218-2d76873c334f	HIGH	SCI_S1	35	60	85
66271320-3d6d-4400-b713-22d5ad291289	HIGH	SCI_S2	35	60	85
76471c9a-fc4c-427d-99d2-673f2ffc53b2	HIGH	SCI_S3	35	60	85
0c5f0c29-696a-4641-902c-21aa780a52fd	HIGH	HLD_S1	35	60	85
8cab8aa6-2326-472d-a270-0f7ab29305b8	HIGH	HLD_S2	35	60	85
b58e2f94-e1ba-4c26-af81-c12e9ddb25f5	HIGH	HLD_S3	35	60	85
2b178134-0ea8-40dd-ad07-95c770aae74a	HIGH	CAD_S1	35	60	85
80bc5d53-596d-4011-adaf-b580c07ec24c	HIGH	CAD_S2	35	60	85
2c789a51-ed11-4bd9-99d0-23bff03f25f7	HIGH	CAD_S3	35	60	85
313ce073-03ff-4918-af9d-0581fb5afe73	HIGH	FED_S1	35	60	85
ef55ff14-0574-4ef6-96bf-bf8bb6cf64d3	HIGH	FED_S2	35	60	85
eb585e6c-e81e-470d-8e18-4f5465be1a37	HIGH	FED_S3	35	60	85
8b0eebbe-d70c-40cd-b51d-6992d99bd613	HIGH	LCR_S1	35	60	85
0a384077-e691-4dbf-b024-fc517f49e257	HIGH	LCR_S2	35	60	85
5ada157a-50bb-4ccd-98ad-38a79d337fac	HIGH	LCR_S3	35	60	85
daf44e0b-795a-41a5-9aa9-60a881271e9a	HIGH	CHT_S1	35	60	85
b4664d5f-7889-497e-a241-71a263fac74a	HIGH	CHT_S2	35	60	85
ea9df196-1707-4c3d-adfa-7a44ebb34fe3	HIGH	CHT_S3	35	60	85
51f992ae-3134-4f68-9109-418ce42e8fee	HIGH	PAI_S1	35	60	85
cbf4705e-8f9d-4541-a7b1-beb5b44c63e9	HIGH	PAI_S2	35	60	85
6e9f6c61-e587-4b90-a96c-91a2dd9bd6b0	HIGH	PAI_S3	35	60	85
63c0a97c-9984-48f1-a84a-2330a11b4cfb	HIGH	EEI_S1	35	60	85
d82cd7b5-47f6-4f68-816d-f392c49b563a	HIGH	EEI_S2	35	60	85
0833c49e-c829-496a-b15f-81cc9ef986d8	HIGH	EEI_S3	35	60	85
48a078f3-07c0-402f-af83-dd02fcd2a9db	HIGH	PHB_S1	35	60	85
7434c952-f9b3-423e-897f-8179dede6b34	HIGH	PHB_S2	35	60	85
d6da84ef-afb7-4e7a-9a4d-8fa4a62efac0	HIGH	PHB_S3	35	60	85
bb783167-c1b9-429b-8bb0-2de4ce82c964	HIGH	FRC_S1	35	60	85
4bbb673b-d67e-45df-a532-d81b4ad17836	HIGH	FRC_S2	35	60	85
0fa3b2cf-26dc-4a02-8be3-de1f8936eb36	HIGH	FRC_S3	35	60	85
a5f5cd82-a518-496b-a2a3-51ccac730bf5	HIGH	BES_S1	35	60	85
56d8c653-e208-4852-ac4e-7222723127bb	HIGH	BES_S2	35	60	85
bd2cabcb-945d-4cf9-8095-06660e65097a	HIGH	BES_S3	35	60	85
4f6389e8-3257-48c5-bb59-0e60dbc72d3f	HIGH	IAR_S1	35	60	85
8cdaaf73-ff37-48dd-b0ab-6e8996490e17	HIGH	IAR_S2	35	60	85
66912e96-9914-447d-a60d-90b34fc02e71	HIGH	IAR_S3	35	60	85
6de97466-df28-41c4-a9be-c1ceaae3064d	SR_HIGH	ACF_S1	40	65	88
78b96d7d-2945-4033-a89b-fbd58d31d9a5	SR_HIGH	ACF_S2	40	65	88
ae2b3292-8151-4597-881c-d9a0dbf620d6	SR_HIGH	ACF_S3	40	65	88
f83f7b58-9780-4150-a24c-d6243ef615a0	SR_HIGH	APO_S1	40	65	88
cbf2c9e7-838c-45a2-a633-bdfac4dcdc01	SR_HIGH	APO_S2	40	65	88
011869c5-1e46-4f6f-80de-02114afa4c11	SR_HIGH	APO_S3	40	65	88
52178b31-15cf-4c8e-a874-da635d727b49	SR_HIGH	BSM_S1	40	65	88
4e007fb0-1a10-4d60-b4bd-2bb73517c646	SR_HIGH	BSM_S2	40	65	88
2a96be72-91cd-4e65-a43b-460e965a159d	SR_HIGH	BSM_S3	40	65	88
e3d43495-1dd5-4288-b6bd-9c196d9e71d2	SR_HIGH	EIR_S1	40	65	88
eb2e8309-9ff9-4421-a1b3-a4b542044a0a	SR_HIGH	EIR_S2	40	65	88
317ed6f6-ca33-447e-bdf6-20bd07ecb211	SR_HIGH	EIR_S3	40	65	88
6df65556-ca81-400f-b051-9ab8dfa34207	SR_HIGH	MHW_S1	40	65	88
e98ff3b3-dbaf-48ff-9661-14cd1842b52b	SR_HIGH	MHW_S2	40	65	88
360e52c3-f426-4a43-afbd-d13e523e273d	SR_HIGH	MHW_S3	40	65	88
072937fc-e70b-4522-a8b6-c8aaac7ff68f	SR_HIGH	DUD_S1	40	65	88
e2840463-442d-4c12-bcf7-7c5a731b9487	SR_HIGH	DUD_S2	40	65	88
e81c3c99-30c9-429f-b8f6-0ef554514e62	SR_HIGH	DUD_S3	40	65	88
46b6dfa0-ce3c-40dd-8220-cb9857f28574	SR_HIGH	SCI_S1	40	65	88
3cb263f6-2387-45fc-acc6-c9668b8e9e02	SR_HIGH	SCI_S2	40	65	88
dd0d2d66-b051-47d7-ab74-4eae599e7858	SR_HIGH	SCI_S3	40	65	88
4f79cbd5-4130-40b3-a855-eb74d1e06dac	SR_HIGH	HLD_S1	40	65	88
b3c1d151-c831-49ce-b82d-ab86b1b69c9b	SR_HIGH	HLD_S2	40	65	88
95bb7d91-424e-43a2-ad9a-5ff0eada165b	SR_HIGH	HLD_S3	40	65	88
61fad9f9-bfb6-4f68-a0b0-291a8000a4e4	SR_HIGH	CAD_S1	40	65	88
04ed239f-46d5-4530-9851-dde110bf61b7	SR_HIGH	CAD_S2	40	65	88
f41f34e9-d567-4bcb-96d1-1398d40de72e	SR_HIGH	CAD_S3	40	65	88
d9f99e53-ae23-4849-8018-c4290b433f51	SR_HIGH	FED_S1	40	65	88
145de25b-3afd-4223-bcbd-ef1ae648fbc6	SR_HIGH	FED_S2	40	65	88
d9e32cad-377a-447c-9296-3c234c94bb1e	SR_HIGH	FED_S3	40	65	88
c89a377f-d2a9-4b86-a2c4-89a2550056a2	SR_HIGH	LCR_S1	40	65	88
569d0e63-3129-4f92-b806-26598e68d56e	SR_HIGH	LCR_S2	40	65	88
5980c9e4-e6e0-42af-865f-7695b1c5fffb	SR_HIGH	LCR_S3	40	65	88
345dfbb6-7fff-4fba-86bc-ce0e7ef3c1fd	SR_HIGH	CHT_S1	40	65	88
ab35fc16-b993-4dde-9698-630d018c7b69	SR_HIGH	CHT_S2	40	65	88
ed4c776e-8ce5-4f12-98f1-3a05d58597d9	SR_HIGH	CHT_S3	40	65	88
6ae69778-1c43-4d57-bcf7-1cc719a82cf1	SR_HIGH	PAI_S1	40	65	88
518b3848-38af-4984-bd27-a10b91368fff	SR_HIGH	PAI_S2	40	65	88
cbd8eacd-b19a-47dd-8dad-9b95c08f8bdb	SR_HIGH	PAI_S3	40	65	88
82fc1ffa-b434-42a5-841d-ad4986d91cdf	SR_HIGH	EEI_S1	40	65	88
608739ca-7206-4635-9364-b77d61f4d4de	SR_HIGH	EEI_S2	40	65	88
0293fe1a-4b62-40a9-9fd0-0493b1a52a9c	SR_HIGH	EEI_S3	40	65	88
1c4f25cb-65f0-4ab1-a2de-60bf2e3f6ff2	SR_HIGH	PHB_S1	40	65	88
09b56cc9-41da-4f51-83f0-dceb2688287b	SR_HIGH	PHB_S2	40	65	88
110a8150-a208-45c5-b53f-1b3294187171	SR_HIGH	PHB_S3	40	65	88
86d21fd0-6e16-409f-a0db-1c8ca179ac0d	SR_HIGH	FRC_S1	40	65	88
ea47a91c-ba1c-46f9-8a18-40048fac5775	SR_HIGH	FRC_S2	40	65	88
4ce314f0-ab4b-4729-a8f1-07267282ac84	SR_HIGH	FRC_S3	40	65	88
cff6000e-902d-4eee-a1af-0571388ea6c6	SR_HIGH	BES_S1	40	65	88
198632c5-bf00-478a-9e8a-8cb0f342014d	SR_HIGH	BES_S2	40	65	88
0dfacfe0-f69c-4746-a40e-1a7d625349c6	SR_HIGH	BES_S3	40	65	88
87a7a432-ade7-4acf-956b-2f3be0502bea	SR_HIGH	IAR_S1	40	65	88
4e99e3bd-fdc7-4aff-9fbb-154dca0b5835	SR_HIGH	IAR_S2	40	65	88
a99a8213-9e64-4c1c-9d9e-54f28750740a	SR_HIGH	IAR_S3	40	65	88
49b557e9-4022-4b71-95a6-82f2fa5b3e10	UG	ACF_S1	45	70	90
5bd47a50-24fa-4b4c-99a5-68b61cdff975	UG	ACF_S2	45	70	90
cedf5844-fe7d-4013-a87d-e2047379531c	UG	ACF_S3	45	70	90
0c52b156-2517-4708-b743-1422c3a77bd9	UG	APO_S1	45	70	90
50d462ca-7440-4164-bffe-8eda99cdaa26	UG	APO_S2	45	70	90
aa3aeefb-3dbc-470e-9225-88040de34990	UG	APO_S3	45	70	90
9a3e7767-b655-4194-9795-2551fe1f5c4f	UG	BSM_S1	45	70	90
e30989f9-8f81-42dc-b1db-022130c651a9	UG	BSM_S2	45	70	90
3d95dc03-b0bd-4513-bbbc-a549f883d609	UG	BSM_S3	45	70	90
09f3e9dd-3aba-4643-b4db-6a9bb2812c4d	UG	EIR_S1	45	70	90
e70d3c32-f8d5-4761-ae5c-5871546e8477	UG	EIR_S2	45	70	90
6011e1a7-88f9-4744-af73-48cb03b31ff1	UG	EIR_S3	45	70	90
6f8fefdb-ea59-4942-b745-6522814c955d	UG	MHW_S1	45	70	90
eb30cd40-6384-48ff-9ef0-306140f639ab	UG	MHW_S2	45	70	90
769313ab-c42e-42b1-89fd-0b239dfa527c	UG	MHW_S3	45	70	90
8b0eb054-e11d-4b78-960e-93bd16629dae	UG	DUD_S1	45	70	90
6718d547-d0f7-45fb-aa5a-54a0444680c9	UG	DUD_S2	45	70	90
3a01d05e-c4d2-4dbd-bd09-6a96e390d325	UG	DUD_S3	45	70	90
2224278a-a137-4e26-bbc3-152c7800d240	UG	SCI_S1	45	70	90
fc36f815-b9fa-425b-9c59-74c2effb449a	UG	SCI_S2	45	70	90
84abc306-981e-456c-87c1-dd5e56064738	UG	SCI_S3	45	70	90
83aacefa-481c-414e-b105-54e7644af5c6	UG	HLD_S1	45	70	90
e979a0a9-a817-49e4-99d3-3abe2f0bc926	UG	HLD_S2	45	70	90
3747da26-bffc-4f3d-9b4f-03aee8ae4dae	UG	HLD_S3	45	70	90
03c5524c-e64c-4e01-a51b-ceb037092c98	UG	CAD_S1	45	70	90
8b4c2515-3f97-49f9-a3fb-5707410b1737	UG	CAD_S2	45	70	90
7f60e72d-b4a1-4cf6-8466-c0a6256cc6d9	UG	CAD_S3	45	70	90
68bd882b-6534-4625-8482-1bf89ef8f124	UG	FED_S1	45	70	90
d80228eb-a95e-4537-b747-2371e1f7d2d0	UG	FED_S2	45	70	90
6aa1f386-cffe-4c8d-81d1-3bca061349ae	UG	FED_S3	45	70	90
87eb1e5f-4432-4a65-9bf7-4bcfbb757173	UG	LCR_S1	45	70	90
1a1bc98e-bc22-4619-befe-540f233ebecb	UG	LCR_S2	45	70	90
2c045177-edd5-4cac-9552-131f9f0c407c	UG	LCR_S3	45	70	90
a328c268-4c33-415f-86cf-4b666b64344c	UG	CHT_S1	45	70	90
87bb983b-0ff2-4ec7-a616-b8151134352a	UG	CHT_S2	45	70	90
7de0980f-299c-4670-a0ef-39fb3929fc28	UG	CHT_S3	45	70	90
614fdedf-3afa-45ad-a694-9812fe27aec0	UG	PAI_S1	45	70	90
247bc45b-019e-4ee0-b92f-5cad555fe0a1	UG	PAI_S2	45	70	90
7c57c223-4159-4a63-84df-212e614fee9a	UG	PAI_S3	45	70	90
f44103f1-43a5-4bb2-a54e-8fae256ea826	UG	EEI_S1	45	70	90
0b3fd20a-0dcb-4a70-9c62-bad969117b91	UG	EEI_S2	45	70	90
3ec9a1dc-1a83-4014-a214-a79a0b80e1ad	UG	EEI_S3	45	70	90
669cf817-3378-4b2c-af14-5c7cb32c32e3	UG	PHB_S1	45	70	90
7fbcc6f5-b3f7-4984-b687-91f7484ba87f	UG	PHB_S2	45	70	90
12a491fe-b3bb-4c36-81c4-7707d718dcc0	UG	PHB_S3	45	70	90
e8e05816-2833-4eba-a647-8016d1a2896b	UG	FRC_S1	45	70	90
a51e0d5e-1d86-4795-b571-70f66ca593cb	UG	FRC_S2	45	70	90
0ba229f3-b627-435a-b3cd-f7f8a4b6befd	UG	FRC_S3	45	70	90
4709e5e6-44f6-4eae-a323-6714ad4c4f0d	UG	BES_S1	45	70	90
50604a84-50a8-48a3-85d0-b9d33d47c778	UG	BES_S2	45	70	90
d30660d8-03e8-401e-b468-b033cd0bd30d	UG	BES_S3	45	70	90
0cd1c6f9-f110-40b9-b9c5-dee88ccafdca	UG	IAR_S1	45	70	90
3d70c15d-8d99-4662-b0df-e8feb988dff5	UG	IAR_S2	45	70	90
a109c337-2aa1-4645-b1df-12f78d704a54	UG	IAR_S3	45	70	90
06e982e1-f357-4380-af84-ca30ef0a45ec	WORKING	ACF_S1	50	75	93
4662731e-eeb6-4b22-a6ed-3c7b6cca150a	WORKING	ACF_S2	50	75	93
13f8dca5-4714-4a49-8da2-e4f3dd893ec6	WORKING	ACF_S3	50	75	93
7e837fcb-d50f-4fe1-bd08-e8bcebd1c74c	WORKING	APO_S1	50	75	93
8aa7f898-0435-4b2a-9274-44c87f6f32ba	WORKING	APO_S2	50	75	93
ab708cca-2031-46ee-8a21-348d3ec85127	WORKING	APO_S3	50	75	93
caf371bf-d571-4a42-81ce-f965572f5da3	WORKING	BSM_S1	50	75	93
6a310de3-708d-4a03-8a34-7805cb58991f	WORKING	BSM_S2	50	75	93
da14e685-f3eb-450e-9d99-b0208caf94a2	WORKING	BSM_S3	50	75	93
d3bf7f72-2475-4394-b5e6-c8a8ba519861	WORKING	EIR_S1	50	75	93
d81e44cc-7247-4480-ac53-b246c224aff1	WORKING	EIR_S2	50	75	93
86bcdc0b-5640-48b4-a7b0-c720c028b3ef	WORKING	EIR_S3	50	75	93
a0e96021-618d-4b23-9f16-3f39dd53bc5f	WORKING	MHW_S1	50	75	93
1798d574-2f19-49c2-80ef-ed5c0cfa9810	WORKING	MHW_S2	50	75	93
757ea73c-130e-416f-9290-ac9d4e8f729e	WORKING	MHW_S3	50	75	93
2bef98af-02b7-449e-a53a-2a2f35a1192c	WORKING	DUD_S1	50	75	93
3a0218b4-7c05-46df-9f27-a1867f7902e6	WORKING	DUD_S2	50	75	93
c7c2c0ae-70cf-4f04-bce5-c8c1fd56f3b3	WORKING	DUD_S3	50	75	93
3b9744ac-543c-48c9-a889-a185e4fcb7e3	WORKING	SCI_S1	50	75	93
16a80596-cd99-4163-9cd8-1844d4e0fc98	WORKING	SCI_S2	50	75	93
7f04afe6-18ad-47fb-b109-149e0fc550c0	WORKING	SCI_S3	50	75	93
a4cb5543-09ef-423e-b7af-d662729d7bab	WORKING	HLD_S1	50	75	93
a10a76cc-098f-421d-b27a-d138d6070328	WORKING	HLD_S2	50	75	93
1b7af758-e343-4dec-9981-3b8f346dc5a1	WORKING	HLD_S3	50	75	93
6183ad2b-7cec-4786-8852-f2abd5080950	WORKING	CAD_S1	50	75	93
d19f56f7-be89-4b50-98f1-4976004b289e	WORKING	CAD_S2	50	75	93
dd12fd20-86cc-4109-a490-7b68298924f8	WORKING	CAD_S3	50	75	93
2523d166-c59a-45ff-a1c0-d95c16b4b6da	WORKING	FED_S1	50	75	93
df99e15c-4b66-4211-b6a5-9d8b51632d9e	WORKING	FED_S2	50	75	93
07893956-a545-4d33-b6ad-e78373fa7ff2	WORKING	FED_S3	50	75	93
f9c1c9ec-28a8-4886-a614-4aa6ecf570c7	WORKING	LCR_S1	50	75	93
eb1c923d-5d37-4e0d-b508-5714b32108c4	WORKING	LCR_S2	50	75	93
dbd02d16-5bed-4ad6-adcc-b9324b76992e	WORKING	LCR_S3	50	75	93
b4cf2af5-a672-4804-a70d-0775c13d5d13	WORKING	CHT_S1	50	75	93
bca3a7e5-1e50-423e-bc13-5fb1112d16da	WORKING	CHT_S2	50	75	93
88f38fda-061f-4598-bc3f-4210c89d1e58	WORKING	CHT_S3	50	75	93
887a9db7-359d-4b27-a37f-3def84306fa8	WORKING	PAI_S1	50	75	93
d196cb3b-9526-4477-97e7-8ab4e136b7bb	WORKING	PAI_S2	50	75	93
d9d1365b-6d82-4676-ad49-9233700a7447	WORKING	PAI_S3	50	75	93
f5f551f0-fa29-4ab4-ad55-0ed83a274b01	WORKING	EEI_S1	50	75	93
0961cc5c-74c5-423e-a8e1-aa9a4036f20d	WORKING	EEI_S2	50	75	93
e4be6d7a-1260-4725-a98e-9c489608ee32	WORKING	EEI_S3	50	75	93
3b1e9638-3de9-44f7-a8bf-6c6a5a140c65	WORKING	PHB_S1	50	75	93
5f7a4565-077f-4014-8080-23457ecbbdf3	WORKING	PHB_S2	50	75	93
ccfbab9e-0cfb-47e9-a426-609c631af76c	WORKING	PHB_S3	50	75	93
769e6e2e-0d56-409b-a121-ab0cb2639ef1	WORKING	FRC_S1	50	75	93
e61646db-caf1-4659-88de-5f6c657eb2fa	WORKING	FRC_S2	50	75	93
65c2c8a0-ea8c-4246-be64-fa5402cc2a7a	WORKING	FRC_S3	50	75	93
e478fc52-bc57-47f8-aaaf-6c76be70c868	WORKING	BES_S1	50	75	93
96e51c89-8c8b-4806-a494-b2c7ddb6ace7	WORKING	BES_S2	50	75	93
9ef1da9f-bf6c-442d-8f65-9331d586d5c6	WORKING	BES_S3	50	75	93
4f127437-cfb0-4017-819c-45cf28a25951	WORKING	IAR_S1	50	75	93
6cc9b503-7843-4e1a-8dc2-dcc85f90f20e	WORKING	IAR_S2	50	75	93
57243b6e-c28b-4470-80bd-f72b1b76cfe7	WORKING	IAR_S3	50	75	93
\.


--
-- Data for Name: sdi_subdomains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_subdomains (id, domain_code, subdomain_code, subdomain_name, description, display_order, is_active, created_at, updated_at) FROM stdin;
1	ACF-01	ACF_S1	Sustained Attention	Ability to maintain focus over long periods	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
2	ACF-01	ACF_S2	Selective Attention	Filtering distractions while focusing	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
3	ACF-01	ACF_S3	Concentration Quality	Depth of focus during cognitive tasks	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
4	APO-02	APO_S1	Subject Mastery	Depth of subject-matter understanding	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
5	APO-02	APO_S2	Exam Performance	Performance under timed evaluation	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
6	APO-02	APO_S3	Consistency Across Subjects	Performance stability across subjects	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
7	BSM-03	BSM_S1	Self-Discipline	Personal discipline and rule-following	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
8	BSM-03	BSM_S2	Class Behavior	Behavior in academic settings	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
9	BSM-03	BSM_S3	Impulse Control	Ability to control impulsive behavior	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
10	EIR-04	EIR_S1	Emotional Awareness	Awareness of own emotional states	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
11	EIR-04	EIR_S2	Emotional Regulation	Managing emotional responses	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
12	EIR-04	EIR_S3	Empathy	Understanding others emotions	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
13	MHW-05	MHW_S1	Stress Management	Coping with stress and pressure	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
14	MHW-05	MHW_S2	Anxiety Levels	General anxiety and worry patterns	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
15	MHW-05	MHW_S3	Mood Stability	Emotional and mood consistency	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
16	DUD-06	DUD_S1	Screen Time Patterns	Daily screen usage patterns	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
17	DUD-06	DUD_S2	Digital Self-Regulation	Self-control with digital devices	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
18	DUD-06	DUD_S3	Online Safety Awareness	Awareness of digital safety	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
19	SCI-07	SCI_S1	Peer Interaction	Quality of peer relationships	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
20	SCI-07	SCI_S2	Communication	Effective communication with others	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
21	SCI-07	SCI_S3	Collaboration	Working effectively in groups	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
22	HLD-08	HLD_S1	Sleep Quality	Sleep patterns and quality	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
23	HLD-08	HLD_S2	Daily Routine	Consistency of daily habits	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
24	HLD-08	HLD_S3	Time Management	Effective use of time	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
25	CAD-09	CAD_S1	Career Awareness	Understanding of career options	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
26	CAD-09	CAD_S2	Goal Clarity	Clarity on career goals	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
27	CAD-09	CAD_S3	Decision Making	Career-related decision-making ability	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
28	FED-10	FED_S1	Parent Relationship	Quality of parent-child relationship	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
29	FED-10	FED_S2	Family Support	Perceived family emotional support	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
30	FED-10	FED_S3	Home Environment	Quality of home learning environment	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
31	LCR-11	LCR_S1	Learning Speed	Speed of new information acquisition	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
32	LCR-11	LCR_S2	Comprehension	Understanding what is learned	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
33	LCR-11	LCR_S3	Retention	Long-term memory retention	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
34	CHT-12	CHT_S1	Critical Thinking	Analyzing and evaluating ideas	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
35	CHT-12	CHT_S2	Problem Solving	Approach to complex problems	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
36	CHT-12	CHT_S3	Creativity	Creative thinking and idea generation	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
37	PAI-13	PAI_S1	Parental Involvement	Engagement in child education	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
38	PAI-13	PAI_S2	Discipline Style	Approach to discipline	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
39	PAI-13	PAI_S3	Communication with Child	Quality of parent-child communication	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
40	EEI-14	EEI_S1	Teacher Quality	Quality of teaching and instruction	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
41	EEI-14	EEI_S2	School Climate	Overall school atmosphere	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
42	EEI-14	EEI_S3	Peer Environment	Peer environment at school	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
43	PHB-15	PHB_S1	Physical Activity	Regular physical activity levels	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
44	PHB-15	PHB_S2	Nutrition	Quality of diet and nutrition	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
45	PHB-15	PHB_S3	Energy Levels	Daily energy and stamina	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
46	FRC-16	FRC_S1	Adaptability	Adapting to new situations	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
47	FRC-16	FRC_S2	Innovation	Creative problem-solving	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
48	FRC-16	FRC_S3	Curiosity	Drive to learn new things	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
49	BES-17	BES_S1	Exam Strategy	Effective exam-taking strategies	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
50	BES-17	BES_S2	Time Management	Managing time during exams	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
51	BES-17	BES_S3	Stress Under Pressure	Handling exam pressure	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
52	IAR-18	IAR_S1	Learning Gap Recovery	Recovering from learning gaps	1	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
53	IAR-18	IAR_S2	Improvement Strategy	Strategy for academic improvement	2	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
54	IAR-18	IAR_S3	Persistence	Persistence after setbacks	3	t	2026-05-01 15:06:22.727416	2026-05-01 15:06:22.727416
\.


--
-- Data for Name: sdi_user_responses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_user_responses (id, user_id, item_id, option_id, score_obtained, time_taken, created_at) FROM stdin;
\.


--
-- Data for Name: sdi_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdi_versions (id, version, label, notes, changed_by, change_summary, created_at) FROM stdin;
962377b9-6b71-4884-b320-d89ec551c475	1	v1.0 — SDI baseline	Auto-created with parity migration	\N	{"norms": 324, "stages": 6, "domains": 18, "weights": 324, "subdomains": 54}	2026-05-01 15:18:40.163873
\.


--
-- Data for Name: security_configurations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.security_configurations (id, config_key, config_value, config_type, description, is_encrypted, compliance_framework, last_modified_by, last_modified_at, created_at) FROM stdin;
\.


--
-- Data for Name: security_incidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.security_incidents (id, incident_code, incident_type, severity, status, title, description, affected_systems, affected_users, detected_at, detected_by, contained_at, resolved_at, root_cause, remediation_steps, preventive_measures, assigned_to, escalated_to, notifications_sent, compliance_impact, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: staff_batch_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff_batch_assignments (id, staff_id, batch_id, subject_id, is_primary, status, created_at) FROM stdin;
\.


--
-- Data for Name: staff_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff_roles (id, role_name, role_code, permissions, description, status, created_at) FROM stdin;
\.


--
-- Data for Name: stage_competency_norms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stage_competency_norms (id, stage_code, competency_id, min_score, median_score, top10_score) FROM stdin;
f5d99692-90f4-43f1-85d6-9122b7661483	FRESHER	e2b719b0-522d-47f1-bd1e-c13a44465b49	25	45	75
39a7411c-e208-403a-8b8a-4be577085b76	JR	e2b719b0-522d-47f1-bd1e-c13a44465b49	35	55	82
32806238-0286-4bde-9de2-d067d8960d19	MID	e2b719b0-522d-47f1-bd1e-c13a44465b49	45	65	88
8d8eedae-31f0-4af7-9475-e66b6107e3c0	SR	e2b719b0-522d-47f1-bd1e-c13a44465b49	55	72	92
22413478-9d31-48aa-847e-8bb08391f689	EXEC	e2b719b0-522d-47f1-bd1e-c13a44465b49	60	78	95
eb8696d2-864b-4af6-b642-dea616cd8ec3	FRESHER	ae9dbf32-0f4a-4924-9b2e-905750982ede	25	45	75
dfa5fffb-d36f-41e5-900e-f596f1525936	JR	ae9dbf32-0f4a-4924-9b2e-905750982ede	35	55	82
aea6214a-9bc3-487a-870b-cdc5ac1ae7d7	MID	ae9dbf32-0f4a-4924-9b2e-905750982ede	45	65	88
643e8c13-c2ac-4a6e-a5de-3fcc132a713e	SR	ae9dbf32-0f4a-4924-9b2e-905750982ede	55	72	92
bac17b3b-dcf4-4468-bfbf-473d42d369f8	EXEC	ae9dbf32-0f4a-4924-9b2e-905750982ede	60	78	95
a6c6dafb-5f0b-4f7f-980c-43dd3b777a2b	FRESHER	cc112339-7074-4598-9935-cbe47fa7a404	25	45	75
168d10eb-fe09-4f67-93e1-ecaace9bf900	JR	cc112339-7074-4598-9935-cbe47fa7a404	35	55	82
66041bee-d26d-4e52-b6d7-70d499ae24d4	MID	cc112339-7074-4598-9935-cbe47fa7a404	45	65	88
78181c01-ecb1-4edf-9dad-9bc82422bd7a	SR	cc112339-7074-4598-9935-cbe47fa7a404	55	72	92
1f4ee384-e41d-4df8-be52-fba84578c913	EXEC	cc112339-7074-4598-9935-cbe47fa7a404	60	78	95
a2f6623a-5d14-4c8b-8ade-1c5f3a78c8b8	FRESHER	7271fa08-e44a-403a-b149-9d13e0f3688b	25	45	75
a2620f88-e419-4c33-a48b-911abb70def4	JR	7271fa08-e44a-403a-b149-9d13e0f3688b	35	55	82
7da939cf-16fa-4203-a720-218407f0ee52	MID	7271fa08-e44a-403a-b149-9d13e0f3688b	45	65	88
6ede6dc8-2529-46a0-a215-f3c40250501b	SR	7271fa08-e44a-403a-b149-9d13e0f3688b	55	72	92
49f04600-d76e-4ffd-bc2a-64ea4e8304a1	EXEC	7271fa08-e44a-403a-b149-9d13e0f3688b	60	78	95
5b2e902d-ccd1-44ae-8ba3-b2a6e6f28e67	FRESHER	f8c00def-9a89-48e8-b2ae-72259b14d366	25	45	75
f1a3f74d-d28e-4831-8b4e-95d157fa7927	JR	f8c00def-9a89-48e8-b2ae-72259b14d366	35	55	82
0812cb82-2d20-4318-a9fe-c760533f3cc9	MID	f8c00def-9a89-48e8-b2ae-72259b14d366	45	65	88
55cbaed5-c91b-4f39-a482-4e22aec39189	SR	f8c00def-9a89-48e8-b2ae-72259b14d366	55	72	92
a39c2feb-5374-4cc4-bcec-a1467f669dd7	EXEC	f8c00def-9a89-48e8-b2ae-72259b14d366	60	78	95
c0857166-8a39-400e-ae8d-90ff443777d1	FRESHER	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	25	45	75
3119dc9d-f969-432a-af23-82e873f56bf0	JR	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	35	55	82
95b1823f-ca64-4c95-af20-d7c76e1eb478	MID	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	45	65	88
f6b1293a-933b-4432-ae19-fc11517fc202	SR	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	55	72	92
8b3f33a6-16ed-436a-a0af-8f61bff73755	EXEC	3ac70e4c-4064-4d58-8525-c7c2ea8b9ac5	60	78	95
e67a9a23-eef0-4bb4-95fb-fd4d5afb9d2b	FRESHER	4d6c9473-f695-4211-ab51-d1356b090bf4	25	45	75
a23d51e3-1751-42a7-9ee5-3a0580bc1b23	JR	4d6c9473-f695-4211-ab51-d1356b090bf4	35	55	82
6c1ea844-f23e-43d8-b4a8-646e3a3ac974	MID	4d6c9473-f695-4211-ab51-d1356b090bf4	45	65	88
863b4f60-11d2-4b9a-b27e-aa1e14e79b33	SR	4d6c9473-f695-4211-ab51-d1356b090bf4	55	72	92
3e802f4b-5359-4aab-9213-b7cb71bdfc43	EXEC	4d6c9473-f695-4211-ab51-d1356b090bf4	60	78	95
cf481126-671c-47fd-ae39-4866e0901e55	FRESHER	6ca14809-7aca-4b68-abf6-ea3e9370a580	25	45	75
02cf500e-4450-40c9-9e76-3c4312431a3b	JR	6ca14809-7aca-4b68-abf6-ea3e9370a580	35	55	82
1227ce7a-74c3-4e09-a169-799ac6931276	MID	6ca14809-7aca-4b68-abf6-ea3e9370a580	45	65	88
d485977e-facc-4cdf-b034-6a4ba1a0950a	SR	6ca14809-7aca-4b68-abf6-ea3e9370a580	55	72	92
6bbc8451-5f53-4455-aea6-12676ccd1366	EXEC	6ca14809-7aca-4b68-abf6-ea3e9370a580	60	78	95
c258eb3b-1472-449d-a6c9-7acd47f383fe	FRESHER	e8fd5615-1881-4dcc-bd44-cd29674d3885	25	45	75
61ebc892-2675-488f-a00b-b2dfbae21669	JR	e8fd5615-1881-4dcc-bd44-cd29674d3885	35	55	82
7b5183f5-c2c6-4304-8841-08a407849b59	MID	e8fd5615-1881-4dcc-bd44-cd29674d3885	45	65	88
0230fcb7-0fa6-4f9a-ad8b-f4d6ec4fd2ca	SR	e8fd5615-1881-4dcc-bd44-cd29674d3885	55	72	92
43dac83c-2f00-4e7b-9e08-11ac93025c8e	EXEC	e8fd5615-1881-4dcc-bd44-cd29674d3885	60	78	95
881c475d-67d5-44f4-96bb-d10137502e6f	FRESHER	b780467e-639b-4507-991b-eb860e7b68bf	25	45	75
5afaf119-895b-4715-bc42-73ecab1ac2c4	JR	b780467e-639b-4507-991b-eb860e7b68bf	35	55	82
246610b0-7faf-4b10-9300-e76b475be7b4	MID	b780467e-639b-4507-991b-eb860e7b68bf	45	65	88
efbbab3a-4806-4957-840c-e06ec803db12	SR	b780467e-639b-4507-991b-eb860e7b68bf	55	72	92
7f633c14-be42-446d-bb59-acba9661c751	EXEC	b780467e-639b-4507-991b-eb860e7b68bf	60	78	95
67e14e56-4866-4463-b370-0cc905ffc19b	FRESHER	1fc73df2-2590-4284-8aa3-dca7dd802fcd	25	45	75
4094b26e-1e10-48e5-b1ab-314493d50533	JR	1fc73df2-2590-4284-8aa3-dca7dd802fcd	35	55	82
7784c5e5-4e04-4a4e-b431-c5465921ccb1	MID	1fc73df2-2590-4284-8aa3-dca7dd802fcd	45	65	88
3d63ee44-7dec-41f1-871a-a63a156ea5ac	SR	1fc73df2-2590-4284-8aa3-dca7dd802fcd	55	72	92
8a299a4b-de04-47e4-8933-2d6f0557b793	EXEC	1fc73df2-2590-4284-8aa3-dca7dd802fcd	60	78	95
eddf6895-02e2-4b57-b403-f53ec0fec2bd	FRESHER	99390c52-0291-4018-88d4-81a4a4da81e6	25	45	75
aca3d366-da4c-4019-b90c-c464effa39e1	JR	99390c52-0291-4018-88d4-81a4a4da81e6	35	55	82
35bd340a-8beb-4f57-9147-774b95fda983	MID	99390c52-0291-4018-88d4-81a4a4da81e6	45	65	88
419c6cfc-10e2-4edd-aac3-6b5b0ac635b0	SR	99390c52-0291-4018-88d4-81a4a4da81e6	55	72	92
2cd0915c-f7f1-4fb2-9bfa-df5eb069dee5	EXEC	99390c52-0291-4018-88d4-81a4a4da81e6	60	78	95
7c4c1647-e95a-4562-9743-1fead2df19d9	FRESHER	a3a8013e-f8ae-4887-96c7-2895f8ab481f	25	45	75
12f6ee03-c5c1-4fbe-a090-82fb666a935b	JR	a3a8013e-f8ae-4887-96c7-2895f8ab481f	35	55	82
be86d33f-d56f-4073-9a91-2aa04afbb862	MID	a3a8013e-f8ae-4887-96c7-2895f8ab481f	45	65	88
426ef4f9-dd23-4fd7-8d56-aefe3912af6e	SR	a3a8013e-f8ae-4887-96c7-2895f8ab481f	55	72	92
ab6086cc-cc04-44c0-bf71-b47cdb02658f	EXEC	a3a8013e-f8ae-4887-96c7-2895f8ab481f	60	78	95
7170267a-4cbe-4dfc-9d54-00b855fa3a5a	FRESHER	8d5cd822-b4ae-489a-992c-9b5ac87a6105	25	45	75
01aaadd2-51e7-4e3b-b6d9-281dd81489cf	JR	8d5cd822-b4ae-489a-992c-9b5ac87a6105	35	55	82
47a6168a-47e9-4852-88cc-a6a720578f38	MID	8d5cd822-b4ae-489a-992c-9b5ac87a6105	45	65	88
b17dd619-190f-41a8-8f49-f64b42a31b3a	SR	8d5cd822-b4ae-489a-992c-9b5ac87a6105	55	72	92
e1c38b72-9b34-4108-84d8-ce27457802b1	EXEC	8d5cd822-b4ae-489a-992c-9b5ac87a6105	60	78	95
78c9eeeb-f2f3-43ae-ba89-9feb7170c719	FRESHER	d7525db7-8927-4459-bfa1-ab274367f8df	25	45	75
88331f0a-6901-4eb7-b5f0-60ed3ea88266	JR	d7525db7-8927-4459-bfa1-ab274367f8df	35	55	82
4728dd95-aee7-4732-9691-84061ad50e7f	MID	d7525db7-8927-4459-bfa1-ab274367f8df	45	65	88
ab7ecaaa-7f4d-4398-a2fa-b4f264d5a9f4	SR	d7525db7-8927-4459-bfa1-ab274367f8df	55	72	92
57cca85e-15c2-46a6-a1fc-d695c567dbf3	EXEC	d7525db7-8927-4459-bfa1-ab274367f8df	60	78	95
23ae115b-f6fa-4856-9943-dd725923edfc	FRESHER	de0175d7-42d0-4d86-88b5-8e6d618be96a	25	45	75
5e693b52-c7dc-496b-9ad0-93c1872117fc	JR	de0175d7-42d0-4d86-88b5-8e6d618be96a	35	55	82
b06ef1f4-827f-443f-943c-8e3cb8799a21	MID	de0175d7-42d0-4d86-88b5-8e6d618be96a	45	65	88
01cdf32b-182c-40fb-9c27-106d9087da09	SR	de0175d7-42d0-4d86-88b5-8e6d618be96a	55	72	92
b8fced56-502b-4abd-ad59-3a5552669d6f	EXEC	de0175d7-42d0-4d86-88b5-8e6d618be96a	60	78	95
72dac601-d8a6-4e2f-9c55-053af28f9038	FRESHER	8d4de2da-6e42-40fc-aa60-0d002fd26948	25	45	75
c11d7532-9ee7-4dd4-82e3-49dfe9197637	JR	8d4de2da-6e42-40fc-aa60-0d002fd26948	35	55	82
b61ea922-ed7f-4f76-912d-0611a7a29e16	MID	8d4de2da-6e42-40fc-aa60-0d002fd26948	45	65	88
4eab03d1-1df8-49f8-8c55-31b5734fb657	SR	8d4de2da-6e42-40fc-aa60-0d002fd26948	55	72	92
d2d72b10-252e-4234-b65f-6e26f3182555	EXEC	8d4de2da-6e42-40fc-aa60-0d002fd26948	60	78	95
5a3f3a66-05c7-423a-a10b-4e847acbe6c6	FRESHER	bf81449b-f2f4-4ee2-9281-e56273b096a7	25	45	75
d7dde282-ea08-4ec5-b6ec-330ac6a26857	JR	bf81449b-f2f4-4ee2-9281-e56273b096a7	35	55	82
c8ee63cd-1655-49da-82ce-97f8521e7f10	MID	bf81449b-f2f4-4ee2-9281-e56273b096a7	45	65	88
89d3bba9-d493-4bf8-83ea-88096dc25c2e	SR	bf81449b-f2f4-4ee2-9281-e56273b096a7	55	72	92
03b73ec0-468f-4d59-a19f-da6fe3edc859	EXEC	bf81449b-f2f4-4ee2-9281-e56273b096a7	60	78	95
89ce5881-ea29-4854-a8cf-63263ab2fc10	FRESHER	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	25	45	75
d6833089-bd95-4796-907e-e40b7872dae8	JR	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	35	55	82
7af4c218-469c-4fb8-aa68-5bbecc47f65d	MID	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	45	65	88
a8824111-c984-47ed-a764-f8fab6b0e2c9	SR	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	55	72	92
71e1940f-359c-4ad2-999c-ffc8179e7733	EXEC	b3b99b67-4747-4943-8f79-e5ec1e0b6d20	60	78	95
f8d93076-a51d-4918-88b9-2564236e5d6f	FRESHER	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	25	45	75
1ab53495-c8a1-4720-a145-d8bd85f926fc	JR	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	35	55	82
20503f5d-60b6-4c5f-9219-d9b388d05331	MID	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	45	65	88
75f1bc82-d22d-4915-b146-f136c6dde96a	SR	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	55	72	92
ed4f1897-5106-41f3-9ae0-283cce21e653	EXEC	a0d4e97b-dfe8-487b-9d15-ad646febb8ff	60	78	95
a9db0534-102e-4a9e-9c74-eafb245028cf	FRESHER	cf5a6ec2-d6c0-42af-b554-8787ae398127	25	45	75
282883aa-e75a-4990-8b5c-6f3ed354997c	JR	cf5a6ec2-d6c0-42af-b554-8787ae398127	35	55	82
282bbde7-30b3-4bd0-8be3-b15844ae083b	MID	cf5a6ec2-d6c0-42af-b554-8787ae398127	45	65	88
460df934-442f-44d4-a01c-80abe2ba71f1	SR	cf5a6ec2-d6c0-42af-b554-8787ae398127	55	72	92
0514a952-b4f8-476f-a9db-42e2d79721d6	EXEC	cf5a6ec2-d6c0-42af-b554-8787ae398127	60	78	95
7e3bb8ff-5dec-42df-af4a-e1546c11ae70	FRESHER	4fffa5ac-3619-4097-8895-be009f4aabd6	25	45	75
a0cc8f23-ab68-4258-b466-9dfa84ac4ac4	JR	4fffa5ac-3619-4097-8895-be009f4aabd6	35	55	82
c02b1871-83dd-4a0c-82bd-26e2a4232451	MID	4fffa5ac-3619-4097-8895-be009f4aabd6	45	65	88
81fa2bcd-1884-4d5b-9cb4-abcf7d73dc33	SR	4fffa5ac-3619-4097-8895-be009f4aabd6	55	72	92
11072cf7-f91e-4a9c-97ce-1b4fa9d4473f	EXEC	4fffa5ac-3619-4097-8895-be009f4aabd6	60	78	95
775d15b7-65fe-4c25-b8c1-bb2e11be3c4e	FRESHER	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	25	45	75
13ccedd6-45ec-4b37-860b-bf19e379e4dd	JR	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	35	55	82
c8bc5718-6ab3-4308-8f78-0a835ba04256	MID	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	45	65	88
e32bfd91-15f7-4de2-a964-8fc04db1245e	SR	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	55	72	92
ebfcc048-eedc-45d0-8cea-a8c61f9b9dd1	EXEC	d2b166fa-8308-4de2-88e7-c56fb2bf42a1	60	78	95
96ececc1-6d63-49f4-8590-b8be68ee91c3	FRESHER	214c70ad-0444-4973-92ba-1ee8991ebf23	25	45	75
96160e11-933b-42da-a91e-9d8aebe25aed	JR	214c70ad-0444-4973-92ba-1ee8991ebf23	35	55	82
a0e1d7f5-a6ee-47d5-be63-d6690fe5593b	MID	214c70ad-0444-4973-92ba-1ee8991ebf23	45	65	88
7f1d7ecb-10fb-4795-8ffe-926ebb1978c1	SR	214c70ad-0444-4973-92ba-1ee8991ebf23	55	72	92
6abb2568-df0a-4053-a143-f2bcc015f36b	EXEC	214c70ad-0444-4973-92ba-1ee8991ebf23	60	78	95
e3003e67-8960-46cd-aaab-af2e1990ead4	FRESHER	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	25	45	75
3b37150f-723b-4c00-869e-4810face0626	JR	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	35	55	82
3514dd66-0a2c-44d6-9d92-a8cbcdfe222c	MID	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	45	65	88
9afd12a8-dca8-4441-a0c1-d56351ef59f5	SR	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	55	72	92
75fcb360-7702-4d79-add2-7cc479764d06	EXEC	9e34db04-5933-47c9-bd3f-6b5b34d6bc69	60	78	95
81227989-0513-4891-a4fe-6c14a98f3621	FRESHER	5a44cbd3-272e-44ee-a983-c53f268e38a2	25	45	75
7babe309-a0d5-4c35-9869-5e6d54d6ba5f	JR	5a44cbd3-272e-44ee-a983-c53f268e38a2	35	55	82
9ef1f97d-8b7f-41aa-97cc-6f61f072e44c	MID	5a44cbd3-272e-44ee-a983-c53f268e38a2	45	65	88
905c2845-1e20-4ef2-951c-7758523ea8cc	SR	5a44cbd3-272e-44ee-a983-c53f268e38a2	55	72	92
47af8841-f39f-4914-9abb-f5187fb4e43c	EXEC	5a44cbd3-272e-44ee-a983-c53f268e38a2	60	78	95
cb8ddc18-c0bf-47b2-a1fb-fe4e125045ef	FRESHER	ba4d5a0b-de42-4777-9f17-b440d557a612	25	45	75
76bdac33-3ee9-4bc1-85ab-4116648ec3e2	JR	ba4d5a0b-de42-4777-9f17-b440d557a612	35	55	82
4858090c-185c-47cd-a8e5-f73b3ee8d456	MID	ba4d5a0b-de42-4777-9f17-b440d557a612	45	65	88
cb9e3115-7fb1-480e-b462-0d7bec552a1a	SR	ba4d5a0b-de42-4777-9f17-b440d557a612	55	72	92
bdb78691-9f02-494c-a742-bc5b6015a546	EXEC	ba4d5a0b-de42-4777-9f17-b440d557a612	60	78	95
d618db0c-bb6f-4034-8905-2062a9e15cbc	FRESHER	a34a79c2-cde4-4893-a47b-a76b77713445	25	45	75
93cc5fe8-7974-462d-ad93-49bdcfda93b3	JR	a34a79c2-cde4-4893-a47b-a76b77713445	35	55	82
05174e6c-7f31-4d9f-988d-5dd0441ea80b	MID	a34a79c2-cde4-4893-a47b-a76b77713445	45	65	88
39b77996-95ea-4ebc-b825-481fefcd0a10	SR	a34a79c2-cde4-4893-a47b-a76b77713445	55	72	92
324fe622-abae-4c97-b79c-70379b7d4826	EXEC	a34a79c2-cde4-4893-a47b-a76b77713445	60	78	95
ceacd6fb-fa6c-427c-b7a9-609f7dbbfcb6	FRESHER	bc5c127d-fcc1-4d0e-9751-6f227917585b	25	45	75
4f73d9dd-60a6-40bc-b26d-a1ad8aa34c99	JR	bc5c127d-fcc1-4d0e-9751-6f227917585b	35	55	82
3d3d8ede-13af-48ab-b90c-81a30104e7db	MID	bc5c127d-fcc1-4d0e-9751-6f227917585b	45	65	88
d6e8a663-e041-4031-a6c8-ed7cfe431a2c	SR	bc5c127d-fcc1-4d0e-9751-6f227917585b	55	72	92
5fcacd6f-bdc7-4354-96de-bf4f366ae2f4	EXEC	bc5c127d-fcc1-4d0e-9751-6f227917585b	60	78	95
0a1317ec-7e1a-4b8e-9add-71b462db537d	FRESHER	0f7f4297-1de4-48fc-8497-2e0c797494fa	25	45	75
134f3e41-f434-40cc-a090-884a47419ac3	JR	0f7f4297-1de4-48fc-8497-2e0c797494fa	35	55	82
1189b6d1-2031-4c88-8784-94bfa5c6c191	MID	0f7f4297-1de4-48fc-8497-2e0c797494fa	45	65	88
58ba4eaf-05aa-4541-bbdd-f8fae95bcd82	SR	0f7f4297-1de4-48fc-8497-2e0c797494fa	55	72	92
95eb7c73-e3d4-4147-96f1-7fbf5f359e10	EXEC	0f7f4297-1de4-48fc-8497-2e0c797494fa	60	78	95
3081626e-a8cc-4ce4-9fd7-216a34e05158	FRESHER	2657d0bc-b2d9-4282-9789-0a633a41b160	25	45	75
c46bfd82-48ae-4dfa-98d2-c94f65a15524	JR	2657d0bc-b2d9-4282-9789-0a633a41b160	35	55	82
2325b5ce-4987-42c4-b8a4-264acc242b73	MID	2657d0bc-b2d9-4282-9789-0a633a41b160	45	65	88
f35d6401-d276-4cb9-94ec-ee842dec53b7	SR	2657d0bc-b2d9-4282-9789-0a633a41b160	55	72	92
72e26601-5038-4400-aa95-8228c63ee07b	EXEC	2657d0bc-b2d9-4282-9789-0a633a41b160	60	78	95
86c2a282-4dc3-4557-a9ff-fd7819bdf799	FRESHER	5ca7c62a-f414-4798-91a3-c07be84e6a45	25	45	75
6d053843-fd40-495f-b002-a199dfc140d4	JR	5ca7c62a-f414-4798-91a3-c07be84e6a45	35	55	82
b0182628-dc7a-479e-bef4-c440ea3acaf4	MID	5ca7c62a-f414-4798-91a3-c07be84e6a45	45	65	88
d705901e-a848-4680-b103-507a715de2ae	SR	5ca7c62a-f414-4798-91a3-c07be84e6a45	55	72	92
a621922c-5c9d-4298-819a-497e40f10db2	EXEC	5ca7c62a-f414-4798-91a3-c07be84e6a45	60	78	95
2591d085-7240-475e-a857-ef5bc77bc889	FRESHER	b97e2925-e046-4fb1-9634-db85e2aa19fe	25	45	75
1769011d-24c5-4c02-83f5-9999801d3a9a	JR	b97e2925-e046-4fb1-9634-db85e2aa19fe	35	55	82
c1e8db77-8fec-42ac-8f19-b86e285e5150	MID	b97e2925-e046-4fb1-9634-db85e2aa19fe	45	65	88
c8796c5e-8ec9-4c16-a416-02232376ec18	SR	b97e2925-e046-4fb1-9634-db85e2aa19fe	55	72	92
4286a14f-008c-4396-aad5-6c7aa2903723	EXEC	b97e2925-e046-4fb1-9634-db85e2aa19fe	60	78	95
3e0a8fd3-7e09-4e34-9697-e032f8112bb5	FRESHER	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	25	45	75
da9024f8-8505-40cb-9619-684605251fff	JR	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	35	55	82
dace151b-713a-482d-900c-b24493eac084	MID	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	45	65	88
9333d4c9-95d9-48d6-af1e-45b33bb62eda	SR	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	55	72	92
d0361f94-43d2-4ce1-a162-7b116cd00ffb	EXEC	6fe50eb1-8338-4de7-bd6c-31c55dc48c66	60	78	95
d55aa1e1-0669-4eb5-b1b4-355d572e050c	FRESHER	11c5184b-9c1b-4e60-a370-b68a68091bdf	25	45	75
c1187933-d64b-40e4-8d68-cabe6e97f490	JR	11c5184b-9c1b-4e60-a370-b68a68091bdf	35	55	82
fdcc4b89-1c40-4411-b797-d50464510d30	MID	11c5184b-9c1b-4e60-a370-b68a68091bdf	45	65	88
dd5070cc-342c-457a-97b3-5cdd7f5fee1e	SR	11c5184b-9c1b-4e60-a370-b68a68091bdf	55	72	92
56746228-f35d-4fb6-978e-f10cfcfb0b8f	EXEC	11c5184b-9c1b-4e60-a370-b68a68091bdf	60	78	95
288478b5-bdbc-4fb1-b9b1-e87ba734155b	FRESHER	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	25	45	75
950f939c-4b5a-48bf-b75a-d91750c7999e	JR	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	35	55	82
287c0e7e-fd31-45c9-9d0f-06d47ae7fd0e	MID	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	45	65	88
b065f2f6-5ae6-41c5-969d-e98eae225d1d	SR	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	55	72	92
bc7bf9ac-1cf0-4033-a01d-256e03d5dd91	EXEC	23b18e24-73b6-4a39-ac25-6a4ee1734fd7	60	78	95
07a2fd2f-b9ca-4352-9056-25898a6b36cc	FRESHER	15663cfd-4327-4d0f-9398-57344ccf0884	25	45	75
1e1ad4e2-4be1-4b81-96f1-6190fa8f0cd5	JR	15663cfd-4327-4d0f-9398-57344ccf0884	35	55	82
bbbdba33-44d2-4367-8a33-0028179db9bf	MID	15663cfd-4327-4d0f-9398-57344ccf0884	45	65	88
f3b44c71-4007-449e-abc3-9542966bac6e	SR	15663cfd-4327-4d0f-9398-57344ccf0884	55	72	92
f8cc25d7-1b83-4f59-a8a1-7917d7dc8564	EXEC	15663cfd-4327-4d0f-9398-57344ccf0884	60	78	95
15e9ad96-9fae-47b3-8b4c-6aebeb79e375	FRESHER	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	25	45	75
6dc7f6c9-f2b3-4721-8a32-8576b3a67249	JR	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	35	55	82
20d3f923-72bd-4e22-8d90-abf82ec9e8b9	MID	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	45	65	88
e4278af9-982d-4d03-8690-0cc2d4bb53cd	SR	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	55	72	92
5ab962ff-0399-404a-aa5c-be4bfddad717	EXEC	d6ccb117-1aa2-4a67-86af-b2d15c17c7b4	60	78	95
14b5813f-a58e-42fb-84a2-0f489202b67c	FRESHER	0aed465c-8ea1-4422-b633-0aad6ca4324d	25	45	75
7a858879-c554-423c-a6b8-f0a72029f055	JR	0aed465c-8ea1-4422-b633-0aad6ca4324d	35	55	82
9cd3aece-671a-4056-afac-9d551941f06f	MID	0aed465c-8ea1-4422-b633-0aad6ca4324d	45	65	88
f198e0c0-ee28-47c8-b191-7f6fbb163eba	SR	0aed465c-8ea1-4422-b633-0aad6ca4324d	55	72	92
0ffb6f3f-a955-440e-a6d4-c2eb8807540e	EXEC	0aed465c-8ea1-4422-b633-0aad6ca4324d	60	78	95
13f4d845-4558-4912-881f-dc57c308d77e	FRESHER	02c9688e-2900-4b9d-af2b-f652e20b22f9	25	45	75
445ec9f0-8acc-40f0-8452-3ebc6bb1fcb9	JR	02c9688e-2900-4b9d-af2b-f652e20b22f9	35	55	82
d8f799a0-accd-4ff6-89d4-be4ffc70ce1c	MID	02c9688e-2900-4b9d-af2b-f652e20b22f9	45	65	88
a9c41176-713c-42af-bd45-8d93a11cd66d	SR	02c9688e-2900-4b9d-af2b-f652e20b22f9	55	72	92
1e35a724-2b58-4889-be19-e319c6f7308d	EXEC	02c9688e-2900-4b9d-af2b-f652e20b22f9	60	78	95
20a6b778-1eb0-49bf-a10f-4a8a2c65f922	FRESHER	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	25	45	75
c2643d20-37b1-410f-9318-ad96626c7dba	JR	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	35	55	82
ad815612-a546-4c6e-8467-cfa55a76c24c	MID	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	45	65	88
eefd37c4-90d7-4d49-8be8-fa0d47e74685	SR	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	55	72	92
df34482f-0d59-4a20-8643-facadc0e5627	EXEC	87e2d09c-573d-4ef1-9eb7-f445cffdf2ec	60	78	95
eaa52dba-3836-4f7a-b67a-2b15d6c80f7a	FRESHER	229abe94-2a63-4b86-810d-d247f4b312bc	25	45	75
9201edd7-ea0a-45d5-8e8c-dcde09d7697f	JR	229abe94-2a63-4b86-810d-d247f4b312bc	35	55	82
4c5bb6dc-f709-462a-b891-a1ad659ddc29	MID	229abe94-2a63-4b86-810d-d247f4b312bc	45	65	88
af299400-567b-4139-a818-916a633af9b7	SR	229abe94-2a63-4b86-810d-d247f4b312bc	55	72	92
077b9f84-27b2-4da5-8daa-ffcfbfe30fec	EXEC	229abe94-2a63-4b86-810d-d247f4b312bc	60	78	95
f0c36152-b4cc-4867-8ef1-7bcf2fbccd8e	FRESHER	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	25	45	75
5069bef6-9e4b-4a34-97e6-3e316f065634	JR	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	35	55	82
3759e55d-01b8-4688-baea-d78dd5f1984e	MID	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	45	65	88
6496c419-1935-46ad-8d2a-452179a1bc28	SR	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	55	72	92
5689efb6-1577-4231-88cf-1f6e4021551d	EXEC	e0430763-95fc-4ec7-bba6-75dc1fdb5cc5	60	78	95
e1a7f69a-8fe4-4497-8086-8c4595888676	FRESHER	68a8270d-3c39-4147-8238-df60a0b0b876	25	45	75
34b78ad5-3c06-4d7d-b4a3-6b2dbb418898	JR	68a8270d-3c39-4147-8238-df60a0b0b876	35	55	82
4bf51208-a723-4199-9452-9961a72433dd	MID	68a8270d-3c39-4147-8238-df60a0b0b876	45	65	88
24bbba4e-8839-40c0-b54f-552d9b7d9bcf	SR	68a8270d-3c39-4147-8238-df60a0b0b876	55	72	92
7893e8ed-118f-4153-9a55-4dceed67ede9	EXEC	68a8270d-3c39-4147-8238-df60a0b0b876	60	78	95
d1a33a3e-dddd-40e7-bca7-bd398d1fef59	FRESHER	edea5550-5eaa-4655-b4f1-7233774a6a7c	25	45	75
765f1145-7ba9-4adc-812f-45cc17c04b3c	JR	edea5550-5eaa-4655-b4f1-7233774a6a7c	35	55	82
6aad70ce-f81f-4ec1-af8e-cfc5bdbf9075	MID	edea5550-5eaa-4655-b4f1-7233774a6a7c	45	65	88
83081f66-994a-470e-9027-cf6c2c7d576a	SR	edea5550-5eaa-4655-b4f1-7233774a6a7c	55	72	92
9b5be367-afa1-437c-b8e6-fe03275391df	EXEC	edea5550-5eaa-4655-b4f1-7233774a6a7c	60	78	95
47499d1a-91d2-4775-b6e1-a5585f4be0b8	FRESHER	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	25	45	75
3c8663f2-f1f4-430d-b58d-0a8366bcb0ec	JR	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	35	55	82
1e2e9f81-3678-47ba-87ee-536f55a9b818	MID	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	45	65	88
844a8723-7a22-4468-85a0-ad5c3ebf3b0b	SR	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	55	72	92
523e9852-a665-4936-81ba-b21bb179bf2f	EXEC	592e6a6a-4f0a-4505-b55f-1e3cce4e11cc	60	78	95
a2538794-921c-4e9b-9884-cfab61d29d16	FRESHER	af883093-9f75-4ba7-82bd-d01ea45888b0	25	45	75
b3237e10-9696-497c-9524-e2964e084c03	JR	af883093-9f75-4ba7-82bd-d01ea45888b0	35	55	82
100a61d6-9a85-41ae-ac4c-610551e7f910	MID	af883093-9f75-4ba7-82bd-d01ea45888b0	45	65	88
5726d6dc-6571-4f16-be3f-2c0d2d8dfe1a	SR	af883093-9f75-4ba7-82bd-d01ea45888b0	55	72	92
a6a23bb1-2c2d-44ad-9b99-fc4eb3745311	EXEC	af883093-9f75-4ba7-82bd-d01ea45888b0	60	78	95
f90e3402-8ee1-4f01-bdff-f8fc878bbd12	FRESHER	bddab227-b2ba-421e-8f14-dad2aa12e5f6	25	45	75
5ff076e4-6017-4480-b046-f2ad66434a33	JR	bddab227-b2ba-421e-8f14-dad2aa12e5f6	35	55	82
050eba78-d778-403d-b819-a03f1352bdc4	MID	bddab227-b2ba-421e-8f14-dad2aa12e5f6	45	65	88
c05bb79e-993c-43cb-83b0-d60955cd2e36	SR	bddab227-b2ba-421e-8f14-dad2aa12e5f6	55	72	92
db7b5c41-883e-4ede-81a1-663907fbe6ec	EXEC	bddab227-b2ba-421e-8f14-dad2aa12e5f6	60	78	95
b97349cb-11d3-40f5-ac51-d711fa3d35ea	FRESHER	d98acd03-5b09-453e-bca8-960566f07c7b	25	45	75
55917c11-caa9-4128-b11f-fbe0cfe519b8	JR	d98acd03-5b09-453e-bca8-960566f07c7b	35	55	82
5f98ca94-1cd6-4c24-bf3b-66ac3e4eb7c4	MID	d98acd03-5b09-453e-bca8-960566f07c7b	45	65	88
1567eab8-fe24-44ae-a0a9-a19fd1daa2a9	SR	d98acd03-5b09-453e-bca8-960566f07c7b	55	72	92
b61b996a-2ab7-4ec2-b193-8eb116e3ee6d	EXEC	d98acd03-5b09-453e-bca8-960566f07c7b	60	78	95
3db2af77-9d9e-47c8-bf12-815b4f508c47	FRESHER	a573e600-0003-4185-a22f-3c4610414309	25	45	75
f5b55e18-0384-47e9-b4ef-921c47cb807b	JR	a573e600-0003-4185-a22f-3c4610414309	35	55	82
33120f36-aae1-48f6-80e6-40ce01dc0f46	MID	a573e600-0003-4185-a22f-3c4610414309	45	65	88
112f4132-366c-4001-b61e-865c02fac3d2	SR	a573e600-0003-4185-a22f-3c4610414309	55	72	92
4b977dc6-3bd2-4482-af7c-662187ea675b	EXEC	a573e600-0003-4185-a22f-3c4610414309	60	78	95
166f575f-bf8f-4e83-9f63-3e91a3ce192f	FRESHER	26304df3-d564-4d70-96ce-07ca92325f44	25	45	75
363d824e-e074-40fc-97ce-fee49159c1c9	JR	26304df3-d564-4d70-96ce-07ca92325f44	35	55	82
08a43c94-38b4-4046-9137-8820947d4de3	MID	26304df3-d564-4d70-96ce-07ca92325f44	45	65	88
0fb626a2-40c2-45c8-977d-bcdd5c428dab	SR	26304df3-d564-4d70-96ce-07ca92325f44	55	72	92
f790565e-d94d-4ee4-8e5f-245bcc2228c4	EXEC	26304df3-d564-4d70-96ce-07ca92325f44	60	78	95
91a119b3-f249-4fa6-826a-fe3369741d6b	FRESHER	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	25	45	75
63f5cce9-bc19-4de8-98d1-259d62d72ab8	JR	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	35	55	82
01679667-8a19-45e1-b7c4-470bd0bac2b5	MID	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	45	65	88
212ca999-719e-48ef-ba2a-0277034aa9bc	SR	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	55	72	92
57ebd857-aa60-43f5-9ef3-918396e96c2c	EXEC	d18cf0a9-2cd9-45cb-a0c2-145f2d8a53c0	60	78	95
a9e9030d-b0f9-448f-8819-eae9cd78d345	FRESHER	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	25	45	75
563bbd60-57b1-4b3a-b1b4-6cd4da8df974	JR	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	35	55	82
740e6b47-21c9-4e2d-a02d-ca17218af451	MID	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	45	65	88
98b4d0fd-5326-4e66-b94b-2f7e6c47a2a0	SR	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	55	72	92
a258d0fe-649e-4367-90ff-07420c5e7128	EXEC	52a1cbfc-99d5-44d5-8b7b-882efa02e4aa	60	78	95
341db647-642d-4dc6-a83d-0dfbcecbb602	FRESHER	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	25	45	75
fd8ec0fa-d990-4061-8963-7842e7cf80c7	JR	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	35	55	82
bfc6759c-b552-4109-83f3-b211a3c1bc2f	MID	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	45	65	88
2a9c7e61-dc14-468d-90dc-2832ba4de81b	SR	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	55	72	92
1efc81d8-6108-4466-850f-79bf58462eef	EXEC	caa13bfa-3c48-4800-b010-e7b5bb1bddbd	60	78	95
4fb5429f-285c-4c68-94e4-0be863d29745	FRESHER	ac3a9ffa-e911-4250-80ee-245231946a8d	25	45	75
2f9a5c50-c6f9-4fcf-b596-8b7b1989b7c1	JR	ac3a9ffa-e911-4250-80ee-245231946a8d	35	55	82
7df15332-12c2-491a-968b-1eeecf3c85e5	MID	ac3a9ffa-e911-4250-80ee-245231946a8d	45	65	88
7e22d0c6-f4c3-4f1d-b9f8-c7abce9b333e	SR	ac3a9ffa-e911-4250-80ee-245231946a8d	55	72	92
bde747a3-abe7-4e36-b444-a9a510951ace	EXEC	ac3a9ffa-e911-4250-80ee-245231946a8d	60	78	95
7f4532ac-dd7e-4821-8daa-01f1556ec9f2	FRESHER	bde3a934-5e03-46af-ba36-9bb1a46954f7	25	45	75
a400855a-9e1e-4339-9629-17660a853d5b	JR	bde3a934-5e03-46af-ba36-9bb1a46954f7	35	55	82
a29a402a-6e09-486c-9ea4-c763d4e30559	MID	bde3a934-5e03-46af-ba36-9bb1a46954f7	45	65	88
943a2e4e-d902-4912-976a-2864e36cdc2b	SR	bde3a934-5e03-46af-ba36-9bb1a46954f7	55	72	92
502948bd-4faf-48dd-a548-70bcfb19044d	EXEC	bde3a934-5e03-46af-ba36-9bb1a46954f7	60	78	95
e20930f1-aed8-4d08-850d-85400a4ee202	FRESHER	6386f4be-6929-4430-b13d-2b80ac8a0bdb	25	45	75
c8f5fdb7-d7e6-44ce-bea8-5b74f92744a8	JR	6386f4be-6929-4430-b13d-2b80ac8a0bdb	35	55	82
d49bbb24-ecb0-4308-a294-b3df6453af45	MID	6386f4be-6929-4430-b13d-2b80ac8a0bdb	45	65	88
b669cb48-7e85-4a39-bfee-34df9578d271	SR	6386f4be-6929-4430-b13d-2b80ac8a0bdb	55	72	92
0341adf4-4ea0-498b-afc7-ab8df4a4ebb5	EXEC	6386f4be-6929-4430-b13d-2b80ac8a0bdb	60	78	95
e84b3d2b-f1b3-4032-b918-144bfc6500bb	FRESHER	f7842945-608d-412c-b26a-fc8fa2d405e8	25	45	75
aa39f7ed-4d9f-4185-92f1-7f091df0bc3e	JR	f7842945-608d-412c-b26a-fc8fa2d405e8	35	55	82
5f92a0bd-7afa-4a1d-801c-e4e2f4651bff	MID	f7842945-608d-412c-b26a-fc8fa2d405e8	45	65	88
7f78ee29-b5b4-4ea7-9e48-82af904d2798	SR	f7842945-608d-412c-b26a-fc8fa2d405e8	55	72	92
a8120d04-32d2-40cb-9e24-9d10d18d3821	EXEC	f7842945-608d-412c-b26a-fc8fa2d405e8	60	78	95
ae72c87c-665f-4f5f-a03a-8e294bb799a6	FRESHER	2426d7dd-df6b-4654-ae51-376b0d3247e3	25	45	75
edcee86a-d44e-4013-8c95-d4a37472ba18	JR	2426d7dd-df6b-4654-ae51-376b0d3247e3	35	55	82
04037a31-dfd4-4292-a437-90440a13086d	MID	2426d7dd-df6b-4654-ae51-376b0d3247e3	45	65	88
cb7da583-507c-41e4-b3fa-caab57b8810a	SR	2426d7dd-df6b-4654-ae51-376b0d3247e3	55	72	92
cfd598ca-697c-42d5-bfbc-7f440f514b39	EXEC	2426d7dd-df6b-4654-ae51-376b0d3247e3	60	78	95
81ee0904-0c1f-467a-a43b-32474f4ffbed	FRESHER	103d92e2-1d5e-4283-8a91-718a59743655	25	45	75
860cf76f-07e9-471c-928e-9a2c5304f47f	JR	103d92e2-1d5e-4283-8a91-718a59743655	35	55	82
bc12482a-fae1-46bd-9236-972abc74b249	MID	103d92e2-1d5e-4283-8a91-718a59743655	45	65	88
d75e3b0a-f9da-48d8-9db0-6f303245b7ef	SR	103d92e2-1d5e-4283-8a91-718a59743655	55	72	92
a6d579fd-db68-41d5-8cc3-422522fa5eeb	EXEC	103d92e2-1d5e-4283-8a91-718a59743655	60	78	95
9ce9c182-f2fb-425f-9989-f523dc55dfe1	FRESHER	0bd37ca4-92b9-4931-86ff-859be789dd67	25	45	75
ce384b6c-7ffe-4231-aa8b-73be032e39d2	JR	0bd37ca4-92b9-4931-86ff-859be789dd67	35	55	82
310577ae-5b0a-4180-a82c-70bff25aece7	MID	0bd37ca4-92b9-4931-86ff-859be789dd67	45	65	88
b4e74b67-930e-4642-856e-6474d73f4707	SR	0bd37ca4-92b9-4931-86ff-859be789dd67	55	72	92
addf3d1b-dbf5-4866-bb49-f07f3f9afdbf	EXEC	0bd37ca4-92b9-4931-86ff-859be789dd67	60	78	95
bce750a4-8535-44b0-ac73-8e1c7410f707	FRESHER	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	25	45	75
2054dc8b-7c73-4280-862d-1785b4e5fabc	JR	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	35	55	82
3433c579-985a-40c1-936a-c466afa88c75	MID	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	45	65	88
1784c027-7556-43b8-ae50-c70183154df2	SR	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	55	72	92
47e862cc-d673-412a-957c-76a3d18a4e35	EXEC	f1b8cdfb-21b3-471e-ba3e-7583368e7e05	60	78	95
1ad7f0ce-f58c-442c-aebc-08fd806c2e91	FRESHER	abfe5de5-353d-4565-ae4b-a36db9884441	25	45	75
2661faf4-6cbe-4828-bea6-6895cc59c8ba	JR	abfe5de5-353d-4565-ae4b-a36db9884441	35	55	82
277748a0-91b7-46f4-85f4-0b785aad13c1	MID	abfe5de5-353d-4565-ae4b-a36db9884441	45	65	88
0973811f-7a54-4c1d-9e2b-be9139ce5107	SR	abfe5de5-353d-4565-ae4b-a36db9884441	55	72	92
ff50a1be-4fe6-465d-bc2f-bbc26be9f9d8	EXEC	abfe5de5-353d-4565-ae4b-a36db9884441	60	78	95
57279c1a-1c85-47b9-b006-07f14ff11f22	FRESHER	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	25	45	75
020641d7-841f-4fb1-b479-136d7e1a931a	JR	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	35	55	82
f95ec6ec-73f6-4b9d-b30a-52bdd35ab64d	MID	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	45	65	88
2e612129-cd12-4db9-8dbb-7a266c367a3e	SR	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	55	72	92
5d5aa050-3fa4-49d0-bb1c-65ada9b96988	EXEC	6b68a79c-e91f-49ef-8fa6-7c09ffd3366a	60	78	95
67a4400c-3f23-4c23-9f1a-eae1369ed5fc	FRESHER	86516083-311e-4cc4-9c2d-8da1035c1226	25	45	75
c516cd1d-1baa-46e3-b4b3-493401812ec9	JR	86516083-311e-4cc4-9c2d-8da1035c1226	35	55	82
2770fca6-f434-44ce-b7bb-2da7e845efbe	MID	86516083-311e-4cc4-9c2d-8da1035c1226	45	65	88
20486fb0-19d6-4c24-8221-0cdb7b66b2e8	SR	86516083-311e-4cc4-9c2d-8da1035c1226	55	72	92
1789866a-3988-43e7-a849-750abc570d85	EXEC	86516083-311e-4cc4-9c2d-8da1035c1226	60	78	95
29792349-23d9-4795-87eb-0e76ab617709	FRESHER	9e2595a9-eec4-44fe-9911-3605e2a6c27e	25	45	75
5580d67c-c712-4b74-9dba-0235f14dfe9d	JR	9e2595a9-eec4-44fe-9911-3605e2a6c27e	35	55	82
a554dfb9-46b1-4322-b848-7bf0b9447497	MID	9e2595a9-eec4-44fe-9911-3605e2a6c27e	45	65	88
d9eadf3e-2f57-4c86-a259-1f664974d1be	SR	9e2595a9-eec4-44fe-9911-3605e2a6c27e	55	72	92
4859ac54-aeab-43bd-966c-06e793b9ce59	EXEC	9e2595a9-eec4-44fe-9911-3605e2a6c27e	60	78	95
059b790a-36fe-46cc-b646-a71f79f4aab0	FRESHER	c77e5916-e12c-4142-9386-1cd156481617	25	45	75
3ff30f07-2ddd-49e2-a33e-ed029c5959b4	JR	c77e5916-e12c-4142-9386-1cd156481617	35	55	82
4617bec6-bd47-472c-932e-d3cc0835bd82	MID	c77e5916-e12c-4142-9386-1cd156481617	45	65	88
9ec5faca-0367-4b6f-8523-5555bf9d87cd	SR	c77e5916-e12c-4142-9386-1cd156481617	55	72	92
5c4d5e13-e8e5-4691-88d5-b93970cef29d	EXEC	c77e5916-e12c-4142-9386-1cd156481617	60	78	95
2e174b72-f276-4158-96a6-b79b2079d580	FRESHER	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	25	45	75
be4cd0e0-61b8-4642-8187-dd725ac32952	JR	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	35	55	82
996b4037-35bc-43e5-aac4-3fa8a00877db	MID	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	45	65	88
554f8886-ad4c-40e3-8f9a-0b3eade582b5	SR	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	55	72	92
71fd14ac-9f5b-42a1-88bc-ddebbceec62f	EXEC	dadc42b8-4473-46f7-a3c6-187dfc79dbc1	60	78	95
cdf5d1dd-b6ff-4f5c-b88a-920c12ec6f7f	FRESHER	945a4bbe-c5b6-4f55-a770-7d07b88a987e	25	45	75
e1bfffab-e7a1-45e9-8943-46206c450715	JR	945a4bbe-c5b6-4f55-a770-7d07b88a987e	35	55	82
2d2b7e45-9ed9-43e1-a204-23e16ddbb142	MID	945a4bbe-c5b6-4f55-a770-7d07b88a987e	45	65	88
b205bd08-49b0-4a5f-960e-304d14bc0c9a	SR	945a4bbe-c5b6-4f55-a770-7d07b88a987e	55	72	92
69e676f5-e564-4099-8288-ae9fe0611cf3	EXEC	945a4bbe-c5b6-4f55-a770-7d07b88a987e	60	78	95
c5570c73-bf33-4655-96c0-567bdceffa1d	FRESHER	1df38045-50e0-449b-926a-8d988ff372a5	25	45	75
617cf022-2f8b-4466-8cf1-c17f66cb38be	JR	1df38045-50e0-449b-926a-8d988ff372a5	35	55	82
d7a9753e-c9f7-4c48-810b-9a10148b21c5	MID	1df38045-50e0-449b-926a-8d988ff372a5	45	65	88
70789bc6-eb4f-4b69-8f5f-1d7bfc0cbb3f	SR	1df38045-50e0-449b-926a-8d988ff372a5	55	72	92
3289b036-4152-423d-9598-5308c51a2fd1	EXEC	1df38045-50e0-449b-926a-8d988ff372a5	60	78	95
de7c56da-d7ea-4ff8-a0cc-55b35d6da2dd	FRESHER	4684e00c-aab3-4e8b-a0d5-818084769a96	25	45	75
7dd27934-5c80-43c5-b0ae-2862d92610b2	JR	4684e00c-aab3-4e8b-a0d5-818084769a96	35	55	82
2394ae7a-048c-4a47-91e6-7f6bece4ba93	MID	4684e00c-aab3-4e8b-a0d5-818084769a96	45	65	88
7ccdeb83-554b-4c55-bffb-465eb64b0218	SR	4684e00c-aab3-4e8b-a0d5-818084769a96	55	72	92
c19fc277-1a88-4dfe-86ff-b6708db90f39	EXEC	4684e00c-aab3-4e8b-a0d5-818084769a96	60	78	95
f72878c8-8dc0-4639-a047-11fbd7b5adc0	FRESHER	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	25	45	75
2d59cd71-c2e8-4418-8218-fa56b8bd83fc	JR	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	35	55	82
30d2c4a4-ebbc-48df-9afd-bb2027d95d4c	MID	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	45	65	88
71412d09-4e91-48dc-8c2c-59e1987e9d08	SR	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	55	72	92
28190c11-bd13-480f-aced-577410cc27f6	EXEC	250c4513-34cc-4e5a-b384-c6a7a94ee4a3	60	78	95
e512e3c8-1840-4c95-be6d-237064955ffa	FRESHER	72184930-fe7a-419a-8c8d-45b20a0715bb	25	45	75
dd4568ba-00e4-413c-b8e6-d9640397e665	JR	72184930-fe7a-419a-8c8d-45b20a0715bb	35	55	82
f4bb6841-d3f6-485a-ba42-b87fcdef63c7	MID	72184930-fe7a-419a-8c8d-45b20a0715bb	45	65	88
6c8b7de3-5931-42b5-ac6e-01fb0600b2b2	SR	72184930-fe7a-419a-8c8d-45b20a0715bb	55	72	92
96d0d33e-0c6f-42d5-a737-c70ce4c2a861	EXEC	72184930-fe7a-419a-8c8d-45b20a0715bb	60	78	95
fe41a1a6-946c-4861-af61-d20d6dc98a48	FRESHER	7a391dd0-2e40-4536-a7b3-5521a0d6e197	25	45	75
81932b93-d2c6-49f4-81ac-0bc47299832b	JR	7a391dd0-2e40-4536-a7b3-5521a0d6e197	35	55	82
adf97448-4ace-4140-a63c-9ffb4b4a8e0c	MID	7a391dd0-2e40-4536-a7b3-5521a0d6e197	45	65	88
a04a04eb-98ac-4b72-8bd1-4f76610901d6	SR	7a391dd0-2e40-4536-a7b3-5521a0d6e197	55	72	92
9ed7987e-8051-46cf-b9f0-9387c757e854	EXEC	7a391dd0-2e40-4536-a7b3-5521a0d6e197	60	78	95
1223c476-fa6c-427c-9458-2bd549748e7d	FRESHER	e2682ae1-28b5-40de-a4c0-dfc0f788b086	25	45	75
09d71144-a41b-45f0-b863-f9edba25cd0c	JR	e2682ae1-28b5-40de-a4c0-dfc0f788b086	35	55	82
cbecf355-2448-45ad-87bd-00ad8f26fb81	MID	e2682ae1-28b5-40de-a4c0-dfc0f788b086	45	65	88
a751fed8-baa7-409d-91e8-57e41f8b6498	SR	e2682ae1-28b5-40de-a4c0-dfc0f788b086	55	72	92
1970a996-e7cc-4eef-bd83-096e05726e58	EXEC	e2682ae1-28b5-40de-a4c0-dfc0f788b086	60	78	95
d550893e-334c-4f85-be19-c35c18448543	FRESHER	441de88e-ef98-42e8-b681-1a95b08721d6	25	45	75
7c77816a-e940-4221-94ab-cf8ee52c5556	JR	441de88e-ef98-42e8-b681-1a95b08721d6	35	55	82
3e9f66ad-4139-486c-8ab7-82951f6fcfb0	MID	441de88e-ef98-42e8-b681-1a95b08721d6	45	65	88
48543c59-a38f-4df6-84a6-ed23ad981a8c	SR	441de88e-ef98-42e8-b681-1a95b08721d6	55	72	92
370dd373-aa34-4db0-ba8e-71e0f92f525b	EXEC	441de88e-ef98-42e8-b681-1a95b08721d6	60	78	95
b4956d9c-c018-467d-bfbb-729e1f00da12	FRESHER	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	25	45	75
09fd7131-48e0-4e2e-85d1-19d5069cff63	JR	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	35	55	82
b8ddd966-1bb7-4103-88b8-bd412dbb92dc	MID	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	45	65	88
21526d16-c078-4fef-9bb4-9053a2e2a324	SR	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	55	72	92
909a415f-3778-41e8-a07d-8d68a3b3d9e9	EXEC	01fb93c7-4da4-4cf7-802b-bc69ffbdc41c	60	78	95
b652b383-a4ed-45a7-a875-be8a2923b3e8	FRESHER	5ec547f1-09bf-4844-bfbe-90f5a6c34490	25	45	75
f6707645-1102-464a-a1c7-2f3381a562d3	JR	5ec547f1-09bf-4844-bfbe-90f5a6c34490	35	55	82
31ece37b-c620-4e0b-8883-d62f3961049d	MID	5ec547f1-09bf-4844-bfbe-90f5a6c34490	45	65	88
c695150f-b97f-4ee9-aa9c-ecf29a0d443b	SR	5ec547f1-09bf-4844-bfbe-90f5a6c34490	55	72	92
fd071cef-a1cb-4937-b177-e95d31b4b2d4	EXEC	5ec547f1-09bf-4844-bfbe-90f5a6c34490	60	78	95
386c731c-ebea-4de8-9abe-6c5115e79277	FRESHER	04f45cea-6096-4aad-99c2-fc4952b1f15a	25	45	75
7b77e87a-5001-42ab-bd60-1ea9ff39e4a7	JR	04f45cea-6096-4aad-99c2-fc4952b1f15a	35	55	82
aa0ea7f0-9cfb-4257-9746-fd471691d67b	MID	04f45cea-6096-4aad-99c2-fc4952b1f15a	45	65	88
95cd01a4-8beb-44b9-9aa0-fa3f290b6cde	SR	04f45cea-6096-4aad-99c2-fc4952b1f15a	55	72	92
28a01d7b-afb0-4440-93ac-86cba3db0bff	EXEC	04f45cea-6096-4aad-99c2-fc4952b1f15a	60	78	95
267cc748-5fdf-4712-b949-c010eaaf80e6	FRESHER	f174dfe6-fa3e-45f2-bad6-f8a098259389	25	45	75
de916fb2-b152-428c-8886-b18944a8de24	JR	f174dfe6-fa3e-45f2-bad6-f8a098259389	35	55	82
68fe5d97-122d-4960-9f57-dcdf3c829c52	MID	f174dfe6-fa3e-45f2-bad6-f8a098259389	45	65	88
5066bb69-0ec9-4e55-aaa9-1d36a0bc83d3	SR	f174dfe6-fa3e-45f2-bad6-f8a098259389	55	72	92
8a1ea6cc-5d97-42e7-b6ac-5c5f7f1a1d40	EXEC	f174dfe6-fa3e-45f2-bad6-f8a098259389	60	78	95
50ee1fc1-da37-4be0-889b-c2342ee7d2d4	FRESHER	500f3c7a-6fc8-403b-bb3e-7c09477c8942	25	45	75
4af8cb23-0be4-41ef-b55d-af3f560ce068	JR	500f3c7a-6fc8-403b-bb3e-7c09477c8942	35	55	82
55fd99d9-5dc4-4716-aa02-a529a7cda149	MID	500f3c7a-6fc8-403b-bb3e-7c09477c8942	45	65	88
7e8855eb-c730-48d9-814b-285b009e11c7	SR	500f3c7a-6fc8-403b-bb3e-7c09477c8942	55	72	92
14c97d11-ef07-4f2f-b330-f4b9e1788ecf	EXEC	500f3c7a-6fc8-403b-bb3e-7c09477c8942	60	78	95
ff206ce5-3fd5-4e6f-a263-b24566efe6a7	FRESHER	fbbbd2de-2901-44f3-95ac-3ae03815cf86	25	45	75
8e0430e4-0853-4b81-8ebc-6f69b3110648	JR	fbbbd2de-2901-44f3-95ac-3ae03815cf86	35	55	82
3c7f58db-c4b1-40b0-8591-acb6e111baeb	MID	fbbbd2de-2901-44f3-95ac-3ae03815cf86	45	65	88
3a4a72ac-74a6-42f8-80a4-75baf04a2282	SR	fbbbd2de-2901-44f3-95ac-3ae03815cf86	55	72	92
246c4f0a-874b-44a3-84e9-9a668395a805	EXEC	fbbbd2de-2901-44f3-95ac-3ae03815cf86	60	78	95
e0d3a8b1-60ef-4ce6-a58d-65514f8fc233	FRESHER	e5339884-e709-492b-951c-3ebcc488888a	25	45	75
65c408dd-a1b4-432d-b755-c70853def244	JR	e5339884-e709-492b-951c-3ebcc488888a	35	55	82
fcd2eecc-0d44-4150-96a4-7a996d5da3fe	MID	e5339884-e709-492b-951c-3ebcc488888a	45	65	88
2b349030-d05d-4e72-8693-e1610bdaf094	SR	e5339884-e709-492b-951c-3ebcc488888a	55	72	92
5163be43-8f9e-4255-acde-7c1ff3dfa2de	EXEC	e5339884-e709-492b-951c-3ebcc488888a	60	78	95
48e97c4f-1fa3-4503-86d7-0261c3b2f8f8	FRESHER	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	25	45	75
e09670bf-9bf9-45d7-bc5d-50d2a260cab3	JR	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	35	55	82
e6a486f2-ea1d-4249-8c9e-cdbcd0009821	MID	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	45	65	88
a78c58cf-5af5-4484-8b0c-430aa683f829	SR	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	55	72	92
7cb03867-f467-452f-8b2c-8014220b1fe7	EXEC	5cac77a8-91c9-46c4-a108-8c9d279cf8d6	60	78	95
52ce0cde-0c44-47be-8c6a-35eb76533638	FRESHER	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	25	45	75
7d4a54d8-3e86-4b06-ad68-0851a268b06c	JR	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	35	55	82
f9c4acad-824a-42cd-a3dd-25903a8364e2	MID	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	45	65	88
ace0c167-a262-4959-9174-c120b1faa685	SR	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	55	72	92
ef762f7b-e675-4e00-99b8-8d09e6530a0b	EXEC	30ef8afc-ec11-48cd-bd7c-b9c58f4e3562	60	78	95
4ab7c8dc-cd77-4dc8-9256-c50143d5e135	FRESHER	7914ba09-3101-4895-bdf9-366e5f881724	25	45	75
e7943d1a-91e7-4352-a223-3cdfea9ddc54	JR	7914ba09-3101-4895-bdf9-366e5f881724	35	55	82
d627eca3-22f3-446e-b068-7aaa85c796ec	MID	7914ba09-3101-4895-bdf9-366e5f881724	45	65	88
78661ab7-75f4-487e-91aa-b7a64d67d03a	SR	7914ba09-3101-4895-bdf9-366e5f881724	55	72	92
a57e2020-9b62-43c1-9a0b-6be8a01705f5	EXEC	7914ba09-3101-4895-bdf9-366e5f881724	60	78	95
462507df-1569-4a93-a8a8-1dfc559640f4	FRESHER	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	25	45	75
af822dad-a7d1-4766-b11e-bf375f640dc0	JR	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	35	55	82
6c386a02-0376-4c6c-8e6e-0ed9cb79035a	MID	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	45	65	88
ebc6fa87-d528-469d-b0bc-a95b2337c228	SR	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	55	72	92
986db402-df50-46c0-a48e-edcbc3011c64	EXEC	27a0d7b2-1063-4eae-8999-7d1b2ee2f7f8	60	78	95
7af74409-346f-467d-85b5-f3c3fbfc2a9f	FRESHER	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	25	45	75
847b86e9-58f5-402a-a511-04229ecb7f75	JR	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	35	55	82
bf678c7b-3057-4fde-ba8a-bb9ce57b397b	MID	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	45	65	88
c4cedd08-86a3-48b6-8df7-4e2ceb3ef9b7	SR	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	55	72	92
4330ed5c-7359-4a69-ada4-cd2dead0d84f	EXEC	118fd01a-0fb2-4ee7-a4fd-3902037b0f76	60	78	95
8f355060-8e1f-46f8-b356-56f2585c6770	FRESHER	40fac2ff-5ea4-438f-b891-2f900665b80b	25	45	75
9954c584-4f57-42d1-9433-b6d803d2a356	JR	40fac2ff-5ea4-438f-b891-2f900665b80b	35	55	82
7e564632-4c8b-477e-bc24-d0eef586cb8e	MID	40fac2ff-5ea4-438f-b891-2f900665b80b	45	65	88
bb1120b7-63ea-40f4-8367-a2aa2c09db74	SR	40fac2ff-5ea4-438f-b891-2f900665b80b	55	72	92
1f9e22ff-292e-4294-90f0-f9c79c962c56	EXEC	40fac2ff-5ea4-438f-b891-2f900665b80b	60	78	95
9e1a06d2-ceaf-4047-9f81-ec82b6c0a4a1	FRESHER	684ea464-ff78-4c77-8cf8-8894c81fec58	25	45	75
37d78245-56b4-4186-b79b-a9f7b05569f2	JR	684ea464-ff78-4c77-8cf8-8894c81fec58	35	55	82
2675fd77-5095-4702-a8e0-08c7fed664ca	MID	684ea464-ff78-4c77-8cf8-8894c81fec58	45	65	88
9f7b59ae-e7be-44dd-bb3a-86c068bf2184	SR	684ea464-ff78-4c77-8cf8-8894c81fec58	55	72	92
5d510e89-8a70-41d8-a236-63955a24d6db	EXEC	684ea464-ff78-4c77-8cf8-8894c81fec58	60	78	95
03e7885a-28c8-435c-954b-ca49d6905527	FRESHER	6a407735-42f8-4e8f-82a7-0a678f62d285	25	45	75
07aaff33-602e-44c5-a3dc-e37e89b9d2e0	JR	6a407735-42f8-4e8f-82a7-0a678f62d285	35	55	82
b579c2f2-9874-4976-b8da-430d8dbff3dc	MID	6a407735-42f8-4e8f-82a7-0a678f62d285	45	65	88
9e41490d-4137-4137-8121-fe232e38e095	SR	6a407735-42f8-4e8f-82a7-0a678f62d285	55	72	92
1d8f9199-4215-4a81-af0f-e92018ffb94f	EXEC	6a407735-42f8-4e8f-82a7-0a678f62d285	60	78	95
9d61e576-ec23-4896-a011-3a1eb9dbde00	FRESHER	1323078d-84da-4b61-8ca3-2f4fa9bac09b	25	45	75
4acba814-cb9d-4db8-a692-7a624e2e450f	JR	1323078d-84da-4b61-8ca3-2f4fa9bac09b	35	55	82
15d5220d-6ab9-44f0-9f58-22a393f87ef1	MID	1323078d-84da-4b61-8ca3-2f4fa9bac09b	45	65	88
ac0ccd80-7b94-4a6e-b98b-b489bd584851	SR	1323078d-84da-4b61-8ca3-2f4fa9bac09b	55	72	92
5dc29b60-9115-46f2-81ec-5d7db0e2ca20	EXEC	1323078d-84da-4b61-8ca3-2f4fa9bac09b	60	78	95
376c9b82-de47-4387-9f1d-53e91dcefc2c	FRESHER	573862b8-a47a-494b-b93f-4b1fd5912f24	25	45	75
a16ce0cb-d2d9-4a98-b34d-0531e8781ab0	JR	573862b8-a47a-494b-b93f-4b1fd5912f24	35	55	82
65acd1c9-89d6-4e23-97ca-520445877426	MID	573862b8-a47a-494b-b93f-4b1fd5912f24	45	65	88
7d1d10a1-2f61-49ad-b32b-6ae6c3c4cbbc	SR	573862b8-a47a-494b-b93f-4b1fd5912f24	55	72	92
ec300642-80e1-46f3-80c0-1953f03076e2	EXEC	573862b8-a47a-494b-b93f-4b1fd5912f24	60	78	95
3eb11366-3810-46ee-9eef-94c1368afa84	FRESHER	d56fbb88-b402-4c02-b8a3-7715e20093c0	25	45	75
83e429f6-5ffd-4182-b288-c9dc290de6f3	JR	d56fbb88-b402-4c02-b8a3-7715e20093c0	35	55	82
46b25c43-cb91-4497-852c-35d31051738c	MID	d56fbb88-b402-4c02-b8a3-7715e20093c0	45	65	88
09a52bfa-26c3-4620-90a0-f090a170864f	SR	d56fbb88-b402-4c02-b8a3-7715e20093c0	55	72	92
99e89dfa-04d8-48bd-9017-de8ab3e0d4ab	EXEC	d56fbb88-b402-4c02-b8a3-7715e20093c0	60	78	95
dcb5d0bf-46a1-4dea-9303-20a6e236c4a5	FRESHER	f735e34e-2752-4ba7-bb9e-8b5c38b57218	25	45	75
31c08199-3b90-41ad-b459-320b1a6ce08c	JR	f735e34e-2752-4ba7-bb9e-8b5c38b57218	35	55	82
19d33e52-a0c0-40cc-879b-f82d5f2eeb9f	MID	f735e34e-2752-4ba7-bb9e-8b5c38b57218	45	65	88
5d476375-5444-49bb-b166-47cef812e3b2	SR	f735e34e-2752-4ba7-bb9e-8b5c38b57218	55	72	92
93a12db1-4828-4d54-9bee-f1cd39b689b4	EXEC	f735e34e-2752-4ba7-bb9e-8b5c38b57218	60	78	95
3f1b84d2-fc5f-4e1f-a1c4-9e04358c2aea	FRESHER	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	25	45	75
78ab6ce0-3bfa-4994-bab0-e41f67233954	JR	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	35	55	82
e4410d3a-e280-4c1a-8427-34324f572720	MID	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	45	65	88
d27b27a0-61e8-4ee5-8458-d069b5eede47	SR	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	55	72	92
9dd7c21f-6625-4f51-af1f-d2ac3f9ae609	EXEC	2ecea6ec-27e0-4fde-90cd-d0f2592adb9d	60	78	95
d0615aeb-807c-4083-8dbc-48541d2ff8f5	FRESHER	ff0f818b-173d-43ef-a528-ef553787ca5f	25	45	75
81214f86-86c9-44c9-bdc9-3b84215fe157	JR	ff0f818b-173d-43ef-a528-ef553787ca5f	35	55	82
f56231da-af16-41d0-81d0-58821453143f	MID	ff0f818b-173d-43ef-a528-ef553787ca5f	45	65	88
1b378ef3-01fb-45dc-afe6-e95d24bd49df	SR	ff0f818b-173d-43ef-a528-ef553787ca5f	55	72	92
44521ec1-906e-4ae1-9ae7-11f6bca963da	EXEC	ff0f818b-173d-43ef-a528-ef553787ca5f	60	78	95
727154ed-8fdb-49f3-95f4-2ab60dbffcbf	FRESHER	a8d775e5-2281-47fb-a984-9dfe240a1841	25	45	75
defbba0c-c35c-4514-9f25-7371fdd93bb7	JR	a8d775e5-2281-47fb-a984-9dfe240a1841	35	55	82
96422ea9-b5e8-4d5d-926d-f62750744bd0	MID	a8d775e5-2281-47fb-a984-9dfe240a1841	45	65	88
6f609300-5ba3-43ab-bc53-34645f8cd81b	SR	a8d775e5-2281-47fb-a984-9dfe240a1841	55	72	92
022ac599-672a-4aef-916c-8361a8ce3d4b	EXEC	a8d775e5-2281-47fb-a984-9dfe240a1841	60	78	95
88e2ef11-43e1-4331-a520-d3e541a50e31	FRESHER	8c949a6a-a93c-4923-99ef-967276e60d8d	25	45	75
60f778d6-211e-444f-a651-b03c05d5cf77	JR	8c949a6a-a93c-4923-99ef-967276e60d8d	35	55	82
962ac5eb-7eeb-4278-a6dc-62c03a1eba7d	MID	8c949a6a-a93c-4923-99ef-967276e60d8d	45	65	88
3af91d78-ff47-4cb2-a518-c6a25cd36643	SR	8c949a6a-a93c-4923-99ef-967276e60d8d	55	72	92
33922075-7e29-484c-98e7-38a3537e4eb9	EXEC	8c949a6a-a93c-4923-99ef-967276e60d8d	60	78	95
b6214924-3442-4f1c-b407-9b72502934ee	FRESHER	5fd97c47-e245-4016-a348-5dd80f708a89	25	45	75
7d15ac91-a941-4bfc-bcab-b1766200d3a3	JR	5fd97c47-e245-4016-a348-5dd80f708a89	35	55	82
3a901615-a989-4139-9ecd-834bde830ff2	MID	5fd97c47-e245-4016-a348-5dd80f708a89	45	65	88
5a8117a0-3b2d-495c-a5af-c5151be21250	SR	5fd97c47-e245-4016-a348-5dd80f708a89	55	72	92
50b67cab-ea83-4b4f-80e8-602e17ab8931	EXEC	5fd97c47-e245-4016-a348-5dd80f708a89	60	78	95
a3f5c43b-83af-4dd9-ae9b-02398567789f	FRESHER	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	25	45	75
fb389c19-b1d9-4d8e-b9cf-c24cb1e0105f	JR	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	35	55	82
539ee00f-ca41-4294-9b33-b7130dbf6bb6	MID	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	45	65	88
4dae9eb6-cbd0-43f9-9c1e-e2d1608e6ac4	SR	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	55	72	92
f5e28f3c-5222-46c3-a290-ae87c9d912b1	EXEC	2b60f322-e228-4a5e-bdae-1d9853b1ca1d	60	78	95
\.


--
-- Data for Name: student_assessment_responses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_assessment_responses (id, session_id, question_id, selected_option, text_response, score, response_time_ms, created_at) FROM stdin;
\.


--
-- Data for Name: student_assessment_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_assessment_sessions (id, student_id, module_id, age_group_id, status, total_questions, questions_answered, raw_score, percentile_score, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: student_bulk_imports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_bulk_imports (id, institute_id, batch_id, file_name, file_size, storage_path, status, total_rows, processed_rows, successful_rows, failed_rows, duplicate_rows, error_log, validation_errors, requires_approval, approval_status, approved_by, approved_at, rejection_reason, uploaded_by, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: student_competency_scores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_competency_scores (id, student_id, competency_id, session_id, raw_score, percentile_score, proficiency_level, assessed_at) FROM stdin;
\.


--
-- Data for Name: student_enrollments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_enrollments (id, institute_id, institute_name, student_id, student_name, parent_id, parent_name, class_name, section, roll_number, admission_date, status, payment_status, fee_amount, paid_amount, due_date, approved_by, approved_at, approval_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: student_import_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_import_records (id, import_id, row_number, student_name, dob, gender, parent_name, parent_email, parent_phone, class_grade, section, roll_number, admission_number, status, validation_errors, student_id, created_at) FROM stdin;
\.


--
-- Data for Name: student_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_subscriptions (id, child_id, student_id, package_id, purchase_date, expiry_date, status, assessment_completed_at, report_generated_at, payment_transaction_id, created_at) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (id, user_id, institute_id, student_code, full_name, dob, status, created_at) FROM stdin;
\.


--
-- Data for Name: study_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.study_tasks (id, child_id, created_by_parent_id, title, description, task_type, subject_id, chapter_id, topic_id, priority, due_date, estimated_minutes, status, completed_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subscription_packages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_packages (id, category, student_segment, product_name, is_recommended, domains_covered, price, validity_days, question_count, report_type, sort_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: supervised_test_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supervised_test_sessions (id, exam_id, parent_id, child_id, status, started_at, ended_at) FROM stdin;
\.


--
-- Data for Name: test_approvals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_approvals (id, test_id, approver_user_id, approval_status, comments, approved_at, created_at) FROM stdin;
\.


--
-- Data for Name: test_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_assignments (id, test_id, assignment_type, child_id, batch_id, institute_id, section, assigned_by, start_date, end_date, status, created_at) FROM stdin;
\.


--
-- Data for Name: test_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_attempts (id, test_id, assignment_id, child_id, status, score_obtained, total_marks, percentage_score, time_taken_seconds, started_at, submitted_at, created_at) FROM stdin;
\.


--
-- Data for Name: test_blueprints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_blueprints (id, blueprint_code, blueprint_name, test_type, description, board_id, class_id, subject_id, chapter_id, duration, total_marks, passing_marks, total_questions, question_distribution, instructions, created_by, institute_id, is_public, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: test_question_bank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_question_bank (id, question_code, question_type, difficulty_level, question_text, option_a, option_b, option_c, option_d, option_e, correct_option, answer_text, explanation, marks, negative_marks, board_id, class_id, subject_id, chapter_id, topic_id, assessment_type, assessment_code, passage_id, case_study_id, diagram_url, tags, language, psychopsis_sub_module_id, created_by, institute_id, is_verified, status, created_at) FROM stdin;
f55d51ed-e836-49f7-ac0e-402d1ad6ee33	QB_MATH_001	MCQ	Easy	What is the HCF of 26 and 91?	13	26	7	91	\N	A	\N	Using Euclid's algorithm: 91 = 26 × 3 + 13, 26 = 13 × 2 + 0. So HCF = 13	1	0	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6a884ad1-6b96-4ac0-b032-a47a4e969a13	0bdffdb6-f3c6-45b5-b806-3d3537acc662	8374da60-ee3b-4888-b61b-a780679b00ff	\N	Practice	\N	\N	\N	\N	\N	EN	\N	\N	\N	f	Active	2026-05-01 04:27:53.788948
84c1cded-56b7-4ace-b4ce-c7097ebeb746	QB_MATH_002	MCQ	Medium	If LCM(12, 21) = 84, what is HCF(12, 21)?	3	4	7	12	\N	A	\N	LCM × HCF = Product of numbers. So 84 × HCF = 12 × 21 = 252. HCF = 252/84 = 3	2	0	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6a884ad1-6b96-4ac0-b032-a47a4e969a13	0bdffdb6-f3c6-45b5-b806-3d3537acc662	8374da60-ee3b-4888-b61b-a780679b00ff	\N	Practice	\N	\N	\N	\N	\N	EN	\N	\N	\N	f	Active	2026-05-01 04:27:53.788948
f2e204ef-407e-49e0-b08a-f2311b0a537d	QB_MATH_003	MCQ	Hard	The decimal expansion of 17/8 will terminate after how many places?	2	3	4	1	\N	B	\N	17/8 = 17/2³ = 2.125 which terminates after 3 decimal places	2	0	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6a884ad1-6b96-4ac0-b032-a47a4e969a13	0bdffdb6-f3c6-45b5-b806-3d3537acc662	8374da60-ee3b-4888-b61b-a780679b00ff	\N	Practice	\N	\N	\N	\N	\N	EN	\N	\N	\N	f	Active	2026-05-01 04:27:53.788948
f531747b-ecfc-4a7a-a0e0-4983f80962f8	QB_MATH_004	MCQ	Easy	Which of the following is an irrational number?	√4	√9	√5	√16	\N	C	\N	√5 cannot be expressed as p/q where p and q are integers, so it is irrational	1	0	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6a884ad1-6b96-4ac0-b032-a47a4e969a13	0bdffdb6-f3c6-45b5-b806-3d3537acc662	8374da60-ee3b-4888-b61b-a780679b00ff	\N	Practice	\N	\N	\N	\N	\N	EN	\N	\N	\N	f	Active	2026-05-01 04:27:53.788948
9e47a954-200d-4a99-a62e-a98dc1be7cdd	QB_MATH_005	MCQ	Medium	What is the LCM of the smallest prime and the smallest composite number?	8	4	6	2	\N	B	\N	Smallest prime = 2, Smallest composite = 4. LCM(2,4) = 4	1	0	97dfc739-bb2b-46a4-b9d2-f884e73b6b67	6a884ad1-6b96-4ac0-b032-a47a4e969a13	0bdffdb6-f3c6-45b5-b806-3d3537acc662	8374da60-ee3b-4888-b61b-a780679b00ff	\N	Practice	\N	\N	\N	\N	\N	EN	\N	\N	\N	f	Active	2026-05-01 04:27:53.788948
\.


--
-- Data for Name: test_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_questions (id, test_id, question_bank_id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, marks, negative_marks, order_index, created_at) FROM stdin;
\.


--
-- Data for Name: test_responses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_responses (id, attempt_id, question_id, selected_option, is_correct, marks_obtained, time_taken_seconds, is_flagged, created_at) FROM stdin;
\.


--
-- Data for Name: test_workflow_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_workflow_history (id, test_id, from_status, to_status, action_by, action_type, comments, created_at) FROM stdin;
\.


--
-- Data for Name: tests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tests (id, test_code, test_name, test_type, blueprint_id, board_id, class_id, subject_id, chapter_id, duration, total_marks, passing_marks, instructions, created_by, institute_id, creator_type, workflow_status, is_auto_generated, scheduled_at, expires_at, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: training_enrollments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_enrollments (id, mentor_id, program_id, status, attendance_percent, assessment_score, started_at, completed_at, failure_reason, retraining_count, created_at) FROM stdin;
\.


--
-- Data for Name: training_programs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_programs (id, program_name, description, role_category, duration_days, passing_score, modules, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id, session_token, ip_address, user_agent, device_type, browser, os, location, is_active, last_activity, expires_at, terminated_at, termination_reason, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, full_name, role, roles, created_at) FROM stdin;
4c5e1296-9aa6-490d-9b75-bc147a2153b3	superadmin@metryx.one	ff6caf5443751b9b330f7539ef6cc9824b8845c79761e5f4b0b7874a09b75d811401028d23fbb56ff8266b36b227c9f5d1ab93213ff242ff5a091c46425234bc.a55aed046798d56d5b36489dd5dc8bf5	Super Administrator	super_admin	{super_admin}	2026-05-01 04:27:53.826207
79aac3fc-6661-440c-8a14-5df884b2c2e6	sentinel-test	x	\N	student	{parent}	2026-05-01 15:06:09.591556
\.


--
-- Data for Name: white_label_partners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.white_label_partners (id, partner_code, company_name, contact_name, contact_email, contact_phone, brand_logo_url, brand_primary_color, brand_accent_color, custom_domain, revenue_share_percent, mentor_pool_size, status, pilot_start_date, rollout_date, terminated_at, termination_reason, created_at, updated_at) FROM stdin;
\.


--
-- Name: concern_areas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.concern_areas_id_seq', 160, true);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.conversations_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: sdi_domains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sdi_domains_id_seq', 18, true);


--
-- Name: sdi_item_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sdi_item_options_id_seq', 1, false);


--
-- Name: sdi_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sdi_items_id_seq', 1, false);


--
-- Name: sdi_subdomains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sdi_subdomains_id_seq', 54, true);


--
-- Name: academic_chapters academic_chapters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_chapters
    ADD CONSTRAINT academic_chapters_pkey PRIMARY KEY (id);


--
-- Name: academic_classes academic_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_classes
    ADD CONSTRAINT academic_classes_pkey PRIMARY KEY (id);


--
-- Name: academic_subjects academic_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_subjects
    ADD CONSTRAINT academic_subjects_pkey PRIMARY KEY (id);


--
-- Name: academic_topics academic_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_topics
    ADD CONSTRAINT academic_topics_pkey PRIMARY KEY (id);


--
-- Name: access_control_policies access_control_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_control_policies
    ADD CONSTRAINT access_control_policies_pkey PRIMARY KEY (id);


--
-- Name: acknowledgements acknowledgements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acknowledgements
    ADD CONSTRAINT acknowledgements_pkey PRIMARY KEY (id);


--
-- Name: admin_audit_logs admin_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_audit_logs
    ADD CONSTRAINT admin_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: assessment_blueprints assessment_blueprints_blueprint_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assessment_blueprints
    ADD CONSTRAINT assessment_blueprints_blueprint_code_unique UNIQUE (blueprint_code);


--
-- Name: assessment_blueprints assessment_blueprints_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assessment_blueprints
    ADD CONSTRAINT assessment_blueprints_pkey PRIMARY KEY (id);


--
-- Name: assessment_template_questions assessment_template_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assessment_template_questions
    ADD CONSTRAINT assessment_template_questions_pkey PRIMARY KEY (id);


--
-- Name: assessment_templates assessment_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assessment_templates
    ADD CONSTRAINT assessment_templates_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: batches batches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (id);


--
-- Name: behavioural_insights behavioural_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.behavioural_insights
    ADD CONSTRAINT behavioural_insights_pkey PRIMARY KEY (id);


--
-- Name: blueprint_sections blueprint_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blueprint_sections
    ADD CONSTRAINT blueprint_sections_pkey PRIMARY KEY (id);


--
-- Name: child_academic_profiles child_academic_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_academic_profiles
    ADD CONSTRAINT child_academic_profiles_pkey PRIMARY KEY (id);


--
-- Name: child_exam_questions child_exam_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_exam_questions
    ADD CONSTRAINT child_exam_questions_pkey PRIMARY KEY (id);


--
-- Name: child_exams child_exams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_exams
    ADD CONSTRAINT child_exams_pkey PRIMARY KEY (id);


--
-- Name: child_subject_enrollments child_subject_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_subject_enrollments
    ADD CONSTRAINT child_subject_enrollments_pkey PRIMARY KEY (id);


--
-- Name: children children_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.children
    ADD CONSTRAINT children_pkey PRIMARY KEY (id);


--
-- Name: cohorts cohorts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cohorts
    ADD CONSTRAINT cohorts_pkey PRIMARY KEY (id);


--
-- Name: competencies competencies_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competencies
    ADD CONSTRAINT competencies_code_key UNIQUE (code);


--
-- Name: competencies competencies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competencies
    ADD CONSTRAINT competencies_pkey PRIMARY KEY (id);


--
-- Name: competency_assessment_items competency_assessment_items_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_assessment_items
    ADD CONSTRAINT competency_assessment_items_code_key UNIQUE (code);


--
-- Name: competency_assessment_items competency_assessment_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_assessment_items
    ADD CONSTRAINT competency_assessment_items_pkey PRIMARY KEY (id);


--
-- Name: competency_assessment_options competency_assessment_options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_assessment_options
    ADD CONSTRAINT competency_assessment_options_pkey PRIMARY KEY (id);


--
-- Name: competency_cluster_map competency_cluster_map_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_cluster_map
    ADD CONSTRAINT competency_cluster_map_pkey PRIMARY KEY (cluster_id, competency_id);


--
-- Name: competency_clusters competency_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_clusters
    ADD CONSTRAINT competency_clusters_pkey PRIMARY KEY (id);


--
-- Name: competency_domains competency_domains_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_domains
    ADD CONSTRAINT competency_domains_code_key UNIQUE (code);


--
-- Name: competency_domains competency_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_domains
    ADD CONSTRAINT competency_domains_pkey PRIMARY KEY (id);


--
-- Name: competency_library competency_library_competency_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_library
    ADD CONSTRAINT competency_library_competency_number_unique UNIQUE (competency_number);


--
-- Name: competency_library competency_library_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_library
    ADD CONSTRAINT competency_library_pkey PRIMARY KEY (id);


--
-- Name: competency_user_responses competency_user_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_user_responses
    ADD CONSTRAINT competency_user_responses_pkey PRIMARY KEY (id);


--
-- Name: competency_versions competency_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_versions
    ADD CONSTRAINT competency_versions_pkey PRIMARY KEY (id);


--
-- Name: compliance_audit_logs compliance_audit_logs_log_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_audit_logs
    ADD CONSTRAINT compliance_audit_logs_log_id_unique UNIQUE (log_id);


--
-- Name: compliance_audit_logs compliance_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_audit_logs
    ADD CONSTRAINT compliance_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: compliance_violations compliance_violations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_violations
    ADD CONSTRAINT compliance_violations_pkey PRIMARY KEY (id);


--
-- Name: concern_areas concern_areas_category_concern_area_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.concern_areas
    ADD CONSTRAINT concern_areas_category_concern_area_key UNIQUE (category, concern_area);


--
-- Name: concern_areas concern_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.concern_areas
    ADD CONSTRAINT concern_areas_pkey PRIMARY KEY (id);


--
-- Name: consent_logs consent_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consent_logs
    ADD CONSTRAINT consent_logs_pkey PRIMARY KEY (id);


--
-- Name: consent_records consent_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consent_records
    ADD CONSTRAINT consent_records_pkey PRIMARY KEY (id);


--
-- Name: consent_types consent_types_consent_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consent_types
    ADD CONSTRAINT consent_types_consent_code_unique UNIQUE (consent_code);


--
-- Name: consent_types consent_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consent_types
    ADD CONSTRAINT consent_types_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: data_retention_policies data_retention_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_retention_policies
    ADD CONSTRAINT data_retention_policies_pkey PRIMARY KEY (id);


--
-- Name: document_access_logs document_access_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_access_logs
    ADD CONSTRAINT document_access_logs_pkey PRIMARY KEY (id);


--
-- Name: document_folders document_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_folders
    ADD CONSTRAINT document_folders_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: education_boards education_boards_board_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education_boards
    ADD CONSTRAINT education_boards_board_code_unique UNIQUE (board_code);


--
-- Name: education_boards education_boards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education_boards
    ADD CONSTRAINT education_boards_pkey PRIMARY KEY (id);


--
-- Name: email_consents email_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_consents
    ADD CONSTRAINT email_consents_pkey PRIMARY KEY (id);


--
-- Name: enrollment_requests enrollment_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment_requests
    ADD CONSTRAINT enrollment_requests_pkey PRIMARY KEY (id);


--
-- Name: entity_codes entity_codes_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_codes
    ADD CONSTRAINT entity_codes_code_unique UNIQUE (code);


--
-- Name: entity_codes entity_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_codes
    ADD CONSTRAINT entity_codes_pkey PRIMARY KEY (id);


--
-- Name: exam_attempts exam_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_attempts
    ADD CONSTRAINT exam_attempts_pkey PRIMARY KEY (id);


--
-- Name: exam_questions exam_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_questions
    ADD CONSTRAINT exam_questions_pkey PRIMARY KEY (id);


--
-- Name: exam_responses exam_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_responses
    ADD CONSTRAINT exam_responses_pkey PRIMARY KEY (id);


--
-- Name: exams exams_exam_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_exam_code_unique UNIQUE (exam_code);


--
-- Name: exams exams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_pkey PRIMARY KEY (id);


--
-- Name: forum_attachments forum_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_attachments
    ADD CONSTRAINT forum_attachments_pkey PRIMARY KEY (id);


--
-- Name: forum_moderation_logs forum_moderation_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_moderation_logs
    ADD CONSTRAINT forum_moderation_logs_pkey PRIMARY KEY (id);


--
-- Name: forum_posts forum_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_pkey PRIMARY KEY (id);


--
-- Name: forum_replies forum_replies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_replies
    ADD CONSTRAINT forum_replies_pkey PRIMARY KEY (id);


--
-- Name: forum_votes forum_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_votes
    ADD CONSTRAINT forum_votes_pkey PRIMARY KEY (id);


--
-- Name: hr_audit_logs hr_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hr_audit_logs
    ADD CONSTRAINT hr_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: hr_consent_logs hr_consent_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hr_consent_logs
    ADD CONSTRAINT hr_consent_logs_pkey PRIMARY KEY (id);


--
-- Name: institute_staff institute_staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institute_staff
    ADD CONSTRAINT institute_staff_pkey PRIMARY KEY (id);


--
-- Name: institutes institutes_institute_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institutes
    ADD CONSTRAINT institutes_institute_code_unique UNIQUE (institute_code);


--
-- Name: institutes institutes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institutes
    ADD CONSTRAINT institutes_pkey PRIMARY KEY (id);


--
-- Name: institutional_slas institutional_slas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institutional_slas
    ADD CONSTRAINT institutional_slas_pkey PRIMARY KEY (id);


--
-- Name: job_applications job_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_pkey PRIMARY KEY (id);


--
-- Name: job_approval_logs job_approval_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_approval_logs
    ADD CONSTRAINT job_approval_logs_pkey PRIMARY KEY (id);


--
-- Name: job_distributions job_distributions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_distributions
    ADD CONSTRAINT job_distributions_pkey PRIMARY KEY (id);


--
-- Name: job_postings job_postings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_postings
    ADD CONSTRAINT job_postings_pkey PRIMARY KEY (id);


--
-- Name: kyc_document_types kyc_document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kyc_document_types
    ADD CONSTRAINT kyc_document_types_pkey PRIMARY KEY (id);


--
-- Name: kyc_documents kyc_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_pkey PRIMARY KEY (id);


--
-- Name: lbi_age_band_weights lbi_age_band_weights_age_band_code_subdomain_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_age_band_weights
    ADD CONSTRAINT lbi_age_band_weights_age_band_code_subdomain_code_key UNIQUE (age_band_code, subdomain_code);


--
-- Name: lbi_age_band_weights lbi_age_band_weights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_age_band_weights
    ADD CONSTRAINT lbi_age_band_weights_pkey PRIMARY KEY (id);


--
-- Name: lbi_age_bands lbi_age_bands_band_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_age_bands
    ADD CONSTRAINT lbi_age_bands_band_code_unique UNIQUE (band_code);


--
-- Name: lbi_age_bands lbi_age_bands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_age_bands
    ADD CONSTRAINT lbi_age_bands_pkey PRIMARY KEY (id);


--
-- Name: lbi_age_groups lbi_age_groups_group_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_age_groups
    ADD CONSTRAINT lbi_age_groups_group_code_unique UNIQUE (group_code);


--
-- Name: lbi_age_groups lbi_age_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_age_groups
    ADD CONSTRAINT lbi_age_groups_pkey PRIMARY KEY (id);


--
-- Name: lbi_assessment_sessions lbi_assessment_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_assessment_sessions
    ADD CONSTRAINT lbi_assessment_sessions_pkey PRIMARY KEY (id);


--
-- Name: lbi_assessments lbi_assessments_assessment_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_assessments
    ADD CONSTRAINT lbi_assessments_assessment_code_unique UNIQUE (assessment_code);


--
-- Name: lbi_assessments lbi_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_assessments
    ADD CONSTRAINT lbi_assessments_pkey PRIMARY KEY (id);


--
-- Name: lbi_cluster_map lbi_cluster_map_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_cluster_map
    ADD CONSTRAINT lbi_cluster_map_pkey PRIMARY KEY (cluster_id, subdomain_code);


--
-- Name: lbi_clusters lbi_clusters_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_clusters
    ADD CONSTRAINT lbi_clusters_code_key UNIQUE (code);


--
-- Name: lbi_clusters lbi_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_clusters
    ADD CONSTRAINT lbi_clusters_pkey PRIMARY KEY (id);


--
-- Name: lbi_domain_scores lbi_domain_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_domain_scores
    ADD CONSTRAINT lbi_domain_scores_pkey PRIMARY KEY (id);


--
-- Name: lbi_domains lbi_domains_domain_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_domains
    ADD CONSTRAINT lbi_domains_domain_code_unique UNIQUE (domain_code);


--
-- Name: lbi_domains lbi_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_domains
    ADD CONSTRAINT lbi_domains_pkey PRIMARY KEY (id);


--
-- Name: lbi_learning_mappings lbi_learning_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_learning_mappings
    ADD CONSTRAINT lbi_learning_mappings_pkey PRIMARY KEY (id);


--
-- Name: lbi_modules lbi_modules_module_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_modules
    ADD CONSTRAINT lbi_modules_module_code_unique UNIQUE (module_code);


--
-- Name: lbi_modules lbi_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_modules
    ADD CONSTRAINT lbi_modules_pkey PRIMARY KEY (id);


--
-- Name: lbi_overall_index lbi_overall_index_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_overall_index
    ADD CONSTRAINT lbi_overall_index_pkey PRIMARY KEY (id);


--
-- Name: lbi_performance_correlation lbi_performance_correlation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_performance_correlation
    ADD CONSTRAINT lbi_performance_correlation_pkey PRIMARY KEY (id);


--
-- Name: lbi_question_bank lbi_question_bank_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_question_bank
    ADD CONSTRAINT lbi_question_bank_pkey PRIMARY KEY (id);


--
-- Name: lbi_question_bank lbi_question_bank_question_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_question_bank
    ADD CONSTRAINT lbi_question_bank_question_code_unique UNIQUE (question_code);


--
-- Name: lbi_questions_legacy lbi_questions_legacy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_questions_legacy
    ADD CONSTRAINT lbi_questions_legacy_pkey PRIMARY KEY (id);


--
-- Name: lbi_questions lbi_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_questions
    ADD CONSTRAINT lbi_questions_pkey PRIMARY KEY (id);


--
-- Name: lbi_questions lbi_questions_question_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_questions
    ADD CONSTRAINT lbi_questions_question_code_unique UNIQUE (question_code);


--
-- Name: lbi_response_scales lbi_response_scales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_response_scales
    ADD CONSTRAINT lbi_response_scales_pkey PRIMARY KEY (id);


--
-- Name: lbi_response_scales lbi_response_scales_scale_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_response_scales
    ADD CONSTRAINT lbi_response_scales_scale_code_unique UNIQUE (scale_code);


--
-- Name: lbi_scoring_rules lbi_scoring_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_scoring_rules
    ADD CONSTRAINT lbi_scoring_rules_pkey PRIMARY KEY (id);


--
-- Name: lbi_scoring_rules lbi_scoring_rules_rule_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_scoring_rules
    ADD CONSTRAINT lbi_scoring_rules_rule_code_unique UNIQUE (rule_code);


--
-- Name: lbi_session_responses lbi_session_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_session_responses
    ADD CONSTRAINT lbi_session_responses_pkey PRIMARY KEY (id);


--
-- Name: lbi_sessions lbi_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_sessions
    ADD CONSTRAINT lbi_sessions_pkey PRIMARY KEY (id);


--
-- Name: lbi_sub_modules lbi_sub_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_sub_modules
    ADD CONSTRAINT lbi_sub_modules_pkey PRIMARY KEY (id);


--
-- Name: lbi_sub_modules lbi_sub_modules_sub_module_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_sub_modules
    ADD CONSTRAINT lbi_sub_modules_sub_module_code_unique UNIQUE (sub_module_code);


--
-- Name: lbi_subdomain_norms lbi_subdomain_norms_age_band_code_subdomain_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_subdomain_norms
    ADD CONSTRAINT lbi_subdomain_norms_age_band_code_subdomain_code_key UNIQUE (age_band_code, subdomain_code);


--
-- Name: lbi_subdomain_norms lbi_subdomain_norms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_subdomain_norms
    ADD CONSTRAINT lbi_subdomain_norms_pkey PRIMARY KEY (id);


--
-- Name: lbi_subdomain_scores lbi_subdomain_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_subdomain_scores
    ADD CONSTRAINT lbi_subdomain_scores_pkey PRIMARY KEY (id);


--
-- Name: lbi_subdomains lbi_subdomains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_subdomains
    ADD CONSTRAINT lbi_subdomains_pkey PRIMARY KEY (id);


--
-- Name: lbi_subdomains lbi_subdomains_subdomain_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_subdomains
    ADD CONSTRAINT lbi_subdomains_subdomain_code_unique UNIQUE (subdomain_code);


--
-- Name: lbi_types lbi_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_types
    ADD CONSTRAINT lbi_types_pkey PRIMARY KEY (id);


--
-- Name: lbi_types lbi_types_type_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_types
    ADD CONSTRAINT lbi_types_type_name_unique UNIQUE (type_name);


--
-- Name: lbi_versions lbi_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_versions
    ADD CONSTRAINT lbi_versions_pkey PRIMARY KEY (id);


--
-- Name: learning_mappings learning_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_mappings
    ADD CONSTRAINT learning_mappings_pkey PRIMARY KEY (id);


--
-- Name: learning_plan_templates learning_plan_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_plan_templates
    ADD CONSTRAINT learning_plan_templates_pkey PRIMARY KEY (id);


--
-- Name: lei_registrations lei_registrations_lei_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lei_registrations
    ADD CONSTRAINT lei_registrations_lei_code_unique UNIQUE (lei_code);


--
-- Name: lei_registrations lei_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lei_registrations
    ADD CONSTRAINT lei_registrations_pkey PRIMARY KEY (id);


--
-- Name: mentor_kpis mentor_kpis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_kpis
    ADD CONSTRAINT mentor_kpis_pkey PRIMARY KEY (id);


--
-- Name: mentor_payouts mentor_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_payouts
    ADD CONSTRAINT mentor_payouts_pkey PRIMARY KEY (id);


--
-- Name: mentor_profiles mentor_profiles_mentor_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_profiles
    ADD CONSTRAINT mentor_profiles_mentor_code_unique UNIQUE (mentor_code);


--
-- Name: mentor_profiles mentor_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_profiles
    ADD CONSTRAINT mentor_profiles_pkey PRIMARY KEY (id);


--
-- Name: mentor_tasks mentor_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_tasks
    ADD CONSTRAINT mentor_tasks_pkey PRIMARY KEY (id);


--
-- Name: mentors mentors_mentor_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentors
    ADD CONSTRAINT mentors_mentor_code_unique UNIQUE (mentor_code);


--
-- Name: mentors mentors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentors
    ADD CONSTRAINT mentors_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: mfa_codes mfa_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_pkey PRIMARY KEY (id);


--
-- Name: ngo_registrations ngo_registrations_ngo_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ngo_registrations
    ADD CONSTRAINT ngo_registrations_ngo_code_unique UNIQUE (ngo_code);


--
-- Name: ngo_registrations ngo_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ngo_registrations
    ADD CONSTRAINT ngo_registrations_pkey PRIMARY KEY (id);


--
-- Name: notification_broadcasts notification_broadcasts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_broadcasts
    ADD CONSTRAINT notification_broadcasts_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: onboarding_approvals onboarding_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.onboarding_approvals
    ADD CONSTRAINT onboarding_approvals_pkey PRIMARY KEY (id);


--
-- Name: parent_student_links parent_student_links_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_student_links
    ADD CONSTRAINT parent_student_links_pkey PRIMARY KEY (id);


--
-- Name: parent_test_assignments parent_test_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_test_assignments
    ADD CONSTRAINT parent_test_assignments_pkey PRIMARY KEY (id);


--
-- Name: parent_test_results parent_test_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_test_results
    ADD CONSTRAINT parent_test_results_pkey PRIMARY KEY (id);


--
-- Name: parent_tests parent_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_tests
    ADD CONSTRAINT parent_tests_pkey PRIMARY KEY (id);


--
-- Name: parents parents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parents
    ADD CONSTRAINT parents_pkey PRIMARY KEY (id);


--
-- Name: payment_reconciliations payment_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_reconciliations
    ADD CONSTRAINT payment_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: performance_analytics performance_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_analytics
    ADD CONSTRAINT performance_analytics_pkey PRIMARY KEY (id);


--
-- Name: permission_definitions permission_definitions_permission_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permission_definitions
    ADD CONSTRAINT permission_definitions_permission_key_unique UNIQUE (permission_key);


--
-- Name: permission_definitions permission_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permission_definitions
    ADD CONSTRAINT permission_definitions_pkey PRIMARY KEY (id);


--
-- Name: platform_settings platform_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (id);


--
-- Name: platform_settings platform_settings_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_setting_key_unique UNIQUE (setting_key);


--
-- Name: platform_transactions platform_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_transactions
    ADD CONSTRAINT platform_transactions_pkey PRIMARY KEY (id);


--
-- Name: pre_onboarding_checklists pre_onboarding_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pre_onboarding_checklists
    ADD CONSTRAINT pre_onboarding_checklists_pkey PRIMARY KEY (id);


--
-- Name: psychometric_age_bands psychometric_age_bands_band_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_age_bands
    ADD CONSTRAINT psychometric_age_bands_band_code_unique UNIQUE (band_code);


--
-- Name: psychometric_age_bands psychometric_age_bands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_age_bands
    ADD CONSTRAINT psychometric_age_bands_pkey PRIMARY KEY (id);


--
-- Name: psychometric_assessment_results psychometric_assessment_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_assessment_results
    ADD CONSTRAINT psychometric_assessment_results_pkey PRIMARY KEY (id);


--
-- Name: psychometric_domain_age_band_config psychometric_domain_age_band_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_domain_age_band_config
    ADD CONSTRAINT psychometric_domain_age_band_config_pkey PRIMARY KEY (id);


--
-- Name: psychometric_domains psychometric_domains_domain_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_domains
    ADD CONSTRAINT psychometric_domains_domain_code_unique UNIQUE (domain_code);


--
-- Name: psychometric_domains psychometric_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_domains
    ADD CONSTRAINT psychometric_domains_pkey PRIMARY KEY (id);


--
-- Name: psychometric_question_bank psychometric_question_bank_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_question_bank
    ADD CONSTRAINT psychometric_question_bank_pkey PRIMARY KEY (id);


--
-- Name: psychometric_question_bank psychometric_question_bank_question_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_question_bank
    ADD CONSTRAINT psychometric_question_bank_question_code_unique UNIQUE (question_code);


--
-- Name: psychometric_subdomains psychometric_subdomains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_subdomains
    ADD CONSTRAINT psychometric_subdomains_pkey PRIMARY KEY (id);


--
-- Name: psychometric_subdomains psychometric_subdomains_subdomain_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_subdomains
    ADD CONSTRAINT psychometric_subdomains_subdomain_code_unique UNIQUE (subdomain_code);


--
-- Name: psychopsis_categories psychopsis_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychopsis_categories
    ADD CONSTRAINT psychopsis_categories_pkey PRIMARY KEY (id);


--
-- Name: role_competency_weights role_competency_weights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_competency_weights
    ADD CONSTRAINT role_competency_weights_pkey PRIMARY KEY (id);


--
-- Name: role_competency_weights role_competency_weights_role_code_competency_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_competency_weights
    ADD CONSTRAINT role_competency_weights_role_code_competency_id_key UNIQUE (role_code, competency_id);


--
-- Name: role_definitions role_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_definitions
    ADD CONSTRAINT role_definitions_pkey PRIMARY KEY (id);


--
-- Name: role_definitions role_definitions_role_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_definitions
    ADD CONSTRAINT role_definitions_role_name_unique UNIQUE (role_name);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: scoring_configs scoring_configs_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scoring_configs
    ADD CONSTRAINT scoring_configs_name_key UNIQUE (name);


--
-- Name: scoring_configs scoring_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scoring_configs
    ADD CONSTRAINT scoring_configs_pkey PRIMARY KEY (id);


--
-- Name: sdi_cluster_map sdi_cluster_map_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_cluster_map
    ADD CONSTRAINT sdi_cluster_map_pkey PRIMARY KEY (cluster_id, subdomain_code);


--
-- Name: sdi_clusters sdi_clusters_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_clusters
    ADD CONSTRAINT sdi_clusters_code_key UNIQUE (code);


--
-- Name: sdi_clusters sdi_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_clusters
    ADD CONSTRAINT sdi_clusters_pkey PRIMARY KEY (id);


--
-- Name: sdi_domains sdi_domains_domain_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_domains
    ADD CONSTRAINT sdi_domains_domain_code_key UNIQUE (domain_code);


--
-- Name: sdi_domains sdi_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_domains
    ADD CONSTRAINT sdi_domains_pkey PRIMARY KEY (id);


--
-- Name: sdi_item_options sdi_item_options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_item_options
    ADD CONSTRAINT sdi_item_options_pkey PRIMARY KEY (id);


--
-- Name: sdi_items sdi_items_item_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_items
    ADD CONSTRAINT sdi_items_item_code_key UNIQUE (item_code);


--
-- Name: sdi_items sdi_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_items
    ADD CONSTRAINT sdi_items_pkey PRIMARY KEY (id);


--
-- Name: sdi_learning_mappings sdi_learning_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_learning_mappings
    ADD CONSTRAINT sdi_learning_mappings_pkey PRIMARY KEY (id);


--
-- Name: sdi_stage_weights sdi_stage_weights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_stage_weights
    ADD CONSTRAINT sdi_stage_weights_pkey PRIMARY KEY (id);


--
-- Name: sdi_stage_weights sdi_stage_weights_stage_code_subdomain_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_stage_weights
    ADD CONSTRAINT sdi_stage_weights_stage_code_subdomain_code_key UNIQUE (stage_code, subdomain_code);


--
-- Name: sdi_stages sdi_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_stages
    ADD CONSTRAINT sdi_stages_pkey PRIMARY KEY (id);


--
-- Name: sdi_stages sdi_stages_stage_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_stages
    ADD CONSTRAINT sdi_stages_stage_code_key UNIQUE (stage_code);


--
-- Name: sdi_subdomain_norms sdi_subdomain_norms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_subdomain_norms
    ADD CONSTRAINT sdi_subdomain_norms_pkey PRIMARY KEY (id);


--
-- Name: sdi_subdomain_norms sdi_subdomain_norms_stage_code_subdomain_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_subdomain_norms
    ADD CONSTRAINT sdi_subdomain_norms_stage_code_subdomain_code_key UNIQUE (stage_code, subdomain_code);


--
-- Name: sdi_subdomains sdi_subdomains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_subdomains
    ADD CONSTRAINT sdi_subdomains_pkey PRIMARY KEY (id);


--
-- Name: sdi_subdomains sdi_subdomains_subdomain_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_subdomains
    ADD CONSTRAINT sdi_subdomains_subdomain_code_key UNIQUE (subdomain_code);


--
-- Name: sdi_user_responses sdi_user_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_user_responses
    ADD CONSTRAINT sdi_user_responses_pkey PRIMARY KEY (id);


--
-- Name: sdi_versions sdi_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_versions
    ADD CONSTRAINT sdi_versions_pkey PRIMARY KEY (id);


--
-- Name: security_configurations security_configurations_config_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_configurations
    ADD CONSTRAINT security_configurations_config_key_unique UNIQUE (config_key);


--
-- Name: security_configurations security_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_configurations
    ADD CONSTRAINT security_configurations_pkey PRIMARY KEY (id);


--
-- Name: security_incidents security_incidents_incident_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_incident_code_unique UNIQUE (incident_code);


--
-- Name: security_incidents security_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_pkey PRIMARY KEY (id);


--
-- Name: express_sessions session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.express_sessions
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: staff_batch_assignments staff_batch_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_batch_assignments
    ADD CONSTRAINT staff_batch_assignments_pkey PRIMARY KEY (id);


--
-- Name: staff_roles staff_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_roles
    ADD CONSTRAINT staff_roles_pkey PRIMARY KEY (id);


--
-- Name: staff_roles staff_roles_role_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_roles
    ADD CONSTRAINT staff_roles_role_code_unique UNIQUE (role_code);


--
-- Name: stage_competency_norms stage_competency_norms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stage_competency_norms
    ADD CONSTRAINT stage_competency_norms_pkey PRIMARY KEY (id);


--
-- Name: stage_competency_norms stage_competency_norms_stage_code_competency_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stage_competency_norms
    ADD CONSTRAINT stage_competency_norms_stage_code_competency_id_key UNIQUE (stage_code, competency_id);


--
-- Name: student_assessment_responses student_assessment_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_assessment_responses
    ADD CONSTRAINT student_assessment_responses_pkey PRIMARY KEY (id);


--
-- Name: student_assessment_sessions student_assessment_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_assessment_sessions
    ADD CONSTRAINT student_assessment_sessions_pkey PRIMARY KEY (id);


--
-- Name: student_bulk_imports student_bulk_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_bulk_imports
    ADD CONSTRAINT student_bulk_imports_pkey PRIMARY KEY (id);


--
-- Name: student_competency_scores student_competency_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_competency_scores
    ADD CONSTRAINT student_competency_scores_pkey PRIMARY KEY (id);


--
-- Name: student_enrollments student_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_enrollments
    ADD CONSTRAINT student_enrollments_pkey PRIMARY KEY (id);


--
-- Name: student_import_records student_import_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_import_records
    ADD CONSTRAINT student_import_records_pkey PRIMARY KEY (id);


--
-- Name: student_subscriptions student_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_subscriptions
    ADD CONSTRAINT student_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: students students_student_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_student_code_unique UNIQUE (student_code);


--
-- Name: study_tasks study_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.study_tasks
    ADD CONSTRAINT study_tasks_pkey PRIMARY KEY (id);


--
-- Name: subscription_packages subscription_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_packages
    ADD CONSTRAINT subscription_packages_pkey PRIMARY KEY (id);


--
-- Name: supervised_test_sessions supervised_test_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supervised_test_sessions
    ADD CONSTRAINT supervised_test_sessions_pkey PRIMARY KEY (id);


--
-- Name: test_approvals test_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_approvals
    ADD CONSTRAINT test_approvals_pkey PRIMARY KEY (id);


--
-- Name: test_assignments test_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_assignments
    ADD CONSTRAINT test_assignments_pkey PRIMARY KEY (id);


--
-- Name: test_attempts test_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_attempts
    ADD CONSTRAINT test_attempts_pkey PRIMARY KEY (id);


--
-- Name: test_blueprints test_blueprints_blueprint_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_blueprints
    ADD CONSTRAINT test_blueprints_blueprint_code_unique UNIQUE (blueprint_code);


--
-- Name: test_blueprints test_blueprints_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_blueprints
    ADD CONSTRAINT test_blueprints_pkey PRIMARY KEY (id);


--
-- Name: test_question_bank test_question_bank_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_question_bank
    ADD CONSTRAINT test_question_bank_pkey PRIMARY KEY (id);


--
-- Name: test_question_bank test_question_bank_question_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_question_bank
    ADD CONSTRAINT test_question_bank_question_code_unique UNIQUE (question_code);


--
-- Name: test_questions test_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_questions
    ADD CONSTRAINT test_questions_pkey PRIMARY KEY (id);


--
-- Name: test_responses test_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_responses
    ADD CONSTRAINT test_responses_pkey PRIMARY KEY (id);


--
-- Name: test_workflow_history test_workflow_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_workflow_history
    ADD CONSTRAINT test_workflow_history_pkey PRIMARY KEY (id);


--
-- Name: tests tests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (id);


--
-- Name: tests tests_test_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_test_code_unique UNIQUE (test_code);


--
-- Name: training_enrollments training_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_enrollments
    ADD CONSTRAINT training_enrollments_pkey PRIMARY KEY (id);


--
-- Name: training_programs training_programs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_programs
    ADD CONSTRAINT training_programs_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: white_label_partners white_label_partners_partner_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.white_label_partners
    ADD CONSTRAINT white_label_partners_partner_code_unique UNIQUE (partner_code);


--
-- Name: white_label_partners white_label_partners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.white_label_partners
    ADD CONSTRAINT white_label_partners_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_session_expire" ON public.express_sessions USING btree (expire);


--
-- Name: idx_cohorts_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cohorts_active ON public.cohorts USING btree (is_active);


--
-- Name: idx_cohorts_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cohorts_role ON public.cohorts USING btree (role_code);


--
-- Name: idx_competencies_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_competencies_domain ON public.competencies USING btree (domain_id);


--
-- Name: idx_concern_areas_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_concern_areas_active ON public.concern_areas USING btree (is_active);


--
-- Name: idx_concern_areas_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_concern_areas_category ON public.concern_areas USING btree (category);


--
-- Name: idx_items_competency; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_items_competency ON public.competency_assessment_items USING btree (competency_id);


--
-- Name: idx_items_lang; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_items_lang ON public.competency_assessment_items USING btree (language_code);


--
-- Name: idx_lbi_norms_band; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lbi_norms_band ON public.lbi_subdomain_norms USING btree (age_band_code);


--
-- Name: idx_options_item; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_options_item ON public.competency_assessment_options USING btree (item_id);


--
-- Name: idx_role_weights_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_role_weights_role ON public.role_competency_weights USING btree (role_code);


--
-- Name: idx_sdi_domains_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sdi_domains_status ON public.sdi_domains USING btree (status);


--
-- Name: idx_sdi_items_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sdi_items_active ON public.sdi_items USING btree (is_active);


--
-- Name: idx_sdi_items_subdomain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sdi_items_subdomain ON public.sdi_items USING btree (subdomain_code);


--
-- Name: idx_sdi_norms_stage; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sdi_norms_stage ON public.sdi_subdomain_norms USING btree (stage_code);


--
-- Name: idx_sdi_options_item; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sdi_options_item ON public.sdi_item_options USING btree (item_id);


--
-- Name: idx_sdi_resp_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sdi_resp_user ON public.sdi_user_responses USING btree (user_id);


--
-- Name: idx_sdi_sub_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sdi_sub_domain ON public.sdi_subdomains USING btree (domain_code);


--
-- Name: idx_stage_norms_stage; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stage_norms_stage ON public.stage_competency_norms USING btree (stage_code);


--
-- Name: idx_user_resp_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_resp_user ON public.competency_user_responses USING btree (user_id);


--
-- Name: idx_versions_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_versions_created ON public.competency_versions USING btree (created_at DESC);


--
-- Name: academic_chapters academic_chapters_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_chapters
    ADD CONSTRAINT academic_chapters_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE CASCADE;


--
-- Name: academic_classes academic_classes_board_id_education_boards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_classes
    ADD CONSTRAINT academic_classes_board_id_education_boards_id_fk FOREIGN KEY (board_id) REFERENCES public.education_boards(id) ON DELETE CASCADE;


--
-- Name: academic_subjects academic_subjects_board_id_education_boards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_subjects
    ADD CONSTRAINT academic_subjects_board_id_education_boards_id_fk FOREIGN KEY (board_id) REFERENCES public.education_boards(id) ON DELETE CASCADE;


--
-- Name: academic_subjects academic_subjects_class_id_academic_classes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_subjects
    ADD CONSTRAINT academic_subjects_class_id_academic_classes_id_fk FOREIGN KEY (class_id) REFERENCES public.academic_classes(id) ON DELETE CASCADE;


--
-- Name: academic_topics academic_topics_chapter_id_academic_chapters_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_topics
    ADD CONSTRAINT academic_topics_chapter_id_academic_chapters_id_fk FOREIGN KEY (chapter_id) REFERENCES public.academic_chapters(id) ON DELETE CASCADE;


--
-- Name: acknowledgements acknowledgements_notification_id_notifications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acknowledgements
    ADD CONSTRAINT acknowledgements_notification_id_notifications_id_fk FOREIGN KEY (notification_id) REFERENCES public.notifications(id) ON DELETE CASCADE;


--
-- Name: acknowledgements acknowledgements_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acknowledgements
    ADD CONSTRAINT acknowledgements_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: admin_audit_logs admin_audit_logs_admin_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_audit_logs
    ADD CONSTRAINT admin_audit_logs_admin_user_id_users_id_fk FOREIGN KEY (admin_user_id) REFERENCES public.users(id);


--
-- Name: assessment_blueprints assessment_blueprints_board_id_education_boards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assessment_blueprints
    ADD CONSTRAINT assessment_blueprints_board_id_education_boards_id_fk FOREIGN KEY (board_id) REFERENCES public.education_boards(id) ON DELETE SET NULL;


--
-- Name: assessment_blueprints assessment_blueprints_class_id_academic_classes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assessment_blueprints
    ADD CONSTRAINT assessment_blueprints_class_id_academic_classes_id_fk FOREIGN KEY (class_id) REFERENCES public.academic_classes(id) ON DELETE SET NULL;


--
-- Name: assessment_blueprints assessment_blueprints_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assessment_blueprints
    ADD CONSTRAINT assessment_blueprints_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: assessment_blueprints assessment_blueprints_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assessment_blueprints
    ADD CONSTRAINT assessment_blueprints_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE SET NULL;


--
-- Name: assessment_template_questions assessment_template_questions_template_id_assessment_templates_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assessment_template_questions
    ADD CONSTRAINT assessment_template_questions_template_id_assessment_templates_ FOREIGN KEY (template_id) REFERENCES public.assessment_templates(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: batches batches_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE CASCADE;


--
-- Name: blueprint_sections blueprint_sections_blueprint_id_assessment_blueprints_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blueprint_sections
    ADD CONSTRAINT blueprint_sections_blueprint_id_assessment_blueprints_id_fk FOREIGN KEY (blueprint_id) REFERENCES public.assessment_blueprints(id) ON DELETE CASCADE;


--
-- Name: child_academic_profiles child_academic_profiles_board_id_education_boards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_academic_profiles
    ADD CONSTRAINT child_academic_profiles_board_id_education_boards_id_fk FOREIGN KEY (board_id) REFERENCES public.education_boards(id) ON DELETE SET NULL;


--
-- Name: child_academic_profiles child_academic_profiles_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_academic_profiles
    ADD CONSTRAINT child_academic_profiles_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: child_academic_profiles child_academic_profiles_class_id_academic_classes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_academic_profiles
    ADD CONSTRAINT child_academic_profiles_class_id_academic_classes_id_fk FOREIGN KEY (class_id) REFERENCES public.academic_classes(id) ON DELETE SET NULL;


--
-- Name: child_exam_questions child_exam_questions_child_exam_id_child_exams_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_exam_questions
    ADD CONSTRAINT child_exam_questions_child_exam_id_child_exams_id_fk FOREIGN KEY (child_exam_id) REFERENCES public.child_exams(id) ON DELETE CASCADE;


--
-- Name: child_exams child_exams_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_exams
    ADD CONSTRAINT child_exams_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: child_subject_enrollments child_subject_enrollments_profile_id_child_academic_profiles_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_subject_enrollments
    ADD CONSTRAINT child_subject_enrollments_profile_id_child_academic_profiles_id FOREIGN KEY (profile_id) REFERENCES public.child_academic_profiles(id) ON DELETE CASCADE;


--
-- Name: child_subject_enrollments child_subject_enrollments_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.child_subject_enrollments
    ADD CONSTRAINT child_subject_enrollments_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE CASCADE;


--
-- Name: children children_parent_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.children
    ADD CONSTRAINT children_parent_id_users_id_fk FOREIGN KEY (parent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: children children_student_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.children
    ADD CONSTRAINT children_student_user_id_users_id_fk FOREIGN KEY (student_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: competencies competencies_domain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competencies
    ADD CONSTRAINT competencies_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES public.competency_domains(id) ON DELETE CASCADE;


--
-- Name: competency_assessment_items competency_assessment_items_competency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_assessment_items
    ADD CONSTRAINT competency_assessment_items_competency_id_fkey FOREIGN KEY (competency_id) REFERENCES public.competencies(id) ON DELETE CASCADE;


--
-- Name: competency_assessment_options competency_assessment_options_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_assessment_options
    ADD CONSTRAINT competency_assessment_options_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.competency_assessment_items(id) ON DELETE CASCADE;


--
-- Name: competency_cluster_map competency_cluster_map_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_cluster_map
    ADD CONSTRAINT competency_cluster_map_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.competency_clusters(id) ON DELETE CASCADE;


--
-- Name: competency_cluster_map competency_cluster_map_competency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_cluster_map
    ADD CONSTRAINT competency_cluster_map_competency_id_fkey FOREIGN KEY (competency_id) REFERENCES public.competencies(id) ON DELETE CASCADE;


--
-- Name: competency_user_responses competency_user_responses_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_user_responses
    ADD CONSTRAINT competency_user_responses_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.competency_assessment_items(id) ON DELETE CASCADE;


--
-- Name: competency_user_responses competency_user_responses_option_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competency_user_responses
    ADD CONSTRAINT competency_user_responses_option_id_fkey FOREIGN KEY (option_id) REFERENCES public.competency_assessment_options(id) ON DELETE SET NULL;


--
-- Name: compliance_violations compliance_violations_mentor_id_mentors_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_violations
    ADD CONSTRAINT compliance_violations_mentor_id_mentors_id_fk FOREIGN KEY (mentor_id) REFERENCES public.mentors(id) ON DELETE CASCADE;


--
-- Name: compliance_violations compliance_violations_reported_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_violations
    ADD CONSTRAINT compliance_violations_reported_by_users_id_fk FOREIGN KEY (reported_by) REFERENCES public.users(id);


--
-- Name: compliance_violations compliance_violations_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_violations
    ADD CONSTRAINT compliance_violations_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: consent_logs consent_logs_parent_id_parents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consent_logs
    ADD CONSTRAINT consent_logs_parent_id_parents_id_fk FOREIGN KEY (parent_id) REFERENCES public.parents(id) ON DELETE CASCADE;


--
-- Name: consent_logs consent_logs_parent_student_link_id_parent_student_links_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consent_logs
    ADD CONSTRAINT consent_logs_parent_student_link_id_parent_student_links_id_fk FOREIGN KEY (parent_student_link_id) REFERENCES public.parent_student_links(id) ON DELETE CASCADE;


--
-- Name: document_access_logs document_access_logs_document_id_documents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_access_logs
    ADD CONSTRAINT document_access_logs_document_id_documents_id_fk FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_access_logs document_access_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_access_logs
    ADD CONSTRAINT document_access_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: document_folders document_folders_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_folders
    ADD CONSTRAINT document_folders_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: documents documents_checker_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_checker_approved_by_users_id_fk FOREIGN KEY (checker_approved_by) REFERENCES public.users(id);


--
-- Name: documents documents_folder_id_document_folders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_folder_id_document_folders_id_fk FOREIGN KEY (folder_id) REFERENCES public.document_folders(id) ON DELETE CASCADE;


--
-- Name: documents documents_last_accessed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_last_accessed_by_users_id_fk FOREIGN KEY (last_accessed_by) REFERENCES public.users(id);


--
-- Name: documents documents_maker_verified_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_maker_verified_by_users_id_fk FOREIGN KEY (maker_verified_by) REFERENCES public.users(id);


--
-- Name: documents documents_rejected_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_rejected_by_users_id_fk FOREIGN KEY (rejected_by) REFERENCES public.users(id);


--
-- Name: documents documents_uploaded_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_uploaded_by_users_id_fk FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: email_consents email_consents_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_consents
    ADD CONSTRAINT email_consents_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: enrollment_requests enrollment_requests_batch_id_batches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment_requests
    ADD CONSTRAINT enrollment_requests_batch_id_batches_id_fk FOREIGN KEY (batch_id) REFERENCES public.batches(id) ON DELETE CASCADE;


--
-- Name: enrollment_requests enrollment_requests_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment_requests
    ADD CONSTRAINT enrollment_requests_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE CASCADE;


--
-- Name: enrollment_requests enrollment_requests_student_id_students_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment_requests
    ADD CONSTRAINT enrollment_requests_student_id_students_id_fk FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: entity_codes entity_codes_generated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_codes
    ADD CONSTRAINT entity_codes_generated_by_users_id_fk FOREIGN KEY (generated_by) REFERENCES public.users(id);


--
-- Name: exam_attempts exam_attempts_exam_id_exams_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_attempts
    ADD CONSTRAINT exam_attempts_exam_id_exams_id_fk FOREIGN KEY (exam_id) REFERENCES public.exams(id) ON DELETE CASCADE;


--
-- Name: exam_attempts exam_attempts_student_id_students_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_attempts
    ADD CONSTRAINT exam_attempts_student_id_students_id_fk FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: exam_questions exam_questions_exam_id_exams_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_questions
    ADD CONSTRAINT exam_questions_exam_id_exams_id_fk FOREIGN KEY (exam_id) REFERENCES public.exams(id) ON DELETE CASCADE;


--
-- Name: exam_responses exam_responses_attempt_id_exam_attempts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_responses
    ADD CONSTRAINT exam_responses_attempt_id_exam_attempts_id_fk FOREIGN KEY (attempt_id) REFERENCES public.exam_attempts(id) ON DELETE CASCADE;


--
-- Name: exam_responses exam_responses_question_id_exam_questions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_responses
    ADD CONSTRAINT exam_responses_question_id_exam_questions_id_fk FOREIGN KEY (question_id) REFERENCES public.exam_questions(id) ON DELETE CASCADE;


--
-- Name: exams exams_batch_id_batches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_batch_id_batches_id_fk FOREIGN KEY (batch_id) REFERENCES public.batches(id) ON DELETE CASCADE;


--
-- Name: exams exams_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE CASCADE;


--
-- Name: forum_attachments forum_attachments_post_id_forum_posts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_attachments
    ADD CONSTRAINT forum_attachments_post_id_forum_posts_id_fk FOREIGN KEY (post_id) REFERENCES public.forum_posts(id) ON DELETE CASCADE;


--
-- Name: forum_attachments forum_attachments_reply_id_forum_replies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_attachments
    ADD CONSTRAINT forum_attachments_reply_id_forum_replies_id_fk FOREIGN KEY (reply_id) REFERENCES public.forum_replies(id) ON DELETE CASCADE;


--
-- Name: forum_moderation_logs forum_moderation_logs_moderated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_moderation_logs
    ADD CONSTRAINT forum_moderation_logs_moderated_by_users_id_fk FOREIGN KEY (moderated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_moderation_logs forum_moderation_logs_post_id_forum_posts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_moderation_logs
    ADD CONSTRAINT forum_moderation_logs_post_id_forum_posts_id_fk FOREIGN KEY (post_id) REFERENCES public.forum_posts(id) ON DELETE CASCADE;


--
-- Name: forum_moderation_logs forum_moderation_logs_reply_id_forum_replies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_moderation_logs
    ADD CONSTRAINT forum_moderation_logs_reply_id_forum_replies_id_fk FOREIGN KEY (reply_id) REFERENCES public.forum_replies(id) ON DELETE CASCADE;


--
-- Name: forum_moderation_logs forum_moderation_logs_reported_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_moderation_logs
    ADD CONSTRAINT forum_moderation_logs_reported_by_users_id_fk FOREIGN KEY (reported_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_posts forum_posts_assigned_mentor_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_assigned_mentor_id_users_id_fk FOREIGN KEY (assigned_mentor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_posts forum_posts_assigned_teacher_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_assigned_teacher_id_users_id_fk FOREIGN KEY (assigned_teacher_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_posts forum_posts_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_posts forum_posts_chapter_id_academic_chapters_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_chapter_id_academic_chapters_id_fk FOREIGN KEY (chapter_id) REFERENCES public.academic_chapters(id) ON DELETE SET NULL;


--
-- Name: forum_posts forum_posts_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE SET NULL;


--
-- Name: forum_posts forum_posts_question_id_test_questions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_question_id_test_questions_id_fk FOREIGN KEY (question_id) REFERENCES public.test_questions(id) ON DELETE SET NULL;


--
-- Name: forum_posts forum_posts_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE SET NULL;


--
-- Name: forum_posts forum_posts_test_id_tests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_test_id_tests_id_fk FOREIGN KEY (test_id) REFERENCES public.tests(id) ON DELETE SET NULL;


--
-- Name: forum_replies forum_replies_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_replies
    ADD CONSTRAINT forum_replies_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_replies forum_replies_post_id_forum_posts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_replies
    ADD CONSTRAINT forum_replies_post_id_forum_posts_id_fk FOREIGN KEY (post_id) REFERENCES public.forum_posts(id) ON DELETE CASCADE;


--
-- Name: forum_votes forum_votes_post_id_forum_posts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_votes
    ADD CONSTRAINT forum_votes_post_id_forum_posts_id_fk FOREIGN KEY (post_id) REFERENCES public.forum_posts(id) ON DELETE CASCADE;


--
-- Name: forum_votes forum_votes_reply_id_forum_replies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_votes
    ADD CONSTRAINT forum_votes_reply_id_forum_replies_id_fk FOREIGN KEY (reply_id) REFERENCES public.forum_replies(id) ON DELETE CASCADE;


--
-- Name: forum_votes forum_votes_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_votes
    ADD CONSTRAINT forum_votes_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: hr_audit_logs hr_audit_logs_actor_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hr_audit_logs
    ADD CONSTRAINT hr_audit_logs_actor_user_id_users_id_fk FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- Name: hr_consent_logs hr_consent_logs_mentor_id_mentors_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hr_consent_logs
    ADD CONSTRAINT hr_consent_logs_mentor_id_mentors_id_fk FOREIGN KEY (mentor_id) REFERENCES public.mentors(id) ON DELETE CASCADE;


--
-- Name: hr_consent_logs hr_consent_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hr_consent_logs
    ADD CONSTRAINT hr_consent_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: institute_staff institute_staff_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institute_staff
    ADD CONSTRAINT institute_staff_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE CASCADE;


--
-- Name: institute_staff institute_staff_role_id_staff_roles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institute_staff
    ADD CONSTRAINT institute_staff_role_id_staff_roles_id_fk FOREIGN KEY (role_id) REFERENCES public.staff_roles(id) ON DELETE CASCADE;


--
-- Name: institute_staff institute_staff_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institute_staff
    ADD CONSTRAINT institute_staff_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: institutes institutes_admin_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institutes
    ADD CONSTRAINT institutes_admin_user_id_users_id_fk FOREIGN KEY (admin_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: institutional_slas institutional_slas_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institutional_slas
    ADD CONSTRAINT institutional_slas_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE CASCADE;


--
-- Name: job_applications job_applications_applicant_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_applicant_user_id_users_id_fk FOREIGN KEY (applicant_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: job_applications job_applications_job_id_job_postings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_job_id_job_postings_id_fk FOREIGN KEY (job_id) REFERENCES public.job_postings(id) ON DELETE CASCADE;


--
-- Name: job_applications job_applications_processed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_processed_by_users_id_fk FOREIGN KEY (processed_by) REFERENCES public.users(id);


--
-- Name: job_approval_logs job_approval_logs_actor_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_approval_logs
    ADD CONSTRAINT job_approval_logs_actor_id_users_id_fk FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: job_approval_logs job_approval_logs_job_id_job_postings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_approval_logs
    ADD CONSTRAINT job_approval_logs_job_id_job_postings_id_fk FOREIGN KEY (job_id) REFERENCES public.job_postings(id) ON DELETE CASCADE;


--
-- Name: job_distributions job_distributions_job_id_job_postings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_distributions
    ADD CONSTRAINT job_distributions_job_id_job_postings_id_fk FOREIGN KEY (job_id) REFERENCES public.job_postings(id) ON DELETE CASCADE;


--
-- Name: job_postings job_postings_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_postings
    ADD CONSTRAINT job_postings_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: job_postings job_postings_hr_review_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_postings
    ADD CONSTRAINT job_postings_hr_review_by_users_id_fk FOREIGN KEY (hr_review_by) REFERENCES public.users(id);


--
-- Name: job_postings job_postings_leadership_approval_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_postings
    ADD CONSTRAINT job_postings_leadership_approval_by_users_id_fk FOREIGN KEY (leadership_approval_by) REFERENCES public.users(id);


--
-- Name: job_postings job_postings_legal_review_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_postings
    ADD CONSTRAINT job_postings_legal_review_by_users_id_fk FOREIGN KEY (legal_review_by) REFERENCES public.users(id);


--
-- Name: kyc_documents kyc_documents_checker_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_checker_id_users_id_fk FOREIGN KEY (checker_id) REFERENCES public.users(id);


--
-- Name: kyc_documents kyc_documents_maker_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_maker_id_users_id_fk FOREIGN KEY (maker_id) REFERENCES public.users(id);


--
-- Name: lbi_age_band_weights lbi_age_band_weights_subdomain_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_age_band_weights
    ADD CONSTRAINT lbi_age_band_weights_subdomain_code_fkey FOREIGN KEY (subdomain_code) REFERENCES public.lbi_subdomains(subdomain_code) ON DELETE CASCADE;


--
-- Name: lbi_assessment_sessions lbi_assessment_sessions_age_band_id_lbi_age_bands_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_assessment_sessions
    ADD CONSTRAINT lbi_assessment_sessions_age_band_id_lbi_age_bands_id_fk FOREIGN KEY (age_band_id) REFERENCES public.lbi_age_bands(id) ON DELETE SET NULL;


--
-- Name: lbi_assessment_sessions lbi_assessment_sessions_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_assessment_sessions
    ADD CONSTRAINT lbi_assessment_sessions_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: lbi_assessment_sessions lbi_assessment_sessions_student_id_students_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_assessment_sessions
    ADD CONSTRAINT lbi_assessment_sessions_student_id_students_id_fk FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: lbi_assessments lbi_assessments_lbi_type_id_lbi_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_assessments
    ADD CONSTRAINT lbi_assessments_lbi_type_id_lbi_types_id_fk FOREIGN KEY (lbi_type_id) REFERENCES public.lbi_types(id) ON DELETE CASCADE;


--
-- Name: lbi_cluster_map lbi_cluster_map_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_cluster_map
    ADD CONSTRAINT lbi_cluster_map_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.lbi_clusters(id) ON DELETE CASCADE;


--
-- Name: lbi_cluster_map lbi_cluster_map_subdomain_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_cluster_map
    ADD CONSTRAINT lbi_cluster_map_subdomain_code_fkey FOREIGN KEY (subdomain_code) REFERENCES public.lbi_subdomains(subdomain_code) ON DELETE CASCADE;


--
-- Name: lbi_domain_scores lbi_domain_scores_domain_id_lbi_domains_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_domain_scores
    ADD CONSTRAINT lbi_domain_scores_domain_id_lbi_domains_id_fk FOREIGN KEY (domain_id) REFERENCES public.lbi_domains(id) ON DELETE CASCADE;


--
-- Name: lbi_domain_scores lbi_domain_scores_session_id_lbi_assessment_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_domain_scores
    ADD CONSTRAINT lbi_domain_scores_session_id_lbi_assessment_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.lbi_assessment_sessions(id) ON DELETE CASCADE;


--
-- Name: lbi_learning_mappings lbi_learning_mappings_subdomain_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_learning_mappings
    ADD CONSTRAINT lbi_learning_mappings_subdomain_code_fkey FOREIGN KEY (subdomain_code) REFERENCES public.lbi_subdomains(subdomain_code) ON DELETE CASCADE;


--
-- Name: lbi_overall_index lbi_overall_index_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_overall_index
    ADD CONSTRAINT lbi_overall_index_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: lbi_overall_index lbi_overall_index_session_id_lbi_assessment_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_overall_index
    ADD CONSTRAINT lbi_overall_index_session_id_lbi_assessment_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.lbi_assessment_sessions(id) ON DELETE CASCADE;


--
-- Name: lbi_overall_index lbi_overall_index_student_id_students_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_overall_index
    ADD CONSTRAINT lbi_overall_index_student_id_students_id_fk FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: lbi_performance_correlation lbi_performance_correlation_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_performance_correlation
    ADD CONSTRAINT lbi_performance_correlation_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: lbi_performance_correlation lbi_performance_correlation_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_performance_correlation
    ADD CONSTRAINT lbi_performance_correlation_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE SET NULL;


--
-- Name: lbi_question_bank lbi_question_bank_sub_module_id_lbi_sub_modules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_question_bank
    ADD CONSTRAINT lbi_question_bank_sub_module_id_lbi_sub_modules_id_fk FOREIGN KEY (sub_module_id) REFERENCES public.lbi_sub_modules(id) ON DELETE CASCADE;


--
-- Name: lbi_questions lbi_questions_age_band_id_lbi_age_bands_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_questions
    ADD CONSTRAINT lbi_questions_age_band_id_lbi_age_bands_id_fk FOREIGN KEY (age_band_id) REFERENCES public.lbi_age_bands(id) ON DELETE RESTRICT;


--
-- Name: lbi_questions lbi_questions_domain_id_lbi_domains_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_questions
    ADD CONSTRAINT lbi_questions_domain_id_lbi_domains_id_fk FOREIGN KEY (domain_id) REFERENCES public.lbi_domains(id) ON DELETE CASCADE;


--
-- Name: lbi_questions_legacy lbi_questions_legacy_lbi_type_id_lbi_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_questions_legacy
    ADD CONSTRAINT lbi_questions_legacy_lbi_type_id_lbi_types_id_fk FOREIGN KEY (lbi_type_id) REFERENCES public.lbi_types(id) ON DELETE CASCADE;


--
-- Name: lbi_questions lbi_questions_response_scale_id_lbi_response_scales_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_questions
    ADD CONSTRAINT lbi_questions_response_scale_id_lbi_response_scales_id_fk FOREIGN KEY (response_scale_id) REFERENCES public.lbi_response_scales(id) ON DELETE SET NULL;


--
-- Name: lbi_questions lbi_questions_subdomain_id_lbi_subdomains_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_questions
    ADD CONSTRAINT lbi_questions_subdomain_id_lbi_subdomains_id_fk FOREIGN KEY (subdomain_id) REFERENCES public.lbi_subdomains(id) ON DELETE CASCADE;


--
-- Name: lbi_scoring_rules lbi_scoring_rules_age_band_id_lbi_age_bands_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_scoring_rules
    ADD CONSTRAINT lbi_scoring_rules_age_band_id_lbi_age_bands_id_fk FOREIGN KEY (age_band_id) REFERENCES public.lbi_age_bands(id) ON DELETE SET NULL;


--
-- Name: lbi_scoring_rules lbi_scoring_rules_domain_id_lbi_domains_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_scoring_rules
    ADD CONSTRAINT lbi_scoring_rules_domain_id_lbi_domains_id_fk FOREIGN KEY (domain_id) REFERENCES public.lbi_domains(id) ON DELETE CASCADE;


--
-- Name: lbi_scoring_rules lbi_scoring_rules_subdomain_id_lbi_subdomains_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_scoring_rules
    ADD CONSTRAINT lbi_scoring_rules_subdomain_id_lbi_subdomains_id_fk FOREIGN KEY (subdomain_id) REFERENCES public.lbi_subdomains(id) ON DELETE CASCADE;


--
-- Name: lbi_session_responses lbi_session_responses_question_id_lbi_questions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_session_responses
    ADD CONSTRAINT lbi_session_responses_question_id_lbi_questions_id_fk FOREIGN KEY (question_id) REFERENCES public.lbi_questions(id) ON DELETE RESTRICT;


--
-- Name: lbi_session_responses lbi_session_responses_session_id_lbi_assessment_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_session_responses
    ADD CONSTRAINT lbi_session_responses_session_id_lbi_assessment_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.lbi_assessment_sessions(id) ON DELETE CASCADE;


--
-- Name: lbi_sessions lbi_sessions_assessment_id_lbi_assessments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_sessions
    ADD CONSTRAINT lbi_sessions_assessment_id_lbi_assessments_id_fk FOREIGN KEY (assessment_id) REFERENCES public.lbi_assessments(id) ON DELETE CASCADE;


--
-- Name: lbi_sessions lbi_sessions_student_id_students_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_sessions
    ADD CONSTRAINT lbi_sessions_student_id_students_id_fk FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: lbi_sub_modules lbi_sub_modules_module_id_lbi_modules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_sub_modules
    ADD CONSTRAINT lbi_sub_modules_module_id_lbi_modules_id_fk FOREIGN KEY (module_id) REFERENCES public.lbi_modules(id) ON DELETE CASCADE;


--
-- Name: lbi_subdomain_norms lbi_subdomain_norms_subdomain_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_subdomain_norms
    ADD CONSTRAINT lbi_subdomain_norms_subdomain_code_fkey FOREIGN KEY (subdomain_code) REFERENCES public.lbi_subdomains(subdomain_code) ON DELETE CASCADE;


--
-- Name: lbi_subdomain_scores lbi_subdomain_scores_session_id_lbi_assessment_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_subdomain_scores
    ADD CONSTRAINT lbi_subdomain_scores_session_id_lbi_assessment_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.lbi_assessment_sessions(id) ON DELETE CASCADE;


--
-- Name: lbi_subdomain_scores lbi_subdomain_scores_subdomain_id_lbi_subdomains_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_subdomain_scores
    ADD CONSTRAINT lbi_subdomain_scores_subdomain_id_lbi_subdomains_id_fk FOREIGN KEY (subdomain_id) REFERENCES public.lbi_subdomains(id) ON DELETE CASCADE;


--
-- Name: lbi_subdomains lbi_subdomains_domain_id_lbi_domains_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lbi_subdomains
    ADD CONSTRAINT lbi_subdomains_domain_id_lbi_domains_id_fk FOREIGN KEY (domain_id) REFERENCES public.lbi_domains(id) ON DELETE CASCADE;


--
-- Name: learning_mappings learning_mappings_competency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_mappings
    ADD CONSTRAINT learning_mappings_competency_id_fkey FOREIGN KEY (competency_id) REFERENCES public.competencies(id) ON DELETE CASCADE;


--
-- Name: learning_plan_templates learning_plan_templates_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_plan_templates
    ADD CONSTRAINT learning_plan_templates_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: learning_plan_templates learning_plan_templates_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_plan_templates
    ADD CONSTRAINT learning_plan_templates_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: lei_registrations lei_registrations_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lei_registrations
    ADD CONSTRAINT lei_registrations_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: lei_registrations lei_registrations_verified_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lei_registrations
    ADD CONSTRAINT lei_registrations_verified_by_users_id_fk FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: mentor_kpis mentor_kpis_mentor_id_mentors_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_kpis
    ADD CONSTRAINT mentor_kpis_mentor_id_mentors_id_fk FOREIGN KEY (mentor_id) REFERENCES public.mentors(id) ON DELETE CASCADE;


--
-- Name: mentor_payouts mentor_payouts_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_payouts
    ADD CONSTRAINT mentor_payouts_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: mentor_payouts mentor_payouts_mentor_id_mentors_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_payouts
    ADD CONSTRAINT mentor_payouts_mentor_id_mentors_id_fk FOREIGN KEY (mentor_id) REFERENCES public.mentors(id) ON DELETE CASCADE;


--
-- Name: mentor_profiles mentor_profiles_activated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_profiles
    ADD CONSTRAINT mentor_profiles_activated_by_users_id_fk FOREIGN KEY (activated_by) REFERENCES public.users(id);


--
-- Name: mentor_profiles mentor_profiles_application_id_job_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_profiles
    ADD CONSTRAINT mentor_profiles_application_id_job_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.job_applications(id);


--
-- Name: mentor_profiles mentor_profiles_mentor_id_mentors_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_profiles
    ADD CONSTRAINT mentor_profiles_mentor_id_mentors_id_fk FOREIGN KEY (mentor_id) REFERENCES public.mentors(id);


--
-- Name: mentor_profiles mentor_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_profiles
    ADD CONSTRAINT mentor_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: mentor_tasks mentor_tasks_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_tasks
    ADD CONSTRAINT mentor_tasks_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: mentor_tasks mentor_tasks_mentor_id_mentors_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentor_tasks
    ADD CONSTRAINT mentor_tasks_mentor_id_mentors_id_fk FOREIGN KEY (mentor_id) REFERENCES public.mentors(id) ON DELETE CASCADE;


--
-- Name: mentors mentors_application_id_job_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentors
    ADD CONSTRAINT mentors_application_id_job_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.job_applications(id);


--
-- Name: mentors mentors_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mentors
    ADD CONSTRAINT mentors_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: mfa_codes mfa_codes_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ngo_registrations ngo_registrations_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ngo_registrations
    ADD CONSTRAINT ngo_registrations_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ngo_registrations ngo_registrations_verified_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ngo_registrations
    ADD CONSTRAINT ngo_registrations_verified_by_users_id_fk FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: notification_broadcasts notification_broadcasts_sender_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_broadcasts
    ADD CONSTRAINT notification_broadcasts_sender_id_users_id_fk FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_recipient_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_recipient_id_users_id_fk FOREIGN KEY (recipient_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_sender_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_sender_id_users_id_fk FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: onboarding_approvals onboarding_approvals_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.onboarding_approvals
    ADD CONSTRAINT onboarding_approvals_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: parent_student_links parent_student_links_parent_id_parents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_student_links
    ADD CONSTRAINT parent_student_links_parent_id_parents_id_fk FOREIGN KEY (parent_id) REFERENCES public.parents(id) ON DELETE CASCADE;


--
-- Name: parent_student_links parent_student_links_student_id_students_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_student_links
    ADD CONSTRAINT parent_student_links_student_id_students_id_fk FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: parent_test_assignments parent_test_assignments_assigned_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_test_assignments
    ADD CONSTRAINT parent_test_assignments_assigned_by_users_id_fk FOREIGN KEY (assigned_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: parent_test_assignments parent_test_assignments_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_test_assignments
    ADD CONSTRAINT parent_test_assignments_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: parent_test_assignments parent_test_assignments_test_id_parent_tests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_test_assignments
    ADD CONSTRAINT parent_test_assignments_test_id_parent_tests_id_fk FOREIGN KEY (test_id) REFERENCES public.parent_tests(id) ON DELETE CASCADE;


--
-- Name: parent_test_results parent_test_results_assignment_id_parent_test_assignments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_test_results
    ADD CONSTRAINT parent_test_results_assignment_id_parent_test_assignments_id_fk FOREIGN KEY (assignment_id) REFERENCES public.parent_test_assignments(id) ON DELETE CASCADE;


--
-- Name: parent_tests parent_tests_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parent_tests
    ADD CONSTRAINT parent_tests_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: parents parents_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parents
    ADD CONSTRAINT parents_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_reconciliations payment_reconciliations_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_reconciliations
    ADD CONSTRAINT payment_reconciliations_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: payment_reconciliations payment_reconciliations_reconciled_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_reconciliations
    ADD CONSTRAINT payment_reconciliations_reconciled_by_users_id_fk FOREIGN KEY (reconciled_by) REFERENCES public.users(id);


--
-- Name: performance_analytics performance_analytics_chapter_id_academic_chapters_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_analytics
    ADD CONSTRAINT performance_analytics_chapter_id_academic_chapters_id_fk FOREIGN KEY (chapter_id) REFERENCES public.academic_chapters(id) ON DELETE SET NULL;


--
-- Name: performance_analytics performance_analytics_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_analytics
    ADD CONSTRAINT performance_analytics_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: performance_analytics performance_analytics_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_analytics
    ADD CONSTRAINT performance_analytics_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE SET NULL;


--
-- Name: platform_settings platform_settings_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: platform_transactions platform_transactions_processed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_transactions
    ADD CONSTRAINT platform_transactions_processed_by_users_id_fk FOREIGN KEY (processed_by) REFERENCES public.users(id);


--
-- Name: pre_onboarding_checklists pre_onboarding_checklists_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pre_onboarding_checklists
    ADD CONSTRAINT pre_onboarding_checklists_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: pre_onboarding_checklists pre_onboarding_checklists_rejected_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pre_onboarding_checklists
    ADD CONSTRAINT pre_onboarding_checklists_rejected_by_users_id_fk FOREIGN KEY (rejected_by) REFERENCES public.users(id);


--
-- Name: pre_onboarding_checklists pre_onboarding_checklists_temporary_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pre_onboarding_checklists
    ADD CONSTRAINT pre_onboarding_checklists_temporary_approved_by_users_id_fk FOREIGN KEY (temporary_approved_by) REFERENCES public.users(id);


--
-- Name: psychometric_assessment_results psychometric_assessment_results_age_band_id_psychometric_age_ba; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_assessment_results
    ADD CONSTRAINT psychometric_assessment_results_age_band_id_psychometric_age_ba FOREIGN KEY (age_band_id) REFERENCES public.psychometric_age_bands(id) ON DELETE CASCADE;


--
-- Name: psychometric_assessment_results psychometric_assessment_results_domain_id_psychometric_domains_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_assessment_results
    ADD CONSTRAINT psychometric_assessment_results_domain_id_psychometric_domains_ FOREIGN KEY (domain_id) REFERENCES public.psychometric_domains(id) ON DELETE CASCADE;


--
-- Name: psychometric_assessment_results psychometric_assessment_results_subdomain_id_psychometric_subdo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_assessment_results
    ADD CONSTRAINT psychometric_assessment_results_subdomain_id_psychometric_subdo FOREIGN KEY (subdomain_id) REFERENCES public.psychometric_subdomains(id) ON DELETE SET NULL;


--
-- Name: psychometric_domain_age_band_config psychometric_domain_age_band_config_age_band_id_psychometric_ag; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_domain_age_band_config
    ADD CONSTRAINT psychometric_domain_age_band_config_age_band_id_psychometric_ag FOREIGN KEY (age_band_id) REFERENCES public.psychometric_age_bands(id) ON DELETE CASCADE;


--
-- Name: psychometric_domain_age_band_config psychometric_domain_age_band_config_domain_id_psychometric_doma; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_domain_age_band_config
    ADD CONSTRAINT psychometric_domain_age_band_config_domain_id_psychometric_doma FOREIGN KEY (domain_id) REFERENCES public.psychometric_domains(id) ON DELETE CASCADE;


--
-- Name: psychometric_question_bank psychometric_question_bank_age_band_id_psychometric_age_bands_i; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_question_bank
    ADD CONSTRAINT psychometric_question_bank_age_band_id_psychometric_age_bands_i FOREIGN KEY (age_band_id) REFERENCES public.psychometric_age_bands(id) ON DELETE CASCADE;


--
-- Name: psychometric_question_bank psychometric_question_bank_domain_id_psychometric_domains_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_question_bank
    ADD CONSTRAINT psychometric_question_bank_domain_id_psychometric_domains_id_fk FOREIGN KEY (domain_id) REFERENCES public.psychometric_domains(id) ON DELETE CASCADE;


--
-- Name: psychometric_question_bank psychometric_question_bank_subdomain_id_psychometric_subdomains; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_question_bank
    ADD CONSTRAINT psychometric_question_bank_subdomain_id_psychometric_subdomains FOREIGN KEY (subdomain_id) REFERENCES public.psychometric_subdomains(id) ON DELETE SET NULL;


--
-- Name: psychometric_subdomains psychometric_subdomains_domain_id_psychometric_domains_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychometric_subdomains
    ADD CONSTRAINT psychometric_subdomains_domain_id_psychometric_domains_id_fk FOREIGN KEY (domain_id) REFERENCES public.psychometric_domains(id) ON DELETE CASCADE;


--
-- Name: psychopsis_categories psychopsis_categories_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psychopsis_categories
    ADD CONSTRAINT psychopsis_categories_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: role_competency_weights role_competency_weights_competency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_competency_weights
    ADD CONSTRAINT role_competency_weights_competency_id_fkey FOREIGN KEY (competency_id) REFERENCES public.competencies(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_granted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_granted_by_users_id_fk FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- Name: role_permissions role_permissions_permission_id_permission_definitions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_permission_definitions_id_fk FOREIGN KEY (permission_id) REFERENCES public.permission_definitions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_role_definitions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_role_definitions_id_fk FOREIGN KEY (role_id) REFERENCES public.role_definitions(id) ON DELETE CASCADE;


--
-- Name: sdi_cluster_map sdi_cluster_map_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_cluster_map
    ADD CONSTRAINT sdi_cluster_map_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.sdi_clusters(id) ON DELETE CASCADE;


--
-- Name: sdi_cluster_map sdi_cluster_map_subdomain_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_cluster_map
    ADD CONSTRAINT sdi_cluster_map_subdomain_code_fkey FOREIGN KEY (subdomain_code) REFERENCES public.sdi_subdomains(subdomain_code) ON DELETE CASCADE;


--
-- Name: sdi_item_options sdi_item_options_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_item_options
    ADD CONSTRAINT sdi_item_options_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.sdi_items(id) ON DELETE CASCADE;


--
-- Name: sdi_items sdi_items_subdomain_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_items
    ADD CONSTRAINT sdi_items_subdomain_code_fkey FOREIGN KEY (subdomain_code) REFERENCES public.sdi_subdomains(subdomain_code) ON DELETE CASCADE;


--
-- Name: sdi_learning_mappings sdi_learning_mappings_subdomain_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_learning_mappings
    ADD CONSTRAINT sdi_learning_mappings_subdomain_code_fkey FOREIGN KEY (subdomain_code) REFERENCES public.sdi_subdomains(subdomain_code) ON DELETE CASCADE;


--
-- Name: sdi_stage_weights sdi_stage_weights_subdomain_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_stage_weights
    ADD CONSTRAINT sdi_stage_weights_subdomain_code_fkey FOREIGN KEY (subdomain_code) REFERENCES public.sdi_subdomains(subdomain_code) ON DELETE CASCADE;


--
-- Name: sdi_subdomain_norms sdi_subdomain_norms_subdomain_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_subdomain_norms
    ADD CONSTRAINT sdi_subdomain_norms_subdomain_code_fkey FOREIGN KEY (subdomain_code) REFERENCES public.sdi_subdomains(subdomain_code) ON DELETE CASCADE;


--
-- Name: sdi_subdomains sdi_subdomains_domain_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_subdomains
    ADD CONSTRAINT sdi_subdomains_domain_code_fkey FOREIGN KEY (domain_code) REFERENCES public.sdi_domains(domain_code) ON DELETE CASCADE;


--
-- Name: sdi_user_responses sdi_user_responses_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_user_responses
    ADD CONSTRAINT sdi_user_responses_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.sdi_items(id) ON DELETE CASCADE;


--
-- Name: sdi_user_responses sdi_user_responses_option_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdi_user_responses
    ADD CONSTRAINT sdi_user_responses_option_id_fkey FOREIGN KEY (option_id) REFERENCES public.sdi_item_options(id) ON DELETE SET NULL;


--
-- Name: security_configurations security_configurations_last_modified_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_configurations
    ADD CONSTRAINT security_configurations_last_modified_by_users_id_fk FOREIGN KEY (last_modified_by) REFERENCES public.users(id);


--
-- Name: security_incidents security_incidents_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: security_incidents security_incidents_detected_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_detected_by_users_id_fk FOREIGN KEY (detected_by) REFERENCES public.users(id);


--
-- Name: security_incidents security_incidents_escalated_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_escalated_to_users_id_fk FOREIGN KEY (escalated_to) REFERENCES public.users(id);


--
-- Name: staff_batch_assignments staff_batch_assignments_batch_id_batches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_batch_assignments
    ADD CONSTRAINT staff_batch_assignments_batch_id_batches_id_fk FOREIGN KEY (batch_id) REFERENCES public.batches(id) ON DELETE CASCADE;


--
-- Name: staff_batch_assignments staff_batch_assignments_staff_id_institute_staff_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_batch_assignments
    ADD CONSTRAINT staff_batch_assignments_staff_id_institute_staff_id_fk FOREIGN KEY (staff_id) REFERENCES public.institute_staff(id) ON DELETE CASCADE;


--
-- Name: staff_batch_assignments staff_batch_assignments_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_batch_assignments
    ADD CONSTRAINT staff_batch_assignments_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE SET NULL;


--
-- Name: stage_competency_norms stage_competency_norms_competency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stage_competency_norms
    ADD CONSTRAINT stage_competency_norms_competency_id_fkey FOREIGN KEY (competency_id) REFERENCES public.competencies(id) ON DELETE CASCADE;


--
-- Name: student_assessment_responses student_assessment_responses_question_id_lbi_question_bank_id_f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_assessment_responses
    ADD CONSTRAINT student_assessment_responses_question_id_lbi_question_bank_id_f FOREIGN KEY (question_id) REFERENCES public.lbi_question_bank(id) ON DELETE CASCADE;


--
-- Name: student_assessment_responses student_assessment_responses_session_id_student_assessment_sess; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_assessment_responses
    ADD CONSTRAINT student_assessment_responses_session_id_student_assessment_sess FOREIGN KEY (session_id) REFERENCES public.student_assessment_sessions(id) ON DELETE CASCADE;


--
-- Name: student_assessment_sessions student_assessment_sessions_age_group_id_lbi_age_groups_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_assessment_sessions
    ADD CONSTRAINT student_assessment_sessions_age_group_id_lbi_age_groups_id_fk FOREIGN KEY (age_group_id) REFERENCES public.lbi_age_groups(id) ON DELETE SET NULL;


--
-- Name: student_assessment_sessions student_assessment_sessions_module_id_lbi_modules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_assessment_sessions
    ADD CONSTRAINT student_assessment_sessions_module_id_lbi_modules_id_fk FOREIGN KEY (module_id) REFERENCES public.lbi_modules(id) ON DELETE CASCADE;


--
-- Name: student_bulk_imports student_bulk_imports_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_bulk_imports
    ADD CONSTRAINT student_bulk_imports_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: student_bulk_imports student_bulk_imports_batch_id_batches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_bulk_imports
    ADD CONSTRAINT student_bulk_imports_batch_id_batches_id_fk FOREIGN KEY (batch_id) REFERENCES public.batches(id);


--
-- Name: student_bulk_imports student_bulk_imports_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_bulk_imports
    ADD CONSTRAINT student_bulk_imports_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE CASCADE;


--
-- Name: student_bulk_imports student_bulk_imports_uploaded_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_bulk_imports
    ADD CONSTRAINT student_bulk_imports_uploaded_by_users_id_fk FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: student_competency_scores student_competency_scores_competency_id_competency_library_id_f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_competency_scores
    ADD CONSTRAINT student_competency_scores_competency_id_competency_library_id_f FOREIGN KEY (competency_id) REFERENCES public.competency_library(id) ON DELETE CASCADE;


--
-- Name: student_competency_scores student_competency_scores_session_id_student_assessment_session; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_competency_scores
    ADD CONSTRAINT student_competency_scores_session_id_student_assessment_session FOREIGN KEY (session_id) REFERENCES public.student_assessment_sessions(id) ON DELETE SET NULL;


--
-- Name: student_enrollments student_enrollments_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_enrollments
    ADD CONSTRAINT student_enrollments_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: student_import_records student_import_records_import_id_student_bulk_imports_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_import_records
    ADD CONSTRAINT student_import_records_import_id_student_bulk_imports_id_fk FOREIGN KEY (import_id) REFERENCES public.student_bulk_imports(id) ON DELETE CASCADE;


--
-- Name: student_import_records student_import_records_student_id_students_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_import_records
    ADD CONSTRAINT student_import_records_student_id_students_id_fk FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: student_subscriptions student_subscriptions_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_subscriptions
    ADD CONSTRAINT student_subscriptions_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: student_subscriptions student_subscriptions_package_id_subscription_packages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_subscriptions
    ADD CONSTRAINT student_subscriptions_package_id_subscription_packages_id_fk FOREIGN KEY (package_id) REFERENCES public.subscription_packages(id) ON DELETE RESTRICT;


--
-- Name: student_subscriptions student_subscriptions_student_id_students_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_subscriptions
    ADD CONSTRAINT student_subscriptions_student_id_students_id_fk FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: students students_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE SET NULL;


--
-- Name: students students_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: study_tasks study_tasks_chapter_id_academic_chapters_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.study_tasks
    ADD CONSTRAINT study_tasks_chapter_id_academic_chapters_id_fk FOREIGN KEY (chapter_id) REFERENCES public.academic_chapters(id) ON DELETE SET NULL;


--
-- Name: study_tasks study_tasks_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.study_tasks
    ADD CONSTRAINT study_tasks_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: study_tasks study_tasks_created_by_parent_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.study_tasks
    ADD CONSTRAINT study_tasks_created_by_parent_id_users_id_fk FOREIGN KEY (created_by_parent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: study_tasks study_tasks_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.study_tasks
    ADD CONSTRAINT study_tasks_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE SET NULL;


--
-- Name: study_tasks study_tasks_topic_id_academic_topics_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.study_tasks
    ADD CONSTRAINT study_tasks_topic_id_academic_topics_id_fk FOREIGN KEY (topic_id) REFERENCES public.academic_topics(id) ON DELETE SET NULL;


--
-- Name: supervised_test_sessions supervised_test_sessions_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supervised_test_sessions
    ADD CONSTRAINT supervised_test_sessions_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: supervised_test_sessions supervised_test_sessions_exam_id_child_exams_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supervised_test_sessions
    ADD CONSTRAINT supervised_test_sessions_exam_id_child_exams_id_fk FOREIGN KEY (exam_id) REFERENCES public.child_exams(id) ON DELETE CASCADE;


--
-- Name: supervised_test_sessions supervised_test_sessions_parent_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supervised_test_sessions
    ADD CONSTRAINT supervised_test_sessions_parent_id_users_id_fk FOREIGN KEY (parent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: test_approvals test_approvals_approver_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_approvals
    ADD CONSTRAINT test_approvals_approver_user_id_users_id_fk FOREIGN KEY (approver_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: test_approvals test_approvals_test_id_tests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_approvals
    ADD CONSTRAINT test_approvals_test_id_tests_id_fk FOREIGN KEY (test_id) REFERENCES public.tests(id) ON DELETE CASCADE;


--
-- Name: test_assignments test_assignments_assigned_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_assignments
    ADD CONSTRAINT test_assignments_assigned_by_users_id_fk FOREIGN KEY (assigned_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: test_assignments test_assignments_batch_id_batches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_assignments
    ADD CONSTRAINT test_assignments_batch_id_batches_id_fk FOREIGN KEY (batch_id) REFERENCES public.batches(id) ON DELETE CASCADE;


--
-- Name: test_assignments test_assignments_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_assignments
    ADD CONSTRAINT test_assignments_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: test_assignments test_assignments_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_assignments
    ADD CONSTRAINT test_assignments_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE CASCADE;


--
-- Name: test_assignments test_assignments_test_id_tests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_assignments
    ADD CONSTRAINT test_assignments_test_id_tests_id_fk FOREIGN KEY (test_id) REFERENCES public.tests(id) ON DELETE CASCADE;


--
-- Name: test_attempts test_attempts_assignment_id_test_assignments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_attempts
    ADD CONSTRAINT test_attempts_assignment_id_test_assignments_id_fk FOREIGN KEY (assignment_id) REFERENCES public.test_assignments(id) ON DELETE SET NULL;


--
-- Name: test_attempts test_attempts_child_id_children_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_attempts
    ADD CONSTRAINT test_attempts_child_id_children_id_fk FOREIGN KEY (child_id) REFERENCES public.children(id) ON DELETE CASCADE;


--
-- Name: test_attempts test_attempts_test_id_tests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_attempts
    ADD CONSTRAINT test_attempts_test_id_tests_id_fk FOREIGN KEY (test_id) REFERENCES public.tests(id) ON DELETE CASCADE;


--
-- Name: test_blueprints test_blueprints_board_id_education_boards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_blueprints
    ADD CONSTRAINT test_blueprints_board_id_education_boards_id_fk FOREIGN KEY (board_id) REFERENCES public.education_boards(id) ON DELETE SET NULL;


--
-- Name: test_blueprints test_blueprints_chapter_id_academic_chapters_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_blueprints
    ADD CONSTRAINT test_blueprints_chapter_id_academic_chapters_id_fk FOREIGN KEY (chapter_id) REFERENCES public.academic_chapters(id) ON DELETE SET NULL;


--
-- Name: test_blueprints test_blueprints_class_id_academic_classes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_blueprints
    ADD CONSTRAINT test_blueprints_class_id_academic_classes_id_fk FOREIGN KEY (class_id) REFERENCES public.academic_classes(id) ON DELETE SET NULL;


--
-- Name: test_blueprints test_blueprints_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_blueprints
    ADD CONSTRAINT test_blueprints_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: test_blueprints test_blueprints_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_blueprints
    ADD CONSTRAINT test_blueprints_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE SET NULL;


--
-- Name: test_blueprints test_blueprints_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_blueprints
    ADD CONSTRAINT test_blueprints_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE SET NULL;


--
-- Name: test_question_bank test_question_bank_board_id_education_boards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_question_bank
    ADD CONSTRAINT test_question_bank_board_id_education_boards_id_fk FOREIGN KEY (board_id) REFERENCES public.education_boards(id) ON DELETE SET NULL;


--
-- Name: test_question_bank test_question_bank_chapter_id_academic_chapters_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_question_bank
    ADD CONSTRAINT test_question_bank_chapter_id_academic_chapters_id_fk FOREIGN KEY (chapter_id) REFERENCES public.academic_chapters(id) ON DELETE SET NULL;


--
-- Name: test_question_bank test_question_bank_class_id_academic_classes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_question_bank
    ADD CONSTRAINT test_question_bank_class_id_academic_classes_id_fk FOREIGN KEY (class_id) REFERENCES public.academic_classes(id) ON DELETE SET NULL;


--
-- Name: test_question_bank test_question_bank_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_question_bank
    ADD CONSTRAINT test_question_bank_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: test_question_bank test_question_bank_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_question_bank
    ADD CONSTRAINT test_question_bank_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE SET NULL;


--
-- Name: test_question_bank test_question_bank_psychopsis_sub_module_id_lbi_sub_modules_id_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_question_bank
    ADD CONSTRAINT test_question_bank_psychopsis_sub_module_id_lbi_sub_modules_id_ FOREIGN KEY (psychopsis_sub_module_id) REFERENCES public.lbi_sub_modules(id) ON DELETE SET NULL;


--
-- Name: test_question_bank test_question_bank_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_question_bank
    ADD CONSTRAINT test_question_bank_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE SET NULL;


--
-- Name: test_question_bank test_question_bank_topic_id_academic_topics_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_question_bank
    ADD CONSTRAINT test_question_bank_topic_id_academic_topics_id_fk FOREIGN KEY (topic_id) REFERENCES public.academic_topics(id) ON DELETE SET NULL;


--
-- Name: test_questions test_questions_question_bank_id_test_question_bank_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_questions
    ADD CONSTRAINT test_questions_question_bank_id_test_question_bank_id_fk FOREIGN KEY (question_bank_id) REFERENCES public.test_question_bank(id) ON DELETE SET NULL;


--
-- Name: test_questions test_questions_test_id_tests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_questions
    ADD CONSTRAINT test_questions_test_id_tests_id_fk FOREIGN KEY (test_id) REFERENCES public.tests(id) ON DELETE CASCADE;


--
-- Name: test_responses test_responses_attempt_id_test_attempts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_responses
    ADD CONSTRAINT test_responses_attempt_id_test_attempts_id_fk FOREIGN KEY (attempt_id) REFERENCES public.test_attempts(id) ON DELETE CASCADE;


--
-- Name: test_responses test_responses_question_id_test_questions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_responses
    ADD CONSTRAINT test_responses_question_id_test_questions_id_fk FOREIGN KEY (question_id) REFERENCES public.test_questions(id) ON DELETE CASCADE;


--
-- Name: test_workflow_history test_workflow_history_action_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_workflow_history
    ADD CONSTRAINT test_workflow_history_action_by_users_id_fk FOREIGN KEY (action_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: test_workflow_history test_workflow_history_test_id_tests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_workflow_history
    ADD CONSTRAINT test_workflow_history_test_id_tests_id_fk FOREIGN KEY (test_id) REFERENCES public.tests(id) ON DELETE CASCADE;


--
-- Name: tests tests_blueprint_id_test_blueprints_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_blueprint_id_test_blueprints_id_fk FOREIGN KEY (blueprint_id) REFERENCES public.test_blueprints(id) ON DELETE SET NULL;


--
-- Name: tests tests_board_id_education_boards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_board_id_education_boards_id_fk FOREIGN KEY (board_id) REFERENCES public.education_boards(id) ON DELETE SET NULL;


--
-- Name: tests tests_chapter_id_academic_chapters_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_chapter_id_academic_chapters_id_fk FOREIGN KEY (chapter_id) REFERENCES public.academic_chapters(id) ON DELETE SET NULL;


--
-- Name: tests tests_class_id_academic_classes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_class_id_academic_classes_id_fk FOREIGN KEY (class_id) REFERENCES public.academic_classes(id) ON DELETE SET NULL;


--
-- Name: tests tests_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tests tests_institute_id_institutes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_institute_id_institutes_id_fk FOREIGN KEY (institute_id) REFERENCES public.institutes(id) ON DELETE SET NULL;


--
-- Name: tests tests_subject_id_academic_subjects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_subject_id_academic_subjects_id_fk FOREIGN KEY (subject_id) REFERENCES public.academic_subjects(id) ON DELETE SET NULL;


--
-- Name: training_enrollments training_enrollments_mentor_id_mentors_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_enrollments
    ADD CONSTRAINT training_enrollments_mentor_id_mentors_id_fk FOREIGN KEY (mentor_id) REFERENCES public.mentors(id) ON DELETE CASCADE;


--
-- Name: training_enrollments training_enrollments_program_id_training_programs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_enrollments
    ADD CONSTRAINT training_enrollments_program_id_training_programs_id_fk FOREIGN KEY (program_id) REFERENCES public.training_programs(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 0DFc4WoRxM7Bg2GErawB9MSBaTnMmSzRORbPEPTUjqeqeGWw6391ePcgbh2MJzh

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 64mwX4INWOH6suCZ3wlUcG9HYXIWyAXzpaGQkAe3l97iSvaIxXkog3YDXML5jru

-- Dumped from database version 15.16 (Debian 15.16-0+deb12u1)
-- Dumped by pg_dump version 15.16 (Debian 15.16-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 64mwX4INWOH6suCZ3wlUcG9HYXIWyAXzpaGQkAe3l97iSvaIxXkog3YDXML5jru

--
-- PostgreSQL database cluster dump complete
--

